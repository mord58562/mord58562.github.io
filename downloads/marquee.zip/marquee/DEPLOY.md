# Deploying Marquee

## Local dev

```
npm run setup       # one-shot: deps, .dev.vars, all migrations, smoke check
npm run dev
```

`setup` will prompt for `TMDB_BEARER` and `TRAKT_CLIENT_ID` if they aren't
already in `.dev.vars`. `MDBLIST_KEY` is optional - skip it to disable the
Beloved bombs row.

Then either paste `http://127.0.0.1:8787/manifest.json` into Stremio's add-on
search, or open `http://127.0.0.1:8787/` in a browser and click "Add to
Stremio".

## Production (Cloudflare Workers)

```
npx wrangler login
npx wrangler d1 create marquee
# copy the returned database_id into wrangler.toml [[d1_databases]] block
for m in migrations/*.sql; do
  npx wrangler d1 execute marquee --file="$m" --remote
done
npx wrangler secret put TMDB_BEARER
npx wrangler secret put TRAKT_CLIENT_ID        # public read-only key, no OAuth
npx wrangler secret put MDBLIST_KEY            # optional, enables Beloved bombs
npx wrangler deploy
```

All API keys above are **operator-side**: the person hosting Marquee provides
them once at deploy time. End users never see or supply any credential - they
just paste the public manifest URL into Stremio.

The deploy URL prints as `https://marquee.<your-subdomain>.workers.dev`. Test:

- `GET https://marquee.<sub>.workers.dev/manifest.json` returns the anonymous manifest.
- `GET https://marquee.<sub>.workers.dev/configure` mints a user and redirects to a sticky settings URL.

Optional: bind a real domain via Cloudflare → Workers Routes.

## Public registry submission

Once the deploy URL is stable and you've smoke-tested install on a real Stremio client:

1. **stremio-addons.net** - submit at <https://stremio-addons.net/submit-addon> with the manifest URL. Approval is typically reviewed within a few days.
2. **stremio-addons.com** - submit via the linked form on <https://stremio-addons.com/submit>.
3. **awesome-stremio lists** - open PRs against curated addon lists on GitHub (search GitHub for `awesome-stremio`).

Pre-submission checklist:

- [ ] `GET https://<host>/manifest.json` returns valid JSON in under 500ms.
- [ ] At least one anonymous catalog row returns non-empty results in under 2s cold.
- [ ] `behaviorHints.configurable: true` and `configurationRequired: false`.
- [ ] Logo and background URLs resolve.
- [ ] `contactEmail` field is set.
- [ ] No real-name or PII anywhere in source or response payloads.
- [ ] Uninstall+reinstall cleanly on at least one TV client (Android TV or webOS).

Marquee's manifest already advertises `behaviorHints.configurable: true` and `configurationRequired: false`, so it works for anonymous installs out of the box; Configure is an opt-in personalization path.

## Migrations after first deploy

Every new SQL file in `migrations/` must be applied with `--remote` to the production D1:

```
npx wrangler d1 execute marquee --file=migrations/000N_xxx.sql --remote
```

## Cost estimate (Cloudflare Workers free tier)

- 100k requests/day free, then $5/10M
- D1: 100k reads/day, 50k writes/day free
- 1M KV reads/day free if/when KV is added

A Marquee instance with a few hundred users and normal Stremio usage fits comfortably in the free tier.
