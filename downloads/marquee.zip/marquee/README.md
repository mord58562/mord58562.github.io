# Marquee

A Stremio add-on that replaces the homepage with curated catalog rows that
adapt to what you watch. Every detail-page open and play press is recorded
to a per-user attention rollup; ranking shifts on the next refresh.

Plays nicely with the rest of the Stremio ecosystem: Marquee never competes
for detail-page rendering (Cinemeta keeps that) and never appears on the
source-selection screen (Torrentio / Real-Debrid / etc. populate Play as
normal). Marquee's only custom surface is the homepage row presentation and
its `/configure` settings panel.

## Install

Paste the manifest URL into Stremio's add-on search on any device. No API
keys or accounts required by end users. Optional personalisation:

- **Stremio library** - one QR scan from a phone via `link.stremio.com`.
- **Letterboxd username** - one field, public RSS only.
- **Last.fm username** - public scrobbles nudge the Tonight mood.

Once submitted to the public Stremio add-on registry, install is a single
URL paste in the Stremio add-on search.

## Status

v0.9.1 - local development, registry-ready manifest. See `DEPLOY.md` for
production deployment to Cloudflare Workers.

### What's new in 0.9.1

- Anime row now emits `kitsu:` ids instead of `tt:`, so Torrentio, Comet,
  Knightcrawler, and TorBox return full anime stream lists for tiles in
  "Anime worth watching". Configure page nudges anime users to install the
  Anime Kitsu addon for kitsu: metadata.
- Manifest `idPrefixes` widened to `["tt", "kitsu:"]` so Marquee still
  receives the engagement signal for anime tiles. `/stream/` is still a
  hardcoded `{streams: []}` no-op for both prefixes - source-selection
  posture is unchanged.
- Spy x Family IMDb id corrected from `tt0944947` (Game of Thrones) to
  `tt12343534`. Anime row never displayed the wrong title because tiles
  are emitted with the curated title field, but the underlying id is now
  right for any future Cinemeta fallback.
- Install landing page now names the supported stream-addon set
  (Torrentio, Comet, MediaFusion, TorBox, Knightcrawler, Easynews,
  Jackettio) and gives the one-line AIOStreams coexistence tip.
- `tests/harmony.test.ts` locks in the debrid-coexistence contract:
  manifest must not advertise `meta`, `stream` stays a no-op, no catalog
  declares a `search` extra, every anime entry carries a unique kitsu id
  that folds back onto its IMDb keyspace.

### What's new in 0.9

- Tile names render on every row. Previously `awards`, `adapted`,
  `watchlist-intent`, and `continue-watching` returned `name: ""` and showed
  up as blank tiles in some Stremio clients. Title is now cached alongside
  year + rating in `title_cache` (migration 0008) and read by every row.
- Real install landing page at `/`. Opening the Worker URL in a browser
  now shows an "Add to Stremio" button, the manifest URL, a /configure
  link, and the row lineup - not a GitHub redirect.
- TV handoff page now includes a scannable QR pointing at /configure on
  the user's phone, so they don't have to type the URL.
- One-shot local setup: `npm run setup` installs deps, prompts for any
  missing secrets, applies every migration, runs typecheck + tests, and
  prints the install URL.
- Configure footer pulls version from `env.ADDON_VERSION` instead of a
  stale hardcoded "v0.1".
- Cheaper engagement tracking: `recordRowSample` now uses one D1 batch
  call instead of one round-trip per ID (12x fewer queries per catalog
  hit).
- Profile refresh trimmed - dropped a redundant `await` on
  `watchlistIntentIds` (the result was discarded).

### What's new in 0.5

- Richer catalog tiles. Every MetaPreview returned by Marquee now carries
  `imdbRating` and `releaseInfo` (visible as star / year badges on tile),
  plus a per-row `description` rationale:
  - Award winners: "Palme d'Or · Oscar - Best Picture"
  - Essentials: "Sight & Sound · NYT 21st century · Letterboxd top 250"
  - Beloved bombs: "92% critics · 2.8/5 audience"
  - On your mind: "You've opened this 4× without pressing Play"
  - Continue: "47% through"
  - Like what you've watched: "Because you watch drama"
  - Your decade: "From the 1970s"
  - Outside your usual: "Outside your usual"
  - Lesser-known: "1,240 votes"
  - Adapted from books: "Based on a book"
  - Anime: "AniList top-rated"
- Cinemeta still owns detail-page rendering; we no longer compete for it.
  Marquee's `meta` resource is dropped from the manifest entirely.
- `stream` stays a legal no-op so Torrentio, Real-Debrid, and every other
  stream add-on populate the source-selection screen unchanged.

### What's new in 0.4

- End users supply zero API keys. MDBList moved to operator-side Worker
  secret. Anime opt-in. Banned word swept from code and docs.

### What's new in 0.3

- Eight new rows: On your mind, Continue, Award winners (Wikidata SPARQL),
  Essentials (Sight & Sound + NYT + Letterboxd top), Critics this week
  (Guardian / IndieWire / NYT RSS), Beloved bombs (MDBList critic-vs-audience
  divergence), Adapted from books, Anime worth watching (AniList, opt-in).
- MDBList aggregate ratings (RT + Metacritic + Letterboxd avg + IMDb +
  TMDB + Trakt + Roger Ebert) per title - operator-side key only.
- Last.fm public scrobbles silently nudge the Tonight mood.
- Wikidata SPARQL - Palme d'Or, Oscar Best Picture, BAFTA Best Film as a
  unified award row, plus "Adapted from books" via P144 lookups.
- IMDb Bayesian shrinkage + daily-rotation epsilon for stable-but-fresh
  ranking across every row.
- Borda-count multi-source blender in scoring helpers.
- Workers Cron Trigger pre-warms profile + Letterboxd diary every 6h.
- Perf: meta/stream handlers return immediately, D1 writes deferred via
  ctx.waitUntil. Context derivation bounded to 300ms. Stremio homepage is
  never noticeably slowed by Marquee.

## Install (local dev)

```
git clone https://github.com/mord58562/marquee && cd marquee
npm run setup       # prompts for any missing secrets, applies migrations
npm run dev
```

Then in Stremio: paste `http://127.0.0.1:8787/manifest.json` into the addons
search, or open `stremio://127.0.0.1:8787/manifest.json`. Or open
`http://127.0.0.1:8787/` in a browser and click "Add to Stremio".

## Row lineup

Anonymous-friendly (work from first install, no signal required):

1. **Tonight** - one editorial pick keyed on mood, weather, and time-of-day.
2. **Under 95 minutes** - well-rated, short.
3. **Limited series** - high-rated finite series.
4. **Recent** - last 18 months, well-rated.
5. **Lesser-known** - anti-popularity long tail.
6. **Award winners** - Wikidata-sourced Palme d'Or / Oscar / BAFTA winners.
7. **Essentials** - broadly loved films, watched-suppressed.
8. **Critics this week** - Guardian / IndieWire / NYT review feeds.
9. **Beloved bombs** - high critic / low audience divergence (requires MDBList).
10. **Adapted from books** - Wikidata P144 lookups.

Adaptive (light up as attention signal accumulates):

11. **Like what you've watched** - profile-aware recommendations.
12. **Your decade** - era-pinned to your most-watched decade.
13. **Less typical for you** - inverse of your top genres.
14. **On your mind** - titles you keep opening without pressing Play.
15. **Continue** - in-flight watches from your Stremio library.

Opt-in:

16. **Anime worth watching** - AniList top-rated; off by default.

## Architecture

- TypeScript on Cloudflare Workers, no SDK, hand-rolled HTTP handlers.
- Data: TMDB, MDBList, Wikidata, AniList, Letterboxd RSS, Last.fm RSS,
  Open-Meteo, date.nager.at, Stremio `link.stremio.com` + `api.strem.io`.
- D1 (SQLite) for per-user attention rollups + meta cache.
- No paid runtime APIs.

## License

MIT.
