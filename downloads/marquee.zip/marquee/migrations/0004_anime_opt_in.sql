-- Anime-related rows are opt-in. Default 0; user toggles on in /configure.
ALTER TABLE users ADD COLUMN show_anime INTEGER NOT NULL DEFAULT 0;
