-- Per-user row engagement, written by the meta/stream handlers and read by
-- the manifest builder to reorder catalogs[] so the rows the user actually
-- engages with sit near the top.
--
-- Score is a recency-decayed count of meta/stream events whose IMDb ID was
-- recently surfaced by a given row. We don't track which row the user came
-- from (Stremio doesn't tell us); instead we credit any row that surfaced
-- the ID in the last few days, proportionally split across them.

CREATE TABLE IF NOT EXISTS row_engagement (
  user_id TEXT NOT NULL,
  row_id TEXT NOT NULL,
  score REAL NOT NULL DEFAULT 0,
  last_seen INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, row_id)
);

-- Compact "recently surfaced by this row for this user" index, capped at a
-- small number of entries per (user, row). On meta/stream events the
-- handler scans this table to find which rows recently included the ID.
CREATE TABLE IF NOT EXISTS row_recent (
  user_id TEXT NOT NULL,
  row_id TEXT NOT NULL,
  imdb_id TEXT NOT NULL,
  ts INTEGER NOT NULL,
  PRIMARY KEY (user_id, row_id, imdb_id)
);
CREATE INDEX IF NOT EXISTS row_recent_by_imdb ON row_recent(user_id, imdb_id);
CREATE INDEX IF NOT EXISTS row_recent_by_ts ON row_recent(user_id, ts);
