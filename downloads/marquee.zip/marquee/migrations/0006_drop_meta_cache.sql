-- Migration 0006: drop the unused meta_cache table.
--
-- meta_cache was created in 0005 as part of the brief Cinemeta-replacement
-- detour. We never shipped a `/meta` endpoint, so the table is dead. title_awards
-- (also from 0005) IS used by the cron + awards row, so it stays.

DROP TABLE IF EXISTS meta_cache;
