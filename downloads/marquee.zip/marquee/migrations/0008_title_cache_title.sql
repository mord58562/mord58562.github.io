-- v0.9: store the display title in title_cache so rows that previously
-- returned name:"" (awards, adapted, watchlist-intent, continue-watching)
-- can hydrate tile names directly from the cron-warmed cache.
ALTER TABLE title_cache ADD COLUMN title TEXT;
