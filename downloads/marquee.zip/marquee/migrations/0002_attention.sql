-- Migration 0002: richer attention monitoring.
--
-- The first schema captured each meta/stream event as a single row with only
-- (user_id, imdb_id, kind, type, ts). That's history. To monitor attention we
-- need richer per-event context and per-(user, title) aggregate state.
--
-- Two changes:
--   1) Widen `events` with session_id, hour_local, day_of_week, prior_event_id
--      to support session clustering and sequence-transition analysis.
--   2) Add `attention` - a per-(user, title) rollup that turns the event stream
--      into the features we actually score against: meta_count, stream_count,
--      last_meta_ts, last_stream_ts, days_since_first_seen, abandoned flag.

ALTER TABLE events ADD COLUMN session_id INTEGER;
ALTER TABLE events ADD COLUMN hour_local INTEGER;       -- 0-23, derived best-effort
ALTER TABLE events ADD COLUMN day_of_week INTEGER;      -- 0=Sunday
ALTER TABLE events ADD COLUMN prior_event_id INTEGER;   -- preceding event in same session, for sequence transitions
ALTER TABLE events ADD COLUMN extra_json TEXT;          -- catch-all: source row id, completion ratio if we know it, etc.

CREATE INDEX IF NOT EXISTS events_user_session ON events(user_id, session_id);

CREATE TABLE IF NOT EXISTS attention (
  user_id TEXT NOT NULL,
  imdb_id TEXT NOT NULL,
  meta_count INTEGER NOT NULL DEFAULT 0,         -- detail-page opens
  stream_count INTEGER NOT NULL DEFAULT 0,       -- play presses
  library_seen INTEGER NOT NULL DEFAULT 0,       -- present in api.strem.io library
  completion_ratio REAL,                         -- 0..1 from library timeOffset/duration, or null
  first_seen_ts INTEGER NOT NULL,
  last_meta_ts INTEGER,
  last_stream_ts INTEGER,
  PRIMARY KEY (user_id, imdb_id)
);
CREATE INDEX IF NOT EXISTS attention_user_last ON attention(user_id, last_stream_ts DESC, last_meta_ts DESC);

-- Per-user time-of-day genre distribution for the Tonight row.
CREATE TABLE IF NOT EXISTS attention_temporal (
  user_id TEXT NOT NULL,
  hour_bucket INTEGER NOT NULL,                  -- 0=morning(5-11), 1=afternoon(12-17), 2=evening(18-22), 3=late(23-04)
  genre TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, hour_bucket, genre)
);

-- Session-to-session transitions for "if X then Y" sequence inference.
CREATE TABLE IF NOT EXISTS attention_sequence (
  user_id TEXT NOT NULL,
  from_imdb TEXT NOT NULL,
  to_imdb TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, from_imdb, to_imdb)
);
