-- Marquee D1 schema.
-- All credentials stored here are AES-GCM ciphertext blobs sealed by a Worker
-- secret. Plaintext credentials never appear in any column.

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,                  -- 22-char base64url, opaque, in the URL
  created_at INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  faves_json TEXT,                      -- ["tt0111161", ...] up to 5
  mood TEXT,                            -- 'quiet' | 'fun' | 'intense' | 'curious' | 'comfort' | NULL
  letterboxd TEXT,                      -- public username, no auth
  trakt_enc TEXT,                       -- AES-GCM ciphertext, or NULL
  stremio_enc TEXT                      -- AES-GCM ciphertext, or NULL
);

-- The implicit-signal log. Every meta/{id} or stream/{id} request from Stremio
-- on this user's install URL writes one row here. This is the continuous-watch
-- signal that drives profile derivation.
CREATE TABLE IF NOT EXISTS events (
  user_id TEXT NOT NULL,
  imdb_id TEXT NOT NULL,
  kind TEXT NOT NULL,                   -- 'meta' (opened detail page) or 'stream' (pressed Play)
  type TEXT NOT NULL,                   -- 'movie' | 'series'
  ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS events_user_ts ON events(user_id, ts DESC);
CREATE INDEX IF NOT EXISTS events_user_imdb ON events(user_id, imdb_id);

-- Per-title metadata cache (TMDB enrichment for profile derivation).
-- We resolve IMDb -> TMDB once per title, then keep the fields we care about.
CREATE TABLE IF NOT EXISTS title_cache (
  imdb_id TEXT PRIMARY KEY,
  tmdb_id INTEGER,
  type TEXT,
  genres_json TEXT,                     -- ["Drama", "Thriller"]
  year INTEGER,
  director TEXT,
  original_language TEXT,
  vote_count INTEGER,
  vote_average REAL,
  refreshed_at INTEGER
);

-- Derived taste profile, refreshed lazily off the event stream.
CREATE TABLE IF NOT EXISTS profile (
  user_id TEXT PRIMARY KEY,
  top_genres_json TEXT,                 -- [["Drama", 0.41], ...]
  top_decades_json TEXT,
  top_directors_json TEXT,
  top_languages_json TEXT,
  watched_set_json TEXT,                -- ["tt0111161", ...] full set for exclusion
  total_events INTEGER,
  derived_at INTEGER
);
