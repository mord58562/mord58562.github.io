-- v0.3 schema additions.
--
-- New per-user fields for external integrations. Tokens stored here are
-- always AES-GCM ciphertext sealed by the CONFIG_AES_KEY worker secret.

ALTER TABLE users ADD COLUMN lastfm TEXT;                       -- public Last.fm username (no auth)
ALTER TABLE users ADD COLUMN mdblist_enc TEXT;                  -- AES-GCM ciphertext, optional
ALTER TABLE users ADD COLUMN trakt_refresh_enc TEXT;            -- AES-GCM ciphertext refresh token
ALTER TABLE users ADD COLUMN trakt_access_enc TEXT;             -- AES-GCM ciphertext short-lived access
ALTER TABLE users ADD COLUMN trakt_access_exp INTEGER;          -- ms epoch
ALTER TABLE users ADD COLUMN tz TEXT;                           -- IANA timezone hint, derived from cf

-- Cached lists imported from external sources (Letterboxd, Trakt, MDBList).
CREATE TABLE IF NOT EXISTS imported_lists (
  user_id TEXT NOT NULL,
  source TEXT NOT NULL,          -- 'letterboxd' | 'trakt' | 'mdblist'
  list_key TEXT NOT NULL,        -- source-specific (slug, url, id)
  imdb_id TEXT NOT NULL,
  rank INTEGER,                  -- ordinal within the source list
  user_rating REAL,              -- e.g. Letterboxd member rating if applicable
  imported_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, source, list_key, imdb_id)
);
CREATE INDEX IF NOT EXISTS imported_lists_lookup ON imported_lists(user_id, source);

-- Persistent ranking lift from "external curators" - single row per (user, imdb)
-- aggregating Letterboxd diary ratings + Trakt history watches + MDBList likes.
CREATE TABLE IF NOT EXISTS external_signal (
  user_id TEXT NOT NULL,
  imdb_id TEXT NOT NULL,
  positive REAL NOT NULL DEFAULT 0,    -- sum of weights from sources that say "you like this"
  negative REAL NOT NULL DEFAULT 0,    -- sum of weights from sources that say "you didn't"
  sources_json TEXT,                   -- ["letterboxd","trakt",...]
  PRIMARY KEY (user_id, imdb_id)
);
