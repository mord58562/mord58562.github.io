-- v0.5: per-title meta cache. Stores the full Stremio Meta object we've
-- built from TMDB + MDBList + Wikidata so subsequent meta requests skip
-- the network round-trips entirely.

CREATE TABLE IF NOT EXISTS meta_cache (
  imdb_id TEXT NOT NULL,
  type TEXT NOT NULL,                   -- 'movie' | 'series'
  meta_json TEXT NOT NULL,              -- serialised Stremio Meta object
  refreshed_at INTEGER NOT NULL,        -- ms epoch
  PRIMARY KEY (imdb_id, type)
);
CREATE INDEX IF NOT EXISTS meta_cache_refreshed ON meta_cache(refreshed_at);

-- Per-award index over tt-ids, written by the Wikidata cron job. Lets us
-- annotate a Meta with "Palme d'Or 2024" without re-running SPARQL.
CREATE TABLE IF NOT EXISTS title_awards (
  imdb_id TEXT NOT NULL,
  award TEXT NOT NULL,                  -- e.g. 'palme_dor', 'oscar_best_picture'
  year INTEGER,
  PRIMARY KEY (imdb_id, award)
);
CREATE INDEX IF NOT EXISTS title_awards_lookup ON title_awards(imdb_id);
