import type { Env, MetaPreview, StremioType } from "./types.js";

import { fetchWithBackoff, tmdbLimiter } from "./limiter.js";

const TMDB = "https://api.themoviedb.org/3";

interface TMDBDiscoverItem {
  id: number;
  title?: string;
  name?: string;
  poster_path: string | null;
  backdrop_path: string | null;
  overview: string;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  vote_count?: number;
  genre_ids: number[];
}

interface TMDBDiscoverResponse {
  results: TMDBDiscoverItem[];
}

interface TMDBExternalIds {
  imdb_id: string | null;
}

// Discover responses are deterministic per-query and change slowly, so a
// cross-isolate KV cache pays for itself even at modest user counts. Per-title
// fetches (external_ids, credits) bypass cache because they're already cheap
// and the response varies per ID.
const DISCOVER_TTL_S = 6 * 3600;
const CACHEABLE_PATHS = ["/discover/", "/find/"];

async function tmdbFetch<T>(env: Env, path: string, query: Record<string, string | number | undefined> = {}): Promise<T> {
  const url = new URL(TMDB + path);
  for (const [k, v] of Object.entries(query)) {
    if (v !== undefined) url.searchParams.set(k, String(v));
  }
  const cacheable = env.CACHE && CACHEABLE_PATHS.some((p) => path.startsWith(p));
  if (cacheable) {
    const cacheKey = `tmdb:${path}?${url.searchParams.toString()}`;
    try {
      const hit = await env.CACHE!.get(cacheKey, "json");
      if (hit !== null) return hit as T;
    } catch { /* ignore cache read failures */ }
  }
  return tmdbLimiter.run(async () => {
    const res = await fetchWithBackoff(url, {
      headers: {
        Authorization: `Bearer ${env.TMDB_BEARER}`,
        Accept: "application/json",
      },
    });
    if (!res.ok) throw new Error(`tmdb ${path} -> ${res.status}`);
    const data = (await res.json()) as T;
    if (cacheable) {
      const cacheKey = `tmdb:${path}?${url.searchParams.toString()}`;
      // Await the put so subsequent requests within the same isolate-burst
      // see the cached value. KV writes are fast in local dev (in-memory)
      // and ~5ms at the edge; cost is acceptable for the consistency.
      await env.CACHE!.put(cacheKey, JSON.stringify(data), { expirationTtl: DISCOVER_TTL_S }).catch(() => {});
    }
    return data;
  });
}

export interface DiscoverOpts {
  type: StremioType;
  sortBy?: string;
  voteCountGte?: number;
  voteCountLte?: number;
  voteAverageGte?: number;
  runtimeLte?: number;
  runtimeGte?: number;
  releaseFromYear?: number;
  releaseToYear?: number;
  releaseFromDate?: string;
  releaseToDate?: string;
  withKeywords?: string;
  withGenres?: string;
  withoutGenres?: string;
  withOriginalLanguage?: string;
  withoutKeywords?: string;
  page?: number;
}

export async function discover(env: Env, opts: DiscoverOpts): Promise<TMDBDiscoverItem[]> {
  const path = opts.type === "movie" ? "/discover/movie" : "/discover/tv";
  const q: Record<string, string | number | undefined> = {
    sort_by: opts.sortBy ?? "vote_average.desc",
    "vote_count.gte": opts.voteCountGte ?? 500,
    "vote_count.lte": opts.voteCountLte,
    "vote_average.gte": opts.voteAverageGte,
    with_keywords: opts.withKeywords,
    without_keywords: opts.withoutKeywords,
    with_genres: opts.withGenres,
    without_genres: opts.withoutGenres,
    with_original_language: opts.withOriginalLanguage,
    page: opts.page ?? 1,
    include_adult: "false",
  };
  const fromDate = opts.releaseFromDate ?? (opts.releaseFromYear ? `${opts.releaseFromYear}-01-01` : undefined);
  // Universal cap: never show films/series with release dates in the future.
  // Without this TMDB's high-rated set leaks pre-release titles into present
  // rows ("8.6 average with 890 votes" on a film that isn't out yet).
  const today = new Date().toISOString().slice(0, 10);
  const explicitTo = opts.releaseToDate ?? (opts.releaseToYear ? `${opts.releaseToYear}-12-31` : undefined);
  const toDate = explicitTo && explicitTo < today ? explicitTo : today;
  if (opts.type === "movie") {
    q["with_runtime.lte"] = opts.runtimeLte;
    q["with_runtime.gte"] = opts.runtimeGte;
    q["primary_release_date.gte"] = fromDate;
    q["primary_release_date.lte"] = toDate;
  } else {
    q["first_air_date.gte"] = fromDate;
    q["first_air_date.lte"] = toDate;
  }
  const data = await tmdbFetch<TMDBDiscoverResponse>(env, path, q);
  return data.results ?? [];
}

const imdbIdCache = new Map<string, string | null>();

export async function tmdbToImdb(env: Env, type: StremioType, tmdbId: number): Promise<string | null> {
  const key = `${type}:${tmdbId}`;
  if (imdbIdCache.has(key)) return imdbIdCache.get(key)!;
  const path = type === "movie" ? `/movie/${tmdbId}/external_ids` : `/tv/${tmdbId}/external_ids`;
  try {
    const data = await tmdbFetch<TMDBExternalIds>(env, path);
    const imdb = data.imdb_id && data.imdb_id.startsWith("tt") ? data.imdb_id : null;
    imdbIdCache.set(key, imdb);
    return imdb;
  } catch {
    imdbIdCache.set(key, null);
    return null;
  }
}

export async function discoverAsImdbMetas(env: Env, type: StremioType, opts: DiscoverOpts): Promise<MetaPreview[]> {
  const items = await discover(env, opts);
  const mapped = await Promise.all(
    items.map(async (it) => {
      const imdb = await tmdbToImdb(env, type, it.id);
      if (!imdb) return null;
      const meta: MetaPreview = {
        id: imdb,
        type,
        name: it.title ?? it.name ?? "Untitled",
      };
      return meta;
    }),
  );
  return mapped.filter((m): m is MetaPreview => m !== null);
}

// Variant that also returns the raw TMDB fields needed for downstream scoring.
// We can't surface this richer object as a MetaPreview (Stremio doesn't accept
// extra fields on Meta Previews - they get dropped silently), so we keep two
// variants: discoverAsImdbMetas for the catalog response, and discoverWithStats
// for ranking decisions before slicing to the final 100.
export interface RankableMeta extends MetaPreview {
  voteAverage: number;
  voteCount: number;
  releaseYear?: number;
  genreIds?: number[];
}

export async function discoverWithStats(env: Env, type: StremioType, opts: DiscoverOpts): Promise<RankableMeta[]> {
  const items = await discover(env, opts);
  const mapped: (RankableMeta | null)[] = await Promise.all(
    items.map(async (it): Promise<RankableMeta | null> => {
      const imdb = await tmdbToImdb(env, type, it.id);
      if (!imdb) return null;
      const dateStr = it.release_date ?? it.first_air_date ?? "";
      const out: RankableMeta = {
        id: imdb,
        type,
        name: it.title ?? it.name ?? "Untitled",
        voteAverage: it.vote_average ?? 0,
        voteCount: it.vote_count ?? 0,
      };
      if (dateStr) out.releaseYear = Number(dateStr.slice(0, 4));
      if (it.genre_ids && it.genre_ids.length) out.genreIds = it.genre_ids.slice();
      return out;
    }),
  );
  return mapped.filter((m): m is RankableMeta => m !== null);
}
