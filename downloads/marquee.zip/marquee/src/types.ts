export type StremioType = "movie" | "series";

export interface Env {
  // Operator-side secrets (the person hosting Marquee provides these once at
  // deploy time). End users never see or supply any API key.
  TMDB_BEARER: string;
  // Public Trakt API key (no OAuth) - used read-only for the trending/anti-
  // popularity filter in the long-tail row. Not user-scoped.
  TRAKT_CLIENT_ID: string;
  MDBLIST_KEY?: string;                 // optional - unlocks Beloved bombs row across all users
  ADDON_VERSION: string;
  ADDON_NAME: string;
  DB: D1Database;
  CACHE?: KVNamespace;                  // optional cross-isolate TMDB cache
}

export interface UserRow {
  id: string;
  created_at: number;
  last_seen: number;
  faves_json: string | null;
  mood: string | null;
  letterboxd: string | null;
  trakt_enc: string | null;
  stremio_enc: string | null;
  lastfm?: string | null;
  // Dormant columns from earlier integrations. SQLite happily ignores
  // unused columns; kept here for type-completeness when reading rows.
  mdblist_enc?: string | null;
  trakt_refresh_enc?: string | null;
  trakt_access_enc?: string | null;
  trakt_access_exp?: number | null;
  tz?: string | null;
  show_anime?: number;                  // 0 or 1
}

export interface TitleCacheRow {
  imdb_id: string;
  tmdb_id: number | null;
  type: string | null;
  title: string | null;
  genres_json: string | null;
  year: number | null;
  director: string | null;
  original_language: string | null;
  vote_count: number | null;
  vote_average: number | null;
  refreshed_at: number | null;
}

export interface DerivedProfile {
  topGenres: Array<[string, number]>;
  topDecades: Array<[number, number]>;
  topDirectors: Array<[string, number]>;
  topLanguages: Array<[string, number]>;
  watchedSet: Set<string>;
  totalEvents: number;
  derivedAt: number;
}

export interface MetaPreview {
  id: string;
  type: StremioType;
  name: string;
  poster?: string;
  posterShape?: "square" | "poster" | "landscape";
  background?: string;
  logo?: string;
  description?: string;
  releaseInfo?: string;
  imdbRating?: string;
  genres?: string[];
}

export interface CatalogResponse {
  metas: MetaPreview[];
  cacheMaxAge?: number;
  staleRevalidate?: number;
  staleError?: number;
}

export type Mood = "any" | "quiet" | "fun" | "intense" | "curious" | "comfort";

export interface UserConfig {
  v: 1;
  mood?: Mood;
  faves?: string[];
  tk?: string;
  lb?: string;
  sa?: string;
}

export interface RowDef {
  id: string;
  type: StremioType;
  name: string;
  extra?: {
    name: string;
    options?: string[];
    optionsLimit?: number;
    isRequired?: boolean;
  }[];
  requires?: ("trakt" | "letterboxd" | "stremio")[];
}
