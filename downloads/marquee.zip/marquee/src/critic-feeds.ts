// Critic RSS bundle. We pull a handful of high-signal RSS feeds, extract
// candidate film references, resolve to IMDb via TMDB. Cached 24h.
//
// Real-world RSS titles vary wildly. Patterns we accept:
//   "Movie Title (2024) review - ..."         (year + review keyword)
//   "Movie Title review: ..."                  (review keyword)
//   "Review: Movie Title (2024)"               (Review: prefix + optional year)
//   "Movie Title - first-look review"
//   "How Movie Title became ..."               (best-effort)
//
// We harvest both <title> and <description> bodies, dedupe by title slug,
// and rank by how many feeds mention the same film this week.

import { fetchWithBackoff } from "./limiter.js";
import { tmdbToImdb } from "./tmdb.js";
import type { Env, MetaPreview } from "./types.js";

interface FeedSpec { name: string; url: string }

const FEEDS: FeedSpec[] = [
  { name: "guardian-film", url: "https://www.theguardian.com/film/rss" },
  { name: "indiewire", url: "https://www.indiewire.com/c/film/feed/" },
  { name: "nyt-movies", url: "https://www.nytimes.com/svc/collections/v1/publish/https://www.nytimes.com/section/movies/rss.xml" },
  { name: "letterboxd-journal", url: "https://letterboxd.com/journal/rss/" },
];

const _cache = new Map<string, { ts: number; metas: MetaPreview[] }>();
const TTL_MS = 1000 * 60 * 60 * 24;

interface Candidate { title: string; year?: number; weight: number }

const PATTERNS: Array<{ re: RegExp; weight: number; titleGroup: number; yearGroup?: number }> = [
  { re: /^Review:\s*(.+?)\s*\((\d{4})\)/i, weight: 1.0, titleGroup: 1, yearGroup: 2 },
  { re: /^Review:\s*(.+?)(?:\s*[-:|]|$)/i,  weight: 0.9, titleGroup: 1 },
  { re: /^(.+?)\s*\((\d{4})\)\s*(?:review|-|:|\|)/i, weight: 1.0, titleGroup: 1, yearGroup: 2 },
  { re: /^(.+?)\s+(?:first[- ]look\s+)?review\b/i, weight: 0.7, titleGroup: 1 },
  { re: /^(.+?)\s+is the\s+(?:best|year's|decade's)/i, weight: 0.5, titleGroup: 1 },
];

function extract(title: string): Candidate | null {
  for (const p of PATTERNS) {
    const m = title.match(p.re);
    const captured = m?.[p.titleGroup];
    if (m && captured) {
      const raw = captured.trim();
      if (raw.length < 2 || raw.length > 80) continue;
      if (/^the\s+(week|year|new|best)/i.test(raw)) continue;
      const yearStr = p.yearGroup ? m[p.yearGroup] : undefined;
      const year = yearStr ? Number(yearStr) : undefined;
      const cand: Candidate = { title: raw, weight: p.weight };
      if (year !== undefined && Number.isFinite(year)) cand.year = year;
      return cand;
    }
  }
  return null;
}

export function harvestTitlesFromFeed(xml: string): Candidate[] {
  const out: Candidate[] = [];
  const items = xml.split(/<item>/i).slice(1);
  for (const raw of items) {
    const body = raw.split(/<\/item>/i)[0] ?? "";
    const tMatch = body.match(/<title>(?:<!\[CDATA\[)?([^<\]]+)/i);
    if (!tMatch || !tMatch[1]) continue;
    const c = extract(tMatch[1]);
    if (c) out.push(c);
  }
  return out;
}

function slug(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "");
}

async function tmdbSearchForImdb(env: Env, title: string, year?: number): Promise<string | null> {
  const url = new URL("https://api.themoviedb.org/3/search/movie");
  url.searchParams.set("query", title);
  url.searchParams.set("include_adult", "false");
  if (year !== undefined) url.searchParams.set("year", String(year));
  const res = await fetchWithBackoff(url, {
    headers: { Authorization: `Bearer ${env.TMDB_BEARER}`, Accept: "application/json" },
  });
  if (!res.ok) return null;
  const data = (await res.json()) as {
    results?: Array<{ id: number; vote_count?: number; title?: string; original_title?: string; release_date?: string }>;
  };
  // Verify the result actually matches the original title (slug-equal or
  // slug-contains). TMDB's search returns near-matches for generic titles
  // ("Hope", "True North") that are entirely different films; we'd rather
  // drop the row entry than mislabel it.
  const target = slug(title);
  const verified = (data.results ?? []).filter((r) => {
    const cand = slug(r.title ?? "") || slug(r.original_title ?? "");
    return cand === target || cand.includes(target) || target.includes(cand);
  });
  // Cap-from-above on release date too (TMDB sometimes returns unreleased
  // films first because they have inflated early ratings).
  const today = new Date().toISOString().slice(0, 10);
  const released = verified.filter((r) => !r.release_date || r.release_date <= today);
  const pool = released.length ? released : verified;
  pool.sort((a, b) => (b.vote_count ?? 0) - (a.vote_count ?? 0));
  const first = pool[0];
  if (!first) {
    if (year !== undefined) return tmdbSearchForImdb(env, title);
    return null;
  }
  return tmdbToImdb(env, "movie", first.id);
}

export async function recentCriticPicks(env: Env): Promise<MetaPreview[]> {
  const hit = _cache.get("feeds");
  if (hit && Date.now() - hit.ts < TTL_MS) return hit.metas;

  const feedTexts = await Promise.all(
    FEEDS.map((f) =>
      fetchWithBackoff(f.url, { headers: { "User-Agent": "Marquee/0.6" } })
        .then((r) => (r.ok ? r.text() : ""))
        .catch(() => ""),
    ),
  );
  const candidates: Candidate[] = [];
  for (const text of feedTexts) candidates.push(...harvestTitlesFromFeed(text));

  // Dedupe; agreement across feeds increases weight.
  const seen = new Map<string, Candidate>();
  for (const c of candidates) {
    const key = `${c.title.toLowerCase().replace(/[^a-z0-9]+/g, "")}|${c.year ?? ""}`;
    const prev = seen.get(key);
    if (prev) prev.weight += c.weight;
    else seen.set(key, { ...c });
  }
  const top = [...seen.values()].sort((a, b) => b.weight - a.weight).slice(0, 40);

  const metas: MetaPreview[] = [];
  for (const c of top) {
    const imdb = await tmdbSearchForImdb(env, c.title, c.year).catch(() => null);
    if (imdb) metas.push({ id: imdb, type: "movie", name: c.title });
    if (metas.length >= 24) break;
  }
  _cache.set("feeds", { ts: Date.now(), metas });
  return metas;
}
