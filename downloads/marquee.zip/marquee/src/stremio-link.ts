// Link-code pairing against Stremio's own infrastructure.
//
// Endpoints (verified against api.strem.io 2026-05-19; same flow Stremio's own
// TV clients use, sourced from stremio-core/src/types/api/request.rs):
//
//   GET  https://link.stremio.com/api/create?type=Create
//        -> { success, code, link, qrcode, result:{...same}, error:null }
//        - `code` is a 4-character pairing code
//        - `link` is the URL the user visits on their phone (link.stremio.com/CODE)
//        - `qrcode` is a URL to an image of the QR (not a data URL)
//
//   GET  https://link.stremio.com/api/read?type=Read&code=ABCD
//        -> { success, authKey } once the user confirms; until then an error or null authKey
//
//   POST https://api.strem.io/api/datastoreGet
//        body: { authKey, collection: "libraryItem", all: true, ids: [] }
//        result: [...libraryItem]
//
// We never expose authKey to the browser. linkRead is called server-side; on
// success we immediately datastoreGet, ingest the library, discard the key.

import { recordLibraryImport } from "./attention.js";
import type { Env } from "./types.js";

const LINK_API = "https://link.stremio.com/api";
const STREMIO_API = "https://api.strem.io/api";

interface LinkCreateResp {
  success?: boolean;
  code?: string;
  link?: string;
  qrcode?: string;
  result?: { code?: string; link?: string; qrcode?: string } | null;
  error?: { code?: number; message?: string } | null;
}

interface LinkReadResp {
  success?: boolean;
  authKey?: string;
  result?: { authKey?: string } | null;
  error?: { code?: number; message?: string } | null;
}

interface LibraryState {
  lastWatched?: string | number | null;
  timeOffset?: number;
  duration?: number;
  timesWatched?: number;
  flaggedWatched?: number;
  overallTimeWatched?: number;
}

interface LibraryItem {
  _id: string;
  name?: string;
  type?: string;
  removed?: boolean;
  temp?: boolean;
  state?: LibraryState;
  mtime?: number | string;
}

interface DatastoreGetResp {
  result?: LibraryItem[];
  error?: { message?: string };
}

async function getJSON<T>(url: string): Promise<T> {
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json() as Promise<T>;
}

async function postJSON<T>(url: string, body: unknown): Promise<T> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json() as Promise<T>;
}

export interface LinkCreateOk {
  code: string;
  qrcode?: string;
  link?: string;
}

export async function linkCreate(): Promise<LinkCreateOk> {
  const data = await getJSON<LinkCreateResp>(`${LINK_API}/create?type=Create`);
  const code = data.code ?? data.result?.code;
  if (!code) throw new Error(`linkCreate: ${data.error?.message ?? "no code"}`);
  return {
    code,
    qrcode: data.qrcode ?? data.result?.qrcode,
    link: data.link ?? data.result?.link,
  };
}

export async function linkRead(code: string): Promise<string | null> {
  try {
    const data = await getJSON<LinkReadResp>(
      `${LINK_API}/read?type=Read&code=${encodeURIComponent(code)}`,
    );
    const key = data.authKey ?? data.result?.authKey;
    return key || null;
  } catch {
    return null;
  }
}

export async function datastoreGetLibrary(authKey: string): Promise<LibraryItem[]> {
  const data = await postJSON<DatastoreGetResp>(`${STREMIO_API}/datastoreGet`, {
    authKey,
    collection: "libraryItem",
    all: true,
    ids: [],
  });
  return data.result ?? [];
}

interface NormalizedLibraryItem {
  imdb_id: string;
  type: "movie" | "series";
  last_watched_ts: number | null;
  times_watched: number;
  completion_ratio: number | null;
  flagged_watched: boolean;
}

function normalize(items: LibraryItem[]): NormalizedLibraryItem[] {
  const out: NormalizedLibraryItem[] = [];
  for (const it of items) {
    if (!it._id || !it._id.startsWith("tt")) continue;
    if (it.removed || it.temp) continue;
    const type = it.type === "series" ? "series" : "movie";
    const state = it.state ?? {};
    const off = state.timeOffset ?? 0;
    const dur = state.duration ?? 0;
    const completion = dur > 0 ? Math.max(0, Math.min(1, off / dur)) : null;
    let lastTs: number | null = null;
    if (typeof state.lastWatched === "number" && state.lastWatched > 0) {
      // Stremio uses ms epoch.
      lastTs = state.lastWatched > 1e12 ? state.lastWatched : state.lastWatched * 1000;
    } else if (typeof state.lastWatched === "string" && state.lastWatched) {
      const parsed = Date.parse(state.lastWatched);
      if (!isNaN(parsed)) lastTs = parsed;
    }
    out.push({
      imdb_id: it._id,
      type,
      last_watched_ts: lastTs,
      times_watched: state.timesWatched ?? 0,
      completion_ratio: completion,
      flagged_watched: !!state.flaggedWatched,
    });
  }
  return out;
}

export interface IngestSummary {
  total: number;
  imported: number;
  watched: number;
}

export async function ingestLibrary(env: Env, userId: string, authKey: string): Promise<IngestSummary> {
  const raw = await datastoreGetLibrary(authKey);
  const normalized = normalize(raw);
  // Cap at the 300 most-recent for v0.1 - anything past that is rarely
  // load-bearing for taste signal and inflates D1 write cost.
  normalized.sort((a, b) => (b.last_watched_ts ?? 0) - (a.last_watched_ts ?? 0));
  const top = normalized.slice(0, 300);
  await recordLibraryImport(env, userId, top);
  const watched = top.filter((n) => n.flagged_watched || n.times_watched > 0).length;
  return { total: raw.length, imported: top.length, watched };
}
