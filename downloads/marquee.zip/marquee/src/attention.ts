// Attention-monitoring layer.
//
// Logs a meta/stream event with rich attention context (session id, hour, weekday,
// preceding event in the same session) and maintains a per-(user, title)
// rollup that turns the event stream into scoring features.
//
// Definitions:
//   - A "session" is a run of events from the same user with <30min gaps.
//   - A "watchlist-intent" title is one with meta_count >= 2 and stream_count == 0
//     in the last 30 days - the user keeps eyeing it but never commits. Marquee
//     prioritises surfacing it.
//   - An "abandoned" title is one with stream_count >= 1 and (library completion
//     ratio < 0.15 OR no follow-up activity within 7 days). Marquee suppresses
//     similar titles.
//   - "Recency-weighted" features decay with a 60-day half-life.

import type { Env } from "./types.js";

const SESSION_GAP_MS = 1000 * 60 * 30;

function hourBucket(hour: number): number {
  if (hour >= 5 && hour <= 11) return 0;   // morning
  if (hour >= 12 && hour <= 17) return 1;  // afternoon
  if (hour >= 18 && hour <= 22) return 2;  // evening
  return 3;                                 // late night
}

interface SessionContext {
  sessionId: number;
  priorEventId: number | null;
}

async function resolveSession(env: Env, userId: string, ts: number): Promise<SessionContext> {
  // Look at the most recent event for this user. If within SESSION_GAP_MS, we
  // continue that session; otherwise we open a new one (session id = ts/1000).
  const row = await env.DB.prepare(
    `SELECT rowid AS id, ts, session_id FROM events
     WHERE user_id = ? ORDER BY ts DESC LIMIT 1`,
  ).bind(userId).first<{ id: number; ts: number; session_id: number | null }>();
  if (row && row.session_id && ts - row.ts <= SESSION_GAP_MS) {
    return { sessionId: row.session_id, priorEventId: row.id };
  }
  return { sessionId: Math.floor(ts / 1000), priorEventId: null };
}

export async function recordAttention(
  env: Env,
  userId: string,
  imdbId: string,
  kind: "meta" | "stream",
  type: "movie" | "series",
  opts: { ts?: number; extra?: Record<string, unknown> } = {},
): Promise<void> {
  const ts = opts.ts ?? Date.now();
  const localHour = new Date(ts).getUTCHours(); // we don't know user TZ here; use UTC as a proxy
  const dow = new Date(ts).getUTCDay();
  const { sessionId, priorEventId } = await resolveSession(env, userId, ts);

  // 1) Append event row.
  await env.DB.prepare(
    `INSERT INTO events
       (user_id, imdb_id, kind, type, ts, session_id, hour_local, day_of_week, prior_event_id, extra_json)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  )
    .bind(
      userId,
      imdbId,
      kind,
      type,
      ts,
      sessionId,
      localHour,
      dow,
      priorEventId,
      opts.extra ? JSON.stringify(opts.extra) : null,
    )
    .run();

  // 2) Bump the per-(user, title) attention rollup.
  await env.DB.prepare(
    `INSERT INTO attention (user_id, imdb_id, meta_count, stream_count, first_seen_ts, last_meta_ts, last_stream_ts)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id, imdb_id) DO UPDATE SET
       meta_count = attention.meta_count + excluded.meta_count,
       stream_count = attention.stream_count + excluded.stream_count,
       last_meta_ts = COALESCE(excluded.last_meta_ts, attention.last_meta_ts),
       last_stream_ts = COALESCE(excluded.last_stream_ts, attention.last_stream_ts)`,
  )
    .bind(
      userId,
      imdbId,
      kind === "meta" ? 1 : 0,
      kind === "stream" ? 1 : 0,
      ts,
      kind === "meta" ? ts : null,
      kind === "stream" ? ts : null,
    )
    .run();

  // 3) If we have a prior event in this session, that's a sequence transition.
  // Record from_imdb -> to_imdb with light weight.
  if (priorEventId !== null) {
    const prior = await env.DB.prepare(
      `SELECT imdb_id FROM events WHERE rowid = ?`,
    ).bind(priorEventId).first<{ imdb_id: string }>();
    if (prior && prior.imdb_id !== imdbId) {
      const w = kind === "stream" ? 1.0 : 0.3;
      await env.DB.prepare(
        `INSERT INTO attention_sequence (user_id, from_imdb, to_imdb, weight)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(user_id, from_imdb, to_imdb) DO UPDATE SET
           weight = attention_sequence.weight + excluded.weight`,
      )
        .bind(userId, prior.imdb_id, imdbId, w)
        .run();
    }
  }

  // 4) Temporal genre weights are updated lazily during profile derivation;
  // we just record the event here and let the profile refresher backfill.
}

export async function recordLibraryImport(
  env: Env,
  userId: string,
  items: Array<{
    imdb_id: string;
    type: "movie" | "series";
    last_watched_ts: number | null;
    times_watched: number;
    completion_ratio: number | null;
    flagged_watched: boolean;
  }>,
): Promise<void> {
  if (items.length === 0) return;
  const now = Date.now();
  // We batch into D1's prepare/run. D1 has a statement-per-run cost but no real
  // batching primitive; the only optimization is parameterised reuse. Workers
  // is fine with 100s of these.
  for (const it of items) {
    const ts = it.last_watched_ts ?? now;
    const kind = it.flagged_watched || it.times_watched > 0 ? "library_watched" : "library_listed";
    await env.DB.prepare(
      `INSERT INTO events (user_id, imdb_id, kind, type, ts, extra_json)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
      .bind(
        userId,
        it.imdb_id,
        kind,
        it.type,
        ts,
        JSON.stringify({
          times_watched: it.times_watched,
          completion_ratio: it.completion_ratio,
          flagged: it.flagged_watched,
        }),
      )
      .run();

    await env.DB.prepare(
      `INSERT INTO attention (user_id, imdb_id, meta_count, stream_count, library_seen, completion_ratio, first_seen_ts, last_stream_ts)
       VALUES (?, ?, 0, ?, 1, ?, ?, ?)
       ON CONFLICT(user_id, imdb_id) DO UPDATE SET
         stream_count = attention.stream_count + excluded.stream_count,
         library_seen = 1,
         completion_ratio = COALESCE(excluded.completion_ratio, attention.completion_ratio),
         last_stream_ts = COALESCE(excluded.last_stream_ts, attention.last_stream_ts)`,
    )
      .bind(
        userId,
        it.imdb_id,
        it.times_watched,
        it.completion_ratio,
        ts,
        ts,
      )
      .run();
  }
}

export interface AttentionRow {
  imdb_id: string;
  meta_count: number;
  stream_count: number;
  library_seen: number;
  completion_ratio: number | null;
  first_seen_ts: number;
  last_meta_ts: number | null;
  last_stream_ts: number | null;
}

export async function attentionRows(env: Env, userId: string, limit = 500): Promise<AttentionRow[]> {
  const res = await env.DB.prepare(
    `SELECT imdb_id, meta_count, stream_count, library_seen, completion_ratio,
            first_seen_ts, last_meta_ts, last_stream_ts
     FROM attention WHERE user_id = ?
     ORDER BY COALESCE(last_stream_ts, last_meta_ts, first_seen_ts) DESC
     LIMIT ?`,
  )
    .bind(userId, limit)
    .all<AttentionRow>();
  return res.results ?? [];
}

// Watchlist-intent: meta_count >= 4 AND stream_count == 0 AND last_meta_ts within 30 days.
// Threshold of 4 picked per attention research - 2 was over-inclusive
// (one curious double-check counts as "intent"; really we want repeated
// returns). These surface in the "On your mind" row.
export async function watchlistIntentIds(env: Env, userId: string, withinDays = 30, limit = 50): Promise<string[]> {
  const cutoff = Date.now() - withinDays * 86400_000;
  const res = await env.DB.prepare(
    `SELECT imdb_id FROM attention
     WHERE user_id = ? AND meta_count >= 4 AND stream_count = 0 AND last_meta_ts >= ?
     ORDER BY last_meta_ts DESC LIMIT ?`,
  )
    .bind(userId, cutoff, limit)
    .all<{ imdb_id: string }>();
  return (res.results ?? []).map((r) => r.imdb_id);
}

// Abandoned: stream_count >= 1 but completion_ratio < 0.15 (when known).
// These titles' genres/directors get a *negative* weight in profile derivation.
export async function abandonedIds(env: Env, userId: string, limit = 50): Promise<string[]> {
  const res = await env.DB.prepare(
    `SELECT imdb_id FROM attention
     WHERE user_id = ? AND stream_count >= 1 AND completion_ratio IS NOT NULL AND completion_ratio < 0.15
     ORDER BY last_stream_ts DESC LIMIT ?`,
  )
    .bind(userId, limit)
    .all<{ imdb_id: string }>();
  return (res.results ?? []).map((r) => r.imdb_id);
}

export { hourBucket };
