import type { Env, TitleCacheRow, UserRow } from "./types.js";

// Crockford base32 minus look-alikes (0/O, 1/I, etc). 8 chars = 40 bits ≈ 1T IDs.
// Short enough to be typeable on a TV remote, long enough that birthday-paradox
// collisions are negligible for any realistic Marquee userbase.
const ID_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789";

export function newUserId(): string {
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  let out = "";
  for (let i = 0; i < 8; i++) {
    const byte = bytes[i] ?? 0;
    const idx = byte % ID_ALPHABET.length;
    out += ID_ALPHABET[idx];
  }
  return out;
}

export function looksLikeUserId(s: string | undefined): boolean {
  if (!s) return false;
  return /^[a-z2-9]{8}$/.test(s);
}

export async function getUser(env: Env, id: string): Promise<UserRow | null> {
  const row = await env.DB.prepare("SELECT * FROM users WHERE id = ?").bind(id).first<UserRow>();
  return row ?? null;
}

export async function touchUser(env: Env, id: string): Promise<void> {
  await env.DB.prepare("UPDATE users SET last_seen = ? WHERE id = ?").bind(Date.now(), id).run();
}

export interface CreateUserInput {
  faves?: string[];
  mood?: string | null;
  letterboxd?: string | null;
}

export async function createUser(env: Env, input: CreateUserInput): Promise<string> {
  const id = newUserId();
  const now = Date.now();
  await env.DB.prepare(
    `INSERT INTO users (id, created_at, last_seen, faves_json, mood, letterboxd)
     VALUES (?, ?, ?, ?, ?, ?)`,
  )
    .bind(
      id,
      now,
      now,
      input.faves && input.faves.length ? JSON.stringify(input.faves) : null,
      input.mood ?? null,
      input.letterboxd ?? null,
    )
    .run();
  return id;
}

export async function updateUserPrefs(env: Env, id: string, input: CreateUserInput): Promise<void> {
  await env.DB.prepare(
    `UPDATE users SET faves_json = ?, mood = ?, letterboxd = ?, last_seen = ? WHERE id = ?`,
  )
    .bind(
      input.faves && input.faves.length ? JSON.stringify(input.faves) : null,
      input.mood ?? null,
      input.letterboxd ?? null,
      Date.now(),
      id,
    )
    .run();
}

export async function logEvent(
  env: Env,
  userId: string,
  imdbId: string,
  kind: "meta" | "stream",
  type: "movie" | "series",
): Promise<void> {
  await env.DB.prepare(
    `INSERT INTO events (user_id, imdb_id, kind, type, ts) VALUES (?, ?, ?, ?, ?)`,
  )
    .bind(userId, imdbId, kind, type, Date.now())
    .run();
}

export interface EventRow {
  imdb_id: string;
  kind: string;
  type: string;
  ts: number;
}

export async function recentEvents(env: Env, userId: string, limit = 500): Promise<EventRow[]> {
  const res = await env.DB.prepare(
    `SELECT imdb_id, kind, type, ts FROM events WHERE user_id = ? ORDER BY ts DESC LIMIT ?`,
  )
    .bind(userId, limit)
    .all<EventRow>();
  return res.results ?? [];
}

export async function getTitleCache(env: Env, imdbIds: string[]): Promise<Map<string, TitleCacheRow>> {
  if (imdbIds.length === 0) return new Map();
  // SQLite IN list - D1's prepare doesn't bind arrays directly; build placeholders.
  const placeholders = imdbIds.map(() => "?").join(",");
  const res = await env.DB.prepare(
    `SELECT * FROM title_cache WHERE imdb_id IN (${placeholders})`,
  )
    .bind(...imdbIds)
    .all<TitleCacheRow>();
  const map = new Map<string, TitleCacheRow>();
  for (const row of res.results ?? []) map.set(row.imdb_id, row);
  return map;
}

export async function upsertTitleCache(env: Env, row: TitleCacheRow): Promise<void> {
  await env.DB.prepare(
    `INSERT INTO title_cache
       (imdb_id, tmdb_id, type, title, genres_json, year, director, original_language, vote_count, vote_average, refreshed_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(imdb_id) DO UPDATE SET
       tmdb_id = excluded.tmdb_id,
       type = excluded.type,
       title = excluded.title,
       genres_json = excluded.genres_json,
       year = excluded.year,
       director = excluded.director,
       original_language = excluded.original_language,
       vote_count = excluded.vote_count,
       vote_average = excluded.vote_average,
       refreshed_at = excluded.refreshed_at`,
  )
    .bind(
      row.imdb_id,
      row.tmdb_id,
      row.type,
      row.title,
      row.genres_json,
      row.year,
      row.director,
      row.original_language,
      row.vote_count,
      row.vote_average,
      row.refreshed_at,
    )
    .run();
}

export interface ProfileRow {
  user_id: string;
  top_genres_json: string | null;
  top_decades_json: string | null;
  top_directors_json: string | null;
  top_languages_json: string | null;
  watched_set_json: string | null;
  total_events: number | null;
  derived_at: number | null;
}

export async function getProfileRow(env: Env, userId: string): Promise<ProfileRow | null> {
  const row = await env.DB.prepare("SELECT * FROM profile WHERE user_id = ?")
    .bind(userId)
    .first<ProfileRow>();
  return row ?? null;
}

export async function upsertProfile(env: Env, row: ProfileRow): Promise<void> {
  await env.DB.prepare(
    `INSERT INTO profile
       (user_id, top_genres_json, top_decades_json, top_directors_json, top_languages_json, watched_set_json, total_events, derived_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET
       top_genres_json = excluded.top_genres_json,
       top_decades_json = excluded.top_decades_json,
       top_directors_json = excluded.top_directors_json,
       top_languages_json = excluded.top_languages_json,
       watched_set_json = excluded.watched_set_json,
       total_events = excluded.total_events,
       derived_at = excluded.derived_at`,
  )
    .bind(
      row.user_id,
      row.top_genres_json,
      row.top_decades_json,
      row.top_directors_json,
      row.top_languages_json,
      row.watched_set_json,
      row.total_events,
      row.derived_at,
    )
    .run();
}
