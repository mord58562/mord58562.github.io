import { abandonedIds, attentionRows } from "./attention.js";
import { recentEvents, getProfileRow, upsertProfile } from "./storage.js";
import { enrichTitles } from "./titleenrich.js";
import type { DerivedProfile, Env, TitleCacheRow } from "./types.js";

const PROFILE_TTL_MS = 1000 * 60 * 30; // refresh profile at most every 30 min

const EMPTY: DerivedProfile = {
  topGenres: [],
  topDecades: [],
  topDirectors: [],
  topLanguages: [],
  watchedSet: new Set(),
  totalEvents: 0,
  derivedAt: 0,
};

function topN<K>(counts: Map<K, number>, n: number): Array<[K, number]> {
  const total = [...counts.values()].reduce((a, b) => a + b, 0);
  if (total === 0) return [];
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([k, v]) => [k, v / total] as [K, number]);
}

function bump<K>(counts: Map<K, number>, key: K, weight: number): void {
  counts.set(key, (counts.get(key) ?? 0) + weight);
}

// Build a profile from the attention rollup. We score each title once (not
// per event), weighting:
//
//   - stream presses much heavier than meta opens (3x)
//   - completion-aware: titles watched >85% get a +50% bump (finished it),
//     titles abandoned at <15% get NEGATIVE weight against their genres/director
//   - rewatch loyalty: stream_count > 1 gets +50% per extra play
//   - watchlist-intent: titles with meta_count>=2, stream_count==0 contribute
//     half weight (they've been considered repeatedly)
//   - recency: 60-day half-life on last interaction
//
// Negative weights from abandoned titles do dial back the user's taste profile
// for similar content, mirroring how a thoughtful programmer would react: "you
// bailed on three slow art films - I'll show fewer of those for a while."
const HALF_LIFE = 1000 * 60 * 60 * 24 * 60;

interface AttentionInput {
  imdb_id: string;
  meta_count: number;
  stream_count: number;
  completion_ratio: number | null;
  last_meta_ts: number | null;
  last_stream_ts: number | null;
  first_seen_ts: number;
  is_abandoned: boolean;
}

function titleWeight(att: AttentionInput, now: number): number {
  const ts = att.last_stream_ts ?? att.last_meta_ts ?? att.first_seen_ts;
  const recency = Math.pow(0.5, (now - ts) / HALF_LIFE);
  let base = att.stream_count * 3 + att.meta_count * 1;
  // Watchlist-intent: never played but eyed repeatedly (>=4 per attention research).
  if (att.stream_count === 0 && att.meta_count >= 4) base += 0.5;
  // Completion bands:
  //   - >=0.92 = finished, strong taste signal
  //   - 0.85..0.92 = near-complete-abandon = POSITIVE (per research): the user
  //     liked it but ran out of time. Don't penalise; reward almost as much
  //     as finishing.
  //   - <0.85 with low engagement is handled below via the abandoned set.
  if (att.completion_ratio !== null) {
    if (att.completion_ratio >= 0.92) base *= 1.5;
    else if (att.completion_ratio >= 0.85) base *= 1.4;
  }
  // Rewatch loyalty - a separate taste cluster. Multiple replays imply
  // strong identification, not just casual liking.
  if (att.stream_count > 1) base *= 1 + 0.5 * (att.stream_count - 1);
  // Abandoned (<0.15 completion + recent stream): their genres / director
  // pull the profile DOWN. Keeps the recommender from doubling down on
  // misses.
  if (att.is_abandoned) return -base * 0.5 * recency;
  return base * recency;
}

function deriveFromAttention(
  attention: AttentionInput[],
  titles: Map<string, TitleCacheRow>,
): DerivedProfile {
  const now = Date.now();
  const genreCounts = new Map<string, number>();
  const decadeCounts = new Map<number, number>();
  const dirCounts = new Map<string, number>();
  const langCounts = new Map<string, number>();
  const watched = new Set<string>();

  for (const att of attention) {
    // Only add to watched-set when they actually pressed Play (or completion>0).
    if (att.stream_count > 0 || (att.completion_ratio ?? 0) > 0) {
      watched.add(att.imdb_id);
    }
    const meta = titles.get(att.imdb_id);
    if (!meta) continue;
    const w = titleWeight(att, now);
    if (w === 0) continue;
    if (meta.genres_json) {
      try {
        const genres = JSON.parse(meta.genres_json) as string[];
        for (const g of genres) bump(genreCounts, g, w);
      } catch { /* ignore */ }
    }
    if (meta.year) bump(decadeCounts, Math.floor(meta.year / 10) * 10, w);
    if (meta.director) bump(dirCounts, meta.director, w);
    if (meta.original_language) bump(langCounts, meta.original_language, w);
  }

  // Filter out genres/directors/etc. whose weight is non-positive (abandoned
  // titles pulled them under zero). `topN` already normalizes against the sum.
  const positive = <K>(m: Map<K, number>): Map<K, number> => {
    const out = new Map<K, number>();
    for (const [k, v] of m) if (v > 0) out.set(k, v);
    return out;
  };

  return {
    topGenres: topN(positive(genreCounts), 8),
    topDecades: topN(positive(decadeCounts), 5),
    topDirectors: topN(positive(dirCounts), 10),
    topLanguages: topN(positive(langCounts), 5),
    watchedSet: watched,
    totalEvents: attention.reduce((a, b) => a + b.meta_count + b.stream_count, 0),
    derivedAt: now,
  };
}

function parseCachedProfile(cached: NonNullable<Awaited<ReturnType<typeof getProfileRow>>>): DerivedProfile {
  return {
    topGenres: JSON.parse(cached.top_genres_json ?? "[]"),
    topDecades: JSON.parse(cached.top_decades_json ?? "[]"),
    topDirectors: JSON.parse(cached.top_directors_json ?? "[]"),
    topLanguages: JSON.parse(cached.top_languages_json ?? "[]"),
    watchedSet: new Set(JSON.parse(cached.watched_set_json ?? "[]")),
    totalEvents: cached.total_events ?? 0,
    derivedAt: cached.derived_at ?? 0,
  };
}

// loadProfile NEVER blocks a catalog request on derivation. We return whatever
// is cached now (stale or empty) and the caller can opt into a background
// refresh via ctx.waitUntil(refreshProfile(...)). The cron handler also
// pre-warms profiles every 6h so most requests never see a cold profile.
export async function loadProfile(env: Env, userId: string): Promise<DerivedProfile> {
  const cached = await getProfileRow(env, userId).catch(() => null);
  if (cached) return parseCachedProfile(cached);
  // No row yet - return empty and let the cron / explicit refresh build one.
  return { ...EMPTY, derivedAt: Date.now() };
}

// Same as loadProfile but flags whether the cached profile is stale enough
// that the caller should kick off a background refresh.
export async function loadProfileWithStale(env: Env, userId: string): Promise<{ profile: DerivedProfile; stale: boolean }> {
  const cached = await getProfileRow(env, userId).catch(() => null);
  if (!cached) return { profile: { ...EMPTY, derivedAt: Date.now() }, stale: true };
  const stale = !cached.derived_at || Date.now() - cached.derived_at >= PROFILE_TTL_MS;
  return { profile: parseCachedProfile(cached), stale };
}

export async function refreshProfile(env: Env, userId: string): Promise<DerivedProfile> {
  const rows = await attentionRows(env, userId, 500);
  const abandoned = new Set(await abandonedIds(env, userId, 80).catch(() => []));

  if (rows.length === 0) {
    await upsertProfile(env, {
      user_id: userId,
      top_genres_json: "[]",
      top_decades_json: "[]",
      top_directors_json: "[]",
      top_languages_json: "[]",
      watched_set_json: "[]",
      total_events: 0,
      derived_at: Date.now(),
    });
    return { ...EMPTY, derivedAt: Date.now() };
  }
  const uniqueIds = [...new Set(rows.map((r) => r.imdb_id))].slice(0, 80);
  const titles = await enrichTitles(env, uniqueIds);
  const attention = rows.map((r) => ({
    imdb_id: r.imdb_id,
    meta_count: r.meta_count,
    stream_count: r.stream_count,
    completion_ratio: r.completion_ratio,
    last_meta_ts: r.last_meta_ts,
    last_stream_ts: r.last_stream_ts,
    first_seen_ts: r.first_seen_ts,
    is_abandoned: abandoned.has(r.imdb_id),
  }));
  const derived = deriveFromAttention(attention, titles);
  await upsertProfile(env, {
    user_id: userId,
    top_genres_json: JSON.stringify(derived.topGenres),
    top_decades_json: JSON.stringify(derived.topDecades),
    top_directors_json: JSON.stringify(derived.topDirectors),
    top_languages_json: JSON.stringify(derived.topLanguages),
    watched_set_json: JSON.stringify([...derived.watchedSet]),
    total_events: derived.totalEvents,
    derived_at: derived.derivedAt,
  });
  return derived;
}

// Map TMDB genre NAME to TMDB genre ID (the discover endpoint takes IDs).
export const GENRE_NAME_TO_ID: Record<string, number> = {
  Action: 28, Adventure: 12, Animation: 16, Comedy: 35, Crime: 80,
  Documentary: 99, Drama: 18, Family: 10751, Fantasy: 14, History: 36,
  Horror: 27, Music: 10402, Mystery: 9648, Romance: 10749, "Science Fiction": 878,
  "TV Movie": 10770, Thriller: 53, War: 10752, Western: 37,
  // TV-specific
  "Action & Adventure": 10759, Kids: 10762, News: 10763, Reality: 10764,
  "Sci-Fi & Fantasy": 10765, Soap: 10766, Talk: 10767, "War & Politics": 10768,
};

export function profileGenresToTMDB(profile: DerivedProfile, topN = 3): string | undefined {
  const ids = profile.topGenres
    .slice(0, topN)
    .map(([name]) => GENRE_NAME_TO_ID[name])
    .filter((x): x is number => typeof x === "number");
  if (ids.length === 0) return undefined;
  return ids.join("|");
}

export function profileLanguagesToISO(profile: DerivedProfile): string | undefined {
  const top = profile.topLanguages[0];
  return top ? top[0] : undefined;
}
