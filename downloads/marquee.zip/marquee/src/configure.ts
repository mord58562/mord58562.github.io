// /configure is the *only* web surface Marquee serves.
//
// Stremio opens this URL when the user clicks Configure on the addon. There
// is no marketing landing page, no separate website. UI is UA-aware:
//
//   - TV builds: cannot render forms (TV remote keyboard is unusable). We
//     render a phone hand-off - a QR pointing back to the same /configure
//     URL with a flag so the phone goes straight to settings, plus a code
//     for the user to verify they paired the right device.
//
//   - Phone / desktop / web: full settings panel - pair button + QR/code for
//     Stremio library import via link.stremio.com, mood toggle, Letterboxd
//     username, and the install URL displayed so the user can save it.

import { STYLE_CSS } from "./style.js";
import type { UserRow } from "./types.js";

// Build a Google Charts QR URL for `text`. Renders a scannable code without
// us shipping any QR library to the Worker.
function qrSrc(text: string, size = 220): string {
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(text)}`;
}

// Root landing page. Shown when someone opens the Worker URL in a browser.
// The actual product lives inside Stremio, so this is intentionally lean:
// one explanation, one "Add to Stremio" button, the manifest URL, the
// /configure link, and a pointer at the source.
export function indexPage(origin: string): string {
  const host = origin.replace(/^https?:\/\//, "");
  const manifest = `${origin}/manifest.json`;
  const stremio = manifest.replace(/^https?:/, "stremio:");
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Marquee</title>
<style>${STYLE_CSS}
  .page { padding: 56px 30px 80px; }
  .install-cta { display: inline-block; background: var(--curtain); color: var(--paper); padding: 14px 28px; border: 0; font-family: "Iowan Old Style", Georgia, serif; font-size: 20px; font-style: italic; text-decoration: none; margin: 14px 0 6px; }
  .install-cta:hover { color: var(--paper); background: var(--ink); }
  .lede { font-family: "Iowan Old Style", Georgia, serif; font-size: 19px; line-height: 1.55; max-width: 56ch; margin: 0 0 22px; }
  .rows-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 8px 24px; font-family: "Iowan Old Style", Georgia, serif; font-size: 15px; margin-top: 8px; }
  .rows-grid div::before { content: "·"; color: var(--curtain); margin-right: 8px; }
  .coexist { font-family: "Iowan Old Style", Georgia, serif; font-size: 14px; color: var(--ink-soft, #555); max-width: 56ch; margin: 28px 0 0; line-height: 1.5; }
  .coexist strong { font-weight: 600; }
</style>
</head>
<body>
  <main class="page">
    <h1>Marquee</h1>
    <p class="dek">A Stremio homepage curated like a rep cinema.</p>

    <p class="lede">Hand-designed rows with sharp identities, slow rotation, and a stated reason for every pick. Each tile carries a star rating, a year, and a one-line rationale. No accounts, no API keys, no detail-page hijacking - Cinemeta still owns titles, Torrentio still owns sources. Marquee only shapes the homepage.</p>

    <p><a class="install-cta" href="${stremio}">Add to Stremio</a></p>
    <p class="helper">Opens Stremio with the install prompt. On a device without Stremio, paste the manifest URL into Stremio &rarr; Addons &rarr; Search.</p>

    <h2 class="section">Manifest URL</h2>
    <div class="url-typable">${host}/manifest.json</div>

    <h2 class="section">Optional personalisation</h2>
    <p>Open <a href="${origin}/configure">/configure</a> to pair your Stremio library, set a mood, pick five favourite films, link Letterboxd, or enable the anime row. Everything is optional - the anonymous install already does the rep-cinema thing on its own.</p>

    <h2 class="section">What ships in the lineup</h2>
    <div class="rows-grid">
      <div>Tonight</div>
      <div>Under 95 minutes</div>
      <div>Limited series</div>
      <div>Recent</div>
      <div>Lesser-known</div>
      <div>Award winners</div>
      <div>Essentials</div>
      <div>Critics this week</div>
      <div>Beloved bombs</div>
      <div>Adapted from books</div>
      <div>Like what you've watched</div>
      <div>Your decade</div>
      <div>Less typical for you</div>
      <div>On your mind</div>
      <div>Continue</div>
      <div>Anime worth watching</div>
    </div>

    <p class="coexist">Coexists with Torrentio, Comet, MediaFusion, TorBox, Knightcrawler, Easynews, Jackettio and other stream addons - Marquee returns no streams of its own, so Play opens the usual source-selection screen unchanged. <strong>If you also use AIOStreams</strong>, open its configure page and turn off the <em>Catalog</em> resource so its rows do not double up with Marquee on the homepage.</p>

    <footer class="colophon">
      Marquee &middot; <a href="https://github.com/mord58562/marquee">source</a> &middot; MIT
    </footer>
  </main>
</body>
</html>`;
}

export function tvHandoffPage(origin: string, userId: string): string {
  // We want the phone to land directly in the settings panel with the same
  // userId, so the user is configuring the install that's on this TV.
  const configureUrl = `${origin}/${userId}/configure`;
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Marquee · Configure on your phone</title>
<style>${STYLE_CSS}
  body { display: flex; align-items: center; justify-content: center; min-height: 100vh; }
  .page { padding: 30px 24px; text-align: center; }
  .url-typable { text-align: center; margin: 18px auto 0; max-width: 480px; font-size: 18px; }
  .id-banner { font-family: ui-monospace, monospace; font-size: 34px; letter-spacing: 0.12em; margin: 18px 0 6px; }
  .qr-block img { width: 220px; height: 220px; }
</style>
</head>
<body>
  <main class="page">
    <h1>Configure Marquee</h1>
    <p class="dek">Scan with a phone camera, or type the URL below.</p>
    <div class="qr-block"><img src="${qrSrc(configureUrl)}" alt="QR pointing to ${configureUrl}" /></div>
    <div class="url-typable">${origin.replace(/^https?:\/\//, "")}/${userId}/configure</div>
    <p class="helper" style="margin-top:20px">Your Marquee ID, to double-check you are configuring this device:</p>
    <div class="id-banner">${userId}</div>
    <p class="helper">A keyboard remote cannot really fill in settings. Use a real keyboard once; everything you set will travel back to this Stremio install.</p>
  </main>
</body>
</html>`;
}

export function settingsPage(origin: string, user: UserRow | null, userId: string, version = ""): string {
  const host = origin.replace(/^https?:\/\//, "");
  const installUrl = `${origin}/${userId}/manifest.json`;
  const stremioUrl = installUrl.replace(/^https?:/, "stremio:");
  const mood = user?.mood ?? "any";
  const letterboxd = (user?.letterboxd ?? "").replace(/"/g, "&quot;");
  const faves = user?.faves_json ? JSON.parse(user.faves_json) : [];
  const favesJson = JSON.stringify(faves);

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Marquee · Configure</title>
<style>${STYLE_CSS}
  .picks { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-top: 12px; }
  .pick { aspect-ratio: 2/3; background: var(--paper-bright); border: 1px solid var(--rule); position: relative; overflow: hidden; }
  .pick img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .pick .x { position: absolute; top:0; right:0; width:22px; height:22px; background: var(--paper); color: var(--ink); border: 1px solid var(--rule); border-top:0; border-right:0; cursor: pointer; font-family: ui-monospace, monospace; font-size: 14px; }
  .pick.empty { display: flex; align-items: center; justify-content: center; font-family: "Iowan Old Style", Georgia, serif; font-style: italic; color: var(--dimmer); font-size: 22px; }
  .search-wrap { position: relative; margin-top: 12px; }
  .search-results { position: absolute; left:0; right:0; top: 100%; background: var(--paper-bright); border: 1px solid var(--ink); max-height: 280px; overflow-y: auto; z-index: 10; }
  .search-row { display: flex; gap: 10px; padding: 8px 10px; cursor: pointer; border-bottom: 1px solid var(--rule); }
  .search-row:hover { background: var(--paper); }
  .search-row img { width: 32px; height: 48px; object-fit: cover; }
  .search-row .meta-text { flex: 1; min-width: 0; }
  .search-row .title { font-family: "Iowan Old Style", Georgia, serif; }
  .search-row .yk { color: var(--dim); font-size: 12px; font-style: italic; }
  .install-row { display: flex; justify-content: space-between; gap: 18px; align-items: center; margin-top: 6px; flex-wrap: wrap; }
  .saved { color: var(--dim); margin-left: 10px; font-style: italic; }
</style>
</head>
<body>
  <main class="page">
    <h1>Marquee</h1>
    <p class="dek">Settings for this install.</p>

    <h2 class="section">Stremio library</h2>
    <div id="pairBlock">
      ${user?.stremio_enc
        ? `<p>Linked. Marquee has your library and continues to learn from what you watch.</p>
           <p><button class="action" id="rePair">Re-pair</button></p>`
        : `<p>Pair your existing Stremio account so the homepage knows your tastes from second one. Uses Stremio's own pairing flow - we never see your password.</p>
           <p><button class="action" id="pairBtn">Show pairing code</button></p>`
      }
    </div>
    <div id="pairActive" style="display:none">
      <div class="qr-block">
        <img id="qrImg" alt="QR" />
      </div>
      <div class="qr-code" id="codeText">&middot; &middot; &middot; &middot;</div>
      <p class="pair-status" id="pairStatus">Open <span id="pairLinkText">link.stremio.com</span> on a phone, type the code, confirm.</p>
    </div>
    <div id="pairDone" style="display:none">
      <p class="pair-status ok" id="pairDoneMsg"></p>
    </div>

    <h2 class="section">Mood (Tonight row default)</h2>
    <div class="moods" id="moods">
      ${["any", "quiet", "fun", "intense", "curious", "comfort"]
        .map((m) => {
          const letter = m === "any" ? "-" : m[0]?.toUpperCase() ?? "·";
          return `<span class="mood-tag${m === mood ? " active" : ""}" data-mood="${m}"><span class="pre">[${letter}]</span>${m}</span>`;
        })
        .join("\n      ")}
    </div>

    <h2 class="section">Five favourites (optional)</h2>
    <p class="helper">Not five you've seen - five that define your taste. Used before live signal accumulates.</p>
    <div class="search-wrap">
      <input type="text" id="search" placeholder="search a film or series&hellip;" autocomplete="off" />
      <div class="search-results" id="results" style="display:none"></div>
    </div>
    <div class="picks" id="picks"></div>

    <h2 class="section">Letterboxd (optional)</h2>
    <p class="helper">Public profile only. We read the same RSS anyone can read.</p>
    <input type="text" id="lb" placeholder="username" value="${letterboxd}" />

    <h2 class="section">Anime</h2>
    <p class="helper">Off by default. Adds the "Anime worth watching" row if you want it.</p>
    <label class="serif" style="font-size:18px;cursor:pointer">
      <input type="checkbox" id="anime"${user?.show_anime ? " checked" : ""} style="margin-right:8px;transform:scale(1.2)" />
      Include anime
    </label>
    <p class="helper" style="margin-top:8px">Tiles are emitted with <code>kitsu:</code> ids so Torrentio, Comet, and other stream addons return full anime stream lists. Pair with the <a href="https://anime-kitsu.strem.fun/configure">Anime Kitsu</a> addon if you don't already have it - it provides anime metadata.</p>

    <h2 class="section">Install URL</h2>
    <p class="helper">Type or paste this into Stremio's add-on search on any device:</p>
    <div class="install-row">
      <div class="url-typable" style="flex:1">${host}/${userId}/manifest.json</div>
      <a class="action" href="${stremioUrl}" style="font-style:italic">Open in Stremio &rarr;</a>
    </div>

    <h2 class="section">&nbsp;</h2>
    <p><button class="action" id="save">Save settings</button><span class="saved" id="saved" hidden>saved.</span></p>

    <footer class="colophon">
      Marquee &middot; <a href="https://github.com/mord58562/marquee">source</a>${version ? ` &middot; v${version}` : ""}
    </footer>
  </main>

<script>
const USER_ID = ${JSON.stringify(userId)};
const HOST = ${JSON.stringify(host)};
const state = { mood: ${JSON.stringify(mood)}, faves: ${favesJson}, lb: ${JSON.stringify(user?.letterboxd ?? "")} };

function renderMoods() {
  document.querySelectorAll(".mood-tag").forEach(el => el.classList.toggle("active", el.dataset.mood === state.mood));
}
function renderPicks() {
  const el = document.getElementById("picks");
  const cells = [];
  for (let i = 0; i < 5; i++) {
    const f = state.faves[i];
    if (f && typeof f === "object" && f.poster) {
      cells.push('<div class="pick"><img src="' + f.poster + '" alt="" /><button class="x" data-i="' + i + '">&times;</button></div>');
    } else {
      cells.push('<div class="pick empty">' + (i + 1) + '</div>');
    }
  }
  el.innerHTML = cells.join("");
  el.querySelectorAll(".x").forEach(b => b.addEventListener("click", e => {
    state.faves.splice(Number(e.currentTarget.dataset.i), 1);
    renderPicks();
  }));
}
// Hydrate posters for faves we got as ids only.
(async function hydrate() {
  for (let i = 0; i < state.faves.length; i++) {
    const f = state.faves[i];
    if (typeof f === "string") {
      const r = await fetch("/api/search?q=" + encodeURIComponent(f)).then(r => r.json()).catch(() => ({results:[]}));
      const hit = (r.results||[])[0];
      state.faves[i] = hit ? { id: hit.id, poster: hit.poster, title: hit.title } : { id: f, poster: null, title: f };
    }
  }
  renderPicks();
})();
renderMoods();

document.getElementById("moods").addEventListener("click", e => {
  const t = e.target.closest(".mood-tag"); if (!t) return;
  state.mood = t.dataset.mood; renderMoods();
});
document.getElementById("lb").addEventListener("input", e => { state.lb = e.target.value.trim(); });
state.showAnime = ${user?.show_anime ? "true" : "false"};
document.getElementById("anime").addEventListener("change", e => { state.showAnime = e.target.checked; });

// Trakt PIN flow is wired on the server side (see src/trakt-oauth.ts and the
// /api/trakt/{start,poll} routes) but no catalog row consumes Trakt tokens
// yet. Surfacing a "link Trakt" affordance here would set the expectation
// that something then happens, and brutal honesty says nothing does. The UI
// returns once a Trakt-driven row ships in v0.6+.

let stimer = null;
const search = document.getElementById("search");
const results = document.getElementById("results");
search.addEventListener("input", () => {
  clearTimeout(stimer);
  const q = search.value.trim();
  if (!q) { results.style.display = "none"; results.innerHTML = ""; return; }
  stimer = setTimeout(async () => {
    const r = await fetch("/api/search?q=" + encodeURIComponent(q)).then(r => r.json()).catch(() => ({results:[]}));
    const items = (r.results || []).slice(0, 8);
    if (!items.length) { results.style.display = "none"; return; }
    results.innerHTML = items.map(it => '<div class="search-row" data-id="' + it.id + '" data-poster="' + (it.poster||"") + '" data-title="' + (it.title||"").replace(/"/g,"&quot;") + '"><img src="' + (it.poster||"") + '" alt=""><div class="meta-text"><div class="title">' + it.title + '</div><div class="yk">' + (it.year||"") + ' &middot; ' + it.kind + '</div></div></div>').join("");
    results.style.display = "block";
    results.querySelectorAll(".search-row").forEach(row => row.addEventListener("click", () => {
      if (state.faves.length >= 5) return;
      if (state.faves.some(f => f.id === row.dataset.id)) return;
      state.faves.push({ id: row.dataset.id, poster: row.dataset.poster, title: row.dataset.title });
      renderPicks();
      search.value = ""; results.style.display = "none";
    }));
  }, 220);
});

// Pair flow.
let activeCode = null, pollTimer = null;
function setStatus(s) { document.getElementById("pairStatus").textContent = s; }
async function startPair() {
  document.getElementById("pairBlock").style.display = "none";
  document.getElementById("pairActive").style.display = "block";
  try {
    const r = await fetch("/api/pair/create", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ userId: USER_ID }),
    }).then(r => r.json());
    if (r.err) { setStatus("Stremio rejected the pair request: " + r.err); return; }
    activeCode = r.code;
    document.getElementById("codeText").textContent = r.code.split("").join(" ");
    document.getElementById("qrImg").src = r.qrcode || ("https://link.stremio.com/qr?data=" + encodeURIComponent(r.link));
    document.getElementById("pairLinkText").textContent = (r.link || "link.stremio.com").replace(/^https?:\\/\\//, "");
    pollPair();
  } catch { setStatus("Could not reach Stremio's pairing service."); }
}
async function pollPair() {
  if (!activeCode) return;
  try {
    const r = await fetch("/api/pair/poll", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ userId: USER_ID, code: activeCode }),
    }).then(r => r.json());
    if (r.status === "linked") {
      document.getElementById("pairActive").style.display = "none";
      document.getElementById("pairDone").style.display = "block";
      document.getElementById("pairDoneMsg").textContent = "Linked. Imported " + r.imported + " items, " + r.watched + " watched. The homepage is being shaped now.";
      return;
    }
    if (r.err) { setStatus("Error: " + r.err); return; }
  } catch {}
  pollTimer = setTimeout(pollPair, 3000);
}
const pairBtn = document.getElementById("pairBtn");
if (pairBtn) pairBtn.addEventListener("click", startPair);
const rePair = document.getElementById("rePair");
if (rePair) rePair.addEventListener("click", () => {
  document.getElementById("pairBlock").style.display = "none";
  startPair();
});

document.getElementById("save").addEventListener("click", async () => {
  document.getElementById("saved").hidden = true;
  const res = await fetch("/api/install", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      userId: USER_ID,
      mood: state.mood,
      letterboxd: state.lb || undefined,
      showAnime: state.showAnime,
      faves: state.faves.map(f => f.id),
    }),
  }).then(r => r.json()).catch(() => null);
  if (res && res.id) {
    const saved = document.getElementById("saved");
    saved.hidden = false;
    setTimeout(() => { saved.hidden = true; }, 1800);
  }
});
</script>
</body>
</html>`;
}
