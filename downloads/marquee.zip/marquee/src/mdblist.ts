// MDBList - one API call returns aggregate ratings (IMDb / Rotten Tomatoes /
// Metacritic / TMDB / Trakt / Letterboxd / Roger Ebert) for any tt-id.
//
// End users never supply an API key. The key is an operator-side worker
// secret (env.MDBLIST_KEY) provided once by whoever is hosting Marquee.
// We cache aggressively (7d per title) so the shared free-tier rate limit
// is never an issue for a realistic userbase.

import type { Env } from "./types.js";

const MDBLIST_BASE = "https://api.mdblist.com";

export interface AggRatings {
  imdb?: number;
  rt?: number;
  metacritic?: number;
  letterboxd?: number;
  tmdb?: number;
  trakt?: number;
}

interface MDBItem {
  imdbid?: string;
  ratings?: Array<{ source: string; value: number | null }>;
}

const _cache = new Map<string, { ts: number; data: AggRatings }>();
const TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

export async function fetchAggRatings(env: Env, imdbId: string): Promise<AggRatings | null> {
  const key = env.MDBLIST_KEY;
  if (!key) return null;
  const cached = _cache.get(imdbId);
  if (cached && Date.now() - cached.ts < TTL_MS) return cached.data;
  const url = `${MDBLIST_BASE}/?i=${encodeURIComponent(imdbId)}&apikey=${encodeURIComponent(key)}`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) return null;
  const data = (await res.json()) as MDBItem;
  const out: AggRatings = {};
  for (const r of data.ratings ?? []) {
    if (r.value === null) continue;
    switch (r.source) {
      case "imdb": out.imdb = r.value; break;
      case "rottentomatoes": out.rt = r.value; break;
      case "metacritic": out.metacritic = r.value; break;
      case "letterboxd": out.letterboxd = r.value; break;
      case "tmdb": out.tmdb = r.value; break;
      case "trakt": out.trakt = r.value; break;
    }
  }
  _cache.set(imdbId, { ts: Date.now(), data: out });
  return out;
}

// Curator-list fetch. URL form: https://mdblist.com/lists/<user>/<slug>
// API:  https://api.mdblist.com/lists/<id>/items?apikey=...
interface MDBListItem {
  imdb_id?: string;
  imdbid?: string;
  rank?: number;
}
export async function fetchListItems(env: Env, listId: string): Promise<{ imdb: string; rank?: number }[]> {
  const key = env.MDBLIST_KEY;
  if (!key) return [];
  const url = `${MDBLIST_BASE}/lists/${encodeURIComponent(listId)}/items?apikey=${encodeURIComponent(key)}`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) return [];
  const data = (await res.json()) as MDBListItem[];
  const out: { imdb: string; rank?: number }[] = [];
  for (const it of data) {
    const id = it.imdb_id ?? it.imdbid;
    if (id && id.startsWith("tt")) {
      const entry: { imdb: string; rank?: number } = { imdb: id };
      if (it.rank !== undefined) entry.rank = it.rank;
      out.push(entry);
    }
  }
  return out;
}
