// Bounded-concurrency limiter for outbound TMDB calls. TMDB allows ~50
// requests/second per IP. The Workers runtime can issue all 50 in parallel
// on a single isolate without any limiter and will only 429 if a single
// cron run fans out wider. The limiter exists for those bursts.
//
// Also handles 429 Retry-After parsing for graceful backoff.

export class Limiter {
  private active = 0;
  private queue: Array<() => void> = [];
  constructor(private readonly maxConcurrent: number) {}

  async acquire(): Promise<void> {
    if (this.active < this.maxConcurrent) {
      this.active++;
      return;
    }
    await new Promise<void>((resolve) => this.queue.push(resolve));
    this.active++;
  }

  release(): void {
    this.active--;
    const next = this.queue.shift();
    if (next) next();
  }

  async run<T>(fn: () => Promise<T>): Promise<T> {
    await this.acquire();
    try {
      return await fn();
    } finally {
      this.release();
    }
  }
}

export const tmdbLimiter = new Limiter(20); // well below TMDB's 50/sec ceiling

// Retries an HTTP call once on 429 with the server's Retry-After hint
// (capped at 5s to avoid blowing the catalog response budget).
export async function fetchWithBackoff(url: string | URL, init: RequestInit = {}): Promise<Response> {
  let res = await fetch(url, init);
  if (res.status === 429) {
    const ra = Number(res.headers.get("retry-after") ?? "1");
    const wait = Math.min(Math.max(0.25, isFinite(ra) ? ra : 1), 5) * 1000;
    await new Promise((r) => setTimeout(r, wait));
    res = await fetch(url, init);
  }
  return res;
}
