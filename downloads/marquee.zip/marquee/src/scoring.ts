// Borrowed from the open-source recommender survey (Watchly, More-Like-This,
// IMDb's own formula). These are small, well-tested primitives.

// IMDb's Bayesian weighted-rating formula:
//   WR = (v/(v+m)) * R + (m/(v+m)) * C
// where R is the title's mean rating, v is its number of votes, C is the
// mean rating across the entire pool, and m is the minimum votes required to
// be considered. With C=6.8 and m=150 the formula does the right thing for
// TMDB scale (~0..10) - it pulls "8.5 with 30 votes" down toward C while
// barely touching "7.8 with 50,000 votes".
export function bayesianShrunk(
  rating: number,
  voteCount: number,
  C = 6.8,
  m = 150,
): number {
  const v = Math.max(0, voteCount);
  return (v / (v + m)) * rating + (m / (v + m)) * C;
}

// FNV-1a 32-bit. Web-Crypto-free, deterministic, fast in a Worker.
function fnv1a(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h;
}

// Daily-rotation epsilon - a stable-but-fresh tie-breaker. Two titles with
// the same shrunk rating land in a different order each day, but within a
// day the order is fixed (so cached responses stay valid). Watchly does this
// via md5(seed:tmdb_id); we use FNV for speed and lack of WebCrypto-async.
//
// Output range: [0, 1e-3) - small enough not to outrank meaningful score
// differences, big enough to break ties.
export function dailyEpsilon(seed: string, id: string): number {
  const day = Math.floor(Date.now() / 86_400_000);
  const h = fnv1a(`${day}:${seed}:${id}`);
  return (h % 1_000_000) / 1_000_000_000;
}

// MMR-style diversity reranker. Walks the input in score order and at each
// step picks the next item whose genre overlap with already-picked items is
// minimised. With LAMBDA=0.7 we still mostly preserve original ranking; the
// effect is to break up runs of "five thrillers in a row" without sacrificing
// quality. Items without genreIds pass through (no penalty information).
export function diversityRerank<T extends { id: string; genreIds?: number[] }>(items: T[], lambda = 0.7): T[] {
  if (items.length <= 2) return items;
  const remaining = items.slice();
  const out: T[] = [];
  const pickedGenreCounts = new Map<number, number>();
  // First item is always the top-ranked.
  const first = remaining.shift();
  if (!first) return items;
  out.push(first);
  for (const g of first.genreIds ?? []) pickedGenreCounts.set(g, 1);
  // Subsequent items: max(lambda*originalRank - (1-lambda)*genreOverlap).
  // We rank by original order (i.e. index), so "high rank" = low index.
  // Equivalent formulation: minimise (lambda * idx + (1-lambda) * overlap).
  while (remaining.length) {
    let bestIdx = 0;
    let bestScore = Infinity;
    for (let i = 0; i < remaining.length; i++) {
      const item = remaining[i]!;
      let overlap = 0;
      for (const g of item.genreIds ?? []) overlap += pickedGenreCounts.get(g) ?? 0;
      const score = lambda * i + (1 - lambda) * overlap;
      if (score < bestScore) {
        bestScore = score;
        bestIdx = i;
      }
    }
    const picked = remaining.splice(bestIdx, 1)[0]!;
    out.push(picked);
    for (const g of picked.genreIds ?? []) {
      pickedGenreCounts.set(g, (pickedGenreCounts.get(g) ?? 0) + 1);
    }
  }
  return out;
}

// Borda-count multi-source blender. Used to merge candidate lists from
// multiple sources (TMDB recs + Trakt similar + Letterboxd-friend likes +
// Wikidata awards + MDBList). Each source returns an ordered list of IMDb
// IDs; we score by (consensus count) primary and (average rank) tiebreak.
// More-Like-This's pattern, deliberately source-weight-free.
export interface SourceList { name: string; ids: string[] }

export function bordaBlend(sources: SourceList[]): string[] {
  const acc = new Map<string, { count: number; rankSum: number; sources: string[] }>();
  for (const src of sources) {
    src.ids.forEach((id, idx) => {
      const cur = acc.get(id);
      if (cur) {
        cur.count++;
        cur.rankSum += idx;
        cur.sources.push(src.name);
      } else {
        acc.set(id, { count: 1, rankSum: idx, sources: [src.name] });
      }
    });
  }
  return [...acc.entries()]
    .sort((a, b) => {
      if (a[1].count !== b[1].count) return b[1].count - a[1].count;
      const aAvg = a[1].rankSum / a[1].count;
      const bAvg = b[1].rankSum / b[1].count;
      return aAvg - bAvg;
    })
    .map(([id]) => id);
}
