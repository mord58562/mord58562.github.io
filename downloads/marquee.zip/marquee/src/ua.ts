// User-Agent classification for the /configure surface.
// Stremio TV clients (Android TV, tvOS, webOS, Tizen) cannot render a real
// settings page usably - keyboards on remotes are unworkable. We detect them
// and short-circuit to a phone-handoff view.

export type Surface = "tv" | "phone" | "tablet" | "desktop" | "web" | "unknown";

export function classifyUA(ua: string | null): Surface {
  if (!ua) return "unknown";
  const s = ua.toLowerCase();

  // Stremio's TV builds set distinctive substrings.
  if (s.includes("androidtv") || s.includes("android tv")) return "tv";
  if (s.includes("appletv") || s.includes("tvos")) return "tv";
  if (s.includes("webos") || s.includes("tizen") || s.includes("smarttv") || s.includes("smart-tv") || s.includes("googletv")) return "tv";
  // Stremio's user agent identifies its variants by name; on TV builds it
  // typically includes "TV" in the parenthetical.
  if (/stremio[^)]*tv/i.test(ua)) return "tv";

  // Android phone vs tablet.
  if (s.includes("android")) return s.includes("mobile") ? "phone" : "tablet";

  // iOS - iPhone is a phone, iPad is a tablet. Modern iPads send a desktop UA;
  // we can detect that via "Macintosh" + touch, but for /configure we don't
  // need to differentiate phone vs tablet, both render the same UI.
  if (s.includes("iphone")) return "phone";
  if (s.includes("ipad")) return "tablet";

  // Stremio web on browsers.
  if (s.includes("stremio")) return "desktop";

  if (s.includes("mobile")) return "phone";
  if (s.includes("macintosh") || s.includes("windows") || s.includes("linux x86")) return "desktop";

  return "web";
}

export function isUnusableForForms(surface: Surface): boolean {
  return surface === "tv";
}
