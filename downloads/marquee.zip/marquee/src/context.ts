// Zero-click context awareness.
//
// Cloudflare Workers expose a per-request `cf` object that carries country,
// latitude, longitude, timezone - derived from the IP, no user input required.
// We use it to compute:
//
//   - local hour-of-day  (early / morning / afternoon / evening / late)
//   - day-of-week        (weekend rhythm vs weeknight rhythm)
//   - lunar phase        (no API needed - computable from a known new moon)
//   - weather code       (Open-Meteo, no key)
//   - upcoming holiday   (date.nager.at, no key)
//
// The context feeds the Tonight row's mood selection silently. The user
// experiences "the addon knows me" without realising why. Apple-style.

export type LocalSlot = "early" | "morning" | "afternoon" | "evening" | "late";
export type LunarPhase = "new" | "waxing" | "full" | "waning";
export type WeatherClass = "clear" | "cloud" | "rain" | "snow" | "storm" | "unknown";

export interface Ctx {
  country?: string;
  latitude?: number;
  longitude?: number;
  hourLocal: number;       // 0-23
  slot: LocalSlot;
  dayOfWeek: number;       // 0=Sun
  isWeekendEvening: boolean;
  lunar: LunarPhase;
  weather: WeatherClass;
  upcomingHoliday?: string;
}

// Known new moon: 2000-01-06 18:14 UTC.
const NEW_MOON_EPOCH_MS = Date.UTC(2000, 0, 6, 18, 14, 0);
const LUNAR_MS = 29.53058867 * 86400_000;

export function lunarPhase(date = new Date()): LunarPhase {
  const cycle = ((date.getTime() - NEW_MOON_EPOCH_MS) % LUNAR_MS) / LUNAR_MS;
  // Map [0, 1) to phase:
  //   0.00-0.07  new
  //   0.07-0.42  waxing
  //   0.42-0.58  full
  //   0.58-0.93  waning
  //   0.93-1.00  new
  if (cycle < 0.07 || cycle >= 0.93) return "new";
  if (cycle < 0.42) return "waxing";
  if (cycle < 0.58) return "full";
  return "waning";
}

export function hourSlot(hourLocal: number): LocalSlot {
  if (hourLocal >= 5 && hourLocal <= 8) return "early";
  if (hourLocal >= 9 && hourLocal <= 11) return "morning";
  if (hourLocal >= 12 && hourLocal <= 17) return "afternoon";
  if (hourLocal >= 18 && hourLocal <= 22) return "evening";
  return "late";
}

interface CFGeo {
  country?: string;
  latitude?: string | number;
  longitude?: string | number;
  timezone?: string;
}

interface OpenMeteoCurrent {
  current_weather?: { weathercode?: number; time?: string };
}

// Open-Meteo weather codes: 0=clear, 1-3=cloud, 45-48=fog, 51-67=rain, 71-77=snow, 80-82=showers, 85-86=snow, 95-99=storm.
function classifyWeather(code?: number): WeatherClass {
  if (code === undefined) return "unknown";
  if (code === 0) return "clear";
  if (code <= 3) return "cloud";
  if (code <= 48) return "cloud";
  if (code <= 67) return "rain";
  if (code <= 77) return "snow";
  if (code <= 82) return "rain";
  if (code <= 86) return "snow";
  if (code <= 99) return "storm";
  return "unknown";
}

async function fetchWeatherCached(env: { CACHE_WEATHER?: Map<string, { ts: number; code: number }> }, lat: number, lon: number): Promise<number | undefined> {
  // Module-scope cache to spare Open-Meteo from per-request hits. 1h TTL is
  // more than enough - recommendations don't need minute-by-minute weather.
  const cache = env.CACHE_WEATHER ?? new Map();
  if (!env.CACHE_WEATHER) env.CACHE_WEATHER = cache;
  const key = `${lat.toFixed(2)}:${lon.toFixed(2)}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.ts < 3600_000) return hit.code;
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=UTC`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) return undefined;
    const data = await res.json() as OpenMeteoCurrent;
    const code = data.current_weather?.weathercode;
    if (typeof code === "number") {
      cache.set(key, { ts: Date.now(), code });
      return code;
    }
  } catch {
    // Open-Meteo briefly down is fine - context falls back to "unknown".
  }
  return undefined;
}

interface NagerHoliday {
  date: string;
  localName: string;
  name: string;
}

const HOLIDAY_CACHE = new Map<string, { ts: number; data: NagerHoliday[] }>();

async function fetchHolidaysCached(country: string, year: number): Promise<NagerHoliday[]> {
  const key = `${country}:${year}`;
  const hit = HOLIDAY_CACHE.get(key);
  if (hit && Date.now() - hit.ts < 86400_000) return hit.data;
  try {
    const url = `https://date.nager.at/api/v3/PublicHolidays/${year}/${country}`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) {
      HOLIDAY_CACHE.set(key, { ts: Date.now(), data: [] });
      return [];
    }
    const data = await res.json() as NagerHoliday[];
    HOLIDAY_CACHE.set(key, { ts: Date.now(), data });
    return data;
  } catch {
    return [];
  }
}

function findUpcomingHoliday(holidays: NagerHoliday[], now: Date): string | undefined {
  const today = now.toISOString().slice(0, 10);
  for (const h of holidays) {
    if (h.date < today) continue;
    const days = (Date.parse(h.date) - Date.parse(today)) / 86400_000;
    if (days <= 14) return h.name;
  }
  return undefined;
}

// Best-effort timezone offset derivation. CF gives timezone string; we use
// Intl to compute the local time when available, otherwise fall back to UTC.
function localHour(tz: string | undefined, now: Date): number {
  try {
    if (tz) {
      const s = new Intl.DateTimeFormat("en", { hour: "numeric", hour12: false, timeZone: tz }).format(now);
      const n = Number(s);
      if (Number.isFinite(n)) return n;
    }
  } catch { /* ignore */ }
  return now.getUTCHours();
}

function localDow(tz: string | undefined, now: Date): number {
  try {
    if (tz) {
      const s = new Intl.DateTimeFormat("en", { weekday: "short", timeZone: tz }).format(now);
      const map: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
      const n = map[s];
      if (typeof n === "number") return n;
    }
  } catch { /* ignore */ }
  return now.getUTCDay();
}

export async function deriveContext(request: Request): Promise<Ctx> {
  const cf = (request as unknown as { cf?: CFGeo }).cf ?? {};
  const now = new Date();
  const country = typeof cf.country === "string" ? cf.country : undefined;
  const lat = typeof cf.latitude === "string" ? Number(cf.latitude) : (typeof cf.latitude === "number" ? cf.latitude : undefined);
  const lon = typeof cf.longitude === "string" ? Number(cf.longitude) : (typeof cf.longitude === "number" ? cf.longitude : undefined);
  const tz = typeof cf.timezone === "string" ? cf.timezone : undefined;

  const hourLocal = localHour(tz, now);
  const dow = localDow(tz, now);
  const slot = hourSlot(hourLocal);
  const isWeekendEvening = (dow === 5 && slot === "evening") || (dow === 6 && (slot === "evening" || slot === "afternoon")) || (dow === 0 && slot === "evening");

  // Module-level mutable cache map smuggled via globalThis; on a Worker this
  // lives for the lifetime of the isolate.
  const weatherEnv = (globalThis as unknown as { __weatherCache?: Map<string, { ts: number; code: number }> });
  weatherEnv.__weatherCache ??= new Map();

  const [weatherCode, holidays] = await Promise.all([
    lat !== undefined && lon !== undefined && Number.isFinite(lat) && Number.isFinite(lon)
      ? fetchWeatherCached({ CACHE_WEATHER: weatherEnv.__weatherCache }, lat, lon)
      : Promise.resolve(undefined),
    country ? fetchHolidaysCached(country, now.getUTCFullYear()) : Promise.resolve([] as NagerHoliday[]),
  ]);

  const ctx: Ctx = {
    hourLocal,
    slot,
    dayOfWeek: dow,
    isWeekendEvening,
    lunar: lunarPhase(now),
    weather: classifyWeather(weatherCode),
  };
  if (country) ctx.country = country;
  if (lat !== undefined) ctx.latitude = lat;
  if (lon !== undefined) ctx.longitude = lon;
  const upcoming = findUpcomingHoliday(holidays, now);
  if (upcoming) ctx.upcomingHoliday = upcoming;
  return ctx;
}

// Pick a mood from the context. This is the "Apple thoughtfulness" layer:
// the user never asked us to consider the weather, but they would expect
// recs to feel right for a rainy Tuesday evening or a full-moon Friday.
export function inferMood(ctx: Ctx, fallback: string): string {
  // Holiday overrides.
  if (ctx.upcomingHoliday) {
    const h = ctx.upcomingHoliday.toLowerCase();
    if (h.includes("halloween") || h.includes("all saints")) return "intense";
    if (h.includes("christmas") || h.includes("new year")) return "comfort";
    if (h.includes("valentine")) return "quiet";
  }
  // Friday/Saturday evening defaults to fun unless weather/lunar pulls otherwise.
  if (ctx.lunar === "full" && (ctx.slot === "evening" || ctx.slot === "late")) return "intense";
  if (ctx.weather === "rain" && (ctx.slot === "evening" || ctx.slot === "late")) return "quiet";
  if (ctx.weather === "snow" && ctx.slot !== "early") return "comfort";
  if (ctx.isWeekendEvening) return "fun";
  if (ctx.slot === "afternoon") return "curious";
  if (ctx.slot === "late") return "intense";
  if (ctx.slot === "early") return "quiet";
  return fallback;
}
