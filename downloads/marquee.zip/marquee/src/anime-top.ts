// Curated anime list. Each entry carries the IMDb id (for back-compat and
// for resolving against title_cache) plus a Kitsu numeric id used as the
// emitted catalog id. Stream addons in the anime ecosystem (Torrentio,
// Comet, Knightcrawler, TorBox) only return anime streams for kitsu:-
// prefixed ids; emitting tt: would resolve meta via Cinemeta but yield
// thin/empty stream lists for the same title. The anime row is opt-in
// and the /configure copy points users at the Anime Kitsu addon for
// kitsu: metadata coverage.
//
// Add new entries here as they release - IMDb id and Kitsu id both
// verified by hand against the public pages on imdb.com and kitsu.io.

export interface AnimeEntry { year: number; title: string; kitsu: number }

export const ANIME_TOP: Record<string, AnimeEntry> = {
  tt0213338:  { year: 1998, title: "Cowboy Bebop",                    kitsu: 1 },
  tt0877057:  { year: 2006, title: "Death Note",                      kitsu: 1376 },
  tt2560140:  { year: 2013, title: "Attack on Titan",                 kitsu: 7442 },
  tt1355642:  { year: 2009, title: "Fullmetal Alchemist: Brotherhood", kitsu: 3936 },
  tt2098220:  { year: 2011, title: "Hunter x Hunter",                 kitsu: 6448 },
  tt0388629:  { year: 1999, title: "One Piece",                       kitsu: 12 },
  tt8431546:  { year: 2019, title: "Vinland Saga",                    kitsu: 41084 },
  tt1910272:  { year: 2011, title: "Steins;Gate",                     kitsu: 5646 },
  tt0772153:  { year: 2006, title: "Code Geass",                      kitsu: 1415 },
  tt5897148:  { year: 2016, title: "Mob Psycho 100",                  kitsu: 11578 },
  tt9335498:  { year: 2019, title: "Demon Slayer: Kimetsu no Yaiba",  kitsu: 41370 },
  tt22248376: { year: 2023, title: "Frieren: Beyond Journey's End",   kitsu: 46474 },
  tt7222086:  { year: 2017, title: "Made in Abyss",                   kitsu: 13273 },
  tt0420644:  { year: 2004, title: "Monster",                         kitsu: 10 },
  tt0112159:  { year: 1995, title: "Neon Genesis Evangelion",         kitsu: 21 },
  tt0409591:  { year: 2002, title: "Naruto",                          kitsu: 11 },
  tt12343534: { year: 2022, title: "Spy x Family",                    kitsu: 45398 },
  tt13616990: { year: 2019, title: "Jujutsu Kaisen",                  kitsu: 42765 },
};

export function listAnimeIds(): string[] {
  return Object.keys(ANIME_TOP);
}

// Reverse map from kitsu:<id> -> IMDb id, built once at module load. Used by
// the meta/stream handlers to fold kitsu attention events back onto the same
// IMDb-keyed rollups everything else in Marquee uses (title_cache, profile,
// watchedSet). Without this fold, anime clicks would land in their own
// orphaned namespace and never influence row ordering.
const KITSU_TO_IMDB: Map<string, string> = new Map(
  Object.entries(ANIME_TOP).map(([imdb, entry]) => [`kitsu:${entry.kitsu}`, imdb]),
);

export function kitsuToImdb(id: string): string | null {
  return KITSU_TO_IMDB.get(id) ?? null;
}
