import { fetchWithBackoff, tmdbLimiter } from "./limiter.js";
import { getTitleCache, upsertTitleCache } from "./storage.js";
import type { Env, TitleCacheRow } from "./types.js";

const TMDB = "https://api.themoviedb.org/3";
const STALE_MS = 1000 * 60 * 60 * 24 * 30; // 30 days

interface TMDBFindResult {
  movie_results: Array<{ id: number; original_language?: string; vote_count?: number; vote_average?: number; genre_ids?: number[]; release_date?: string }>;
  tv_results: Array<{ id: number; original_language?: string; vote_count?: number; vote_average?: number; genre_ids?: number[]; first_air_date?: string }>;
}

interface TMDBFullMovie {
  id: number;
  title?: string;
  original_title?: string;
  genres: Array<{ id: number; name: string }>;
  original_language?: string;
  vote_count?: number;
  vote_average?: number;
  release_date?: string;
  credits?: { crew?: Array<{ job?: string; name: string }> };
}

interface TMDBFullTV {
  id: number;
  name?: string;
  original_name?: string;
  genres: Array<{ id: number; name: string }>;
  original_language?: string;
  vote_count?: number;
  vote_average?: number;
  first_air_date?: string;
  created_by?: Array<{ name: string }>;
  credits?: { crew?: Array<{ job?: string; name: string }> };
}

async function tmdbGet<T>(env: Env, path: string, query: Record<string, string> = {}): Promise<T | null> {
  const url = new URL(TMDB + path);
  for (const [k, v] of Object.entries(query)) url.searchParams.set(k, v);
  return tmdbLimiter.run(async () => {
    const res = await fetchWithBackoff(url, {
      headers: { Authorization: `Bearer ${env.TMDB_BEARER}`, Accept: "application/json" },
    });
    if (!res.ok) return null;
    return res.json() as Promise<T>;
  });
}

async function fetchOne(env: Env, imdbId: string): Promise<TitleCacheRow | null> {
  const found = await tmdbGet<TMDBFindResult>(env, `/find/${imdbId}`, { external_source: "imdb_id" });
  if (!found) return null;
  const m = found.movie_results?.[0];
  const tv = found.tv_results?.[0];
  if (m) {
    const full = await tmdbGet<TMDBFullMovie>(env, `/movie/${m.id}`, { append_to_response: "credits" });
    if (!full) return null;
    const director = full.credits?.crew?.find((c) => c.job === "Director")?.name ?? null;
    return {
      imdb_id: imdbId,
      tmdb_id: full.id,
      type: "movie",
      title: full.title ?? full.original_title ?? null,
      genres_json: JSON.stringify((full.genres ?? []).map((g) => g.name)),
      year: full.release_date ? Number(full.release_date.slice(0, 4)) : null,
      director,
      original_language: full.original_language ?? null,
      vote_count: full.vote_count ?? null,
      vote_average: full.vote_average ?? null,
      refreshed_at: Date.now(),
    };
  }
  if (tv) {
    const full = await tmdbGet<TMDBFullTV>(env, `/tv/${tv.id}`, { append_to_response: "credits" });
    if (!full) return null;
    const director = full.created_by?.[0]?.name ?? full.credits?.crew?.find((c) => c.job === "Director")?.name ?? null;
    return {
      imdb_id: imdbId,
      tmdb_id: full.id,
      type: "series",
      title: full.name ?? full.original_name ?? null,
      genres_json: JSON.stringify((full.genres ?? []).map((g) => g.name)),
      year: full.first_air_date ? Number(full.first_air_date.slice(0, 4)) : null,
      director,
      original_language: full.original_language ?? null,
      vote_count: full.vote_count ?? null,
      vote_average: full.vote_average ?? null,
      refreshed_at: Date.now(),
    };
  }
  return null;
}

export async function enrichTitles(env: Env, imdbIds: string[]): Promise<Map<string, TitleCacheRow>> {
  const have = await getTitleCache(env, imdbIds);
  const now = Date.now();
  const missing = imdbIds.filter((id) => {
    const row = have.get(id);
    return !row || !row.refreshed_at || now - row.refreshed_at > STALE_MS;
  });
  // Concurrency-bounded fetch - TMDB tolerates ~50 rps; we do 8 at a time.
  const CONC = 8;
  for (let i = 0; i < missing.length; i += CONC) {
    const slice = missing.slice(i, i + CONC);
    const results = await Promise.all(slice.map((id) => fetchOne(env, id).catch(() => null)));
    for (const row of results) {
      if (row) {
        await upsertTitleCache(env, row);
        have.set(row.imdb_id, row);
      }
    }
  }
  return have;
}
