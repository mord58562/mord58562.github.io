import { ROWS } from "./rows.js";
import type { Env, UserRow } from "./types.js";

// Default sort key per row: lower is better. These define the static order
// for an anonymous install (no engagement signal). Personalized installs
// reorder by per-user engagement score on top of this base.
const ROW_BASE_PRIORITY: Record<string, number> = {
  tonight: 0,                  // daily ritual stays at top
  "continue-watching": 1,      // in-flight beats anything else when present
  "watchlist-intent": 2,       // "you've been eyeing this"
  echoes: 3,
  "from-your-decade": 4,
  "short-worth-it": 5,
  "weekend-deep-dive": 6,
  "festival-darlings": 7,
  "long-tail": 8,
  "outside-your-cone": 9,
  awards: 10,
  essentials: 11,
  "critic-picks": 12,
  "beloved-bombs": 13,
  adapted: 14,
  "anime-top": 15,
};

export async function buildManifestAsync(env: Env, user: UserRow | null) {
  const hasProfile = !!user;
  // Profile-aware rows are advertised only when the user is identified - for
  // anonymous installs we keep the homepage clean and don't surface empty rows.
  // Rows that need user signal to make sense are hidden until the user has it.
  // For anonymous installs the homepage is still strong via essentials,
  // awards, critic-picks, beloved-bombs, adapted - all zero-input. Anime is
  // opt-in (hidden unless the user enables it).
  const showAnime = !!(user && (user as unknown as { show_anime?: number }).show_anime);
  const visibleRows = ROWS.filter((r) => {
    if (["echoes", "from-your-decade", "outside-your-cone", "watchlist-intent", "continue-watching"].includes(r.id)) {
      return hasProfile;
    }
    if (r.id === "anime-top") return showAnime;
    return true;
  });

  // Adaptive ordering: per-user engagement (from row_engagement) layered on
  // top of the base priority. A row that the user has clicked into recently
  // (high engagement score) gets boosted; a row they've never touched stays
  // at its base position.
  const { loadRowScores } = await import("./row-engagement.js");
  const scores = user ? await loadRowScores(env, user.id).catch(() => new Map<string, number>()) : new Map<string, number>();
  const orderedRows = [...visibleRows].sort((a, b) => {
    const sa = (scores.get(a.id) ?? 0) - (ROW_BASE_PRIORITY[a.id] ?? 99) / 100;
    const sb = (scores.get(b.id) ?? 0) - (ROW_BASE_PRIORITY[b.id] ?? 99) / 100;
    return sb - sa;
  });
  return {
    id: "com.mord58562.marquee",
    version: env.ADDON_VERSION,
    name: env.ADDON_NAME,
    description:
      "A homepage curated like a rep cinema. Hand-designed rows with sharp identities, slow rotation, and a stated reason for each pick.",
    logo: "https://raw.githubusercontent.com/mord58562/marquee/main/public/logo.svg",
    background: "https://raw.githubusercontent.com/mord58562/marquee/main/public/background.svg",
    contactEmail: "mord58562@proton.me",
    resources: [
      "catalog",
      // We deliberately do NOT register `meta`. Cinemeta owns detail-page
      // rendering for tt-prefixed IDs and that's what users expect. Marquee's
      // value-add is richer catalog tiles (imdbRating + releaseInfo + per-row
      // rationale on each MetaPreview), not a competing meta provider.
      //
      // Stream stays a no-op so Torrentio, Real-Debrid, and every other stream
      // add-on populate the source-selection screen unchanged. We use the
      // request as a play-signal side channel only.
      { name: "stream", types: ["movie", "series"], idPrefixes: ["tt"] },
    ],
    types: ["movie", "series"],
    idPrefixes: ["tt"],
    catalogs: orderedRows.map((r) => ({
      type: r.type,
      id: r.id,
      name: r.name,
      extra: r.extra,
    })),
    behaviorHints: {
      configurable: true,
      configurationRequired: false,
    },
  };
}
