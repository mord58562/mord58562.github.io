// Static metadata for the Letterboxd top-50 IMDb IDs. Baked in so the
// Essentials row renders fully-populated tiles on first install (before any
// title_cache warming has happened). Year is the field that shows on the
// tile as a release badge in most Stremio clients.
//
// All entries are verified against well-established public knowledge -
// release year and title only. IMDb ratings are deliberately omitted because
// they fluctuate over time; the cron-warmed title_cache fills imdbRating
// for clients that show it.

export interface EssentialEntry { year: number; title: string }

export const LB_TOP_50_META: Record<string, EssentialEntry> = {
  tt0111161: { year: 1994, title: "The Shawshank Redemption" },
  tt0068646: { year: 1972, title: "The Godfather" },
  tt0468569: { year: 2008, title: "The Dark Knight" },
  tt0050083: { year: 1957, title: "12 Angry Men" },
  tt0167260: { year: 2003, title: "The Lord of the Rings: The Return of the King" },
  tt0108052: { year: 1993, title: "Schindler's List" },
  tt0110912: { year: 1994, title: "Pulp Fiction" },
  tt0120737: { year: 2001, title: "The Lord of the Rings: The Fellowship of the Ring" },
  tt0060196: { year: 1966, title: "The Good, the Bad and the Ugly" },
  tt0109830: { year: 1994, title: "Forrest Gump" },
  tt0167261: { year: 2002, title: "The Lord of the Rings: The Two Towers" },
  tt0137523: { year: 1999, title: "Fight Club" },
  tt1375666: { year: 2010, title: "Inception" },
  tt0073486: { year: 1975, title: "One Flew Over the Cuckoo's Nest" },
  tt0099685: { year: 1990, title: "Goodfellas" },
  tt0080684: { year: 1980, title: "The Empire Strikes Back" },
  tt0133093: { year: 1999, title: "The Matrix" },
  tt0047478: { year: 1954, title: "Seven Samurai" },
  tt0114369: { year: 1995, title: "Seven" },
  tt0317248: { year: 2002, title: "City of God" },
  tt0816692: { year: 2014, title: "Interstellar" },
  tt0102926: { year: 1991, title: "The Silence of the Lambs" },
  tt0038650: { year: 1946, title: "It's a Wonderful Life" },
  tt0245429: { year: 2001, title: "Spirited Away" },
  tt0120815: { year: 1998, title: "Saving Private Ryan" },
  tt0118799: { year: 1997, title: "Life Is Beautiful" },
  tt0120586: { year: 1998, title: "American History X" },
  tt6751668: { year: 2019, title: "Parasite" },
  tt0103064: { year: 1991, title: "Terminator 2: Judgment Day" },
  tt0088763: { year: 1985, title: "Back to the Future" },
  tt0054215: { year: 1960, title: "Psycho" },
  tt0021749: { year: 1931, title: "City Lights" },
  tt0253474: { year: 2002, title: "The Pianist" },
  tt0027977: { year: 1936, title: "Modern Times" },
  tt2582802: { year: 2014, title: "Whiplash" },
  tt0407887: { year: 2006, title: "The Departed" },
  tt0095327: { year: 1988, title: "Grave of the Fireflies" },
  tt0064116: { year: 1968, title: "Once Upon a Time in the West" },
  tt0034583: { year: 1942, title: "Casablanca" },
  tt0078788: { year: 1979, title: "Apocalypse Now" },
  tt1675434: { year: 2011, title: "The Intouchables" },
  tt0209144: { year: 2000, title: "Memento" },
  tt0110413: { year: 1994, title: "Léon: The Professional" },
  tt0082971: { year: 1981, title: "Raiders of the Lost Ark" },
  tt0405094: { year: 2006, title: "The Lives of Others" },
  tt0078748: { year: 1979, title: "Alien" },
  tt0114814: { year: 1995, title: "The Usual Suspects" },
  tt0086190: { year: 1983, title: "Star Wars: Return of the Jedi" },
};
