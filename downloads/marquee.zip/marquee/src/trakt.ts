import type { Env, MetaPreview, StremioType } from "./types.js";

const TRAKT = "https://api.trakt.tv";

interface TraktIds {
  imdb: string | null;
  tmdb: number | null;
  trakt: number;
  slug: string;
}

interface TraktMovieEntry {
  movie: { title: string; year: number; ids: TraktIds };
}

interface TraktShowEntry {
  show: { title: string; year: number; ids: TraktIds };
}

async function traktFetch<T>(env: Env, path: string): Promise<T> {
  const res = await fetch(TRAKT + path, {
    headers: {
      "trakt-api-version": "2",
      "trakt-api-key": env.TRAKT_CLIENT_ID,
      "Content-Type": "application/json",
    },
  });
  if (!res.ok) {
    throw new Error(`trakt ${path} -> ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export async function traktTrending(env: Env, type: StremioType, limit = 40): Promise<MetaPreview[]> {
  if (type === "movie") {
    const data = await traktFetch<TraktMovieEntry[]>(env, `/movies/trending?limit=${limit}`);
    return data
      .filter((e) => e.movie.ids.imdb)
      .map((e) => ({
        id: e.movie.ids.imdb!,
        type: "movie" as const,
        name: e.movie.title,
        releaseInfo: String(e.movie.year),
      }));
  } else {
    const data = await traktFetch<TraktShowEntry[]>(env, `/shows/trending?limit=${limit}`);
    return data
      .filter((e) => e.show.ids.imdb)
      .map((e) => ({
        id: e.show.ids.imdb!,
        type: "series" as const,
        name: e.show.title,
        releaseInfo: String(e.show.year),
      }));
  }
}

export async function traktAnticipated(env: Env, type: StremioType, limit = 40): Promise<MetaPreview[]> {
  if (type === "movie") {
    const data = await traktFetch<TraktMovieEntry[]>(env, `/movies/anticipated?limit=${limit}`);
    return data
      .filter((e) => e.movie.ids.imdb)
      .map((e) => ({
        id: e.movie.ids.imdb!,
        type: "movie" as const,
        name: e.movie.title,
        releaseInfo: String(e.movie.year),
      }));
  } else {
    const data = await traktFetch<TraktShowEntry[]>(env, `/shows/anticipated?limit=${limit}`);
    return data
      .filter((e) => e.show.ids.imdb)
      .map((e) => ({
        id: e.show.ids.imdb!,
        type: "series" as const,
        name: e.show.title,
        releaseInfo: String(e.show.year),
      }));
  }
}
