// Verified IMDb-ID arrays for essentials-style rows. Every ID in this file
// is a real film I can attest to by name; lists I could not verify against
// authoritative sources have been removed rather than shipped speculatively.
//
// LETTERBOXD_TOP_50 is a snapshot of the kinds of films that consistently
// appear in Letterboxd's all-time popular charts. We treat it as a working
// "broadly-loved films" sample, not as a claim to be the live Letterboxd
// top 50. (The live chart is dynamic; pulling it from Letterboxd directly
// is a v0.6 task.)

export const LETTERBOXD_TOP_50 = [
  "tt0111161", // The Shawshank Redemption
  "tt0068646", // The Godfather
  "tt0468569", // The Dark Knight
  "tt0050083", // 12 Angry Men
  "tt0167260", // The Lord of the Rings: The Return of the King
  "tt0108052", // Schindler's List
  "tt0110912", // Pulp Fiction
  "tt0120737", // The Lord of the Rings: The Fellowship of the Ring
  "tt0060196", // The Good, the Bad and the Ugly
  "tt0109830", // Forrest Gump
  "tt0167261", // The Lord of the Rings: The Two Towers
  "tt0137523", // Fight Club
  "tt1375666", // Inception
  "tt0073486", // One Flew Over the Cuckoo's Nest
  "tt0099685", // Goodfellas
  "tt0080684", // The Empire Strikes Back
  "tt0133093", // The Matrix
  "tt0047478", // Seven Samurai
  "tt0114369", // Seven
  "tt0317248", // City of God
  "tt0816692", // Interstellar
  "tt0102926", // The Silence of the Lambs
  "tt0038650", // It's a Wonderful Life
  "tt0245429", // Spirited Away
  "tt0120815", // Saving Private Ryan
  "tt0118799", // Life Is Beautiful
  "tt0120586", // American History X
  "tt6751668", // Parasite
  "tt0103064", // Terminator 2: Judgment Day
  "tt0088763", // Back to the Future
  "tt0054215", // Psycho
  "tt0021749", // City Lights
  "tt0253474", // The Pianist
  "tt0027977", // Modern Times
  "tt2582802", // Whiplash
  "tt0407887", // The Departed
  "tt0095327", // Grave of the Fireflies
  "tt0064116", // Once Upon a Time in the West
  "tt0034583", // Casablanca
  "tt0078788", // Apocalypse Now
  "tt1675434", // The Intouchables
  "tt0209144", // Memento
  "tt0110413", // Léon: The Professional
  "tt0082971", // Raiders of the Lost Ark
  "tt0405094", // The Lives of Others
  "tt0078748", // Alien
  "tt0114814", // The Usual Suspects
  "tt0086190", // Star Wars: Return of the Jedi
];

export function dedup(ids: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const id of ids) {
    if (!id || !id.startsWith("tt") || seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  return out;
}
