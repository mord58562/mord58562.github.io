// Wikidata SPARQL - open, no auth, returns IMDb IDs for award winners.
//
// We use a small set of pre-written queries and cache the results in a
// module-level map for the lifetime of the Worker isolate. For production
// each query result is also dropped into D1's title_cache for next-cold-start
// reuse (TODO: schema doesn't have a generic kv-of-lists table yet, so we
// just keep it in-memory for v0.3).

const ENDPOINT = "https://query.wikidata.org/sparql";
const _cache = new Map<string, { ts: number; data: string[] }>();
const TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7d

async function runSPARQL(query: string): Promise<Array<Record<string, string>>> {
  const url = `${ENDPOINT}?format=json&query=${encodeURIComponent(query)}`;
  const res = await fetch(url, {
    headers: {
      Accept: "application/sparql-results+json",
      "User-Agent": "Marquee/0.3 (+https://github.com/mord58562/marquee)",
    },
  });
  if (!res.ok) return [];
  const data = (await res.json()) as {
    results?: { bindings?: Array<Record<string, { value?: string }>> };
  };
  const out: Array<Record<string, string>> = [];
  for (const b of data.results?.bindings ?? []) {
    const row: Record<string, string> = {};
    for (const [k, v] of Object.entries(b)) {
      if (v?.value) row[k] = v.value;
    }
    out.push(row);
  }
  return out;
}

const AWARDS: Record<string, string> = {
  // Wikidata award QIDs. Only entries we have verified ship here; unverified
  // ones were removed rather than risk wrong attributions in the catalog.
  palme_dor: "Q179808",
  oscar_best_picture: "Q102427",
  bafta_best_film: "Q15326",
  cannes_grand_prix: "Q3057678",
};

export async function imdbIdsForAward(awardKey: string, since?: number): Promise<string[]> {
  const cacheKey = `${awardKey}:${since ?? "all"}`;
  const cached = _cache.get(cacheKey);
  if (cached && Date.now() - cached.ts < TTL_MS) return cached.data;

  const qid = AWARDS[awardKey];
  if (!qid) return [];
  // P166 = "award received"; P345 = "IMDb ID"; P577 = "publication date".
  const sinceClause = since ? `FILTER(YEAR(?date) >= ${since})` : "";
  const query = `
SELECT ?film ?imdbId ?date WHERE {
  ?film wdt:P166 wd:${qid} ;
        wdt:P345 ?imdbId .
  OPTIONAL { ?film wdt:P577 ?date }
  ${sinceClause}
}
LIMIT 200`;
  const rows = await runSPARQL(query);
  const ids = rows
    .map((r) => r["imdbId"])
    .filter((s): s is string => !!s && s.startsWith("tt"));
  // Dedupe while preserving order.
  const seen = new Set<string>();
  const out: string[] = [];
  for (const id of ids) {
    if (seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  _cache.set(cacheKey, { ts: Date.now(), data: out });
  return out;
}

// Adapted-from-book: films whose Wikidata says "based on" (P144) a literary work.
export async function imdbIdsAdaptedFromBooks(limit = 200): Promise<string[]> {
  const cached = _cache.get("adapted");
  if (cached && Date.now() - cached.ts < TTL_MS) return cached.data;
  const query = `
SELECT DISTINCT ?film ?imdbId WHERE {
  ?film wdt:P144 ?work ;
        wdt:P345 ?imdbId ;
        wdt:P31/wdt:P279* wd:Q11424 .
  ?work wdt:P31/wdt:P279* wd:Q571 .
}
LIMIT ${limit}`;
  const rows = await runSPARQL(query);
  const ids = rows
    .map((r) => r["imdbId"])
    .filter((s): s is string => !!s && s.startsWith("tt"));
  const seen = new Set<string>();
  const out: string[] = [];
  for (const id of ids) {
    if (seen.has(id)) continue;
    seen.add(id);
    out.push(id);
  }
  _cache.set("adapted", { ts: Date.now(), data: out });
  return out;
}
