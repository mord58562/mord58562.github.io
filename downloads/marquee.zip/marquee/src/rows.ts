import type { RowDef } from "./types.js";

// Row labels are deliberately flat and declarative. A rep-cinema programme
// just names the section; it does not editorialise. Anything cute reads as
// AI prose at scale.
export const ROWS: RowDef[] = [
  {
    id: "tonight",
    type: "movie",
    name: "Tonight",
    extra: [
      {
        name: "genre",
        options: ["Quiet", "Fun", "Intense", "Curious", "Comfort"],
        isRequired: false,
      },
    ],
  },
  {
    id: "short-worth-it",
    type: "movie",
    name: "Under 95 minutes",
  },
  {
    id: "weekend-deep-dive",
    type: "series",
    name: "Limited series",
  },
  {
    id: "festival-darlings",
    type: "movie",
    name: "Recent",
  },
  {
    id: "long-tail",
    type: "movie",
    name: "Lesser-known",
  },
  {
    id: "echoes",
    type: "movie",
    name: "Like what you've watched",
  },
  {
    id: "from-your-decade",
    type: "movie",
    name: "Your decade",
  },
  {
    id: "outside-your-cone",
    type: "movie",
    name: "Less typical for you",
  },
  // v0.3 - every row below works in anonymous state too (degrades gracefully).
  {
    id: "watchlist-intent",
    type: "movie",
    name: "On your mind",
  },
  {
    id: "continue-watching",
    type: "movie",
    name: "Continue",
  },
  {
    id: "awards",
    type: "movie",
    name: "Award winners",
  },
  {
    id: "essentials",
    type: "movie",
    name: "Essentials",
  },
  {
    id: "critic-picks",
    type: "movie",
    name: "Critics this week",
  },
  {
    id: "beloved-bombs",
    type: "movie",
    name: "Beloved bombs",
  },
  {
    id: "adapted",
    type: "movie",
    name: "Adapted from books",
  },
  {
    id: "anime-top",
    type: "series",
    name: "Anime worth watching",
  },
];
