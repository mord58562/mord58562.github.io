// Per-user row engagement tracking. Powers adaptive manifest ordering so
// rows the user actually clicks into surface higher.
//
// Mechanism: when a catalog row returns IDs, we sample the top ~12 and
// record them in row_recent. When a meta or stream event fires for an IMDb
// ID, we attribute the event proportionally to any rows that recently
// included that ID. Scores decay so old engagement fades.

import type { Env } from "./types.js";

const RECENT_TTL_MS = 1000 * 60 * 60 * 24 * 7; // a week
const SAMPLE_PER_ROW = 12;

// Record a sample of IDs returned by `rowId` for `userId`. Fire-and-forget
// from the catalog handler via ctx.waitUntil so it never blocks the
// response.
export async function recordRowSample(
  env: Env,
  userId: string,
  rowId: string,
  imdbIds: string[],
): Promise<void> {
  if (!userId || imdbIds.length === 0) return;
  const sample = imdbIds.slice(0, SAMPLE_PER_ROW);
  const ts = Date.now();
  // Single multi-row INSERT via D1's batch API. ON CONFLICT updates the
  // timestamp so we always have the freshest sample. One round-trip vs
  // SAMPLE_PER_ROW round-trips on the prior loop.
  const stmt = env.DB.prepare(
    `INSERT INTO row_recent (user_id, row_id, imdb_id, ts)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(user_id, row_id, imdb_id) DO UPDATE SET ts = excluded.ts`,
  );
  await env.DB.batch(sample.map((id) => stmt.bind(userId, rowId, id, ts))).catch(() => {});
}

// Credit an event (meta/stream) to any rows that recently surfaced this
// ID for this user. Called from the meta/stream handlers, also via
// ctx.waitUntil.
export async function creditEvent(
  env: Env,
  userId: string,
  imdbId: string,
  weight: number,
): Promise<void> {
  if (!userId) return;
  const cutoff = Date.now() - RECENT_TTL_MS;
  const res = await env.DB.prepare(
    `SELECT row_id FROM row_recent WHERE user_id = ? AND imdb_id = ? AND ts >= ?`,
  ).bind(userId, imdbId, cutoff).all<{ row_id: string }>().catch(() => ({ results: [] as Array<{ row_id: string }> }));
  const rows = res.results ?? [];
  if (rows.length === 0) return;
  // Split the credit across all rows that surfaced the ID, so if a film was
  // in two rows the user clicking it doesn't double-count.
  const share = weight / rows.length;
  const now = Date.now();
  for (const r of rows) {
    await env.DB.prepare(
      `INSERT INTO row_engagement (user_id, row_id, score, last_seen)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(user_id, row_id) DO UPDATE SET
         score = row_engagement.score + excluded.score,
         last_seen = excluded.last_seen`,
    ).bind(userId, r.row_id, share, now).run().catch(() => {});
  }
}

// Returns a recency-decayed engagement score per row for a user. Rows the
// user has never engaged with return undefined (caller decides default).
export async function loadRowScores(env: Env, userId: string): Promise<Map<string, number>> {
  const HALF_LIFE_MS = 1000 * 60 * 60 * 24 * 30; // 30d
  const res = await env.DB.prepare(
    `SELECT row_id, score, last_seen FROM row_engagement WHERE user_id = ?`,
  ).bind(userId).all<{ row_id: string; score: number; last_seen: number }>().catch(() => ({ results: [] as Array<{ row_id: string; score: number; last_seen: number }> }));
  const out = new Map<string, number>();
  const now = Date.now();
  for (const r of res.results ?? []) {
    const age = now - r.last_seen;
    const decayed = r.score * Math.pow(0.5, age / HALF_LIFE_MS);
    if (decayed > 0.001) out.set(r.row_id, decayed);
  }
  return out;
}
