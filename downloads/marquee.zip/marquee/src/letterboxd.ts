// Letterboxd integration - public profile only, no credentials, no scraping
// of authenticated pages. We use the per-user RSS feed Letterboxd has always
// exposed at `https://letterboxd.com/{username}/rss/`. The RSS includes the
// title, year, the user's own rating (in stars), the watched date, and -
// load-bearingly - the TMDB id. Mapping to IMDb is a single TMDB call per
// title via /movie/{tmdb}/external_ids (already cached by titleenrich).
//
// "Just work" requirements applied here:
//   - User supplies one field (username). Nothing else.
//   - Silent backfill on save. The user sees a count, never a progress bar.
//   - Ratings are weighted with the user's own stars (a 5/5 in their diary
//     counts much harder than a 2/5, exactly like their library data does).
//   - Negative weight on titles the user rated <=2 stars (these become
//     genre/director suppression signal in profile derivation).
//   - Cached aggressively to not hammer Letterboxd.

import { recordLibraryImport } from "./attention.js";
import { tmdbToImdb } from "./tmdb.js";
import type { Env } from "./types.js";

interface LBEntry {
  tmdb_id: number;
  type: "movie" | "series";
  watched_ts: number | null;
  member_rating_05: number | null; // 0..5 stars on Letterboxd scale, 0.5 increments
}

const LB_USER_AGENT = "Marquee/0.1 (+https://github.com/mord58562/marquee)";

function pickFirst(s: string, re: RegExp): string | null {
  const m = s.match(re);
  return m && m[1] ? m[1] : null;
}

export function parseDiaryRSS(xml: string): LBEntry[] {
  const items = xml.split(/<item>/i).slice(1);
  const out: LBEntry[] = [];
  for (const raw of items) {
    const body = (raw.split(/<\/item>/i)[0] ?? "");
    // Only diary entries (watch / review). A user's RSS can also include lists
    // and stories; we skip those.
    const guid = pickFirst(body, /<guid[^>]*>([^<]+)<\/guid>/i) ?? "";
    if (!/letterboxd-(watch|review)/i.test(guid)) continue;

    const tmdbStr = pickFirst(body, /<tmdb:movieId>(\d+)<\/tmdb:movieId>/i)
      ?? pickFirst(body, /<letterboxd:tmdbId>(\d+)<\/letterboxd:tmdbId>/i);
    if (!tmdbStr) continue;
    const tmdb_id = Number(tmdbStr);
    if (!Number.isFinite(tmdb_id)) continue;

    const ratingStr = pickFirst(body, /<letterboxd:memberRating>([\d.]+)<\/letterboxd:memberRating>/i);
    const member_rating_05 = ratingStr ? Number(ratingStr) : null;

    let watched_ts: number | null = null;
    const watchedDate = pickFirst(body, /<letterboxd:watchedDate>([^<]+)<\/letterboxd:watchedDate>/i);
    if (watchedDate) {
      const parsed = Date.parse(watchedDate);
      if (!isNaN(parsed)) watched_ts = parsed;
    }
    if (watched_ts === null) {
      const pub = pickFirst(body, /<pubDate>([^<]+)<\/pubDate>/i);
      if (pub) {
        const parsed = Date.parse(pub);
        if (!isNaN(parsed)) watched_ts = parsed;
      }
    }

    out.push({ tmdb_id, type: "movie", watched_ts, member_rating_05 });
  }
  return out;
}

export async function fetchDiary(username: string): Promise<LBEntry[]> {
  const url = `https://letterboxd.com/${encodeURIComponent(username)}/rss/`;
  const res = await fetch(url, { headers: { "User-Agent": LB_USER_AGENT, Accept: "application/rss+xml" } });
  if (!res.ok) return [];
  const xml = await res.text();
  return parseDiaryRSS(xml);
}

// Convert an LB entry into the attention.recordLibraryImport input shape.
// Mapping rules:
//   - 4.0..5.0 stars  -> completion_ratio 1.0, flagged_watched true (strong positive)
//   - 2.5..3.5 stars  -> completion_ratio 1.0, flagged_watched true (neutral positive - they watched it)
//   - 0.5..2.0 stars  -> completion_ratio 0.05, flagged_watched false (counts as ABANDONED → negative weight)
//   - no rating       -> completion_ratio null, flagged_watched true (they watched it but didn't rate)
function entryToLibraryItem(imdb: string, e: LBEntry): {
  imdb_id: string;
  type: "movie" | "series";
  last_watched_ts: number | null;
  times_watched: number;
  completion_ratio: number | null;
  flagged_watched: boolean;
} {
  const r = e.member_rating_05;
  let completion: number | null;
  let flagged: boolean;
  if (r === null) {
    completion = null;
    flagged = true;
  } else if (r >= 4.0) {
    completion = 1.0;
    flagged = true;
  } else if (r >= 2.5) {
    completion = 1.0;
    flagged = true;
  } else {
    completion = 0.05;
    flagged = false; // abandoned → triggers negative weighting in profile derivation
  }
  return {
    imdb_id: imdb,
    type: e.type,
    last_watched_ts: e.watched_ts,
    times_watched: 1,
    completion_ratio: completion,
    flagged_watched: flagged,
  };
}

export interface LBImportSummary {
  total: number;
  resolved: number;
  loved: number; // rated >= 4 stars
}

export async function ingestLetterboxd(env: Env, userId: string, username: string): Promise<LBImportSummary> {
  const entries = await fetchDiary(username);
  if (entries.length === 0) return { total: 0, resolved: 0, loved: 0 };

  // Resolve TMDB→IMDb in bounded concurrency. tmdbToImdb has an in-memory cache.
  const items: Array<{ imdb_id: string; type: "movie" | "series"; last_watched_ts: number | null; times_watched: number; completion_ratio: number | null; flagged_watched: boolean }> = [];
  const CONC = 6;
  for (let i = 0; i < entries.length; i += CONC) {
    const slice = entries.slice(i, i + CONC);
    const mapped = await Promise.all(slice.map(async (e) => {
      const imdb = await tmdbToImdb(env, e.type, e.tmdb_id).catch(() => null);
      if (!imdb) return null;
      return entryToLibraryItem(imdb, e);
    }));
    for (const m of mapped) if (m) items.push(m);
  }
  if (items.length === 0) return { total: entries.length, resolved: 0, loved: 0 };
  await recordLibraryImport(env, userId, items);
  const loved = entries.filter((e) => (e.member_rating_05 ?? 0) >= 4).length;
  return { total: entries.length, resolved: items.length, loved };
}
