// Shared CSS for the /configure page. Visual register: minimal settings panel.
// No gradients, no shadcn defaults, no soft cards, no border-radius on inputs,
// system fonts only. The page is a settings panel inside Stremio, not a
// website - there is no hero, no marketing.

export const STYLE_CSS = `
  :root {
    --ink: #f1e9d7;
    --paper: #14110e;
    --paper-bright: #1c1814;
    --rule: rgba(241, 233, 215, 0.18);
    --curtain: #a4392c;
    --dim: rgba(241, 233, 215, 0.62);
    --dimmer: rgba(241, 233, 215, 0.40);
  }
  @media (prefers-color-scheme: light) {
    :root {
      --ink: #211d18;
      --paper: #efe7d4;
      --paper-bright: #f5eedc;
      --rule: rgba(33, 29, 24, 0.22);
      --curtain: #8e2e23;
      --dim: rgba(33, 29, 24, 0.62);
      --dimmer: rgba(33, 29, 24, 0.42);
    }
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; background: var(--paper); color: var(--ink); }
  body {
    font-family: -apple-system, "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-size: 15px;
    line-height: 1.55;
  }
  .serif { font-family: "Iowan Old Style", "Palatino Linotype", Palatino, "Times New Roman", Georgia, serif; }
  .mono  { font-family: ui-monospace, "SF Mono", Menlo, "Cascadia Mono", monospace; }
  .page { max-width: 640px; margin: 0 auto; padding: 40px 30px 80px; }
  h1 {
    font-family: "Iowan Old Style", "Palatino Linotype", Palatino, Georgia, serif;
    font-weight: 400;
    font-size: 36px;
    letter-spacing: -0.01em;
    margin: 0 0 4px;
  }
  h1 + .dek { color: var(--dim); font-style: italic; margin: 0 0 28px; }
  h2.section {
    font-size: 11px;
    letter-spacing: 0.22em;
    text-transform: uppercase;
    color: var(--dim);
    font-weight: 600;
    margin: 28px 0 10px;
    padding-top: 18px;
    border-top: 1px solid var(--rule);
  }
  p { margin: 0 0 14px; max-width: 60ch; }
  .helper { color: var(--dim); font-size: 13px; font-style: italic; margin: 6px 0 0; }
  a { color: var(--ink); text-decoration: underline; text-underline-offset: 3px; text-decoration-thickness: 1px; }
  a:hover { color: var(--curtain); }
  input[type=text] {
    width: 100%;
    padding: 9px 0;
    background: transparent;
    border: 0;
    border-bottom: 1px solid var(--ink);
    color: var(--ink);
    font: inherit;
    font-size: 17px;
    font-family: "Iowan Old Style", "Palatino Linotype", Palatino, Georgia, serif;
  }
  input[type=text]:focus { outline: none; border-bottom-color: var(--curtain); }
  input[type=text]::placeholder { color: var(--dimmer); font-style: italic; }
  .url-typable {
    font-family: ui-monospace, "SF Mono", Menlo, monospace;
    font-size: 14px;
    background: var(--paper-bright);
    padding: 10px 12px;
    border: 1px solid var(--rule);
    word-break: break-all;
    user-select: all;
  }
  button.action {
    background: transparent;
    border: 0;
    padding: 4px 0;
    cursor: pointer;
    color: var(--curtain);
    font: inherit;
    font-family: "Iowan Old Style", Georgia, serif;
    font-style: italic;
    font-size: 18px;
    border-bottom: 1px solid var(--curtain);
  }
  button.action:hover { color: var(--ink); border-bottom-color: var(--ink); }
  .moods { font-family: "Iowan Old Style", Georgia, serif; font-size: 18px; line-height: 1.9; }
  .mood-tag {
    display: inline-block; margin-right: 22px; cursor: pointer;
    color: var(--dim); user-select: none;
  }
  .mood-tag.active { color: var(--curtain); font-style: italic; }
  .mood-tag .pre { font-family: ui-monospace, monospace; font-size: 13px; margin-right: 4px; color: inherit; }
  .qr-block { text-align: center; padding: 14px 0; }
  .qr-block img { width: 200px; height: 200px; image-rendering: pixelated; background: white; padding: 8px; }
  .qr-code {
    font-family: ui-monospace, monospace;
    font-size: 42px; letter-spacing: 0.16em;
    text-align: center; margin: 12px 0;
  }
  .pair-status { font-style: italic; color: var(--dim); text-align: center; margin: 10px 0; }
  .pair-status.ok { color: var(--curtain); }
  .colophon {
    margin-top: 48px; padding-top: 18px; border-top: 1px solid var(--rule);
    font-size: 12px; color: var(--dimmer); letter-spacing: 0.04em;
  }
  .colophon a { color: var(--dim); }
`;
