import { recordAttention } from "./attention.js";
import { buildCatalog } from "./catalogs.js";
import { indexPage, settingsPage, tvHandoffPage } from "./configure.js";
import { deriveContext } from "./context.js";
import { ingestLetterboxd } from "./letterboxd.js";
import { fetchWithBackoff } from "./limiter.js";
import { buildManifestAsync } from "./manifest.js";
import { creditEvent, recordRowSample } from "./row-engagement.js";
import { refreshProfile } from "./profile.js";
import { createUser, getUser, looksLikeUserId, touchUser, updateUserPrefs } from "./storage.js";
import { ingestLibrary, linkCreate, linkRead } from "./stremio-link.js";
import { classifyUA } from "./ua.js";
import type { Env, UserRow } from "./types.js";

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function json(body: unknown, init: { status?: number; maxAge?: number } = {}): Response {
  const headers: Record<string, string> = {
    "Content-Type": "application/json; charset=utf-8",
    ...CORS,
  };
  // We deliberately bypass HTTP caching here. Stremio respects the
  // `cacheMaxAge` / `staleRevalidate` fields in the response BODY for its
  // own catalog cache, and our cross-isolate TMDB cache lives in KV.
  // Setting HTTP Cache-Control on top caused a wrangler-dev Workers Cache
  // bug where empty responses got persistently cached.
  headers["Cache-Control"] = "no-store";
  void init.maxAge;
  return new Response(JSON.stringify(body), { status: init.status ?? 200, headers });
}

function html(body: string): Response {
  return new Response(body, {
    headers: { "Content-Type": "text/html; charset=utf-8", ...CORS, "Cache-Control": "no-store" },
  });
}

function notFound(): Response {
  return json({ err: "not found" }, { status: 404 });
}

interface ParsedRoute {
  userId?: string;
  resource:
    | "manifest"
    | "configure"
    | "catalog"
    | "meta"
    | "stream"
    | "search"
    | "install"
    | "userget"
    | "pair_create"
    | "pair_poll";
  type?: string;
  id?: string;
  extra?: string;
}

function parseRoute(pathname: string): ParsedRoute | null {
  const parts = pathname.replace(/^\/+|\/+$/g, "").split("/");
  if (parts.length === 0 || parts[0] === "") return null;

  if (parts[0] === "api" && parts[1] === "search") return { resource: "search" };
  if (parts[0] === "api" && parts[1] === "install") return { resource: "install" };
  if (parts[0] === "api" && parts[1] === "user" && parts[2]) {
    return { resource: "userget", userId: parts[2] };
  }
  if (parts[0] === "api" && parts[1] === "pair" && parts[2] === "create") {
    return { resource: "pair_create" };
  }
  if (parts[0] === "api" && parts[1] === "pair" && parts[2] === "poll") {
    return { resource: "pair_poll" };
  }

  const TOP = new Set(["manifest.json", "configure", "catalog", "meta", "stream", "api"]);
  let i = 0;
  let userId: string | undefined;
  if (parts[0] && !TOP.has(parts[0])) {
    // Treat first segment as user ID if it looks like one. Otherwise reject -
    // we no longer support the old base64-config-in-URL format.
    if (looksLikeUserId(parts[0])) userId = parts[0];
    else return null;
    i = 1;
  }

  const head = parts[i];
  if (head === "manifest.json") return { userId, resource: "manifest" };
  if (head === "configure") return { userId, resource: "configure" };

  if (head === "catalog" || head === "meta" || head === "stream") {
    const type = parts[i + 1];
    const tail = parts[i + 2];
    if (!type || !tail) return null;
    if (head === "catalog") {
      const extraTail = parts[i + 3];
      if (extraTail) {
        if (!extraTail.endsWith(".json")) return null;
        return { userId, resource: "catalog", type, id: tail, extra: extraTail.slice(0, -5) };
      }
      if (!tail.endsWith(".json")) return null;
      return { userId, resource: "catalog", type, id: tail.slice(0, -5) };
    } else {
      if (!tail.endsWith(".json")) return null;
      return { userId, resource: head, type, id: tail.slice(0, -5) };
    }
  }

  return null;
}

async function handleSearch(env: Env, url: URL): Promise<Response> {
  const q = url.searchParams.get("q")?.trim();
  if (!q) return json({ results: [] });
  const res = await fetchWithBackoff(
    `https://api.themoviedb.org/3/search/multi?query=${encodeURIComponent(q)}&include_adult=false&page=1`,
    { headers: { Authorization: `Bearer ${env.TMDB_BEARER}`, Accept: "application/json" } },
  );
  if (!res.ok) return json({ results: [] }, { status: 200 });
  const data = (await res.json()) as { results: Array<Record<string, unknown>> };
  const out = (data.results ?? [])
    .filter((r) => r["media_type"] === "movie" || r["media_type"] === "tv")
    .slice(0, 12)
    .map((r) => {
      const mt = r["media_type"] as string;
      const title = (r["title"] ?? r["name"] ?? "Untitled") as string;
      const dateStr = (r["release_date"] ?? r["first_air_date"] ?? "") as string;
      const posterPath = r["poster_path"] as string | null;
      return {
        // Search returns TMDB ids; we'll resolve to IMDb on /api/install via the
        // /find endpoint, but to keep this fast we just pass the tmdb id back.
        id: `tmdb:${mt}:${r["id"]}`,
        kind: mt === "movie" ? "Film" : "Series",
        title,
        year: dateStr ? dateStr.slice(0, 4) : null,
        poster: posterPath ? `https://image.tmdb.org/t/p/w154${posterPath}` : null,
      };
    });
  return json({ results: out }, { maxAge: 600 });
}

interface InstallBody {
  faves?: string[];
  mood?: string | null;
  letterboxd?: string | null;
  showAnime?: boolean;
  userId?: string;
}

async function tmdbIdToImdb(env: Env, mt: string, tmdbId: string): Promise<string | null> {
  const path = mt === "movie" ? `/movie/${tmdbId}/external_ids` : `/tv/${tmdbId}/external_ids`;
  const res = await fetchWithBackoff(`https://api.themoviedb.org/3${path}`, {
    headers: { Authorization: `Bearer ${env.TMDB_BEARER}`, Accept: "application/json" },
  });
  if (!res.ok) return null;
  const data = (await res.json()) as { imdb_id?: string | null };
  return data.imdb_id && data.imdb_id.startsWith("tt") ? data.imdb_id : null;
}

async function normalizeFaves(env: Env, raw: string[] | undefined): Promise<string[]> {
  if (!raw) return [];
  const out: string[] = [];
  for (const item of raw.slice(0, 5)) {
    if (item.startsWith("tt")) {
      out.push(item);
    } else if (item.startsWith("tmdb:")) {
      const [, mt, tmdbId] = item.split(":");
      if (!mt || !tmdbId) continue;
      const imdb = await tmdbIdToImdb(env, mt, tmdbId).catch(() => null);
      if (imdb) out.push(imdb);
    }
  }
  return out;
}

async function handleInstall(env: Env, req: Request, ctx: ExecutionContext): Promise<Response> {
  let body: InstallBody;
  try {
    body = (await req.json()) as InstallBody;
  } catch {
    return json({ err: "bad body" }, { status: 400 });
  }
  const faves = await normalizeFaves(env, body.faves);
  const mood = body.mood && body.mood !== "any" ? body.mood : null;
  const letterboxd = body.letterboxd?.trim() || null;
  const showAnime = body.showAnime ? 1 : 0;
  let id: string;
  let previousLetterboxd: string | null = null;
  if (body.userId && looksLikeUserId(body.userId)) {
    const existing = await getUser(env, body.userId);
    if (existing) {
      previousLetterboxd = existing.letterboxd;
      await updateUserPrefs(env, body.userId, { faves, mood, letterboxd });
      id = body.userId;
    } else {
      id = await createUser(env, { faves, mood, letterboxd });
    }
  } else {
    id = await createUser(env, { faves, mood, letterboxd });
  }
  // Side-channel update for show_anime (not on updateUserPrefs).
  await env.DB.prepare("UPDATE users SET show_anime = ? WHERE id = ?")
    .bind(showAnime, id).run().catch(() => {});
  // Silent Letterboxd backfill on first save or when the username changes.
  // We don't wait for it - Workers' waitUntil keeps the request from blocking,
  // and the result lands in D1 by the time the next catalog request runs.
  if (letterboxd && letterboxd !== previousLetterboxd) {
    ctx.waitUntil(
      ingestLetterboxd(env, id, letterboxd)
        .then(() => refreshProfile(env, id))
        .catch(() => {}),
    );
  }
  return json({ id });
}

interface PairCreateBody {
  userId?: string;
}

async function handlePairCreate(env: Env, req: Request): Promise<Response> {
  let body: PairCreateBody = {};
  try {
    body = (await req.json()) as PairCreateBody;
  } catch {
    // empty body is fine - we'll mint a fresh user
  }
  // Resolve userId: existing if valid, otherwise mint.
  let userId: string | null = null;
  if (body.userId && looksLikeUserId(body.userId)) {
    const existing = await getUser(env, body.userId);
    if (existing) userId = body.userId;
  }
  if (!userId) {
    userId = await createUser(env, {});
  }
  try {
    const link = await linkCreate();
    return json({
      userId,
      code: link.code,
      qrcode: link.qrcode ?? null,
      link: link.link ?? `https://link.stremio.com/#${link.code}`,
    });
  } catch (e) {
    return json({ err: `Stremio linkCreate failed: ${e}` }, { status: 502 });
  }
}

interface PairPollBody {
  userId: string;
  code: string;
}

async function handlePairPoll(env: Env, req: Request): Promise<Response> {
  let body: PairPollBody;
  try {
    body = (await req.json()) as PairPollBody;
  } catch {
    return json({ err: "bad body" }, { status: 400 });
  }
  if (!body.userId || !looksLikeUserId(body.userId) || !body.code) {
    return json({ err: "bad userId/code" }, { status: 400 });
  }
  const user = await getUser(env, body.userId);
  if (!user) return json({ err: "no such user" }, { status: 404 });

  const authKey = await linkRead(body.code);
  if (!authKey) {
    return json({ status: "waiting" });
  }
  // The authKey lives here, in memory, just long enough to pull the library.
  // We do not store it anywhere - the user's library is now backfilled as
  // attention events keyed by their marquee userId, and that's all we keep.
  try {
    const summary = await ingestLibrary(env, body.userId, authKey);
    // Refresh derived profile so personalized rows light up immediately.
    await refreshProfile(env, body.userId).catch(() => {});
    return json({
      status: "linked",
      imported: summary.imported,
      watched: summary.watched,
      total: summary.total,
    });
  } catch (e) {
    return json({ status: "error", err: String(e) }, { status: 502 });
  }
}

async function handleUserGet(env: Env, userId: string): Promise<Response> {
  const user = await getUser(env, userId);
  if (!user) return json({ err: "not found" }, { status: 404 });
  return json({
    id: user.id,
    faves: user.faves_json ? JSON.parse(user.faves_json) : [],
    mood: user.mood ?? "any",
    letterboxd: user.letterboxd ?? "",
    showAnime: !!user.show_anime,
    hasStremio: !!user.stremio_enc,
  });
}


// Scheduled handler: Cloudflare Cron Trigger refreshes the derived taste
// profile, re-pulls Letterboxd diaries for users with a username on file,
// and populates title_awards from Wikidata. Triggered every 6h.
async function runScheduled(env: Env): Promise<void> {
  // Active = touched in the last 14 days. Keeps the cron cost bounded.
  const cutoff = Date.now() - 14 * 86400_000;
  const users = await env.DB.prepare(
    "SELECT id, letterboxd FROM users WHERE last_seen >= ? LIMIT 500",
  ).bind(cutoff).all<{ id: string; letterboxd: string | null }>();
  for (const u of users.results ?? []) {
    if (u.letterboxd) await ingestLetterboxd(env, u.id, u.letterboxd).catch(() => {});
    await refreshProfile(env, u.id).catch(() => {});
  }
  // Weekly award refresh - run a Wikidata pull once a day-equivalent
  // (every 4th cron tick - sloppy but cheap; populates title_awards).
  const tick = Math.floor(Date.now() / (6 * 3600_000));
  if (tick % 4 === 0) await refreshAwards(env).catch(() => {});
}

async function refreshAwards(env: Env): Promise<void> {
  const { imdbIdsForAward } = await import("./wikidata.js");
  const { imdbIdsAdaptedFromBooks } = await import("./wikidata.js");
  const { enrichTitles } = await import("./titleenrich.js");
  const { LETTERBOXD_TOP_50 } = await import("./essentials-lists.js");
  const { listAnimeIds } = await import("./anime-top.js");
  const fromYear = new Date().getFullYear() - 30;
  const awards: Array<[string, string]> = [
    ["palme_dor", "palme_dor"],
    ["oscar_best_picture", "oscar_best_picture"],
    ["bafta_best_film", "bafta_best_film"],
    ["cannes_grand_prix", "cannes_grand_prix"],
  ];
  const allIds = new Set<string>([...LETTERBOXD_TOP_50, ...listAnimeIds()]);
  for (const [key, award] of awards) {
    const ids = await imdbIdsForAward(key, fromYear).catch(() => []);
    for (const id of ids) {
      allIds.add(id);
      await env.DB.prepare(
        `INSERT INTO title_awards (imdb_id, award) VALUES (?, ?) ON CONFLICT(imdb_id, award) DO NOTHING`,
      ).bind(id, award).run().catch(() => {});
    }
  }
  const adapted = await imdbIdsAdaptedFromBooks(150).catch(() => []);
  for (const id of adapted) allIds.add(id);
  // Pre-warm title_cache for every static-row ID we'll surface, bounded so a
  // single cron tick can't TMDB-fanout itself into rate-limit territory.
  await enrichTitles(env, [...allIds].slice(0, 250)).catch(() => {});
}

export default {
  async scheduled(_event: ScheduledEvent, env: Env, ctx: ExecutionContext): Promise<void> {
    ctx.waitUntil(runScheduled(env));
  },
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

    const url = new URL(request.url);

    // Browser landing. The product lives inside Stremio, but a person who
    // pastes the Worker URL into a browser should get a one-click way to
    // install - not a redirect off to GitHub.
    if (url.pathname === "/" || url.pathname === "") {
      return html(indexPage(url.origin));
    }

    const route = parseRoute(url.pathname);
    if (!route) return notFound();

    // Look up the user row once if we have an ID. All resources downstream see it.
    let user: UserRow | null = null;
    if (route.userId) {
      user = await getUser(env, route.userId).catch(() => null);
      if (user) await touchUser(env, route.userId).catch(() => {});
    }

    switch (route.resource) {
      case "install":
        if (request.method !== "POST") return json({ err: "POST only" }, { status: 405 });
        return handleInstall(env, request, ctx);

      case "pair_create":
        if (request.method !== "POST") return json({ err: "POST only" }, { status: 405 });
        return handlePairCreate(env, request);

      case "pair_poll":
        if (request.method !== "POST") return json({ err: "POST only" }, { status: 405 });
        return handlePairPoll(env, request);

      case "userget":
        if (!route.userId) return notFound();
        return handleUserGet(env, route.userId);

      case "manifest":
        return json(await buildManifestAsync(env, user), { maxAge: 3600 });

      case "configure": {
        // Stremio opens this URL when the user clicks Configure on an addon.
        // UA-aware: TVs cannot render forms usably, so they get a phone hand-off.
        const surface = classifyUA(request.headers.get("User-Agent"));

        if (route.userId) {
          // Already-paired install (or at least already-identified). Render
          // the settings panel on phone/desktop/web; on TV, hand off to phone.
          if (surface === "tv") {
            return html(tvHandoffPage(url.origin, route.userId));
          }
          return html(settingsPage(url.origin, user, route.userId, env.ADDON_VERSION));
        }

        // No userId yet (the addon was installed at the root /manifest.json).
        // Mint a user and route appropriately.
        const freshId = await createUser(env, {}).catch(() => null);
        if (!freshId) return notFound();
        if (surface === "tv") {
          return html(tvHandoffPage(url.origin, freshId));
        }
        // On a real device, give them a sticky URL so refreshes keep settings.
        return Response.redirect(`${url.origin}/${freshId}/configure`, 302);
      }

      case "search":
        return handleSearch(env, url);

      case "catalog": {
        if (route.type !== "movie" && route.type !== "series") return notFound();
        if (!route.id) return notFound();
        const extra = new URLSearchParams();
        if (route.extra) {
          for (const pair of route.extra.split("&")) {
            const [k, v] = pair.split("=");
            if (k && v !== undefined) extra.set(decodeURIComponent(k), decodeURIComponent(v));
          }
        }
        try {
          // Context derivation does at most two short network calls (weather +
          // holidays, both cached for hours). We bound the wait to 300ms - if
          // those services slow down, we ship the catalog without context.
          const ctxPromise = deriveContext(request).catch(() => undefined);
          const timeout = new Promise<undefined>((res) => setTimeout(() => res(undefined), 300));
          const reqCtx = await Promise.race([ctxPromise, timeout]);
          const data = await buildCatalog(env, user, route.id, extra, reqCtx);
          // Sample the top IDs for engagement attribution. Non-blocking.
          if (user && route.id && data.metas && data.metas.length) {
            const ids = data.metas.map((m) => m.id).filter((id): id is string => !!id && id.startsWith("tt"));
            const rowId = route.id;
            const userId = user.id;
            ctx.waitUntil(recordRowSample(env, userId, rowId, ids).catch(() => {}));
          }
          // Lazy title warming. For static-ID rows (awards, adapted, etc.) the
          // tile name comes from title_cache. On the very first hit before the
          // 6-hour cron has warmed the cache, names render blank. Trigger an
          // enrichTitles in waitUntil so the second hit is fully populated.
          if (data.metas && data.metas.length) {
            const missing = data.metas
              .filter((m) => (!m.name || m.name === "") && m.id.startsWith("tt"))
              .map((m) => m.id)
              .slice(0, 40);
            if (missing.length > 0) {
              ctx.waitUntil(
                import("./titleenrich.js")
                  .then((mod) => mod.enrichTitles(env, missing))
                  .catch(() => {}),
              );
            }
          }
          return json(data, { maxAge: data.cacheMaxAge ?? 3600 });
        } catch (e) {
          return json({ metas: [], err: String(e) }, { status: 200, maxAge: 60 });
        }
      }

      case "meta": {
        // Defensive: not advertised in the manifest. Anything that lands here
        // gets a 404 so Cinemeta handles the lookup. But Stremio fires meta
        // requests to EVERY installed handler that claims tt-prefix, so we
        // also see this as a "user opened detail page" signal even though
        // we don't return metadata. Credit row engagement via waitUntil.
        if (user && route.id && route.id.startsWith("tt") && (route.type === "movie" || route.type === "series")) {
          const id = route.id;
          const t = route.type;
          const userId = user.id;
          ctx.waitUntil(recordAttention(env, userId, id, "meta", t).catch(() => {}));
          ctx.waitUntil(creditEvent(env, userId, id, 1).catch(() => {}));
        }
        return json({ err: "not provided" }, { status: 404 });
      }

      case "stream": {
        // Stremio fires /stream/{id} on Play to every installed stream add-on
        // (Torrentio, Real-Debrid, etc.) in parallel. Marquee replies with an
        // empty stream list, which is the legal "I have nothing here" answer
        // and never appears on the source-selection screen. We log the play
        // event in waitUntil so the response stays sub-100ms.
        if (user && route.id && route.id.startsWith("tt") && (route.type === "movie" || route.type === "series")) {
          const t = route.type;
          const id = route.id;
          const userId = user.id;
          ctx.waitUntil(recordAttention(env, userId, id, "stream", t).catch(() => {}));
          // Stream events earn a row 3x the credit of a meta-open.
          ctx.waitUntil(creditEvent(env, userId, id, 3).catch(() => {}));
        }
        return json({ streams: [] }, { maxAge: 0 });
      }
    }
  },
};
