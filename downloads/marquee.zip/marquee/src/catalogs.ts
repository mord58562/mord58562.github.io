import { ANIME_TOP, listAnimeIds } from "./anime-top.js";
import { attentionRows } from "./attention.js";
import { getTitleCache } from "./storage.js";
import { LETTERBOXD_TOP_50, dedup } from "./essentials-lists.js";
import { LB_TOP_50_META } from "./essentials-meta.js";
import type { Ctx } from "./context.js";
import { inferMood } from "./context.js";
import { recentCriticPicks } from "./critic-feeds.js";
import { fetchAggRatings } from "./mdblist.js";
import { GENRE_NAME_TO_ID, loadProfile, profileGenresToTMDB, profileLanguagesToISO } from "./profile.js";
import { bayesianShrunk, dailyEpsilon, diversityRerank } from "./scoring.js";
import { discoverWithStats } from "./tmdb.js";
import type { RankableMeta } from "./tmdb.js";
import { traktTrending } from "./trakt.js";
import { imdbIdsAdaptedFromBooks, imdbIdsForAward } from "./wikidata.js";
import type { CatalogResponse, DerivedProfile, Env, MetaPreview, UserRow } from "./types.js";

const DAY = 86400;
const EMPTY_PROFILE: DerivedProfile = {
  topGenres: [],
  topDecades: [],
  topDirectors: [],
  topLanguages: [],
  watchedSet: new Set(),
  totalEvents: 0,
  derivedAt: 0,
};

// Mood -> TMDB genre/quality tuning. Genre IDs are stable TMDB constants:
// 18=Drama 10749=Romance 28=Action 53=Thriller 35=Comedy 12=Adventure
// 27=Horror 99=Doc 80=Crime 9648=Mystery 10751=Family 10752=War
// 878=Sci-Fi 14=Fantasy.
const MOOD_TUNING: Record<
  string,
  { genres?: string; withoutGenres?: string; voteAvg?: number; voteCountLte?: number }
> = {
  quiet: { genres: "18", withoutGenres: "28,53,27,10751", voteAvg: 7.3, voteCountLte: 50000 },
  fun: { genres: "35,12,14", withoutGenres: "27,99,18", voteAvg: 7.0, voteCountLte: 60000 },
  intense: { genres: "53,80,27", voteAvg: 7.0, voteCountLte: 80000 },
  curious: { genres: "99,9648,878", voteAvg: 7.3, voteCountLte: 40000 },
  comfort: { genres: "10751,35", voteAvg: 7.0, voteCountLte: 80000 },
};

function dedupe(metas: MetaPreview[]): MetaPreview[] {
  const seen = new Set<string>();
  const out: MetaPreview[] = [];
  for (const m of metas) {
    if (seen.has(m.id)) continue;
    seen.add(m.id);
    out.push(m);
  }
  return out;
}

function pickByDay(metas: MetaPreview[], n = 1): MetaPreview[] {
  if (metas.length === 0) return [];
  const day = Math.floor(Date.now() / 1000 / DAY);
  const start = day % metas.length;
  const out: MetaPreview[] = [];
  for (let i = 0; i < n && i < metas.length; i++) {
    const item = metas[(start + i) % metas.length];
    if (item) out.push(item);
  }
  return out;
}

function applyProfileFilter(metas: MetaPreview[], profile: DerivedProfile): MetaPreview[] {
  return metas.filter((m) => !profile.watchedSet.has(m.id));
}

// Re-rank candidates by Bayesian-shrunk rating + per-day epsilon, then apply
// MMR-style diversity rerank so back-to-back picks don't all share the same
// top genre. Without shrinkage "9.0 with 60 votes" beats "8.0 with 50,000
// votes" (classic recsys bug). With shrinkage the high-confidence rating
// wins, the daily epsilon makes ties shuffle daily, and diversity rerank
// breaks up genre runs.
function rankByShrunkRating(rowId: string, candidates: RankableMeta[]): RankableMeta[] {
  const sorted = [...candidates].sort((a, b) => {
    const sa = bayesianShrunk(a.voteAverage, a.voteCount) + dailyEpsilon(rowId, a.id);
    const sb = bayesianShrunk(b.voteAverage, b.voteCount) + dailyEpsilon(rowId, b.id);
    return sb - sa;
  });
  return diversityRerank(sorted);
}

function applyProfileFilterRich(metas: RankableMeta[], profile: DerivedProfile): RankableMeta[] {
  return metas.filter((m) => !profile.watchedSet.has(m.id));
}

// Map a ranked TMDB candidate into a Stremio MetaPreview. We fill in
// imdbRating (visible as a star badge in most clients) and releaseInfo
// (visible as a year badge) from data we already have, and optionally set
// a per-row description for the tile's "why this pick" rationale.
function preview(r: RankableMeta, description?: string): MetaPreview {
  const out: MetaPreview = {
    id: r.id,
    type: r.type,
    name: r.name,
  };
  if (r.voteAverage > 0) out.imdbRating = r.voteAverage.toFixed(1);
  if (r.releaseYear) out.releaseInfo = String(r.releaseYear);
  if (description) out.description = description;
  return out;
}

function previewMany(rs: RankableMeta[], descFor?: (r: RankableMeta) => string | undefined): MetaPreview[] {
  return rs.map((r) => preview(r, descFor ? descFor(r) : undefined));
}

export async function buildCatalog(
  env: Env,
  user: UserRow | null,
  rowId: string,
  extra: URLSearchParams,
  ctx?: Ctx,
): Promise<CatalogResponse> {
  const skip = Number(extra.get("skip") ?? "0");
  const genreExtra = (extra.get("genre") ?? "").toLowerCase();
  const profile = user ? await loadProfile(env, user.id).catch(() => EMPTY_PROFILE) : EMPTY_PROFILE;
  // Mood resolution, in priority order:
  //   1) explicit Stremio filter dropdown (genre extra) - user just chose
  //   2) the user's saved mood
  //   3) inferred from request context (weather/time/lunar/holiday) - silent
  //   4) "any"
  const savedMood = user?.mood && user.mood !== "any" ? user.mood : null;
  const inferred = ctx ? inferMood(ctx, "any") : "any";
  const mood = (genreExtra || savedMood || inferred || "any").toLowerCase();

  switch (rowId) {
    case "tonight": {
      const tuning = MOOD_TUNING[mood] ?? { voteAvg: 7.3, voteCountLte: 12000 };
      const candidates = await discoverWithStats(env, "movie", {
        type: "movie",
        sortBy: "vote_average.desc",
        voteCountGte: 3000,
        voteCountLte: tuning.voteCountLte ?? 12000,
        voteAverageGte: tuning.voteAvg ?? 7.3,
        withGenres: tuning.genres ?? profileGenresToTMDB(profile, 4),
        withoutGenres: tuning.withoutGenres,
        page: 1 + Math.floor(skip / 20),
      });
      const ranked = rankByShrunkRating("tonight", applyProfileFilterRich(candidates, profile));
      return wrap(pickByDay(previewMany(ranked), 6), DAY / 4);
    }

    case "short-worth-it": {
      const candidates = await discoverWithStats(env, "movie", {
        type: "movie",
        sortBy: "vote_average.desc",
        voteCountGte: 2000,
        voteAverageGte: 7.3,
        runtimeLte: 95,
        runtimeGte: 60,
        withGenres: profileGenresToTMDB(profile, 5),
        page: 1 + Math.floor(skip / 20),
      });
      const ranked = rankByShrunkRating("short", applyProfileFilterRich(candidates, profile));
      return wrap(previewMany(ranked), DAY);
    }

    case "weekend-deep-dive": {
      const candidates = await discoverWithStats(env, "series", {
        type: "series",
        sortBy: "vote_average.desc",
        voteCountGte: 800,
        voteAverageGte: 8.0,
        page: 1 + Math.floor(skip / 20),
      });
      const ranked = rankByShrunkRating("series", applyProfileFilterRich(candidates, profile));
      return wrap(previewMany(ranked), DAY);
    }

    case "festival-darlings": {
      const now = new Date();
      const from = new Date(now.getFullYear(), now.getMonth() - 18, 1);
      const fromDate = `${from.getFullYear()}-${String(from.getMonth() + 1).padStart(2, "0")}-01`;
      const candidates = await discoverWithStats(env, "movie", {
        type: "movie",
        sortBy: "vote_average.desc",
        voteCountGte: 150,
        voteCountLte: 8000,
        voteAverageGte: 7.0,
        releaseFromDate: fromDate,
        withoutGenres: "99,10770",
        page: 1 + Math.floor(skip / 20),
      });
      const ranked = rankByShrunkRating("festival", applyProfileFilterRich(candidates, profile));
      return wrap(previewMany(ranked), DAY * 3);
    }

    case "long-tail": {
      const candidates = await discoverWithStats(env, "movie", {
        type: "movie",
        sortBy: "vote_average.desc",
        voteCountGte: 1000,
        voteCountLte: 4000,
        voteAverageGte: 7.4,
        withoutGenres: "99,10770",
        withGenres: profileGenresToTMDB(profile, 4),
        withOriginalLanguage: profileLanguagesToISO(profile),
        page: 1 + Math.floor(skip / 20),
      });
      const trending = new Set((await traktTrending(env, "movie", 50).catch(() => [])).map((m) => m.id));
      const filtered = applyProfileFilterRich(
        candidates.filter((m) => !trending.has(m.id)),
        profile,
      );
      const ranked = rankByShrunkRating("longtail", filtered);
      return wrap(previewMany(ranked, (r) => `${r.voteCount.toLocaleString()} votes`), DAY);
    }

    // Profile-aware rows shown only when the user has built up signal.
    case "echoes": {
      if (profile.totalEvents < 5) return wrap([], DAY);
      const candidates = await discoverWithStats(env, "movie", {
        type: "movie",
        sortBy: "vote_average.desc",
        voteCountGte: 500,
        voteAverageGte: 7.0,
        withGenres: profileGenresToTMDB(profile, 3),
        withOriginalLanguage: profileLanguagesToISO(profile),
        page: 1 + Math.floor(skip / 20),
      });
      const topGenre = profile.topGenres[0]?.[0];
      const ranked = rankByShrunkRating("echoes", applyProfileFilterRich(candidates, profile));
      return wrap(
        previewMany(ranked, () => topGenre ? `Because you watch ${topGenre.toLowerCase()}` : undefined),
        DAY,
      );
    }

    case "from-your-decade": {
      if (profile.topDecades.length === 0) return wrap([], DAY * 2);
      const decade = profile.topDecades[0]?.[0] ?? 2010;
      const candidates = await discoverWithStats(env, "movie", {
        type: "movie",
        sortBy: "vote_average.desc",
        voteCountGte: 400,
        voteAverageGte: 7.2,
        releaseFromYear: decade,
        releaseToYear: decade + 9,
        withGenres: profileGenresToTMDB(profile, 4),
        page: 1 + Math.floor(skip / 20),
      });
      const ranked = rankByShrunkRating("decade", applyProfileFilterRich(candidates, profile));
      return wrap(previewMany(ranked, () => `From the ${decade}s`), DAY * 2);
    }

    case "outside-your-cone": {
      if (profile.totalEvents < 8) return wrap([], DAY);
      const knownGenreIds = new Set(
        profile.topGenres.map(([n]) => GENRE_NAME_TO_ID[n]).filter((x): x is number => !!x),
      );
      const ALL_GENRE_IDS = [28, 12, 16, 35, 80, 18, 14, 36, 27, 9648, 10749, 878, 53, 10752, 37];
      const adjacent = ALL_GENRE_IDS.filter((id) => !knownGenreIds.has(id));
      const candidates = await discoverWithStats(env, "movie", {
        type: "movie",
        sortBy: "vote_average.desc",
        voteCountGte: 1500,
        voteAverageGte: 7.4,
        withGenres: adjacent.slice(0, 4).join("|"),
        page: 1 + Math.floor(skip / 20),
      });
      const ranked = rankByShrunkRating("cone", applyProfileFilterRich(candidates, profile));
      return wrap(previewMany(ranked, () => "Outside your usual"), DAY * 3);
    }

    // ─────────────────────────────────────────────────────────────────
    // v0.3 rows. Every one of these works for anonymous users (no profile)
    // and improves with signal.

    case "watchlist-intent": {
      if (!user) return wrap([], DAY);
      // Titles the user keeps eyeing but never plays. The attention rollup
      // already has the query plus the per-title meta_count we can surface.
      const rows = await attentionRows(env, user.id, 500).catch(() => []);
      const cutoff = Date.now() - 30 * DAY * 1000;
      const ids = rows
        .filter((r) => r.meta_count >= 4 && r.stream_count === 0 && (r.last_meta_ts ?? 0) >= cutoff)
        .sort((a, b) => (b.last_meta_ts ?? 0) - (a.last_meta_ts ?? 0))
        .slice(0, 30);
      if (ids.length === 0) return wrap([], DAY);
      const cached = await getTitleCache(env, ids.map((r) => r.imdb_id)).catch(() => new Map());
      const metas: MetaPreview[] = ids.map((r) => {
        const t = cached.get(r.imdb_id);
        const out: MetaPreview = {
          id: r.imdb_id,
          type: (t?.type === "series" ? "series" : "movie") as "movie" | "series",
          name: t?.title ?? "",
          description: `You've opened this ${r.meta_count}× without pressing Play`,
        };
        if (t?.year) out.releaseInfo = String(t.year);
        if (t?.vote_average) out.imdbRating = t.vote_average.toFixed(1);
        return out;
      });
      return wrap(metas, DAY / 2);
    }

    case "continue-watching": {
      if (!user) return wrap([], DAY);
      // From the per-(user, title) attention rollup: titles with progress
      // strictly between 5% and 92% are "in flight".
      const rows = await attentionRows(env, user.id, 200);
      const inflight = rows
        .filter((r) => r.completion_ratio !== null && r.completion_ratio > 0.05 && r.completion_ratio < 0.92)
        .sort((a, b) => (b.last_stream_ts ?? 0) - (a.last_stream_ts ?? 0));
      const cached = await getTitleCache(env, inflight.map((r) => r.imdb_id)).catch(() => new Map());
      const metas: MetaPreview[] = inflight.map((r) => {
        const t = cached.get(r.imdb_id);
        const out: MetaPreview = {
          id: r.imdb_id,
          type: (t?.type === "series" ? "series" : "movie") as "movie" | "series",
          name: t?.title ?? "",
          description: `${Math.round((r.completion_ratio ?? 0) * 100)}% through`,
        };
        if (t?.year) out.releaseInfo = String(t.year);
        if (t?.vote_average) out.imdbRating = t.vote_average.toFixed(1);
        return out;
      });
      return wrap(metas, DAY / 4);
    }

    case "awards": {
      // Prefer the cron-warmed title_awards cache (single fast D1 query).
      // Fall back to live Wikidata SPARQL only if the cache is empty (cold
      // start before any cron has run).
      const AWARD_LABEL: Record<string, string> = {
        palme_dor: "Palme d'Or",
        oscar_best_picture: "Oscar - Best Picture",
        bafta_best_film: "BAFTA - Best Film",
        cannes_grand_prix: "Cannes Grand Prix",
      };
      let labels = new Map<string, string[]>();
      let orderedIds: string[] = [];
      const cached = await env.DB.prepare(
        `SELECT imdb_id, GROUP_CONCAT(award) AS awards FROM title_awards GROUP BY imdb_id`,
      ).all<{ imdb_id: string; awards: string }>().catch(() => ({ results: [] as Array<{ imdb_id: string; awards: string }> }));
      const rows = cached.results ?? [];
      if (rows.length >= 20) {
        for (const r of rows) {
          orderedIds.push(r.imdb_id);
          labels.set(r.imdb_id, r.awards.split(",").map((a) => AWARD_LABEL[a] ?? a));
        }
      } else {
        // Cold fallback - live SPARQL.
        const fromYear = new Date().getFullYear() - 30;
        const [palme, oscar, bafta] = await Promise.all([
          imdbIdsForAward("palme_dor", fromYear).catch(() => []),
          imdbIdsForAward("oscar_best_picture", fromYear).catch(() => []),
          imdbIdsForAward("bafta_best_film", fromYear).catch(() => []),
        ]);
        const push = (ids: string[], label: string) => {
          for (const id of ids) {
            const arr = labels.get(id) ?? [];
            arr.push(label);
            labels.set(id, arr);
          }
        };
        push(palme, "Palme d'Or");
        push(oscar, "Oscar - Best Picture");
        push(bafta, "BAFTA - Best Film");
        orderedIds = dedup([...palme, ...oscar, ...bafta]);
      }
      const filtered = orderedIds.filter((id) => !profile.watchedSet.has(id));
      const sliced = filtered.slice(0, 60);
      const cachedAwards = await getTitleCache(env, sliced).catch(() => new Map());
      const metas: MetaPreview[] = sliced.map((id) => {
        const t = cachedAwards.get(id);
        const out: MetaPreview = {
          id,
          type: "movie",
          name: t?.title ?? "",
          description: (labels.get(id) ?? []).join(" · "),
        };
        if (t?.year) out.releaseInfo = String(t.year);
        if (t?.vote_average) out.imdbRating = t.vote_average.toFixed(1);
        return out;
      });
      return wrap(metas, DAY * 7);
    }

    case "essentials": {
      // Verified broadly-loved films, watched-suppressed. Year + title come
      // from a baked-in static map so tiles render fully on first install
      // (no title_cache warming needed). imdbRating is read from title_cache
      // when available (cron-warmed).
      const merged = dedup(LETTERBOXD_TOP_50).filter((id) => !profile.watchedSet.has(id));
      const slice = merged.slice(0, 50);
      const cached = await getTitleCache(env, slice).catch(() => new Map());
      const metas: MetaPreview[] = slice.map((id) => {
        const meta = LB_TOP_50_META[id];
        const t = cached.get(id);
        const out: MetaPreview = {
          id,
          type: "movie",
          name: meta?.title ?? "",
          description: "Broadly loved",
        };
        if (meta?.year) out.releaseInfo = String(meta.year);
        if (t?.vote_average) out.imdbRating = t.vote_average.toFixed(1);
        return out;
      });
      return wrap(metas, DAY * 7);
    }

    case "critic-picks": {
      const candidates = await recentCriticPicks(env).catch(() => []);
      const filtered = candidates
        .filter((m) => !profile.watchedSet.has(m.id))
        .map((m) => ({ ...m, description: "Reviewed this week" }));
      return wrap(filtered, DAY);
    }

    case "beloved-bombs": {
      // Critic-vs-audience divergence using MDBList. The MDBList key is an
      // operator-side worker secret - end users never supply one. If the
      // operator hasn't set it, the row degrades to empty (Stremio hides it).
      if (!env.MDBLIST_KEY) return wrap([], DAY);
      const candidates = await discoverWithStats(env, "movie", {
        type: "movie",
        sortBy: "vote_average.desc",
        voteCountGte: 300,
        voteCountLte: 5000,
        voteAverageGte: 6.5,
        page: 1 + Math.floor(skip / 20),
      });
      const filtered = applyProfileFilterRich(candidates, profile);
      // Concurrent rating lookups, bounded.
      const scored: Array<RankableMeta & { critic: number; audience: number }> = [];
      const CONC = 8;
      for (let i = 0; i < filtered.length; i += CONC) {
        const slice = filtered.slice(i, i + CONC);
        const r = await Promise.all(slice.map((m) => fetchAggRatings(env, m.id).catch(() => null)));
        slice.forEach((m, idx) => {
          const agg = r[idx];
          if (!agg) return;
          const critic = Math.max(agg.rt ?? 0, agg.metacritic ?? 0);
          const audience = (agg.letterboxd ?? 0) * 20; // LB is 0-5, scale to 0-100
          if (critic >= 75 && audience > 0 && critic - audience >= 20) {
            scored.push({ ...m, critic, audience });
          }
        });
        if (scored.length >= 30) break;
      }
      const ranked = scored.sort((a, b) => (b.critic - b.audience) - (a.critic - a.audience));
      const metas: MetaPreview[] = ranked.map((s) =>
        preview(s, `${Math.round(s.critic)}% critics · ${(s.audience / 20).toFixed(1)}/5 audience`),
      );
      return wrap(metas, DAY);
    }

    case "adapted": {
      const all = await imdbIdsAdaptedFromBooks(200).catch(() => []);
      const filtered = all.filter((id) => !profile.watchedSet.has(id));
      const sliced = filtered.slice(0, 80);
      const cachedAdapted = await getTitleCache(env, sliced).catch(() => new Map());
      const metas: MetaPreview[] = sliced.map((id) => {
        const t = cachedAdapted.get(id);
        const out: MetaPreview = {
          id,
          type: "movie",
          name: t?.title ?? "",
          description: "Based on a book",
        };
        if (t?.year) out.releaseInfo = String(t.year);
        if (t?.vote_average) out.imdbRating = t.vote_average.toFixed(1);
        return out;
      });
      return wrap(metas, DAY * 7);
    }

    case "anime-top": {
      // Hand-verified series list (src/anime-top.ts). Tiles are emitted as
      // kitsu:<id> rather than tt: so anime-aware stream addons (Torrentio,
      // Comet, Knightcrawler, TorBox) return full anime stream lists. Meta
      // for kitsu: ids is owned by the Anime Kitsu addon - the /configure
      // copy nudges anime users to install it alongside Marquee. We still
      // dedupe against watchedSet by the IMDb id since that's what attention
      // events accumulate against.
      const imdbIds = listAnimeIds().filter((id) => !profile.watchedSet.has(id));
      const metas: MetaPreview[] = imdbIds.map((imdb) => {
        const a = ANIME_TOP[imdb]!;
        return {
          id: `kitsu:${a.kitsu}`,
          type: "series",
          name: a.title,
          releaseInfo: String(a.year),
          description: "Curated anime",
        };
      });
      return wrap(metas, DAY * 7);
    }

    default:
      return wrap([], DAY);
  }
}

function wrap(metas: MetaPreview[], maxAge: number): CatalogResponse {
  return {
    metas: dedupe(metas).slice(0, 100),
    cacheMaxAge: maxAge,
    staleRevalidate: maxAge * 2,
    staleError: maxAge * 7,
  };
}
