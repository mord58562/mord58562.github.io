import { describe, expect, it } from "vitest";
import { bayesianShrunk, bordaBlend, dailyEpsilon } from "../src/scoring.js";

describe("bayesianShrunk (IMDb weighted rating)", () => {
  it("returns the title's mean when vote_count is huge", () => {
    expect(bayesianShrunk(8.5, 100_000)).toBeCloseTo(8.5, 1);
  });
  it("pulls a low-vote rating toward the global mean C", () => {
    const s = bayesianShrunk(9.5, 10);
    expect(s).toBeLessThan(8.5);
    expect(s).toBeGreaterThan(6.8);
  });
  it("does not overshoot C for a zero-vote item", () => {
    expect(bayesianShrunk(10, 0)).toBeCloseTo(6.8, 4);
  });
  it("respects explicit C and m overrides", () => {
    expect(bayesianShrunk(10, 100, 5.0, 100)).toBeCloseTo(7.5, 4);
  });
});

describe("dailyEpsilon", () => {
  it("returns a small positive number in [0, 1e-3)", () => {
    const e = dailyEpsilon("row", "tt0111161");
    expect(e).toBeGreaterThanOrEqual(0);
    expect(e).toBeLessThan(1e-3);
  });
  it("is deterministic within the same day for the same (seed, id)", () => {
    expect(dailyEpsilon("row", "tt0068646")).toEqual(dailyEpsilon("row", "tt0068646"));
  });
  it("differs across seeds for the same id", () => {
    expect(dailyEpsilon("row1", "tt0111161")).not.toEqual(dailyEpsilon("row2", "tt0111161"));
  });
});

describe("bordaBlend", () => {
  it("ranks by consensus count, breaking ties by average rank", () => {
    const r = bordaBlend([
      { name: "a", ids: ["tt1", "tt2", "tt3"] },
      { name: "b", ids: ["tt2", "tt1"] },
      { name: "c", ids: ["tt3"] },
    ]);
    // tt1: count 2, avg 0.5; tt2: count 2, avg 0.5; tt3: count 2, avg 1.0
    expect(r[0]).toMatch(/tt[12]/);
    expect(r[1]).toMatch(/tt[12]/);
    expect(r[2]).toBe("tt3");
  });
  it("returns empty for empty input", () => {
    expect(bordaBlend([])).toEqual([]);
  });
});

import { diversityRerank } from "../src/scoring.js";
describe("diversityRerank", () => {
  it("preserves order when no genre overlap", () => {
    const items = [
      { id: "a", genreIds: [1] },
      { id: "b", genreIds: [2] },
      { id: "c", genreIds: [3] },
    ];
    expect(diversityRerank(items).map((i) => i.id)).toEqual(["a", "b", "c"]);
  });
  it("breaks up runs of same-genre items after a couple of picks", () => {
    // With LAMBDA=0.7 the reranker preserves original rank strongly; the
    // diversity effect shows once same-genre overlap accumulates enough to
    // outweigh the small rank cost. Here, after a and b are picked, c (no
    // overlap) is preferred over d (heavy overlap) even though d is closer
    // to its original rank.
    const items = [
      { id: "a", genreIds: [1, 2] },
      { id: "b", genreIds: [1, 2] },
      { id: "c", genreIds: [3, 4] },
      { id: "d", genreIds: [1, 2] },
    ];
    const ranked = diversityRerank(items).map((i) => i.id);
    expect(ranked[0]).toBe("a");
    expect(ranked[2]).toBe("c");
    expect(ranked[3]).toBe("d");
  });
  it("returns 0/1/2-item arrays unchanged", () => {
    expect(diversityRerank([])).toEqual([]);
    expect(diversityRerank([{ id: "a" }])).toEqual([{ id: "a" }]);
    expect(diversityRerank([{ id: "a" }, { id: "b" }])).toEqual([{ id: "a" }, { id: "b" }]);
  });
});
