import { describe, expect, it } from "vitest";
import { hourSlot, inferMood, lunarPhase } from "../src/context.js";
import type { Ctx } from "../src/context.js";

describe("lunarPhase", () => {
  it("returns 'new' around the known new moon epoch (2000-01-06)", () => {
    expect(lunarPhase(new Date(Date.UTC(2000, 0, 6, 18, 14, 0)))).toBe("new");
  });
  it("returns a valid phase for any date", () => {
    const phases = new Set(["new", "waxing", "full", "waning"]);
    for (let m = 0; m < 12; m++) {
      const d = new Date(Date.UTC(2024, m, 15));
      expect(phases.has(lunarPhase(d))).toBe(true);
    }
  });
});

describe("hourSlot", () => {
  it("maps hours to the correct slot bucket", () => {
    expect(hourSlot(6)).toBe("early");
    expect(hourSlot(10)).toBe("morning");
    expect(hourSlot(14)).toBe("afternoon");
    expect(hourSlot(20)).toBe("evening");
    expect(hourSlot(2)).toBe("late");
    expect(hourSlot(23)).toBe("late");
  });
});

describe("inferMood", () => {
  const base: Ctx = {
    hourLocal: 20, slot: "evening", dayOfWeek: 2,
    isWeekendEvening: false, lunar: "waxing", weather: "clear",
  };

  it("returns 'intense' on a full-moon evening", () => {
    expect(inferMood({ ...base, lunar: "full" }, "any")).toBe("intense");
  });
  it("returns 'quiet' for a rainy evening", () => {
    expect(inferMood({ ...base, weather: "rain" }, "any")).toBe("quiet");
  });
  it("returns 'comfort' for snow", () => {
    expect(inferMood({ ...base, weather: "snow" }, "any")).toBe("comfort");
  });
  it("returns 'fun' on weekend evenings absent overriding signals", () => {
    expect(inferMood({ ...base, isWeekendEvening: true }, "any")).toBe("fun");
  });
  it("returns 'intense' for Halloween-window", () => {
    expect(inferMood({ ...base, upcomingHoliday: "Halloween" }, "any")).toBe("intense");
  });
  it("returns 'comfort' for Christmas-window", () => {
    expect(inferMood({ ...base, upcomingHoliday: "Christmas Day" }, "any")).toBe("comfort");
  });
  it("falls back to provided default when no rule fires", () => {
    const safe: Ctx = { ...base, slot: "morning", weather: "unknown" };
    // Morning gets no specific rule; falls through to fallback.
    expect(inferMood(safe, "any")).toBe("any");
  });
});
