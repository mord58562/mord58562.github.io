import { describe, expect, it } from "vitest";
import { looksLikeUserId, newUserId } from "../src/storage.js";

describe("newUserId", () => {
  it("returns 8-char alphanumeric string from the Crockford-ish alphabet", () => {
    for (let i = 0; i < 32; i++) {
      const id = newUserId();
      expect(id).toMatch(/^[a-z2-9]{8}$/);
    }
  });
  it("produces unique IDs across many calls (no obvious collisions)", () => {
    const ids = new Set();
    for (let i = 0; i < 1000; i++) ids.add(newUserId());
    expect(ids.size).toBe(1000);
  });
});

describe("looksLikeUserId", () => {
  it("accepts valid 8-char IDs", () => {
    expect(looksLikeUserId("abc234fg")).toBe(true);
    expect(looksLikeUserId(newUserId())).toBe(true);
  });
  it("rejects wrong length, wrong case, wrong charset", () => {
    expect(looksLikeUserId("abc")).toBe(false);
    expect(looksLikeUserId("abcdefghi")).toBe(false);
    expect(looksLikeUserId("ABCDEFGH")).toBe(false);
    expect(looksLikeUserId("abc01234")).toBe(false); // 0 and 1 are excluded
    expect(looksLikeUserId(undefined)).toBe(false);
    expect(looksLikeUserId("")).toBe(false);
  });
});
