import { describe, expect, it } from "vitest";
import { parseDiaryRSS } from "../src/letterboxd.js";

const SAMPLE = `<?xml version="1.0" encoding="UTF-8"?>
<rss>
  <channel>
    <item>
      <title>Past Lives, 2023 - ★★★★½</title>
      <guid>letterboxd-review-12345</guid>
      <pubDate>Mon, 12 Feb 2024 12:00:00 +0000</pubDate>
      <letterboxd:filmTitle>Past Lives</letterboxd:filmTitle>
      <letterboxd:filmYear>2023</letterboxd:filmYear>
      <letterboxd:memberRating>4.5</letterboxd:memberRating>
      <letterboxd:watchedDate>2024-02-11</letterboxd:watchedDate>
      <tmdb:movieId>666277</tmdb:movieId>
    </item>
    <item>
      <title>Some Bad Film</title>
      <guid>letterboxd-watch-99999</guid>
      <letterboxd:memberRating>1.5</letterboxd:memberRating>
      <letterboxd:watchedDate>2024-03-01</letterboxd:watchedDate>
      <tmdb:movieId>123</tmdb:movieId>
    </item>
    <item>
      <title>Random list, not diary</title>
      <guid>letterboxd-list-77777</guid>
    </item>
  </channel>
</rss>`;

describe("parseDiaryRSS", () => {
  it("extracts only diary entries (watch + review), skipping lists", () => {
    const entries = parseDiaryRSS(SAMPLE);
    expect(entries).toHaveLength(2);
  });
  it("parses tmdb_id, rating, watched_ts correctly", () => {
    const [first] = parseDiaryRSS(SAMPLE);
    expect(first?.tmdb_id).toBe(666277);
    expect(first?.member_rating_05).toBe(4.5);
    expect(first?.watched_ts).toBe(Date.parse("2024-02-11"));
  });
  it("preserves low-rating entries (these become negative-weight events)", () => {
    const entries = parseDiaryRSS(SAMPLE);
    const bad = entries.find((e) => e.tmdb_id === 123);
    expect(bad?.member_rating_05).toBe(1.5);
  });
  it("returns [] for empty/malformed XML", () => {
    expect(parseDiaryRSS("")).toEqual([]);
    expect(parseDiaryRSS("<rss></rss>")).toEqual([]);
  });
});
