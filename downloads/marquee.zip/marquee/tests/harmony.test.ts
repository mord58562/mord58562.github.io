import { describe, expect, it } from "vitest";
import { ANIME_TOP, kitsuToImdb, listAnimeIds } from "../src/anime-top.js";
import { buildManifestAsync } from "../src/manifest.js";
import type { Env } from "../src/types.js";

// These tests lock in the contract that lets Marquee coexist with every
// stream addon in the Stremio ecosystem (Torrentio, MediaFusion, Comet,
// Jackettio, Knightcrawler, AIOStreams, Easynews+, TorBox, Premiumize,
// DebridLink, etc.). Breaking any of them would silently regress the
// "Marquee never appears on the source-selection screen" promise.

const env: Env = {
  TMDB_BEARER: "stub",
  TRAKT_CLIENT_ID: "stub",
  ADDON_VERSION: "0.0.0",
  ADDON_NAME: "Marquee",
  DB: undefined as unknown as D1Database,
};

describe("manifest debrid-harmony contract", () => {
  it("does NOT advertise the `meta` resource (Cinemeta keeps detail-page rendering)", async () => {
    const m = await buildManifestAsync(env, null);
    const resourceNames = m.resources.map((r) => (typeof r === "string" ? r : r.name));
    expect(resourceNames).not.toContain("meta");
  });

  it("advertises `stream` for tt + kitsu only (mal:/anidb:/tmdb:/tvdb: pass through untouched)", async () => {
    // kitsu: is included so Marquee receives engagement signal for the opt-in
    // anime row (whose tiles emit as kitsu:<id> for Torrentio/Comet/etc.
    // anime stream coverage). The handler still returns {streams: []} for
    // both prefixes - it never appears on source-selection.
    const m = await buildManifestAsync(env, null);
    const stream = m.resources.find(
      (r): r is { name: string; types: string[]; idPrefixes: string[] } =>
        typeof r !== "string" && r.name === "stream",
    );
    expect(stream).toBeDefined();
    expect(stream!.idPrefixes).toEqual(["tt", "kitsu:"]);
    expect(stream!.types).toEqual(["movie", "series"]);
  });

  it("top-level idPrefixes covers tt + kitsu only - mal:/anidb:/tmdb:/tvdb: stay with their owners", async () => {
    const m = await buildManifestAsync(env, null);
    expect(m.idPrefixes).toEqual(["tt", "kitsu:"]);
  });

  it("declares only movie + series types (no realtime / tv / channel that anime/IPTV addons own)", async () => {
    const m = await buildManifestAsync(env, null);
    expect(m.types).toEqual(["movie", "series"]);
  });

  it("every advertised catalog is movie or series (never a stream-addon territory like tv)", async () => {
    const m = await buildManifestAsync(env, null);
    for (const c of m.catalogs) {
      expect(["movie", "series"]).toContain(c.type);
    }
  });

  it("no catalog declares a `search` extra (Marquee stays out of universal search)", async () => {
    const m = await buildManifestAsync(env, null);
    for (const c of m.catalogs) {
      const names = (c.extra ?? []).map((e: { name: string }) => e.name);
      expect(names).not.toContain("search");
    }
  });
});

describe("anime row id contract", () => {
  it("every entry has a positive kitsu id (required for Torrentio/Comet anime streams)", () => {
    for (const id of listAnimeIds()) {
      const entry = ANIME_TOP[id]!;
      expect(entry.kitsu).toBeGreaterThan(0);
    }
  });

  it("kitsu ids are unique across the curated set", () => {
    const seen = new Set<number>();
    for (const id of listAnimeIds()) {
      const k = ANIME_TOP[id]!.kitsu;
      expect(seen.has(k)).toBe(false);
      seen.add(k);
    }
  });

  it("kitsuToImdb folds every advertised kitsu id back onto its IMDb key", () => {
    // Locks in the engagement-rollup invariant: anime clicks must land in
    // the same IMDb keyspace as everything else, never in their own
    // orphaned namespace.
    for (const imdb of listAnimeIds()) {
      const kitsuId = `kitsu:${ANIME_TOP[imdb]!.kitsu}`;
      expect(kitsuToImdb(kitsuId)).toBe(imdb);
    }
  });

  it("kitsuToImdb returns null for unknown kitsu ids (no silent mis-attribution)", () => {
    expect(kitsuToImdb("kitsu:999999999")).toBeNull();
    expect(kitsuToImdb("tt0000000")).toBeNull();
  });
});
