import { describe, expect, it } from "vitest";
import { classifyUA, isUnusableForForms } from "../src/ua.js";

describe("classifyUA", () => {
  it("returns 'unknown' for null", () => {
    expect(classifyUA(null)).toBe("unknown");
  });
  it("detects Android TV variants", () => {
    expect(classifyUA("Stremio/1.5 (Linux; Android TV 11)")).toBe("tv");
    expect(classifyUA("Mozilla AndroidTV WebView")).toBe("tv");
  });
  it("detects Apple TV", () => {
    expect(classifyUA("Stremio/1.0 (AppleTV; tvOS 16)")).toBe("tv");
  });
  it("detects webOS / Tizen / generic smart TVs", () => {
    expect(classifyUA("Mozilla webOS")).toBe("tv");
    expect(classifyUA("Mozilla Tizen")).toBe("tv");
    expect(classifyUA("Mozilla SmartTV")).toBe("tv");
  });
  it("classifies iPhone as phone, iPad as tablet", () => {
    expect(classifyUA("Mozilla iPhone Safari")).toBe("phone");
    expect(classifyUA("Mozilla iPad Safari")).toBe("tablet");
  });
  it("classifies Android Mobile as phone, Android (no Mobile) as tablet", () => {
    expect(classifyUA("Mozilla Android Mobile")).toBe("phone");
    expect(classifyUA("Mozilla Android")).toBe("tablet");
  });
  it("classifies macOS Stremio as desktop", () => {
    expect(classifyUA("Stremio/4.4 (Macintosh; Intel Mac OS X)")).toBe("desktop");
  });
});

describe("isUnusableForForms", () => {
  it("returns true only for TV surface", () => {
    expect(isUnusableForForms("tv")).toBe(true);
    expect(isUnusableForForms("phone")).toBe(false);
    expect(isUnusableForForms("desktop")).toBe(false);
  });
});
