import { describe, expect, it } from "vitest";
import { harvestTitlesFromFeed } from "../src/critic-feeds.js";

const SAMPLE = `<?xml version="1.0"?>
<rss><channel>
  <item><title><![CDATA[Past Lives (2023) review - a tender masterpiece]]></title></item>
  <item><title>Anatomy of a Fall review: gripping courtroom drama</title></item>
  <item><title>Review: The Holdovers (2023)</title></item>
  <item><title>How Oppenheimer became the year's defining film</title></item>
  <item><title>The week ahead in cinema</title></item>
  <item><title>random news headline with no film</title></item>
</channel></rss>`;

describe("harvestTitlesFromFeed", () => {
  it("extracts candidate films from common review-title shapes", () => {
    // Feature-article headlines like "How X became the year's defining film"
    // are deliberately not parsed - too prone to false positives. Only
    // explicit review titles get harvested.
    const c = harvestTitlesFromFeed(SAMPLE);
    const titles = c.map((x) => x.title.toLowerCase());
    expect(titles).toContain("past lives");
    expect(titles).toContain("anatomy of a fall");
    expect(titles).toContain("the holdovers");
  });
  it("captures release years when present", () => {
    const past = harvestTitlesFromFeed(SAMPLE).find((c) => c.title.toLowerCase() === "past lives");
    expect(past?.year).toBe(2023);
  });
  it("skips generic week-recap titles", () => {
    const c = harvestTitlesFromFeed(SAMPLE);
    expect(c.find((x) => /week ahead/i.test(x.title))).toBeUndefined();
  });
  it("returns [] for an empty feed", () => {
    expect(harvestTitlesFromFeed("")).toEqual([]);
  });
});
