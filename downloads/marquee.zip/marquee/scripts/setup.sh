#!/usr/bin/env bash
# One-shot local-dev bootstrap for Marquee.
#
# What it does, in order:
#   1. Installs npm deps if node_modules is absent or stale.
#   2. Copies .dev.vars.example -> .dev.vars if .dev.vars is missing.
#   3. Prompts for any missing required secrets and writes them into .dev.vars.
#   4. Applies every migration in migrations/ to the local D1 database.
#   5. Runs typecheck + tests as a smoke check.
#   6. Prints the install URL and the next command to run.
#
# Idempotent: rerun any time. Anything already done is skipped.

set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"

say() { printf "\033[1;36m%s\033[0m\n" "$*"; }
warn() { printf "\033[1;33m%s\033[0m\n" "$*"; }
err() { printf "\033[1;31m%s\033[0m\n" "$*" >&2; }

# 1. Node modules.
if [ ! -d node_modules ] || [ package.json -nt node_modules ]; then
  say "Installing npm dependencies..."
  npm install
else
  say "npm deps already installed."
fi

# 2. .dev.vars.
if [ ! -f .dev.vars ]; then
  say "Creating .dev.vars from .dev.vars.example"
  cp .dev.vars.example .dev.vars
fi

# 3. Required secrets. TMDB_BEARER is mandatory; TRAKT_CLIENT_ID is required
#    for the long-tail row but Marquee still boots without it. MDBLIST_KEY is
#    optional (unlocks Beloved bombs).
need_secret() {
  local key="$1"
  local prompt="$2"
  local current
  current=$(grep "^${key}=" .dev.vars | cut -d= -f2- || true)
  if [ -n "$current" ]; then
    say "  ${key} already set."
    return
  fi
  warn "  ${key} is empty. ${prompt}"
  printf "  Paste value (or press Enter to skip): "
  read -r value
  if [ -n "$value" ]; then
    # Escape any slashes for sed.
    local esc
    esc=$(printf '%s\n' "$value" | sed 's/[\\/&]/\\&/g')
    sed -i.bak "s/^${key}=.*/${key}=${esc}/" .dev.vars
    rm -f .dev.vars.bak
  fi
}

say "Checking secrets in .dev.vars..."
need_secret TMDB_BEARER "Get a v4 read-access token at https://www.themoviedb.org/settings/api"
need_secret TRAKT_CLIENT_ID "Get a Client ID at https://trakt.tv/oauth/applications (no OAuth, public read-only)"
need_secret MDBLIST_KEY "Optional. Free key at https://mdblist.com - enables the Beloved bombs row"

# 4. Migrations.
say "Applying all D1 migrations to local DB..."
for mig in migrations/*.sql; do
  echo "  $(basename "$mig")"
  npx --yes wrangler d1 execute marquee --local --file="$mig" >/dev/null 2>&1 || {
    warn "  ($(basename "$mig") may have already been applied; continuing)"
  }
done

# 5. Smoke check.
say "Running typecheck..."
npm run typecheck
say "Running test suite..."
npm test --silent

# 6. Print install URL.
PORT=$(grep -E 'dev.*--port' package.json | sed -E 's/.*--port +([0-9]+).*/\1/' | head -1)
PORT=${PORT:-8787}
say ""
say "Marquee local install URL:"
printf "  \033[1;32mhttp://127.0.0.1:%s/manifest.json\033[0m\n" "$PORT"
say ""
say "Next:"
echo "  1) Start the dev server:    npm run dev"
echo "  2) In Stremio Addons search, paste the URL above."
echo "  3) Or open: stremio://127.0.0.1:${PORT}/manifest.json"
echo ""
echo "  /configure works too: http://127.0.0.1:${PORT}/configure"
echo ""
