# Set Memory Digest - 2026-05-28

_Set Memory reads rekordbox session log data. It does not perform audio analysis._

## Headline

6734 new track(s) in library. 25 forgotten favourite(s) surfaced. 200 prep issue(s).

## Activity

`█ ▂▁   ▆▁  ▂` (2025-06 to 2026-05, 92 sessions, peak 37/mo)

## Sessions Ingested This Sync

- 0 new session(s) found
- 390 session(s) already in state.db, skipped
- Library: 7993 track(s) on USB, 6734 new to state.db this sync

## USB Drives

| Drive | Last Mounted | Library Size |
|-------|--------------|--------------|
| ROB USB 6 | 2026-05-27T08:55:59.724824+00:00 | 4514 |
| ROB USB 11 | 2026-05-27T08:57:30.935456+00:00 | 6446 |
| ROB USB 12 | 2026-05-27T08:59:51.314442+00:00 | 5900 |
| ROB USB 7 | 2026-05-28T05:11:06.374855+00:00 | 5427 |
| rob usb 2 | 2026-05-28T05:11:07.492067+00:00 | 7993 |

## Forgotten Favourites (appeared >= 5 times, last seen > 90 days ago)

| Title | Artist | Appearances | Last Session |
|-------|--------|-------------|--------------|
| Body Musik | DJ Deeon | 50 | 2025-08-10 19:31:46 |
| party up (dmx) | gimela | 50 | 2025-08-10 19:31:46 |
| Vladimir Dubyshkin - Russian Porn Magazine | trip | 45 | 2025-06-15 21:44:22 |
| Free Yourself | The Obsessed | 45 | 2025-08-10 19:31:46 |
| DJ Friendly | Elkka | 35 | 2023-12-02 15:01:51 |
| HEADIE ONE X DRAKE - ONLY YOU FREESTYLE (SLICK'S LETHAL EDIT) | Slick | 34 | 2024-12-21 15:50:25 |
| Installation | Pangaea | 34 | 2024-11-29 16:37:14 |
| Do What You Want | The Presets | 33 | 2025-06-25 21:56:40 |
| Dance Power 90 | Upper90 | 30 | 2025-08-10 19:31:46 |
| My Singing Monsters - Plant Island | GhostMeow | 29 | 2024-08-27 21:26:53 |
| Sims 2000 | Indecorum | 29 | 2023-12-02 15:01:56 |
| Bump It xo | AISHA (Sco)/Franck | 28 | 2025-09-04 16:17:10 |
| Marlon Hoffstadt aka DJ Daddy Trance - Bass Is Pumping | Marlon Hoffstadt | 26 | 2024-12-21 15:50:25 |
| Malugi & Marlon Hoffstadt - Faster Alone (Original Mix) | Marlon Hoffstadt | 26 | 2023-11-23 16:37:50 |
| Speed It Up - Dr. Bounce Remix | Club Caviar/Dr. Bounce | 26 | 2025-06-18 20:45:15 |
| Seb's Foot (FREE DL) | BOYSWHOCRY | 25 | 2022-08-27 12:10:50 |
| Drinkee (Carl Cox Remix) | SOFI TUKKER | 25 | 2025-02-21 19:07:41 |
| Body Move (Vocal Mix) | Jelsen | 25 | 2025-08-10 19:31:46 |
| Open the Gate | Glowal | 25 | 2025-05-29 19:12:13 |
| Wave Corners - Even Mike (Dissolver Remix) | ʍɐʇ ıs uɐʇ | 24 | 2022-09-21 19:28:24 |
| Pour the Milk | Robbie Doherty | 24 | 2022-09-12 19:33:25 |
| Spring Girl (Vintage Culture Remix (Extended)) | Maori, Adam Ten | 24 | 2025-08-10 19:31:46 |
| ColaZero | Clüb De Combat | 24 | 2025-08-10 19:31:46 |
| Give You | Odd Mob | 24 | 2025-08-10 19:31:46 |
| Shy FX - Original Nuttah 25 (Skeptic Speedy G Dub) | BlueDollarBillz | 23 | 2023-11-23 16:37:50 |

## Never Played After Add (in library >= threshold days, never in any session)

| Title | Artist | Added |
|-------|--------|-------|
| FREESPEED: SMBG - 5AM DISCO | SPEED | 1904-01-01 |
| Yellow (Original Mix) | Untidy presents | 2015-06-03 |
| Gemini | Papa Nugs | 2015-06-03 |
| Lift Me Up | Venkman & Jon BW | 2017-08-15 |
| NOISE | Unknown | 2022-06-03 |
| SINEWAVE | Unknown | 2022-06-03 |
| SIREN | Unknown | 2022-06-03 |
| HORN | Unknown | 2022-06-03 |
| Demo Track 1 | Loopmasters | 2022-06-03 |
| Demo Track 2 | Loopmasters | 2022-06-03 |
| CYMBAL | Unknown | 2022-06-03 |
| LET'S GO | Loopmasters | 2022-06-03 |
| NEEDLE SCRATCH NOISE | Unknown | 2022-06-03 |
| CLAP | Unknown | 2022-06-03 |
| SNARE8 | Unknown | 2022-06-03 |
| HORN | Unknown | 2022-06-03 |
| SNARE9 | Unknown | 2022-06-03 |
| REWIND | Unknown | 2022-06-03 |
| BOOM DOWN LIFTER2 | Loopmasters | 2022-06-03 |
| NOISE DOWN LIFTER1 | Loopmasters | 2022-06-03 |
| IMPACT KICK | Loopmasters | 2022-06-03 |
| NOISE DOWN LIFTER2 | Loopmasters | 2022-06-03 |
| SNARE | Loopmasters | 2022-06-03 |
| BOOM DOWN LIFTER1 | Loopmasters | 2022-06-03 |
| CLASH CYMBAL | Unknown | 2022-06-03 |
| IMPACT SNARE | Loopmasters | 2022-06-03 |
| SHORT BOOM | Loopmasters | 2022-06-03 |
| Berg - Bayaka (Full Version) | Berg | 2022-06-09 |
| Shamanic Tales | ASTRIX (official) | 2022-06-09 |
| Deep Jungle Walk | ASTRIX (official) | 2022-06-09 |
| Valley of Stevie (feat. Ace Ventura) | ASTRIX (official) | 2022-06-09 |
| He.art | ASTRIX (official) | 2022-06-09 |
| Agate (feat. Ritmo) | ASTRIX (official) | 2022-06-09 |
| Sapana (Album Version) | ASTRIX (official) | 2022-06-09 |
| Awake the Snake (feat. Tristan) | ASTRIX (official) | 2022-06-09 |
| [A1] - Falhaber - Rock The Beat -(Original mix)- [D4EP002] | D4-MASCHINE | 2022-06-09 |
| Ferdinger - St. Nimmerlein (Trudge Remix) [Artaphine Premiere] | Artaphine | 2022-06-09 |
| RATHER BE - EXTENDED MIX | WIRED SKY | 2022-06-09 |
| Lost Tribe - Gamemaster (Original Mix) | Soundly Sleep | 2022-06-09 |
| Storm - Storm (Mark Sherry & Dr Willis's 'Flashback' mix) [Armada] | Mark Sherry | 2022-06-09 |
| Cosmic Gate - Exploration of Space | X Trance X | 2022-06-09 |
| Tiësto - Lethal Industry (Original Mix) [Magik Muzik] | Black Hole Recordings | 2022-06-09 |
| Chasing The Light | Marie Davidson | 2022-06-09 |
| CRW - I Feel Love (DJ JamX & De Leon Remix) | mariellaqc | 2022-06-09 |
| The Space Brothers - Forever (Original Mix) | The Space Brothers | 2022-06-09 |
| Markus Volker - Ameno (Brutal mix) FREE DOWNLOAD | Markus Volker | 2022-06-09 |
| Zapfenstreich - Tyche (John Rayet Orchestral Techno Remix) [Set of the Day] | Techno | 2022-06-09 |
| PREMIERE: Rachel Raw & Krüger Meyer - Buzzer [Jannowitz Records] | Techno | 2022-06-09 |
| Michael Schumacher - Illusion [Set of the Day] | Techno | 2022-06-09 |
| PREMIERE: Lady Maru - Acid Carpet (BB Deng Remix) [Acid Boyler Coalition] | Techno | 2022-06-09 |
| PREMIERE: Torsten Kanzler - Laughing Man (Original Mix) [Zug der Liebe] | Techno | 2022-06-09 |
| PREMIERE: Khaled Abdrabo - Sequenze (Lycos Remix) [Set of the Day Melodic] | Techno | 2022-06-09 |
| PREMIERE: Sardu - Astris (Gizmo & Mac Remix)[Mirror Records] | Techno | 2022-06-09 |
| Side Effects - Next Destination | Trancentral | 2022-06-09 |
| Side Effects & Sonic Sense - Space Travel | Trancentral | 2022-06-09 |
| Side Effects -  Waves Of Sound | Trancentral | 2022-06-09 |
| Leaves from the Vine | youngstereo | 2022-06-09 |
| Absolute - Local X Mr Traumatik X Fernquest (prod. Vibe Chemistry) | MR TRAUMATIK | 2022-06-09 |
| Morchella | Davyncy | 2022-06-09 |
| Piano Man | Billy Joel | 2022-06-09 |
| We Trying to Stay Alive (feat. Refugee All Stars) | Wyclef Jean | 2022-06-09 |
| jaw harp | cellojoegetloopy | 2022-06-09 |
| Macarena (Bayside Boys Remix) | Los Del Rio | 2022-06-09 |
| Busindre Reel | Hevia | 2022-06-09 |
| Ice Ice Baby | Vanilla Ice | 2022-06-09 |
| Billie Jean | Michael Jackson | 2022-06-09 |
| Gimme! Gimme! Gimme! (A Man After Midnight) | Abba | 2022-06-09 |
| Call Me Maybe | Carly Rae Jepsen | 2022-06-09 |
| Nicki Minaj - Starships | Nicki Minaj | 2022-06-09 |
| Knock2 - dashstar* | NIGHTMODE | 2022-06-09 |
| AC Slater x Curbi - Navigator [OUT NOW] | Spinnin' Records | 2022-06-09 |
| Gentlemens Club - 1999 Feat. Dread MC & B Live (MPH Remix) | ClubFriendly | 2022-06-09 |
| Zero - Barry White | CRUCAST | 2022-06-09 |
| Show Me | Habstrakt | 2022-06-09 |
| NOTION - HOOKED [OUT NOW] | NOTION | 2022-06-09 |
| Schnappi | MongolianChildrensSong | 2022-06-09 |
| Daga Da | Sammy Virji | 2022-06-09 |
| Astrix - Deep Jungle Walk (He.Art) | nukirowson | 2022-06-09 |
| Careless Whisper | GeorgeMichael | 2022-06-09 |
| Weird Fishes | Lianne La Havas | 2022-06-09 |
| Solid Space - Destination Moon (1982) | Herve Teckel | 2022-06-09 |
| STEREO LOVE | Lauren Carlyle | 2022-06-09 |
| Machine Girl - Krystle (URL Cyber Palace Mix) | DREDCOL. | 2022-06-09 |
| Lose Yourself | Eminem | 2022-06-09 |
| I smell marijuana | Ethan Overton | 2022-06-09 |
| Matrix & Futurebound - Got You There (T & Sugah remix) | T and Sugah | 2022-06-09 |
| Last Friday Night (T.G.I.F.) | KatyPerry | 2022-06-09 |
| BLACK CINDERELLA FT ERROL DUNKLEY - SELECTA J-MAN REMIX - CLIP | Chopstick Dubplate | 2022-06-09 |
| Wings X Us (dnb mix) - Maya Randle | mayarandle | 2022-06-09 |
| Surumu | Sascha Funke/N/A | 2022-06-09 |
| Game Boys - Tetris (Blood Remix) | ALICE OUT OF SPACE | 2022-06-17 |
| House of Hip Hop - Various Artists (L.M.R. Edition) | DJ L.M.R. | 2022-06-17 |
| Julian Jumpin Perez On Party Radio B96 | Sounds Good Productions | 2022-06-17 |
| 624 - Dave Clarke - Back In The Box  (2008) | The Classic Mix CD Series | 2022-06-17 |
| Man with a Horn (Peter Presta's Remix) | Irving Project | 2022-06-17 |
| Various Artists - Hold Me On | DjChaves PopMusic | 2022-06-17 |
| Oh Well, Oh Well Mix | hope-is-in-music | 2022-06-17 |
| Carnibal 002 , Various Artists (snippet), Out Now on Juno | Carnibal Records | 2022-06-17 |
| Too Turned On | Alisha | 2022-06-17 |
| It's Hard Sometimes | Frankie Knuckles | 2022-06-17 |

_Added uses rekordbox StockDate when populated; otherwise file creation date (may predate library import)._

## Recently Added, Not Played Yet

_All recent additions have been played, or no recent additions._

## Prep Audit (BPM / key / hot cues missing)

| Title | Artist | Missing |
|-------|--------|---------|
| DJ Friendly | Elkka | hot cues |
| HEADIE ONE X DRAKE - ONLY YOU FREESTYLE (SLICK'S LETHAL EDIT) | Slick | hot cues |
| Installation | Pangaea | hot cues |
| My Singing Monsters - Plant Island | GhostMeow | hot cues |
| Pour the Milk | Robbie Doherty | hot cues |
| Wave Corners - Even Mike (Dissolver Remix) | ʍɐʇ ıs uɐʇ | hot cues |
| Shy FX - Original Nuttah 25 (Skeptic Speedy G Dub) | BlueDollarBillz | hot cues |
| Murg - Grove Street | Murg | hot cues |
| She Said  ++  Free Download | Introversion | hot cues |
| Always Keep It 69 | Partiboi69 | hot cues |
| Hammer House - The Jumper (Mass Medium Remix) | Hammer House | hot cues |
| Summer In New York (DubDogz & Selva Remix) | SOFI TUKKER | hot cues |
| Crank That - Osmosis Jones | Osmosis Jones | hot cues |
| Pump Up the Jam - DJ Reiz | DJ Reiz | hot cues |
| Raingurl | Yaeji | hot cues |
| Technotronic- Pump up the jam (NightFunk Remix) | NightFunk | hot cues |
| Trance wax - Trance wax 5 (NTBR edit) | NTBR | hot cues |
| DJ Reiz - Faust Into The Stars | Union Trance Mission | hot cues |
| Premiere: Sally C 'Let's Get This' | Mixmag | hot cues |
| Countdown | Bushbaby | hot cues |
| ATW - HYPE | BlueDollarBillz | hot cues |
| Free From Desire - Jualian Muller | HATE | hot cues |
| Go (Claude VonStroke Remix) | The Chemical Brothers | hot cues |
| Incident Prism - Gang Bounce (Héctor Oaks as DJKAOS11 Remix) | Molekül | hot cues |
| Michael Bibi - Hanging Tree (Original Mix) | MichaelBibi | hot cues |
| icy girl - lucavanlocke | lucavanlocke | hot cues |
| Dj Streaks - BIG WHIPS, BIG GUNS [HZRX] | HOUZ | hot cues |
| Do It Right (feat. Tkay Maidza) | martinsolveig | hot cues |
| Godzilla Dub | ZeroFG | hot cues |
| Lauryn Hill - Doo Wop (That Thing) (Kreature 2 Step Mix) \|\| Bodygruv Dubs \|\| 2023 | BlueDollarBillz | hot cues |
| Leave You In My Dust - $leazy | Kevin M | hot cues |
| More Girls Plz, 2 Many Men | Max Durham | hot cues |
| Prozak - Hotsteppa \|\| Self-Released \|\| 2023 | BlueDollarBillz | hot cues |
| Skin On Skin // Eye for a Eye // CLEAN BOILER ROOM EDIT | Sandals | hot cues |
| The Difference (feat. Toro y Moi) [Willaris. K Dub] | Flume | hot cues |
| The Weekend [Michael Gray] | Benedict Bernabe | hot cues |
| 69 Ur Enemies | Partiboi69 | hot cues |
| Loïcc - Watagans Crux (Eastern Distributor's Psytekk Mix) [FC01R] | FAN CLUB© | hot cues |
| Narciss - Sundowner (Body 2 Body Mix) [LT073 \| A2 \| Premiere] | NovaFuture | hot cues |
| Rich Girl - Aurenz | Aurenz | hot cues |
| That Got Dark - Interplanetary Criminal Remix | Bluetoof/Interplanetary Criminal | hot cues |
| hollaback girl - RAW | RAW | hot cues |
| Crank That - Juicy Selektah | Filth Inc. | hot cues |
| Energy | STACE CADET | hot cues |
| Flume Never Be Like You (Martin Solveig remix) | martinsolveig | hot cues |
| Glamorous (Janis €uro Dance Edit) FREE DL | Janis Zielinski | hot cues |
| K On My D + C - X-Coast K-Hole Mix | Partiboi69/Juicy Romance/X-COAST | hot cues |
| OFD025 - Digga D - WHO? [Upper90 Edit] | ỌZỌ | hot cues |
| Ruff Sqwad - Together (Brion Edit) | Brion Moore | hot cues |
| The 302 (Patrick Topping Edit) | DJ Deeon & Gettoblaster | hot cues |
| Walking Away - pb69 | Partiboi69 | hot cues |
| Bicep - Glue | ALI  HAERY | hot cues |
| Can I Vape In Here? | Partiboi69 | hot cues |
| Cola (Club Mix) | CAMELPHAT | hot cues |
| God Made Me Phunky - Marlon Hoffstadt Acid Mix | MD X-Spress/Marlon Hoffstadt | hot cues |
| Gotta Let You Go - DSNT | DSNT Records | hot cues |
| Narciss - Until The Day We Meet Again [Artaphine Premiere] | Artaphine | hot cues |
| Other Shit - Josh Christian | Josh Christian | hot cues |
| Partiboi69 - My Favourite Number | Mutual Pleasure | hot cues |
| Play Wit My Drums | DJ Assault | hot cues |
| Pump It (DJ Deeon Remix) | DJ Funk | hot cues |
| Skin on Skin - For Tha Shot | Steel City Dance Discs | hot cues |
| Stray Dogs | Mistr Dean | hot cues |
| The Seducer | Max Dean | hot cues |
| The Underground (Addictive Trip Mix) [feat. Celeda] | Saeed & Palash & Saeed Younan | hot cues |
| Turpins Falls (feat. Nyla Hunter) | Cassettes For Kids / Point of You | hot cues |
| What's A Girl To Do (Dubspinna Festival Remix) - Fatima Yamaha | dubspinna | hot cues |
| Who's Got The Ketamine?! | Partiboi69 | hot cues |
| Binary Finary - 1998 (Original Mix) | Binary Finary | hot cues |
| CORONA MAKES ME LOSE MY BREATH | benuebermensch | hot cues |
| Derrière | Logic1000 | hot cues |
| Edge of Saturday Night | The Blessed Madonna & Kylie Minogue | hot cues |
| Ghetto Kraviz (DJ Slugo 'Juke' Remix 2) | Nina Kraviz | hot cues |
| Go - Claude VonStroke Remix | The Chemical Brothers/Claude VonStroke | hot cues |
| Madonna - Hung Up | Madonna | hot cues |
| My Body Hurts | SOFI TUKKER | hot cues |
| Partiboi69 - K On My D+C (ft. Juicy Romance) | Mutual Pleasure | hot cues |
| Partiboi69 - Wine Dine 69 | Mutual Pleasure | hot cues |
| Pure Bliss Meltdown | Loods | hot cues |
| S.C.D.D. HAZMAT Team – I Love This City | Steel City Dance Discs | hot cues |
| STÜM - Telepathy | exxy | hot cues |
| Turbo Ride | Sedef Adasi | hot cues |
| Walking On A Dream - Sam La More | Empire Of The Sun | hot cues |
| Wouldn't You Like To Be A Hoe Too | DJ Slugo | hot cues |
| Zdarlight | Digitalism | hot cues |
| Club Is On Fire | Mickey Kojak | hot cues |
| Control The Party | Prospa | hot cues |
| DJ Fresh - Gold Dust (Tsuki Remix) | Tsuki | hot cues |
| Denis Sulta - Dubelle Oh XX (Jackmaster VIP) | Prest | hot cues |
| Don't Like - skin on skin | Skin On Skin // Stay On Sight Recordings | hot cues |
| FA$HION KILLA | t e s t p r e s s | hot cues |
| Lemin -  Yokota Groove | Lemin | hot cues |
| Martin Solveig & GTA - Intoxicated [OUT NOW] | Spinnin' Deep | hot cues |
| PREMIERE: LB aka LABAT - Feel the Beat (Partiboi69 Remix) | Bolting Bits | hot cues |
| Peak | Ahadadream | hot cues |
| Praise The Lord - DURDENHAUER | DURDENHAUER | hot cues |
| Promiscuous - Josh Coakley | Josh Coakley | hot cues |
| S.E.X - C.G.P (Conant Gardens Posse) Remix | Omar S/L'Renee | hot cues |
| Sex In The Club | MCR-T x Partiboi69 | hot cues |
| Srt | DJ Deeon | hot cues |
| Super Sharp Shooter (Dijon Coleman's Room Two Remix) | The Ganja Kru | hot cues |
| Sweater Weather | Jomarijan | hot cues |
| AJ Tracey & Aitch - Rain (Count Donkula Cats n Donx Bootleg) | Count Donkula | hot cues |
| ASS ATTACK | SKY LEON | hot cues |
| Acid Movement | Granary 12 | hot cues |
| All That Acid (can play up to 140) | Mickey Kojak | hot cues |
| Bours?  - Birds Of Marigny (KTK Records) | THE BRVTALIST | hot cues |
| Color Your Brain - Brown | Fky | hot cues |
| DJ Assault - Nympho | Benjamin Guena | hot cues |
| Dj Gius " De-Generation" | MissYAMA | hot cues |
| Dj Slugo (ZeroTwoVibes Tehno Rework) - Wouldn't You Like To Be A Hoe Too | itacher | hot cues |
| Dom Dolla - San Frandisco | ⠶ Dom Dolla ⠶ | hot cues |
| Douha (Mali Mali) | Disclosure | hot cues |
| Energia | SOFI TUKKER | hot cues |
| Faneto - Slick | Slick | hot cues |
| Hard 2 B N Love | Lyric | hot cues |
| Ho Chi Min (feat. Bèo Dạt Mây Trôi & HCMC Students) | Red Axes | hot cues |
| House Of Orgasm | Dj Peter G & The Clubjock | hot cues |
| How Deep Is Your Love | Calvin Harris | hot cues |
| I LIKE TO MOVE IT - MASTIKSOUL REMIX | mastiksoul | hot cues |
| Interplanetary Criminal - Pose Up Kill Dem [Warehouse Rave] | SWL 2TON | hot cues |
| Jordan 1s - Effy Rework | Vv Pete/UTILITY/Effy | hot cues |
| Magnificent | Partiboi69 | hot cues |
| Mall Grab - Breathing | Mall Grab | hot cues |
| Manía (feat. Jazz Alonso) | Pangaea | hot cues |
| Modern Romance | Catz 'N Dogz & Gerd Janson | hot cues |
| Perfect (Exceeder) [Outwork Vocal Remix] | Mason; Princess Superstar | hot cues |
| Please Playboy | Ben Hemsley | hot cues |
| Pula Perereka | Doctor Jeep | hot cues |
| Russian Porn Magazine | Vladimir Dubyshkin | hot cues |
| SHOW ME LUV | FELIXCW | hot cues |
| SOFI TUKKER & John Summit - Sun Came Up (Claptone Remix) | SOFI TUKKER | hot cues |
| SPECIAL INTEREST - Street Pulse Beat (Boy Harsher Remix) | Boy Harsher | hot cues |
| STÜM - Watch Ya Self | STÜM | hot cues |
| Sam Alfred - 1999 | Happy Wax Records | hot cues |
| Skulls | Red Axes | hot cues |
| Slingshot (Roza Terenzi Remix) | Solar Suite | hot cues |
| Sound Test | Red Axes | hot cues |
| Souvlaki - Inferno (Fired Up Mix) | James Byrne | hot cues |
| Space Cowboy (Classic Radio) | Jamiroquai/David Morales | hot cues |
| Todd Edwards - Shut The Door ( Todds Original ) | Bangerboy | hot cues |
| Acid Phase (Kai Tracid Remix) | Emmanuel Top | hot cues |
| Alison's Gaff [Free DL] | Cedarwood State Trax | hot cues |
| Born Slippy (Nuxx) | Underworld | hot cues |
| Country & Western - Centrifuge (1993) | Caliggiasound1993 | hot cues |
| Dave Winnel feat. Alst3n - Jungle Juice | Dave Winnel | hot cues |
| Farley Knows House | Farley "Jackmaster" Funk | hot cues |
| Greaze Mode - Adam Cutting | Adam Cutting | hot cues |
| Gypsy Woman (Kaytronik Remix Extended Version) | r2records | hot cues |
| House Is (Mike Dunn BlackBall Vokal MixX) | Black Widow | hot cues |
| House Is - Mike Dunn BlackBall Vokal MixX | Black Widow/Mike Dunn | hot cues |
| Hume Highway Hakke | Steel City Dance Discs | hot cues |
| Juicy Romance - Hummer | Mutual Pleasure | hot cues |
| Let Go | Partiboi69 | hot cues |
| Lights Out | Mickey Kojak | hot cues |
| Medicine | Jansons/Dope Earth Alien | hot cues |
| No Place Like Home | Partiboi69 | hot cues |
| Nosebleed Section - LUUDE | LUUDE | hot cues |
| Premiere: D.Dan - Haashish Gadani [Lobster Theremin] | When We Dip | hot cues |
| Premiere: Trudge - Ice On My Neck [LT079] | RAW | hot cues |
| Rubi's Acid Spa | Dr. Rubinstein | hot cues |
| Six Foe - Seasons | Swedish Fish | hot cues |
| Soichi Terada & Masalo - Diving Into Minds (Club Mix) | Acid (Tanzaro) | hot cues |
| The Ganja Kru - Super Sharp Shooter (Dijon Coleman's Room Two Remix) \|\| Self-Released \|\| 2018 | BlueDollarBillz | hot cues |
| The Heavyweight Kru - Bad Ass Bass | TheCunce | hot cues |
| Thirsty | Elkka | hot cues |
| Travelling Jazz | Herr Krank/Jean De La Fonk | hot cues |
| WHEN DESIRES TURN EVIL | TAFKAMP | hot cues |
| Wicked Wicked Jungle Is Massive (Ali G Indahouse) O7TklQTeuSE Youtube | user | hot cues |
| 2 The Groove - Dr. Bounce Remix | B.O.B. Ltd./Mr. Ocean/Dr. Bounce | hot cues |
| 4am | Katia Val | hot cues |
| 681 | Skeptic | hot cues |
| Alcemist - Repression | DnB Allstars | hot cues |
| Ale Castro & The Checkup - Last Minute (Eden Burns Remix) | Pets Recordings | hot cues |
| Automat | Anderson | hot cues |
| Back to the Groove | Justin Jay/coldsweat/DJ Deeon | hot cues |
| Bad Ass Bass | The Heavyweight Kru | hot cues |
| Barbra Streisand (Radio Edit) | Duck Sauce | hot cues |
| Bitch I Ain't The One | Detroit In Effect | hot cues |
| Blackwater (E-Dancer Vocal Dub Edit) | Octave One | hot cues |
| Blawan - My Guide To Dancing On Carpet [TESC008] | Lasha Mikaia | hot cues |
| Blue Monday (DJ Dan Remix) | Orgy | hot cues |
| Blurred - Pianoman Original Club Mix | Pianoman | hot cues |
| Bou & Trigga - Veteran VIP | Skankandbass | hot cues |
| Business Generation (feat. Krol) | Aman Umber | hot cues |
| Cue Music | Mike Simonetti | hot cues |
| D Shake - Yaaah (Original Mix) | Retro Trance Records | hot cues |
| DA FLOW | Shay Whelan | hot cues |
| DJ Dolphin (DJ Heartstring Remix) | Grand V | hot cues |
| Dale Dale | DJ Tennis & Luke Alessi | hot cues |
| Deep Dream | Ebbs N Flow | hot cues |
| Detroit In Effect - Shake a Lil' Faster | MAYONNAISE | hot cues |
| Dich Verlieren (ft. elinorac & Kissing Disease) [KTA019] | Butschi & Trancemaster Krause | hot cues |
| Doo Wop (That Thing) (Kreature 2 step mix) | Ms. Lauryn Hill | hot cues |
| Drop the Pressure | Mylo | hot cues |
| Drunk n Space (Count Donkula edit) | OMFO | hot cues |
| Estelle, Kanye West - American Boy (Riordan Edit) [BRIEFLY FILTERED FOR COPYRIGHT REASONS] | Riordan | hot cues |
| F-ME | 𝕸𝖊𝖟𝖊𝖗 𝕿𝖍𝖊 𝕬𝖗𝖈𝖍𝖎𝖙𝖊𝖈𝖙 | hot cues |
| Faster Alone | Malugi & Marlon Hoffstadt | hot cues |
| Gala - freed from desire | Ryan Bramley | hot cues |

_Sorted by most-played first. Tracks already in rotation are the most valuable to prep._

## Played Together (track pairs sharing many sessions)

| A | B | Sessions |
|---|---|----------|
| party up (dmx) (gimela) | Free Yourself (The Obsessed) | 27 |
| DJ Friendly (Elkka) | Installation (Pangaea) | 27 |
| Bump It xo (AISHA (Sco)/Franck) | DJ Friendly (Elkka) | 23 |
| Bump It xo (AISHA (Sco)/Franck) | Installation (Pangaea) | 22 |
| Spring Girl (Vintage Culture Remix (Extended)) (Maori, Adam Ten) | ColaZero (Clüb De Combat) | 22 |
| Malugi & Marlon Hoffstadt - Faster Alone (Original Mix) (Marlon Hoffstadt) | Installation (Pangaea) | 22 |
| Malugi & Marlon Hoffstadt - Faster Alone (Original Mix) (Marlon Hoffstadt) | DJ Friendly (Elkka) | 21 |
| Body Move (Vocal Mix) (Jelsen) | party up (dmx) (gimela) | 20 |
| Spring Girl (Vintage Culture Remix (Extended)) (Maori, Adam Ten) | party up (dmx) (gimela) | 20 |
| party up (dmx) (gimela) | ColaZero (Clüb De Combat) | 20 |
| Dance Power 90 (Upper90) | Do What You Want (The Presets) | 20 |
| Bump It xo (AISHA (Sco)/Franck) | House of Pleasure (Narciss) | 19 |
| Spring Girl (Vintage Culture Remix (Extended)) (Maori, Adam Ten) | Give You (Odd Mob) | 19 |
| party up (dmx) (gimela) | Give You (Odd Mob) | 19 |
| Give You (Odd Mob) | Push The Tempo (Odd Mob Extended Mix) (Sub Focus, Katy B) | 19 |
| Give You (Odd Mob) | ColaZero (Clüb De Combat) | 19 |
| DJ Friendly (Elkka) | House of Pleasure (Narciss) | 19 |
| Shy FX - Original Nuttah 25 (Skeptic Speedy G Dub) (BlueDollarBillz) | Marlon Hoffstadt aka DJ Daddy Trance - Bass Is Pumping (Marlon Hoffstadt) | 19 |
| Installation (Pangaea) | House of Pleasure (Narciss) | 19 |
| Body Move (Vocal Mix) (Jelsen) | Spring Girl (Vintage Culture Remix (Extended)) (Maori, Adam Ten) | 18 |
| Body Move (Vocal Mix) (Jelsen) | Body Musik (DJ Deeon) | 18 |
| Body Move (Vocal Mix) (Jelsen) | ColaZero (Clüb De Combat) | 18 |
| Speed It Up - Dr. Bounce Remix (Club Caviar/Dr. Bounce) | Malugi & Marlon Hoffstadt - Faster Alone (Original Mix) (Marlon Hoffstadt) | 18 |
| Speed It Up - Dr. Bounce Remix (Club Caviar/Dr. Bounce) | Vladimir Dubyshkin - Russian Porn Magazine (trip) | 18 |
| Speed It Up - Dr. Bounce Remix (Club Caviar/Dr. Bounce) | Installation (Pangaea) | 18 |
| Seguimento (CRAZED (BR)) | KNOW BETTER (6 SENSE) | 18 |
| Spring Girl (Vintage Culture Remix (Extended)) (Maori, Adam Ten) | Push The Tempo (Odd Mob Extended Mix) (Sub Focus, Katy B) | 18 |
| party up (dmx) (gimela) | Push The Tempo (Odd Mob Extended Mix) (Sub Focus, Katy B) | 18 |
| Malugi & Marlon Hoffstadt - Faster Alone (Original Mix) (Marlon Hoffstadt) | Vladimir Dubyshkin - Russian Porn Magazine (trip) | 18 |
| Vladimir Dubyshkin - Russian Porn Magazine (trip) | Installation (Pangaea) | 18 |
| Push The Tempo (Odd Mob Extended Mix) (Sub Focus, Katy B) | ColaZero (Clüb De Combat) | 18 |
| Free Yourself (The Obsessed) | Dance Power 90 (Upper90) | 18 |
| Sims 2000 (Indecorum) | Suzuka (Sam Alfred) | 18 |
| Body Move (Vocal Mix) (Jelsen) | Give You (Odd Mob) | 17 |
| Speed It Up - Dr. Bounce Remix (Club Caviar/Dr. Bounce) | DJ Friendly (Elkka) | 17 |
| DJ Friendly (Elkka) | Vladimir Dubyshkin - Russian Porn Magazine (trip) | 17 |
| I GET DEEP (Close to Custom) | Razor Cut (Tension Mix) (Tywi) | 17 |
| Titty Twister (Viper 2) | Morning Disco Tonic Bongo (Belaria) | 16 |
| Titty Twister (Viper 2) | DJ Logic Please Forgive Me (Logic1000) | 16 |
| Body Move (Vocal Mix) (Jelsen) | Push The Tempo (Odd Mob Extended Mix) (Sub Focus, Katy B) | 16 |
| Bump It xo (AISHA (Sco)/Franck) | Malugi & Marlon Hoffstadt - Faster Alone (Original Mix) (Marlon Hoffstadt) | 16 |
| Bump It xo (AISHA (Sco)/Franck) | Free Yourself (The Obsessed) | 16 |
| Bump It xo (AISHA (Sco)/Franck) | Rompa Stompa (Ingo/Charlotte Birch) | 16 |
| Seguimento (CRAZED (BR)) | Sims 2000 (Indecorum) | 16 |
| Seguimento (CRAZED (BR)) | Suzuka (Sam Alfred) | 16 |
| party up (dmx) (gimela) | Body Musik (DJ Deeon) | 16 |
| party up (dmx) (gimela) | Dance Power 90 (Upper90) | 16 |
| Morning Disco Tonic Bongo (Belaria) | DJ Logic Please Forgive Me (Logic1000) | 16 |
| DJ Friendly (Elkka) | Free Yourself (The Obsessed) | 16 |
| DJ Friendly (Elkka) | Rompa Stompa (Ingo/Charlotte Birch) | 16 |

## Distribution (plays across BPM and key)

**BPM (share of plays):**

- <100: 67 (1%)
- 100-119: 99 (1%)
- 120-127: 2130 (23%)
- 128-134: 2044 (22%)
- 135-144: 2904 (31%)
- 145-159: 1748 (19%)
- 160+: 360 (4%)
- unknown: 0 (0%)

**Top keys (Camelot, by plays):**

- 6A: 1170
- 5A: 932
- 4A: 794
- 8A: 768
- 3A: 610
- 11A: 598
- 9A: 586
- 7A: 575

## Summary Stats

- Total sessions in state.db: 481
- Total unique tracks ever played: 2021
- Tracks currently in library: 6878
- Tracks in state.db (incl. deleted): 6878
- USB drives seen: 5
- State.db last updated: 2026-05-28T05:11:07.492067+00:00
