# Set Memory - ground-up design

A blind redesign for Rob's DJ history + rekordbox playlist tool. macOS 14+, Apple Silicon, on-machine only. Two co-equal headlines: **Set Memory** (every track he has ever played, deduped across USBs) and **Playlist Lab** (suggestions written back to rekordbox).

The reference register is rekordbox 6.8.6, Things 3, Soulver 3, Reeder 5, Linear, Plex, Tana. The anti-register is shadcn, v0, Lovable - the boxy card-and-stat-tile look. Every decision below is made against the 75-item AI-tells ban list.

---

## 1. Architecture sketch

Three processes, one bundle:

- **Set Memory.app** - SwiftUI front end, AppKit where SwiftUI is too generic (custom row, custom waveform strip, custom About panel).
- **smd** (Set-Memory daemon) - a small `XPC` helper that owns the SQLCipher + DeviceSQL parsers, the dedupe index, and rekordbox writebacks. Front end never touches disk except for window state.
- **smwatch** - a launchd-loaded `DA_REGISTER_CALLBACK` USB watcher (DiskArbitration framework) that fires the moment a `PIONEER/` directory appears on a mounted volume. No polling.

Files (in `~/Library/Application Support/com.mord58562.set-memory/`):

```
library.db            SQLite (WAL). One row per unique track (hashed). Plays as a child table.
sessions.db           One row per CDJ session (USB + date + venue if inferred).
hashes/<sha1>.parts   Track fingerprints (BPM/key/duration/path-hash 4-tuple) for dedupe across USBs.
imports/<usb-id>.log  Per-USB ingest log, append-only. Replay = full rebuild.
rekordbox.lock        Acquired before any write to rekordbox 6 master.db.
```

The pipeline (USB plugged -> suggestion on screen, target <10s for a 200-track USB):

1. `smwatch` sees `PIONEER/` appear on `/Volumes/HDJ-S1`. Posts a `Darwin notification`.
2. `smd` opens the SQLCipher master.db read-only with the published key derivation, or the DeviceSQL `export.pdb` if older. Streams rows; never loads the whole DB.
3. Each row hashes to a track key `(title-norm, artist-norm, duration-quantised-to-second, BPM-quantised-to-0.01)`. SHA1 the tuple. If the hash exists in `library.db`, attach a new play row; else insert track + play.
4. Sessions inferred by gap-clustering plays: any gap >40 min = new session. Venue inferred from the USB volume name if it follows Rob's convention (he renames USBs `HOLIDAY-PROHIBITION-2025-09-12` etc.); otherwise null.
5. As sessions land, the **Playlist Lab** worker reruns its candidate index incrementally: not 70 algorithms, one composable scorer with named recipes (see §5). Suggestions written to `library.db.suggestions` with provenance.
6. Front end observes via `NSFilePresenter` on `library.db-wal`. New rows fade in.

Writeback to rekordbox: `smd` reads `~/Library/Pioneer/rekordbox/master.db` SQLCipher key (already public knowledge in the Pioneer community), takes an exclusive lock, writes new rows into `djmdPlaylist`, `djmdSongPlaylist` matched by `Content.ID`, and triggers a USN bump so rekordbox sees the change on next focus. Rekordbox must be quit during write; we detect via `NSRunningApplication` and surface a single banner with a "Quit rekordbox for me" affordance.

The 10-second budget: parse + hash is ~3s for 200 tracks on M-series; session segmentation is ~50ms; suggestion rescore is ~1.5s; UI fade-in starts at row 1, not at row N. Total perceived first-suggestion time is closer to 2s.

---

## 2. Information architecture

**Two surfaces, not seven.** Most tools of this shape default to sidebar (Library, Sessions, Playlists, Tags, Smart Folders, History, Stats, Settings) - eight items, all top-level, the tell #48. Refused.

The app has exactly two screens, switched by a single hardware-feeling toggle in the title-bar area:

- **HISTORY** - the Set Memory surface. Browse what was played.
- **LAB** - the Playlist Lab surface. Browse what could be played next.

A third pseudo-surface is **the session strip** - a horizontal scrollable ribbon of sessions, always present at the bottom of either screen. It's not a screen; it's an inhabitant. Clicking a session in the strip filters whatever's above it. This is the editorial decision: **sessions are not a tab, they are the spine**. Everything is "scoped to one or more sessions". The default scope is all-time; a click on the strip scopes to one night; shift-click extends.

What's hidden:

- No "Stats" page. Counts appear inline in section headers (`HISTORY · 14,228 plays · 3,107 tracks · 96 sessions`) as a single muted line, not a tile grid.
- No "Tags" page. Tags live as inline chips on rows, filterable by clicking a chip - no separate management UI until that meta-volume justifies it.
- No "Library" / "Imports" / "USBs" page. USB status is a single dot in the title bar. Click it for a popover with the import log when something is wrong.
- No Welcome / Onboarding. First launch shows the empty state of HISTORY with a single one-liner (see §8). Plug a USB, the app fills in.

Navigation model: the sidebar is *the session strip on the bottom*, rotated to where the data actually wants to live. Time goes left-to-right. This is the apartment-floorplan equivalent of "the kitchen is at the back".

---

## 3. Visual design system

### Type ladder (one face, weight + size do the work)

One sans for UI: **Söhne** (licensed, cached locally) - failing that, **SF Pro Text** (NOT iOS 17pt body; macOS 13pt is the floor). One mono for numerics: **SF Mono**, always `monospacedDigit()`. No third face.

| Token | Size | Weight | Tracking | Use |
| --- | --- | --- | --- | --- |
| display-32 | 32 pt | 600 | -0.4 px | session date in inspector |
| header-19 | 19 pt | 600 | -0.25 px | screen title (`HISTORY`, `LAB`) - UPPER, restrained |
| section-13 | 13 pt | 500 | +0.1 px | section dividers inside a screen |
| body-13 | 13 pt | 400 | 0 px | track title |
| meta-11 | 11 pt | 400 | +0.2 px | artist, label, year |
| caption-10 | 10 pt | 500 | +0.6 px | column headers (the one place UPPER+tracked is allowed) |
| numeric-13 | 13 pt | 400 mono | tabular | BPM, key, ordinal counts |
| numeric-split | 13/11 pt | 500/300 mono | tabular | `128.04` rendered with `.04` at 11pt 300 weight - signature element (§11) |

Four weights used (300, 400, 500, 600). 700 is reserved and unused - holding it back is a tool.

### Palette (5 colours, named, no Tailwind ramp)

Dark mode is the only mode shipped. Light mode is deferred until Rob asks; a DJ tool exists in dark rooms.

| Token | Hex | Role |
| --- | --- | --- |
| `ink` | `#0B0E13` | base background. Deep blue-black, never pure #000. |
| `slab` | `#141821` | row surface, panels. |
| `slab-hi` | `#1B2030` | hovered or selected row. |
| `rule` | `#252B3A` | 1px insets - never used as a drop shadow. |
| `fog` | `#9AA3B8` | secondary text (artist, year). |
| `pearl` | `#E6E8EF` | primary text. Off-white, slightly cool. |
| `ember` | `#E2723A` | warm accent. Used once per surface: the "needle" - the current selection, the in-flight suggestion, the now-playing import. |
| `tide` | `#5A8FB0` | cool accent. Used for healthy state: USB connected, write succeeded, sessions detected. |

That's it. Two neutrals' worth of greys, primary + secondary text, one warm needle, one cool tide. No reds, no greens, no semantic palette. Errors borrow ember; success borrows tide.

Data-meaningful colour exists in *one* place: the **BPM strip** behind a row, an inline 4px-tall sparkline coloured along a tempo ramp (`#3A5E80` at 60 BPM through `tide` at 120 through `ember` at 150 through `#C04A2C` at 180). Same ramp used for the session-strip energy histogram. Camelot keys get the standard wheel colours (the only third-party convention honoured, because DJs already know it).

### Spacing scale

4 / 8 / 12 / 20 / 28 / 48. Note 20 and 28 instead of 16 and 24 - this breaks the 8-grid lock that screams template. Page-edge insets are 28; row vertical padding is 8; section gaps are 48 (deliberately generous - negative space is a design element).

### Radius scale

Three values: **2** (chips, BPM pill), **6** (row, popover), **10** (window-attached panels). No 8. The slight off-by-one creates an unconscious "this isn't shadcn" cue.

### Elevation

No drop shadows. Z-axis via inset 1px `rule` borders at the panel boundary and a single 1px highlight at the top of any raised surface (`#FFFFFF` at 4% opacity). Plex-style.

### Motion timings

- Hover-into-state: 80ms ease-out (cubic-bezier 0.2, 0, 0, 1).
- Selection: 120ms ease-out, no scale change.
- Row insert (new play from a fresh USB): 220ms enter, 60ms internal stagger across siblings, no exit animation - data appearing should feel like silt settling.
- Session strip scope change: 180ms cross-fade on the upper content, no slide.
- Suggestion writeback: 400ms confirm flash on the affected row, then 1200ms slow `tide` to `pearl` fade on the writeback dot.
- `prefers-reduced-motion` swaps every transition for opacity-only.

### Custom signature elements (recurring across screens)

1. **The split decimal**: every BPM and every percentage renders integer-at-13pt-500 and decimal-at-11pt-300, baseline-aligned. Borrowed-from-rekordbox cue that immediately identifies the app.
2. **The tide dot**: a 6px circle in `tide` placed exactly 4px left of any row that has been touched in the last 24h. Things-3-checkbox energy but data-driven, not interactive.
3. **The ember needle**: a 1px vertical `ember` line, 12px tall, marking the currently-focused element in any list. Replaces the default macOS selection background entirely.

---

## 4. Headline surface design (open the app, see this)

```
┌──────────────────────────────────────────────────────────────────────────────┐
│  ●  HISTORY ─── LAB                                       ⟡ HDJ-S1  ⌘K       │
│                                                                              │
│                                                                              │
│   FRI 12 SEP · HOLIDAY PROHIBITION                                           │
│   3h 42m · 47 tracks · peak 128.04                                           │
│                                                                              │
│  │ 22:14   Body & Soul (Forrest)              hou  127.98  7A   ◆◆◆◆◆       │
│  │ 22:18   Make Me Feel (Joeski Rerub)        hou  128.01  7A   ◆◆◆◆◇       │
│ ▎│ 22:22   Diamond Life (Sade · Brawther)     dis  124.10  9A   ◆◆◆◆◇       │
│  │ 22:27   Music Sounds Better (Stardust)     fil  128.00  9A   ◆◆◆◇◇       │
│  │ 22:31   ...                                                                │
│                                                                              │
│   THU 04 SEP · SLYFOX BACK ROOM                                              │
│   2h 11m · 28 tracks · peak 137.02                                           │
│                                                                              │
│  │ 23:45   Bipolar Mind (Roman Flügel)        tec  137.02  4A   ◆◆◆◆◆       │
│  │ ...                                                                       │
│                                                                              │
├──────────────────────────────────────────────────────────────────────────────┤
│  ┃▁▂▃▅▇▆▅▃▂▁┃▁▃▆▇▇▇▅▃▂▁┃▂▄▆▇▆▄▂▁┃▃▅▇▇▆▅▃▂┃▁▂▃▅▇▇▆ ... 96 sessions  ←year→  │
└──────────────────────────────────────────────────────────────────────────────┘
```

What the user sees in the first half-second:

- **Two-word toggle, top-left.** No icons, no chrome. The active surface is in `pearl`; the inactive in `fog`. A 1px `ember` underline under the active word.
- **No hero, no welcome, no stat tiles, no card grid.** The screen IS the data.
- **Session headers** in `header-19` followed by a single muted summary line in `meta-11`. The header carries the venue if known.
- **Track rows** below each session header. The `▎` glyph in the leftmost column is the **ember needle** on the focused row. The `│` is the **tide rail** showing which rows had a play in the last 24h.
- **Session strip at the bottom** - per-session energy histograms (BPM distribution coloured along the tempo ramp), separated by `┃`. Scroll horizontally. Click a column = scope upper content to that session. Drag-select a range = scope to range. The strip is always 56px tall; never collapses; never hides.
- **Right of the title bar**: the USB dot (`⟡` glyph means a CDJ-format USB is mounted), and `⌘K` as the global jump key.

Visual hierarchy: time-then-track. The user's eye lands on the date first, scans down to the track, picks up BPM/key on the right. Nothing competes with that path. The session strip is at the bottom because it's the *map*, not the *content* - peripheral vision, always there, never in the way.

Asymmetric weighting: HISTORY content gets ~78% of the vertical real estate; the session strip gets 56px; the title row gets 32px. No 1/3-2/3, no sidebar, no inspector.

---

## 5. Suggestion design (the LAB surface)

LAB shares the chrome but the content shape is different. A suggestion is not a card and not a row; it's a **proposal**.

```
   FORGOTTEN FAVOURITES
   Played a lot, then dropped. Sorted by months-since-last.

   ▎ Sebkha (Mehmet Aslan)              dis  119.04  8A     played 11x, last 14 mo ago
     last in:  Mayfair · Apr 2024                            ▏ ▏▏▏ ▏  ▏     ▏

     EBO (Forrest) · same set, +2 BPM, 8A→9A · adjacent →

   ▎ Sundream (Rüfüs Du Sol · Joeski Rerub) tec 124.00 11A   played 9x, last 9 mo ago
     last in:  Slyfox · Aug 2024                              ▏▏▏ ▏▏     ▏ ▏

     [add to rekordbox playlist: ➜ Forgotten Favourites]
```

A suggestion has three lines:

1. **The track**, in the standard row format (§7), with the `▎` ember needle reserved for the user's focused suggestion.
2. **The "why" line** - one fragment of natural-language provenance: `played 11x, last 14 mo ago`, or `same energy as your Slyfox Aug set`, or `bridges Forrest → Sade by key`. No template like "Recommendation #3 of 70". Voice copy. Each recipe has its own grammar.
3. **The play-history sparkline** - a horizontal axis representing the last 24 months, with a 1px `tide` tick at every set the track appeared in. Empty space on the right = months-since-last, immediately visible.

70 suggestions are organised into **recipes** with editorial names, not algorithms with index numbers. Each recipe is a section header in the LAB surface:

- `FORGOTTEN FAVOURITES` - played ≥5 times, gap to last play ≥6 months.
- `BRIDGE TRACKS` - tracks Rob played between two genres that he often plays back-to-back.
- `KEY NEIGHBOURS` - tracks he owns and rates but hasn't played near a recent set's energy profile.
- `OPENERS` - tracks that have appeared in the first 4 of ≥3 sets.
- `CLOSERS` - the reverse.
- `BPM SIBLINGS` - tracks within 0.5 BPM of his most-played BPM in the last 90 days.
- `LATE-DOORS` - tracks played only after 02:30.

Seven recipes, ~10 suggestions per recipe, but each recipe expands lazily: the first three suggestions render eagerly; the rest are revealed by clicking the recipe header. **No infinite scroll. No "show more" generic text - the header itself ("FORGOTTEN FAVOURITES · 11") is the affordance.**

At-a-glance: title, artist, BPM, key, play count, months-since-last, the sparkline.
On-hover (after 100ms intent delay): the "add to rekordbox playlist" affordance appears at the right edge of the suggestion, slid in 8px from the right; the recipe name pre-fills the playlist name.
On-click: focuses the suggestion (ember needle), reveals the second-line "why", and surfaces an `adjacent →` link that previews the next two suggestions from the same recipe inline.

Navigating 70 without overwhelm: the seven recipe headers compress to a 24px tall strip when scrolled past, sticky. The user always has the recipe context. `J`/`K` walks suggestions; `H`/`L` walks recipes. One keystroke, ⌘⏎, writes the focused suggestion to the recipe-named playlist.

---

## 6. Set Memory surface (explore history)

HISTORY's job is one thing: **scoped browsing of plays in time order**.

Browse model:

- **Default scope** is "all time, all USBs". Sessions appear in reverse-chronological order, grouped by session.
- **Scope by clicking the session strip.** One click = one session. Shift-click = range. Cmd-click = multi-select non-adjacent.
- **Scope by typing.** `⌘K` opens a single-line "scope" field that accepts:
  - `bpm:128` or `bpm:128-132`
  - `key:7A` or `key:7A+9A`
  - `genre:house`
  - `played:>5` or `played:<2`
  - `last:>6mo`
  - `venue:slyfox`
  - free text matches title or artist
  - terms space-separated, AND by default; `|` for OR.
  - The scope appears as a row of removable chips below the title bar, never as a dropdown.

Search is debounced 120ms. Results render asynchronously; rows already on screen stay, non-matching rows fade out at 30% opacity rather than disappear (so the user can see what got excluded - one of Tufte's data-density moves applied to search).

Sessions ARE browsable as scenes:

- **Date** (always shown in header).
- **Venue** (if the USB volume name follows convention, or if Rob has manually labelled it).
- **Energy curve** - the per-session histogram in the bottom strip IS the scene's "shape". A long ramp from 120 to 134 looks visibly different to a peaky two-bumped 128/138 set.
- **Duration + track count + peak BPM** in the session-header summary line.
- **Right-click any session** reveals: rename, label venue, tag (`bday`, `b2b`, `daytime`), export tracklist as `.txt` to clipboard.

A session can be **promoted to the Lab** - a button at the right of the session header, label simply `analyse →`. Clicking jumps to LAB with the scope set to "find me tracks adjacent to this set". The two surfaces are linked, not siloed.

---

## 7. Track row design

The atom of the app. Used in HISTORY, in LAB suggestion proposals, and in the session-promoted analysis view.

```
 ▎│ 22:22   Diamond Life (Sade · Brawther Rerub)        dis  124.10  9A   ◆◆◆◆◇
                                                            ▁▂▃▃▂▁
```

Fields, left to right:

| Width | Field | Treatment |
| --- | --- | --- |
| 8 px | needle (`▎`) | `ember`, only on the focused row |
| 4 px | tide rail (`│`) | `tide` only if play within last 24h |
| 56 px | time (`22:22`) | `numeric-13`, tabular, `fog` |
| flex (45ch min) | title + artist | title `body-13` `pearl`; artist + remixer in parens `meta-11` `fog`. One line, ellipsised. |
| 36 px | genre tag | three-letter lowercase chip, `rule` background, `fog` text, radius 2. `hou tec dis dnb fil etc`. |
| 64 px | BPM (split decimal) | `128.04` rendered as 13pt 500 + 11pt 300; right-aligned. |
| 32 px | key | Camelot notation in mono-13, coloured by Camelot wheel. |
| 56 px | rating | 5 diamond glyphs (`◆◇`), `pearl` filled / `fog` empty. Diamond not star - star is the iTunes tell. |
| 80 px (HISTORY) | mini-sparkline | tiny BPM trajectory over the session, anchored on this track. Visible only on hover. |

Row height: **24px**. (Pro-tool density. SwiftUI's default 44px is the iOS tell.)
Row vertical padding: 4px top, 4px bottom.
Row hover: background shifts from `slab` to `slab-hi` over 80ms. The tide rail brightens by 15%.
Row selection: needle appears, never a background fill. **The whole row's text shifts up by 0.5px on focus.** A subtle physical cue, invisible until you notice it. (Delight detail per §9.)

The **signature visual element** of the row: the **split-decimal BPM**. Anywhere you see `128.04` rendered with the decimal in lighter weight, you know it's this app. It appears in every track row, every suggestion, every session header peak, and the LAB recipe sparklines.

---

## 8. Empty + partial + error states

Three categories per the AI-tells doc. Each gets insight + action, never icon + headline + body + button.

### Empty (no data at all - first launch)

```
   HISTORY


   Nothing here yet.

   Set Memory reads CDJ-export USBs (PIONEER/Master/master.db). Plug one in
   and the rows below fill in as they're parsed; the session strip at the
   bottom gets a notch for each set.


   ─ or, if you'd like to try the shape of the app ─

   Load the sample night  (one 3h set, 47 tracks, anonymised)
```

Left-aligned. No icon, no centred hero, no big button. The action is inline-linked text. The sample-night offer is the editorial decision - first run otherwise has zero data and zero shape.

### Partial (some USBs ingested, but the user just plugged a new one)

The session strip shows existing sessions plus a **breathing notch** at the right edge - a placeholder rectangle in `slab-hi` that pulses at 1.2s period until parse completes. Above, the new session's header appears immediately with the count incrementing live (`47... 62... 89 tracks`). No spinner, no progress bar, no toast.

### Error - three tiers

- **Inline (field-level):** the scope chip in `⌘K` that didn't match anything turns from `fog` to `ember` outline; tooltip-on-hover shows the parse problem.
- **Banner (page-level):** if `smd` can't read a USB's master.db (corrupt, wrong key, etc.), a single 32px-tall strip appears under the title bar:
  ```
   ⟡ HDJ-S1 · master.db won't open. SQLCipher key version 5; this build supports 4.
              Eject the USB and try the diagnostic build.  copy log  ✕
  ```
  Specific (key version), actionable (the actual next step), with two affordances (copy log, dismiss). No "Oops!" no "Something went wrong".
- **Full-page boundary:** reserved for `library.db` corruption. Renders only the title bar + a centred 320px panel: `Your history index can't be opened. The raw USB data is untouched. Rebuilding from the import logs takes about [42] seconds. [ Rebuild ]`. The bracketed number is computed from current import log size.

---

## 9. Interactions + micro-motion

What moves:

- **Row hover** - 80ms background shift only. Cursor stays default arrow (not pointer; this is a Mac).
- **Row focus** - 0.5px upward shift + ember needle fade in over 120ms. Doesn't move neighbours.
- **Session-strip scope** - clicking a column briefly enlarges that column's bar by 8% over 120ms, then settles. Upper content cross-fades, doesn't slide.
- **New play arrives from active USB ingest** - row fades in at 220ms, the tide rail flicks to full brightness, then settles to its resting tide colour over 800ms. Apparent rhythm of silt settling. Multiple new rows stagger by 60ms.
- **Suggestion writeback succeeds** - the `add to rekordbox playlist` affordance briefly inverts: ember background, ink text, for 300ms, then returns to its rest state with a small `tide` checkmark replacing the action text. After 1.2s the checkmark fades and the row gets a permanent `tide` dot in its leftmost gutter signifying "queued in rekordbox".
- **`⌘K` scope field** - slides down 24px from under the title bar, doesn't sheet, doesn't overlay. Hitting return removes the field and renders the chip below the title bar. Escape rolls it back up.

What's static:

- The session strip's per-column bars (until scope change).
- All numeric values - no count-up animations, no jitter (every numeric is `monospacedDigit`).
- Empty state - no breathing logo, no shimmer, no progress dots.

**The delight detail**: the **split-decimal BPM**, when the row is focused, very slowly (4-second period, sinusoidal) drifts the decimal portion's weight from 300 to 350 and back. It's subliminal - the decimal almost looks alive on the focused row. On unfocused rows it never moves. Reduced-motion turns it off entirely. This is the recurring "noticed once, kept" detail.

A second easter-egg-class delight (not user-discoverable from copy): the very first session ever ingested has its session-strip column rendered in `ember`, not the tempo ramp. The "you started here" marker. Never advertised; never explained.

---

## 10. Settings

Settings is a `Settings { ... }` SwiftUI **scene**, not a sheet. Three tabs, no more.

**General**:
- USB watch: on / off (default on).
- Auto-import on mount: on / off (default on).
- "Anonymise venue from USB name": on / off (default off; respects the convention).

**rekordbox**:
- rekordbox 6 master.db path - autodetected; field shown only if autodetection fails.
- "Quit rekordbox automatically before writing": off (default) / ask / yes.
- "Backup master.db before each write" - on (default, 5-deep rotating copies).

**About** is its own tab (NOT under General). Custom About panel via `NSApp.orderFrontStandardAboutPanel(options:)` with: app name in display-32, version in numeric-split, a single attributed credit line, and an inline mark of the brand glyph (§11) at 48×48.

What's NOT exposed (deliberately):

- No "theme" toggle. Dark only.
- No font size toggle (responds to system Accessibility text-size already).
- No telemetry toggle - there is no telemetry to toggle.
- No "Customise columns" - the row shape is the row shape.
- No notification preferences - the app emits none.
- No keyboard shortcut editor - they're discoverable in the menu bar.
- No syncing/backup config - that's Time Machine's job.
- No language picker - the app is English. If it ever ships multi-locale, it'll be a build, not a runtime toggle.

That's ~8 controls total. Compare to the 40-toggle AI-default Settings (tell #49).

---

## 11. Brand mark + signature element

### The 16×16 glyph

Drawn by hand in a `Path` constructor, not an SF Symbol. Reads as both a stylus needle and a waveform peak.

```
 . . . . . . . . . . . . . . . .
 . . . . . . . ▒ ▒ . . . . . . .
 . . . . . . ▓ █ █ ▓ . . . . . .
 . . . . . ▒ ▓ █ █ ▓ ▒ . . . . .
 . . . . . ▓ █ █ █ █ ▓ . . . . .
 . . . . . ▒ ▓ █ █ ▓ ▒ . . . . .
 . . . . . . ▒ █ █ ▒ . . . . . .
 . . . . . . . █ █ . . . . . . .
 . . . . . . . █ █ . . . . . . .
 . . . . . . . █ █ . . . . . . .
 . . . . . . . █ █ . . . . . . .
 . . . ▒ ▓ █ █ █ █ █ █ ▓ ▒ . . .
 . . . . . . . . . . . . . . . .
 . . . . . . . . . . . . . . . .
 . . . . . . . . . . . . . . . .
 . . . . . . . . . . . . . . . .
```

A faceted diamond at the top tapering into a 4-pixel needle that "lands" on a 14-pixel horizontal baseline. The diamond echoes the rating diamond in the row. The needle echoes the focus needle. The baseline echoes the tide rail. Three of the app's recurring elements compressed into one mark. Template, isTemplate=true; tints to `ember` in app, monochrome in the Dock and menu bar.

### The recurring visual signature

Two signatures (per "one anchor" guidance):

1. **The split-decimal numeric treatment** described in §3 and §7. It's the typographic equivalent of a brand voice - every number in the app is rendered this way.
2. **The needle + rail + diamond triplet.** The ember needle (focus), the tide rail (recency), the diamond rating. These three glyphs together identify a row at 100% zoom from a thumbnail.

A screenshot of any screen contains the split-decimal somewhere; any track row contains the triplet. Both pass the "would a designer name what maker built this" test.

---

## 12. macOS native moves

**Lean into:**

- `Settings { ... }` scene (not `.sheet`).
- `MenuBarExtra(.window)` for the import-status icon - the `⟡` glyph in the menu bar with a small `tide`/`ember` dot, click for a 280×360 popover showing currently-mounted CDJ USBs and their parse progress.
- `@SceneStorage` for window size, scope chips, and the session-strip scroll offset, restored across launches.
- `NSWorkspace.shared.notificationCenter` for USB mount/unmount events as the *secondary* trigger (DiskArbitration is primary).
- `.controlSize(.small)` plus `.formStyle(.grouped)` inside Settings.
- Custom About panel via `NSApp.orderFrontStandardAboutPanel(options:)`.
- `NSToolbar` with item identifiers (not the SwiftUI `.toolbar` shortcut) so the title-bar items get proper customisation, drag, and contextual menu support.
- Keyboard: `⌘K` scope, `⌘1` HISTORY, `⌘2` LAB, `J/K` row, `H/L` recipe, `⌘⏎` write to rekordbox, `⌘⌥⏎` write all visible suggestions to recipe-named playlists.
- AppleScript: minimal scripting dictionary exposing "session count", "last import date", "trigger rescan". No write actions exposed via AppleScript; safety boundary.

**Refuse:**

- `NavigationSplitView` (the universal AI default).
- `Label("Title", systemImage:)` rows.
- Default `Table` with striping.
- Sheet-as-Settings.
- iOS-port body sizes (17pt) on Mac.
- `.padding()` with no value.
- Tahoe/iOS 26 uniform glass.
- A "Customise Toolbar" sheet (the toolbar has 3 items; customisation is overkill).

---

## 13. One-decision-per-screen

- **HISTORY** is for *recalling what was played and when*. It refuses to recommend, to edit metadata, to play audio, to export anywhere except a tracklist to the clipboard. It is a museum.
- **LAB** is for *picking what to play next and committing it to rekordbox*. It refuses to display history except as one-line provenance under each suggestion. It is a workshop.
- **Session strip** is for *scoping*. It refuses to be a sidebar; it refuses to host editing; it refuses to grow taller than 56px.
- **`⌘K` scope** is for *narrowing the visible set*. It refuses to be a global app launcher, a settings opener, or anything else.
- **Settings** is for *the eight things that need to be tuned*. It refuses to surface column choices, theme toggles, or notification prefs.
- **Menu bar `⟡`** is for *background ingest status*. It refuses to be a popover into the full app.
- **About panel** is for *what this thing is*. It refuses to be an update channel or a marketing surface.

Each surface answers one question. Asked a second question, it points at another surface.

---

# Ship-v1: the 5 things to build first

1. **The row.** The split-decimal BPM, the needle, the tide rail, the diamond rating, the 24px height, the 11pt mono key in Camelot colours. If the row is right, every other surface is downstream. Build it as an isolated `View` with mock data and iterate it until it's identifiable.
2. **The session strip.** The per-session BPM histogram coloured by tempo ramp, the click-to-scope, the year-scrubber at the right edge. This is the second half of the visual identity and the spine of the IA.
3. **`smd` + the parse pipeline.** SQLCipher + DeviceSQL reads, the dedupe hash, `library.db` writes, the `NSFilePresenter` push to the UI. The thing has to actually work on a real CDJ USB before any LAB recipes get built.
4. **One LAB recipe end-to-end: FORGOTTEN FAVOURITES.** Including the rekordbox-6 master.db writeback with backup. If one recipe can be ingested, scored, displayed, focused, and one-keystroke written to rekordbox, the architecture is proven and the other six recipes are configuration.
5. **The empty + partial + error states.** Specifically the first-launch empty state with the sample-night offer, the live-incrementing partial state during ingest, and the SQLCipher-key-mismatch banner. The bar for "doesn't look AI" is set by these three more than by the happy path; a designer will look at the empty state first.

Brand mark, About panel, menu bar item, AppleScript dictionary, second recipe, and the analyse→ session-to-LAB jump come after these five.
