# Set Memory - Swift architecture audit

Date: 2026-06-01
Scope: gui/Sources/*.swift, gui/build.sh, gui/Info.plist
Classification: HAZARD (crash / data loss / silent corruption) > BUG (wrong behaviour) > DEBT (will hurt soon) > QUALITY (polish).

---

## P0 - HAZARD (fix immediately)

### H1. `String(cString:)` on a possibly-null pointer when `sqlite3_open_v2` fails
File: `StateDB.swift:21-26`
```
guard rc == SQLITE_OK, let h else {
    let msg = String(cString: sqlite3_errmsg(h))   // <-- h is nil here
    sqlite3_close(h)
    ...
}
```
Inside the `else`, `h` is `nil` (the guard failed because it was nil OR because rc != OK). On the nil branch this passes `nil` to `String(cString:)`, which traps. `sqlite3_errmsg` requires a non-null db handle - when the handle itself failed to allocate, SQLite returns a static error string via `sqlite3_errstr(rc)` instead.
**Fix:** branch on whether the handle is non-nil; use `sqlite3_errstr(rc)` when it is nil. Don't call `sqlite3_close(nil)` (it's actually defined to be a no-op since 3.7.10, so the close is benign, but the errmsg is not).

### H2. DispatchSource resume/suspend imbalance on rapid app activation toggles
File: `AppState.swift:105-131`
The active/inactive observers protect against double-suspend with `fileWatcherSuspended`, which is the right pattern (the comment even cites the bug class). But two paths still bypass it:
- The `init` happens-before `didBecomeActive` notification can fire. If macOS posts `didResignActive` before the app ever becomes active (rare but possible during launch with another app in focus), the watcher is suspended even though it was started in `resume()` state - that's actually safe. The HAZARD is the inverse: if `init` is followed immediately by `didBecomeActive`, the active-handler enters the `fileWatcherSuspended == false` branch and does nothing - good. But there is no synchronization between `startFileWatcher()` (line 346-364, which calls `src.resume()`) and `startAppActivityMonitoring()` registration: both happen on the main actor in `init`, so the ordering is deterministic. Currently safe.
- `deinit` at line 90-97: `if fileWatcherSuspended { fileWatcher?.resume() }` then `cancel()`. Good. But the deinit runs synchronously on whatever queue releases the last reference. `AppState` is `@MainActor`-isolated, so deinit should be main-actor too under Swift 6 strict; under Swift 5 it may release from a Task continuation, which would touch `fileWatcherSuspended` off the main actor. Currently no crash because it's a Bool primitive, but it's a strict-concurrency violation that will be diagnosed in Swift 6.

**Fix:** keep the boolean, but in `deinit` capture the source locally before resuming and don't touch any `@MainActor` state. Or move the watcher into its own actor-typed wrapper so its deinit is queue-defined.

### H3. `AppState.deinit` removes observers added against `Notification.Name`
File: `AppState.swift:95-96`
```
NSWorkspace.shared.notificationCenter.removeObserver(self)
NotificationCenter.default.removeObserver(self)
```
Observers were registered with the block-based API (`addObserver(forName:object:queue:using:)`, lines 107, 121, 140, 160), which returns an opaque `NSObjectProtocol` token. `removeObserver(self)` does **not** remove block-based observers - it only removes selector-based observers registered with `addObserver(_:selector:name:object:)`. The observers leak past `AppState`'s lifetime (in practice `AppState` is a `@StateObject` that lives for the whole app, so it never leaks in production - but if anyone ever instantiates AppState for tests or previews, the closures keep firing forever and reference dead objects).
**Fix:** store the returned tokens in `[NSObjectProtocol]` and call `removeObserver(token)` for each in deinit.

### H4. `sqlite3_close(handle)` in deinit instead of `sqlite3_close_v2`
File: `StateDB.swift:34`
`sqlite3_close` returns `SQLITE_BUSY` and leaks the connection if any prepared statements are still alive. The `prepare()` helper uses `defer { sqlite3_finalize(stmt) }`, so in steady state nothing is outstanding. But on a thrown error from `prepare` during query execution (e.g. SQLITE_BUSY), the defer still finalizes - that path is fine. The remaining risk is a future caller that holds a statement across a throw. Use `sqlite3_close_v2(handle)` which marks the connection as zombie and finalizes when safe. Zero-cost defensive fix.
Classification: HAZARD-leaning-DEBT today, becomes a hazard the moment anyone adds a long-lived prepared statement.

### H5. `searchTask?.cancel()` doesn't actually cancel a `Task.detached` whose body is synchronous SQLite
File: `AppState.swift:289-302`
The detached search task does `try? db.search(...)` synchronously without any cancellation checks. `Task.cancel()` only signals - the SQLite call runs to completion. With a 200-char-result limit and the wide LIKE scan over `tracks`, that's tens to hundreds of ms. The newer task fires while the older still has the CPU; `await MainActor.run` will then deliver results out of order. The `removeDuplicates + debounce(180ms)` upstream usually prevents user-visible damage, but holding `Cmd-A Backspace` types fast enough to interleave.
**Fix:** check `Task.isCancelled` after the synchronous block and before the `MainActor.run`; capture an epoch counter the main actor compares against before assigning `searchResults`.

---

## P1 - BUG (incorrect behaviour)

### B1. `runSync()` mutates `syncVolumeFilter` from a detached path without restoring on error
File: `AppState.swift:151-158`
```
self.syncVolumeFilter = label
self.runSync()
self.syncVolumeFilter = saved
```
`runSync()` returns immediately (it dispatches detached); `syncVolumeFilter = saved` then runs synchronously on the same main-actor tick. So the captured filter inside `runSync` is the new label (captured at line 311 before the detached starts) - correct. But during the gap between `runSync()` and `saved` restoration, the menu briefly shows the auto-mount label as if the user picked it. Visible flicker. Also, if the user opens the picker in that one-tick window and clicks, their click is overwritten. Tiny race, but it's a bug.
**Fix:** capture-and-pass the filter as a function arg to `runSync(volumeFilter:)` instead of round-tripping through the @Published.

### B2. `lastSyncAt = "never"` defeats `relative()` parsing
File: `Models.swift:80`, `MainView.swift:275-279`
`MainView.syncedAgo` checks `if last == "never" { return "never synced" }`, but if the DB ever stores `last_sync_at` and then the row is missing for some reason, scalarString returns nil and Swift defaults to `"never"` again via `?? "never"` at `StateDB.swift:54`. Good. But `relative()` at `ContentView.swift:805-813` uses `ISO8601DateFormatter` with `.withFractionalSeconds` first, then a bare fallback. If the DB stores `2026-06-01T09:00:00` (no Z, no fractional), both parses fail and we return the raw prefix. Cosmetic but easy to fix.
**Fix:** add a `DateFormatter` fallback that accepts trailing-Z-optional ISO8601.

### B3. `sessions()` "sourceLabel" parsing strips legitimate volume names that begin with `PIONEER`
File: `StateDB.swift:200-203`
```
.filter { ... && !$0.hasPrefix("PIONEER") && $0 != "Master" && !$0.hasPrefix("master.db") }
.first ?? src
```
A user-named USB volume "PIONEER-Backup" would be filtered out. Also, on the desktop-rekordbox path the source is `/Volumes/<label>/PIONEER/Master/master.db`, so the first surviving component is the volume label. On CDJ-export path it's `/Volumes/<label>/PIONEER/rekordbox/export.pdb` (so the `rekordbox` and `export.pdb` strings need similar treatment, currently not). Result: pdb-sourced sessions show `rekordbox` as the source label, not the USB.
**Fix:** parse the volume label directly with `URL(fileURLWithPath:).pathComponents` and grab `pathComponents[2]` if `pathComponents[1] == "Volumes"`. Drop the substring filter entirely.

### B4. `relative()` for `last_seen_at` may show "never seen" timestamps in the future
File: `ContentView.swift:805-813`
No clamp on a positive interval. If a USB record has a clock-skewed last_seen_at (e.g. CDJ has wrong RTC), `RelativeDateTimeFormatter` prints "in 3 days". Cosmetic but unsettling.
**Fix:** clamp to past with `min(d, Date())`.

### B5. `forgotten()` SQL requires a JOIN to `sessions` via `last_seen_session`
File: `StateDB.swift:58-72`
`tracks.last_seen_session` is an INTEGER reference to `sessions.session_id`. There is no index on `tracks.last_seen_session`, and no FK index is auto-created. The JOIN is `sessions s ON s.session_id = t.last_seen_session` - that direction uses the sessions PK index, OK. But `WHERE t.total_appearances >= ? AND s.session_date < ?` then filters; the planner has to scan all tracks with appearances >= N and probe sessions for each. Add an index on `tracks(total_appearances)` and/or denormalise `last_seen_session_date` into tracks. See D3.

### B6. `sessionsByMonth` formatter has no timezone pinned
File: `StateDB.swift:240-247`
`DateFormatter` defaults to current locale + timezone. The session dates in SQLite are stored as `substr(session_date, 1, 7)` (raw text "YYYY-MM"). When we walk backwards N months from `Date()` and format, the formatted YM is in the user's local timezone, but the stored YMs are whatever timezone the ingest used (Python's `datetime.now().isoformat()`, local). They line up only because both use local time. Fragile if a user's machine TZ changes between ingest and read.
**Fix:** force `formatter.timeZone = .current` (explicit) and document the assumption, or store ISO with explicit Z in ingest and parse here.

---

## P2 - DEBT (architecture, will hurt soon)

### D1. AppState is the universal junk drawer - 23 `@Published` properties, 640 lines
File: `AppState.swift`
Mixed responsibilities: query orchestration, file watching, subprocess control (sync), subprocess control (suggester), subprocess control (playlist creation), suggestion CRUD, USB mount detection, config persistence, file resolution, NSWorkspace integration, app activity tracking, search debounce. Every one of those would be a clearly testable component in isolation. Every `@Published` triggers `objectWillChange` on the entire AppState - any view observing `state` re-evaluates `body` on every single one.
**Fix:** split into:
- `LibraryStore` (the @Published collection holder, dumb)
- `LibraryQueries` (one method per surface, owns the StateDB)
- `SyncCoordinator` (runs the Python subprocesses, exposes `syncing` etc.)
- `VolumeMonitor` (mount detection + NSWorkspace observers)
- `SuggesterService` (the suggester subprocess + throttle)
- `Config` (load/save thresholds)
Each lives behind a protocol; views observe only the one they need. Cut re-renders by ~5x on heavy state pages.

### D2. SQLite statement preparation churn on every query
File: `StateDB.swift:298-335`
Every call to `prepare()` runs `sqlite3_prepare_v2` then `sqlite3_finalize`. SQLite has a small statement cache but a fresh `StateDB` instance is created for every reload (`AppState.reloadAll` at line 178-180 opens a new connection in the detached task) and for every search (`runSearch`, line 296). That's 8-13 prepares per reload + a fresh `sqlite3_open_v2` (which scans the WAL header). Roughly 20-50ms wasted per reload.
**Fix:** keep a long-lived `StateDB` instance on AppState; cache prepared statements in a `[String: OpaquePointer]` keyed by SQL; `sqlite3_reset` + rebind on reuse, `sqlite3_clear_bindings` after step. Add a small `closure` for one-shot statements that don't need caching.

### D3. Missing indexes for hot queries
File: `StateDB.swift` queries vs `ingest.py` lines 428-540
Indexes that exist: `idx_sessions_date`, `idx_appearances_content`, `idx_appearances_session`, `idx_track_aliases_canonical`, `idx_tracks_dedup_key`, `idx_playlist_tracks_content`.
Queries that lack supporting indexes:
- `forgotten`: `WHERE t.total_appearances >= ? ORDER BY total_appearances DESC` - full table scan of `tracks`. Add `idx_tracks_total_appearances` desc.
- `neverPlayed` / `recentlyAddedUnplayed`: `WHERE total_appearances = 0 AND in_library = 1 AND COALESCE(added_at, date_created) < ?` - full scan. Add `idx_tracks_added_at_unplayed` partial: `WHERE total_appearances = 0 AND in_library = 1`.
- `deletedCandidates`: `WHERE in_library = 0 OR last_in_library_at < ?` - the OR prevents index usage entirely. Rewrite as `UNION ALL` or split. Add `idx_tracks_in_library_last_in_library_at`.
- `search`: `WHERE title LIKE '%x%' OR artist LIKE '%x%'` - LIKE-with-leading-wildcard cannot use a btree index. If search latency matters, add FTS5 virtual table on `(title, artist)`.
- `distribution`: full `appearances JOIN tracks GROUP BY bpm, key_camelot` - O(appearances). Could be materialised as a small denormalised counts table during ingest.

These all live in `ingest.py` schema, but the audit calls them out because StateDB.swift queries them.

### D4. `Distribution.bpmBuckets: [(label: String, count: Int)]` - tuple-of-strings can't ever be `Sendable`
File: `Models.swift:60-72`
Custom `==` and `hash` are written by hand because Swift can't synthesise them for labelled tuples. The type can't be `Sendable` (tuples-with-labels aren't `Sendable` in Swift 6). It's passed across actor boundaries at `AppState.swift:247`. Compiler will diagnose under strict concurrency.
**Fix:** introduce `struct BpmBucket: Hashable, Sendable { let label: String; let count: Int }` and `struct KeyCount`.

### D5. `sessionsByMonth: [(String, Int)]` same problem
File: `AppState.swift:19`, `StateDB.swift:227-248`. Same `Sendable` issue, same fix - real struct.

### D6. `Track` and friends not `Sendable`
File: `Models.swift:3-21` and others
Each is `Hashable` but not `Sendable`. They're plain value types whose stored properties are all `Sendable` (`String?`, `Double?`, `Int`, `Bool`). Adding `Sendable` is free. They cross actors at every reload.
**Fix:** add `Sendable` conformance to `Track`, `UsbDrive`, `CoAppearancePair`, `DeletedCandidate`, `SessionRecord`, `PlaylistSuggestion`, `SetMemoryStats`, `Thresholds`.

### D7. `StateDB` not `Sendable` but constructed inside `Task.detached`
File: `AppState.swift:180`, `StateDB.swift`
The class holds a mutable `OpaquePointer` and is created/used entirely inside a detached task, so it never crosses an actor boundary - safe in practice. But Swift 6 strict concurrency will flag the class definition. Either mark it `final` + `@unchecked Sendable` (with a comment explaining the queue discipline) or wrap it in an actor.

### D8. `NSWorkspace` observer fires on `.main` queue and re-fires after volume settles
File: `AppState.swift:140-159`
`NSWorkspace.didMountNotification` is followed by `.didMountNotification` again 1-3 times during APFS volume mount (snapshot, then writable, then user-visible mount). Without dedup the auto-sync fires multiple times for the same physical mount. The 0.6s delay helps but doesn't eliminate it. Also `self.runSync()` checks `!self.syncing` - but `syncing` flips true synchronously in `runSync()`, so subsequent fires within the same ~50ms see it true and skip. Currently safe by accident.
**Fix:** add a `recentlyAutosynced: Set<String>` with a 30s TTL keyed by volume label.

### D9. Magic numbers scattered
- `AppState.swift:65` `suggesterMinInterval: 12.0` — fine, named.
- `AppState.swift:151` `.now() + 0.6` — auto-sync settle delay, name it.
- `AppState.swift:282` `.milliseconds(180)` — search debounce, name it.
- `AppState.swift:375` `.now() + 0.45` — file-watcher coalesce, name it.
- `StateDB.swift:30` `sqlite3_busy_timeout(h, 3000)` — name it `kBusyTimeoutMs`.
- `StateDB.swift:193` `limit: Int = 200` and `AppState.swift:227` `db.sessions(limit: 500)` — disagree on default. Make one source.
- `MainView.swift:17` `.frame(width: 218)` sidebar width — fine if it's a brand choice.
- `App.swift:16` min window `1100 x 640` — fine.

### D10. `try?` swallowing prepare errors in `search` and `tracksInSession`
- `AppState.swift:296-297`: `try? StateDB(...)` and `try? db.search(...)` both return nil silently. User sees an empty search result rather than the actual error (likely SQLITE_BUSY mid-sync). Pipe to `lastError`.
- `ContentView.swift:759-763` (SessionRow loadTracks): same pattern - if DB open fails, the expansion shows an empty list with no explanation.

### D11. SessionRow opens its own StateDB connection per click
File: `ContentView.swift:758-764`
Bypasses AppState entirely; hardcodes the state.db path; opens a connection per expansion. Should go through an `AppState.tracksInSession(_:)` method that uses the shared connection (after D2).

### D12. Sidebar `expanded` state not persisted
File: `Sidebar.swift:8`
`@State private var expanded: Set<String>` resets to default on every relaunch. `@AppStorage` (or `@SceneStorage` for per-window) would persist it. Tiny UX win.

### D13. `selectedSection` not persisted
File: `AppState.swift:23`
Same issue - users reopen the app, lose their last view.
**Fix:** mirror to `UserDefaults`.

### D14. SwiftUI `Settings` scene vs `.sheet`
File: `MainView.swift:27-29`
Settings is presented as a `.sheet`, not as a `Scene { Settings { ... } }` at the App level. ⌘, only works because TopBar adds it explicitly at line 215. The platform-native approach is `Settings { SettingsView() }` in the App body - it auto-binds ⌘,, gives a proper Settings window (with the platform's expected behaviour: detached, can be reopened, no parent modal). The current sheet-as-Settings is on the AI-design-tells radar.
**Fix:** move SettingsView into a `Settings` scene in `App.swift`; remove the `@State showingSettings`, the `.sheet` modifier, and the manual ⌘, binding.

### D15. Default window restoration / .windowResizability
File: `App.swift:12-29`
`WindowGroup` lacks `.defaultSize(...)`, `.windowResizability(.contentMinSize)`. The .frame(minWidth: 1100, minHeight: 640) is on the root view rather than the window, which means SwiftUI can size the window smaller than the content on first launch (forcing scrollbars). Also no `.commandsRemoved()` for the panes that would help reduce menu clutter.

### D16. App icon copy can fail silently
File: `build.sh:18-20`
Both icon-generation and the `cp` are `|| true`. If the icon goes missing, every build silently ships without one. Fail loud unless `--no-icon` is passed.

### D17. build.sh doesn't pin Swift version or warn on Xcode/CLT mismatch
File: `build.sh:34-41`
`swiftc -target arm64-apple-macos13.0` - good. But no `-swift-version 5`. On a machine with Swift 6 toolchain, default is 6, and concurrency diagnostics will erupt without warning. Add `-swift-version 5` until D6/D7 are addressed, or commit to enabling strict.

### D18. Info.plist gaps for a Pages-distributable build
- Missing `NSAppleEventsUsageDescription` - if you ever AppleScript-launch rekordbox, you need it.
- Missing `LSApplicationCategoryType` (recommended for Notarization/Pages-listed apps).
- `CFBundleVersion` = "1" should bump per build.
- No `LSUIElement` (correct - this is a full-window app).
- No `ITSAppUsesNonExemptEncryption` declared - if you ever submit to Mac App Store, required.

### D19. `runSync()` doesn't surface the success message
File: `AppState.swift:306-342`
Failure: surfaces `lastError`. Success: silent. The user sees the progress spinner stop and... that's it. Add `lastSyncResult` like `lastPlaylistResult` for parity.

### D20. `reloadSuggestions()` writes `lastSuggesterRunAt` then `reloadSuggestionsThrottled` writes it again
File: `AppState.swift:384-396`
`reloadSuggestionsThrottled` updates the timestamp (line 387) before calling `reloadSuggestions()` which updates it again (line 395). Harmless but suggests the throttling logic could live in one place. The throttle also runs *inside* `MainActor.run` after every reload (line 255), so a steady drip of file-watcher events does fire the suggester every 12s regardless of whether `data_version` actually moved (the `data_version` skip protects the query path but not the suggester run on the very tick where data_version did move). Acceptable; just note that "throttled" doesn't mean "only when data changed".

---

## P3 - QUALITY (polish)

### Q1. `Theme.tempoColor(for:)` runs an O(n) switch even though the buckets are sorted
File: `Theme.swift:41-56`. Linear scan, but n=7. Acceptable. The default `return ink3` at end is unreachable given `160+` always returns - could be a `for-in` over the ramp. Cosmetic.

### Q2. `relative()` builds a fresh `ISO8601DateFormatter` per call
File: `ContentView.swift:805-813`. Hot in StatusBar / UsbRow lists. Cache them.

### Q3. `pctString` is free-floating private function
File: `ContentView.swift:650-653`. Should be on Theme or a `Format` enum alongside `shortDate`/`relative`.

### Q4. `Sources/Format.swift` doesn't exist
`shortDate`, `relative`, `pctString` live at file scope in ContentView. Move to a `Format.swift` so they're discoverable from other files.

### Q5. `ContentView.swift` is 814 lines mixing 9 surface types + 3 helpers
Each surface (`SuggestionsPanel`, `TrackTable`, `PairTable`, `UsbTable`, `DistributionPanel`, `SearchPanel`, `SessionsTable`, `DeletedTable`) wants its own file. The `TrackRow` inline-expansion alone is 130 lines.

### Q6. `ForEach(tracks)` with no `id:` parameter where `Track: Identifiable` - fine.
But `ForEach(state.suggestions)` etc. are also fine. `ForEach(Array(sessionTracks.enumerated()), id: \.element.id)` at line 722 is slightly awkward - replace with a `ForEach(sessionTracks.indices, id: \.self)` or a struct `IndexedTrack`.

### Q7. `Models.swift:65` `Distribution` `Hashable` is only used... where?
Search shows no direct use of Distribution as a dict key or in a `Set`. Drop the manual `==`/`hash` if unused — simpler. (Equatable still useful for SwiftUI `.equatable()`.)

### Q8. `Theme.tempoRamp.first { $0.label == b.label }` lookup per BPM bar
File: `ContentView.swift:573`. Build a `[String: Color]` once.

### Q9. `DispatchQueue.main.asyncAfter` mixed with `Task { @MainActor in ... }`
File: `AppState.swift:151, 366-376`. Two patterns for "do this later on main". Pick one (the modern `Task` form is enough; you lose the named DispatchWorkItem cancel-by-handle, but you gain Task cancellation, which actually composes with the rest of the codebase).

### Q10. `Sidebar` group ID is a string literal repeated across `expanded` set and `group(_:title:items:)` calls
File: `Sidebar.swift:13-23`. Tiny: extract an enum `SidebarGroup: String { case playlists, memory, library }`.

### Q11. `BPMCell` width hardcoded twice (36 in `BPMCell` AND in the column header at `ContentView.swift:233`)
Centralise as `Theme.Layout.bpmColumnWidth`.

### Q12. `TrackTableKind.search` empty message duplicates `SearchPanel`'s empty message
`ContentView.swift:258` and `ContentView.swift:663`. Same string twice.

### Q13. `App.swift`'s ⌘R shortcut conflicts with TopBar's ⌘R
`App.swift:23` and `MainView.swift:195` both bind ⌘R to "Sync now". SwiftUI handles duplicate shortcuts but logs a warning at runtime and behaviour is undefined which one fires. The TopBar one is redundant given the menu command exists.

### Q14. Error log via NSLog
`StateDB.swift:259, 307, 330`. NSLog is rate-limited and routed to ASL/the unified log. `os_log` with a category subsystem would be cleaner and queryable in Console.app.

### Q15. `bind_text` SQLITE_TRANSIENT cast pattern is repeated and ugly
`StateDB.swift:318`. Make a file-level constant `private let SQLITE_TRANSIENT = unsafeBitCast(...)`. SQLite has had this idiom since forever; the constant lives nowhere in the C header by default for Swift.

### Q16. Dead code: `Type.display`, `Type.sectionTitle`, `Type.dataLarge`
`Theme.swift:73-80`. None of them are referenced in the codebase. Drop.

### Q17. Dead code: `Theme.strokeBright`
`Theme.swift:17`. Not referenced.

### Q18. Dead code in Models.swift: `SetMemoryStats.stateTrackCount`
`Models.swift:78`, populated in `StateDB.swift:52`, never read by any view. Drop both.

### Q19. `searchSinkCancellable` set once and never re-created
`AppState.swift:48, 280`. Fine. Could be `let` if observation moved into init body before stored-property closure.

### Q20. `expanded: Set<String>` initial value `["playlists", "memory", "library"]` makes the chevron rotation animation kick on first frame
Visible flash. Initialise to `[]` and expand in `.onAppear` if you want the animation, or accept the fully-open default and remove the rotation animation.

### Q21. `ScrollView` wraps a single `surface` in `ContentView.body`
`ContentView.swift:11-18`. If the surface is itself a `LazyVStack` (SuggestionsPanel) you get a nested-scroll situation; the outer `ScrollView` is the one that scrolls, the inner `LazyVStack` is fine - just confirming. Most surfaces are `VStack`, so scrolling them inside ScrollView eagerly creates every row. Switch each surface to `LazyVStack` for free virtualisation, or move the ScrollView wrapping into each surface.

### Q22. `TrackTable` body iterates with `ForEach(tracks)` inside a `VStack` (not Lazy)
`ContentView.swift:226`. For 500-row results this builds every row at parse time. Use `LazyVStack`.

---

## Concurrency-safety summary (Swift 6 readiness)

| Item | File | Status |
|------|------|--------|
| `AppState` @MainActor | AppState.swift:8 | Correct |
| Detached tasks for I/O | multiple | Correct pattern |
| `StateDB` Sendable | StateDB.swift | Missing - add `@unchecked Sendable` with queue note, or wrap in actor |
| Track et al Sendable | Models.swift | Missing - trivial add |
| Tuple types in @Published | Models.swift, AppState.swift | Need real structs |
| Observer cleanup | AppState.swift:95-96 | Wrong API for block-based observers |
| DispatchSource resume/suspend | AppState.swift | Now correct (boolean), deinit may run off main |
| Task cancellation | search, suggester | Cancellation signalled but ignored inside sync SQLite |
| `weak self` captures | all closures | Correct |

---

## Concrete top-priority work list

1. Fix `String(cString:)` nil-deref in `StateDB.init` (H1).
2. Replace `removeObserver(self)` with token-based removal (H3).
3. Switch to `sqlite3_close_v2` (H4).
4. Add `Sendable` to all Models structs; replace labelled-tuple `@Published`s with structs (D4, D5, D6).
5. Move SettingsView into a real `Settings` scene (D14).
6. Cache prepared statements + share one long-lived `StateDB` (D2).
7. Add the missing indexes in `ingest.py` (D3).
8. Split AppState into the 6 components named in D1.
9. Add task-cancellation epoch to search to prevent out-of-order writes (H5).
10. Drop dead code (Q16-Q18) and the duplicated ⌘R (Q13).
