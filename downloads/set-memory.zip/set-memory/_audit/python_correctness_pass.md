# Set Memory - Python correctness audit (2026-06-01)

Scope: full read of `set_memory.py`, `ingest.py`, `analyse.py`, `digest.py`, `config.py`, `notify.py`, `pdb_reader.py`, `playlist_suggester.py`, `rekordbox_writer.py` (~5,500 lines), plus `tests/` (~1,400 lines).

Test run: `89 passed, 8 skipped` (smoke/pdb tests skipped: no USB mounted).
Live state.db: 481 sessions, 9,352 appearances, 6,878 canonical tracks, 7,561 aliases, 5 dismissals, schema_version=5, no rating / genre / play_count / color / playlist data despite v5 columns being present (see C1).

The report is ordered by impact (P0 = data correctness or user-visible breakage, P1 = misleading output / hidden bug, P2 = redundancy / cleanup).

---

## P0 - data correctness / user-facing breakage

### A1. `_anniversary_sets` emits duplicate content_ids inside the playlist
**File:** `playlist_suggester.py:1037-1054`
**Live evidence:** anniversary_1y for session #285 returns 51 content_ids; `71041714` appears 3x, `45745916`/`140753650`/`215380374`/`120185852`/`229290178`/`45092348`/`232947095`/`162245`/`52103692`/`69033721`/`155369565`/`264006286`/`162760044`/`41935266`/`247409609`/`54461866`/`155312438`/`156622980`/`31511029` each appear 2x. (10 of 481 sessions have within-session dupes - the CDJ history sometimes records two play-throughs back-to-back.)
**Cause:** the loop blindly extends `ids` from `appearances` ordered by `track_no` without a `seen` set. When the resulting playlist is pushed to rekordbox, it will contain repeated rows.
**Fix:** dedupe while preserving first-occurrence order:
```python
seen: set[str] = set(); ids: list[str] = []
for r in track_rows:
    cid = str(r[0])
    if cid not in seen:
        seen.add(cid); ids.append(cid)
```
Apply the same pattern to any other generator that consumes raw `appearances` rows. Audit suggests at minimum `_anniversary_sets` and `_neglected_playlist` (the latter already dedupes via the PRIMARY KEY but worth a check).

### A2. v5 fields are zero-populated on the live DB; v5 generators silently return nothing
**File:** `ingest.py:_apply_schema:558-562`, `playlist_suggester.py:1217-1448`
**Live evidence:**
- `rating IS NOT NULL`: 0 of 6,878
- `genre IS NOT NULL`: 0
- `play_count IS NOT NULL`: 0
- `color_name IS NOT NULL`: 0
- `playlists` rows: 0 (despite the master.db USB having been ingested - 2,471 aliases originated from it)

Result: `_starred_cold`, `_genre_packs`, `_color_packs`, `_loved_but_unplayed`, `_playlist_co_occurrence`, `_neglected_playlist` all return `None` / `[]`. Six of the v5 generators are dead until the user re-plugs the master.db USB. The user has no way to know.

**Cause:** the v5 migration adds the columns but does not back-fill them. Re-ingest is required, but ingest only runs when launchd sees a USB mount. Aliases recorded earlier are not refreshed.

**Fix:** add a one-shot "refresh metadata for known USBs" path. Two options:
1. On `_apply_schema`, if `v5 columns just added`, store a `pending_v5_backfill=1` marker; surface a notification next ingest: "Replug your master.db USB to enrich your library."
2. Cheaper: after first v5 ingest of any master.db USB, opportunistically iterate every alias whose `source_db_path` points at the same master.db file and re-`_upsert_library_track` from a snapshot.

Add a test: `test_v5_generators_return_empty_when_columns_blank` to lock in the safe-degradation contract.

### A3. Forgotten-favourite variants are essentially identical lists
**File:** `playlist_suggester.py:105-129`
**Live evidence:** the top 25 ids of `forgotten_pack` (≥5 plays, 90d cold), `forgotten_pack_deep` (≥10 plays, 180d cold), `forgotten_pack_revisit` (≥3 plays, 60d cold) overlap 25/25 with each other. All three SQL queries `ORDER BY total_appearances DESC` with no recency tie-breaker, so the head of the list is identical whenever the top tracks meet all three appearance floors (which they do, because they have 10-30 plays each).
**Effect:** dismissing one variant doesn't reveal new tracks - it just hides 80 points of score on the same playlist.
**Fix:** make the variants genuinely orthogonal. E.g.
- `forgotten_pack`: deep top-of-bank (≥10 plays, ≥180d cold), `ORDER BY plays DESC`
- `forgotten_pack_revisit`: shallow ≥3 plays, 60-180d, **exclude** anything in `forgotten_pack`, order by `last_session_date ASC`
- `forgotten_pack_deep`: tracks ≥5 plays, **never** seen in the last 365d, order by `total_appearances DESC`
Each variant must subtract the prior variant's content_ids. The same bug affects `_recently_added_variants` (window 7/30/90 days are nested, so the 90-day pack supersets the 30-day pack).

### A4. `_recompute_session_fingerprints` does not zero-out the orphan session row, and `track_count` can land at 0 forever
**File:** `ingest.py:_recompute_session_fingerprints:734-777`
**Live evidence:** session #1 has `track_count = 0`, `raw_history_id = '2022'`, `session_date = '2022-06-10 00:15:12'`. It has zero appearances. `_recompute_session_fingerprints` keeps it because `cids` is empty so `new_fp` falls back to `old_fp` and the seen-map records it; subsequent merges into another session leave it stranded.
**Effect:** every generator that joins `appearances → sessions` ignores it (no rows match), but `compute_summary_stats` reports `total_sessions` one too high, and any "session count" stat overstates.
**Fix:** at the end of `_recompute_session_fingerprints`, `DELETE FROM sessions WHERE NOT EXISTS (SELECT 1 FROM appearances WHERE session_id = sessions.session_id)`.

### A5. SQLCipher `PRAGMA key` uses string interpolation
**File:** `ingest.py:140`
```python
conn.execute(f"PRAGMA key = '{key}'")
```
In practice the key is a hex string from `pyrekordbox.deobfuscate(BLOB)` - safe today. But if pyrekordbox's deobfuscation ever returns a string containing `'`, `\`, or `;`, the connection silently mis-keys and SQLCipher reports the file as "not a database". The recovery path (line 232 raises `RuntimeError`) loses the cause.
**Fix:** use `conn.execute("PRAGMA key = ?", (key,))` (SQLCipher 4 supports it for `key`), or escape `'` → `''` before interpolation. Add an assertion `assert all(c in "0123456789abcdef" for c in key)` at the top so a malformed key fails loudly with a clear message rather than as a generic SQLCipher error.

### A6. `state.db` corruption recovery deletes the file unconditionally
**File:** `set_memory.py:_open_state_db:726-741`
```python
except sqlite3.DatabaseError as exc:
    state_db_path.unlink(missing_ok=True)
```
A transient lock or a partial WAL replay can raise `DatabaseError`; the recovery silently nukes years of session history. The user has no warning.
**Fix:** move the broken file to `state.db.corrupt-<timestamp>` instead of unlinking, and only attempt that recovery if `state_db_path.stat().st_size < 65536` or after the user has explicitly opted in via a flag. Add a regression test that opens a 0-byte file (should not nuke) and a known-corrupt file (should rename, not delete).

---

## P1 - misleading output, hidden bugs, behaviour the user wouldn't expect

### B1. `bpm_ramp` and `_energy_arc_presets` filter `NOT IN (SELECT alias_content_id FROM track_aliases)` - which is a no-op
**Files:** `playlist_suggester.py:559, 1180`
The v3 dedup deletes the alias's track row, so aliases can never appear in `tracks`. The sub-select is pure overhead (it scans the alias table on every iteration of the BPM arc, six times per preset).
**Fix:** drop the filter. Add a comment in `_migrate_v3_dedup` documenting the invariant "after dedup, `tracks.content_id` is always canonical; aliases live only in `track_aliases`" so future readers know they don't need the filter.

### B2. `_seed_companions` ignores `companions_per_seed` for the seed picker's pool
**File:** `playlist_suggester.py:407-449`
The `seen_seeds` set is updated to include every track in the resulting suggestion (line 654 in `_transition_chains` shows the same pattern). But `seed_companions` only adds the seed itself to `seen_seeds` (line 422), so a track that was already a *companion* in suggestion 1 can become the *seed* of suggestion 2 - yielding heavy overlap between adjacent "Around X" packs (live: seed_2 "Around party up (dmx)" and seed_3 "Around Vladimir Dubyshkin" share 5/15 tracks).
**Fix:** after picking a seed and its companions, `seen_seeds.update(ids)` so neither the seed nor its companions can anchor the next suggestion. Already the right pattern in `_transition_chains`; copy it here.

### B3. `_personal_canon` / `_current_rotation` / `_rested_heroes` use SQLite `EXP()` and `LOG()` without a feature check
**Files:** `playlist_suggester.py:726, 833, 866`
`EXP` and `LOG` require SQLite ≥3.35 (Python 3.11+ on macOS ships this, but Python 3.9 / earlier homebrew Pythons do not). If a user runs on older sqlite, `OperationalError: no such function: EXP` propagates up to the GUI / CLI.
**Fix:** at module import, probe with `sqlite3.connect(":memory:").execute("SELECT EXP(0)")` once and cache the result. If unavailable, fall back to Python-side scoring (fetch (cid, days_ago) pairs, weight in Python). Tests should cover both branches with `pytest.skipif`. Document the minimum SQLite version in `README.md` install steps.

### B4. `_similar_sessions` pulls *every* appearance row into Python on every call
**File:** `playlist_suggester.py:1106-1108`
With 9k appearances today, fine. Scales linearly in `len(appearances)` * `len(recent_sessions)` (currently 3) for the Jaccard scan. At 100k appearances and 10 recent sessions the round trip alone is ~1s; the Python loop another ~1-2s. The function runs on every `suggestions` call, so the GUI will jitter.
**Fix:** materialise the per-session set into SQLite via a CTE and let SQLite do the intersection counting:
```sql
WITH target AS (SELECT content_id FROM appearances WHERE session_id = ?)
SELECT a.session_id,
       COUNT(*) FILTER (WHERE a.content_id IN target) AS inter,
       (SELECT COUNT(DISTINCT content_id) FROM appearances
        WHERE session_id = a.session_id) AS sz
FROM appearances a GROUP BY a.session_id;
```
Or cache the in-Python sets across the three iterations of the outer loop (current code rebuilds them each call - actually it pulls once and reuses, so OK; only the N*M Python loop is the bottleneck). Lower-effort fix: limit to sessions in the last 24 months.

### B5. `_neglected_playlist` returns one playlist only, then short-circuits on `recent_plays > 0`
**File:** `playlist_suggester.py:1411-1448`
The query is `ORDER BY recent_plays ASC, p.track_count DESC LIMIT 1`. If the lowest `recent_plays` is non-zero (every playlist has at least one recent play), the function returns `None`. There may still be many *near-neglected* playlists. Also: only ever surfaces ONE neglected playlist, even if Rob has 30 dead playlists.
**Fix:** return a list (multiple `Suggestion`s) sorted ascending by `recent_plays`, capped at e.g. 5; tighten the gate to `recent_plays = 0`; add a sister generator for "playlist barely touched (1-2 recent plays)".

### B6. `dedup_key_for` over-normalises and may merge distinct mixes
**File:** `ingest.py:586-619`
`_PAREN_RE` strips everything in `(...)` / `[...]` / `{...}`. That collapses:
- `"Track Title (Original Mix)"` and `"Track Title (DJ X Remix)"` → same key, **merged**.
- `"Track Title - DJ X Remix"` (no parens) and `"Track Title"` → DIFFERENT keys (the `- DJ X Remix` survives).
That's two different remixes of the same record being treated as one track *iff* the remix name happens to live inside parens. The docstring claims this is intentional. It is rarely what a DJ wants: a 90-BPM original and a 140-BPM remix are different tools, and the dedup merge will pick whichever has more plays as canonical and silently throw away the BPM / key of the other.
**Fix:** preserve in-paren content that contains the words `remix`, `mix`, `edit`, `version`, `vip`, `bootleg`, `dub`, `instrumental`. Concretely:
```python
def _strip_parens(s):
    return _PAREN_RE.sub(lambda m: m.group(0) if re.search(r'(remix|mix|edit|version|vip|bootleg|dub|inst)', m.group(0), re.I) else " ", s)
```
Add tests: same key for `"Track (Free Download)"` vs `"Track [320kbps]"`, different keys for `"Track"` vs `"Track (DJ X Remix)"`.

### B7. `_migrate_v3_dedup` runs on every `ensure_schema()` call, but only for v<3 dbs - subsequent dedupes are skipped
**File:** `ingest.py:564-565`
After the v3 migration runs once, `schema_version` jumps to 5, so a track with a missing dedup_key inserted later (e.g. via a future `_upsert_library_track` whose title/artist were `None` at insert time) never gets reconsidered. The `_upsert_library_track` does set `dedup_key` on insert (line 930), but a track inserted via session ingest with `None` title (because `read_content` couldn't find the row) gets `dedup_key=None` forever.
**Fix:** lightweight idempotent re-dedup: at the end of every ingest, run `_compute_missing_dedup_keys + _collapse_new_groups`. Cheap because most rows already have keys (covered by the `WHERE dedup_key IS NULL` filter).

### B8. `_query_co_appearance` performs N+1 lookups for titles/artists
**File:** `analyse.py:337-352`
For each pair returned, two `SELECT title, artist FROM tracks WHERE content_id = ?` round trips. With limit=10 that's 20 queries. Trivial today; ugly under heavier load.
**Fix:** single query with two joins:
```sql
SELECT ta.title, ta.artist, tb.title, tb.artist, p.shared
FROM (SELECT a.content_id, b.content_id, COUNT(DISTINCT a.session_id) AS shared
      FROM appearances a JOIN appearances b
      ON a.session_id = b.session_id AND a.content_id < b.content_id
      GROUP BY a.content_id, b.content_id HAVING shared >= ?
      ORDER BY shared DESC LIMIT ?) p
JOIN tracks ta ON ta.content_id = p.a.content_id
JOIN tracks tb ON tb.content_id = p.b.content_id;
```

### B9. `_query_recently_added_unplayed` uses `effective_add` alias in WHERE - works on SQLite, but `_query_never_played` does the same trick; both rely on SQLite-specific aliasing
**Files:** `analyse.py:212-220, 246-253`
PostgreSQL / MySQL would reject this. Not actively broken (sqlite3 only) - flag for portability docs.

### B10. `_content_ids_for_kind` "together" branch re-resolves titles to content_ids via `WHERE title = ? AND artist = ?`
**File:** `set_memory.py:702-715`
Lossy: same title across different remixes / labels. The caller already knew the content_ids - they're discarded by `_query_co_appearance` (which only returns titles for display) and re-derived here. Fragile.
**Fix:** add `a_content_id` / `b_content_id` to `CoAppearancePair` so the round-trip through titles isn't needed.

### B11. `rekordbox_writer.create_playlist` doesn't verify rekordbox stayed quit between the check and the write
**File:** `rekordbox_writer.py:225-264`
`is_rekordbox_running()` runs at line 225, the backup at 253, the write at 258-263. If the user launches rekordbox between 225 and 258, the SQLCipher exclusive lock will throw inside pyrekordbox with a confusing OperationalError.
**Fix:** re-check just before the `db.commit()` at line 263; if running, abort and tell the user to quit and retry. (Backup is already written so no data damage.)

### B12. `_backup_master_db` doesn't prune old backups
**File:** `rekordbox_writer.py:180-191`
Every `create_playlist` call drops a copy of master.db into `rekordbox-backups/`. master.db can be 100-200 MB; ten suggestion writes = 2 GB on disk. No retention policy.
**Fix:** at backup time, list `master-*.db` files in `BACKUP_DIR` and keep only the most recent N (configurable, default 5). Note that pre-flight backups are still cheap insurance, but ten copies is more than the user wants.

### B13. `notify._fire_terminal_notifier` uses `-sender com.apple.Terminal`, which routes the notification to Terminal.app's icon
**File:** `notify.py:48`
If Rob hasn't opened Terminal, the notification still fires, but clicking it opens Terminal, not Set Memory. Per `feedback_just_work_principle` and the "open SetMemory.app" intent the rest of the codebase signals, the sender should be SetMemory's bundle ID.
**Fix:** `-sender com.mord58562.setmemory` (assuming that's the GUI bundle ID; check `gui/`). The `-open file://...` already opens the file; the `-sender` only controls icon and grouping.

### B14. `_run_create_playlist` never resolves dismissed suggestions out of the loop
**File:** `set_memory.py:497-509`
When the user requests `--suggestion forgotten_pack` and that ID was dismissed, `generate_all` (default `include_dismissed=False`) filters it out, then `next(...)` returns `None` and the CLI errors with "Unknown suggestion id". Expected behaviour is probably to honour the explicit request.
**Fix:** call `generate_all(conn, include_dismissed=True)` when a specific `--suggestion` is supplied.

### B15. `_run_suggestions` ignores `--limit-per-kind` for singleton kinds
**File:** `playlist_suggester.py:44-102`
`limit_per_kind` is plumbed into `_cliques`, `_seed_companions`, `_key_chains`, `_transition_chains`, `_genre_packs`, `_color_packs`, `_playlist_co_occurrence`, but **not** into the singleton kinds (`_personal_canon`, `_closer_canon`, `_buy_and_bury`, etc.) which have hard-coded internal limits (e.g. 50, 25, 60). The CLI argument's documentation suggests it controls "how many of each kind"; users will be confused.
**Fix:** either (a) make every generator accept `limit_per_kind`, or (b) rename the CLI arg to `--limit-per-family` and document that singletons aren't affected.

---

## P2 - cleanups, redundancy, test gaps

### C1. v5 migration has no back-fill instruction in the digest
**File:** `digest.py`, `ingest.py:_apply_schema`
Per A2, the v5 columns get added but stay NULL until the master.db USB is replugged. The user reading the digest sees `Set Memory Digest - 2026-06-01` with no hint that 6 of the suggestion generators are silently disabled.
**Fix:** in the digest, render a one-line "Library enrichment: 0/6878 tracks have ratings; replug your master.db USB to enable star-based suggestions." When the count rises above 0, drop the line. Same for genre/playlist.

### C2. `_personal_canon`, `_closer_canon`, `_opener_canon`, `_peak_canon` heavily overlap
**File:** `playlist_suggester.py:721-824`
All four return the top-N by some session-position-restricted count; on Rob's data, the top 5 of `peak_canon` overlap 5/5 with the top 5 of `personal_canon`. The differentiation is only at the tail.
**Fix:** make canons mutually-exclusive (peak = "top N peak-slot tracks NOT in personal_canon", etc.) OR drop the redundant ones. Position-role packs already do this via `_position_role_packs`; the four canons are largely subsumed.

### C3. `_cliques` and `_seed_companions` produce the same families on this data
**File:** `playlist_suggester.py:326-449`
A clique on the top edge weight = the seed + its top companions on the same data. Live: clique #1 and seed_1 share 4 of 5 tracks.
**Fix:** seed-companion suggestions should exclude tracks already covered by a clique suggestion (run cliques first; pass a "blocked" set into seed_companions; have seed_companions choose seeds NOT in any clique).

### C4. `_buy_and_bury` and `_recently_added_variants` share the same WHERE skeleton with inverted thresholds
**File:** `playlist_suggester.py:255-284, 890-913`
Both are `total_appearances=0 AND in_library=1 AND COALESCE(added_at, date_created)` filtered by recency. Today the 90-day "still unplayed" and the 120-day "bury" share many tracks (offset by ~30 days). At a glance both work but the score deltas (70 vs 58) suggest the user is meant to act differently. Worth a docstring clarifying when one fires vs the other.

### C5. `prep_pack` legacy is still in `playlist_suggester.py` despite the 2026-06-01 removal
**File:** `playlist_suggester.py:154-178, 287-319`
`_prep_variants` and `_prep_pack` remain in the file with a comment "Prep-pack variants intentionally absent". Dead code adds maintenance burden and risks accidental re-enablement.
**Fix:** delete `_prep_variants` and `_prep_pack` from `playlist_suggester.py`. The same surfaces are still served by `analyse._query_prep_issues` for the legacy `query prep` CLI - keep that.

### C6. `compute_fingerprint` is intentionally order-independent
**File:** `ingest.py:398-402`
The same track set in a different order produces the same fingerprint. That's fine for "this gig was recorded onto two USBs" but it also collapses "Set A: [X,Y,Z]" and "Set B: [Z,Y,X]" - which on the rekordbox CDJ might be two distinct nights with the same warm-up rotation. The current fingerprint also dedupes track ids before hashing (`sorted(set(...))`); a session that played the same track at positions 1, 5, and 10 will fingerprint identically to a session that played it only at position 1.
**Recommendation:** keep order-independence (the use case is "same gig, different USB", and DJs rarely play the *exact* same setlist twice in different orders) but document the limitation in the docstring. Add a "played 5+ tracks twice in one session" detector to surface CDJ-double-history sessions (see A1 - these exist in Rob's data).

### C7. `pdb_reader._iter_table_pages` cycle guard works on `page_idx`, not on `next_page`
**File:** `pdb_reader.py:214-238`
`seen` records every page we've visited. The guard `if page_idx in seen: return` fires only at the *start* of an iteration. A malicious .pdb whose `next_page` points back at the seed will be caught - good. But there's a separate corner case: `next_page` could point at an unrelated table's page (different `page_type`). Line 230 only yields when `page_type == table_type`, but the loop still follows the pointer chain. The 2 KB cap from `if page_start + len_page > len(buf)` keeps us safe within the file. Resilience is OK; doesn't need a fix, just a comment.

### C8. `_iter_rows` reads `num_row_offsets` as `rc_word & 0x1FFF` - correct, but the math comment is misleading
**File:** `pdb_reader.py:259-261`
Comment says "b13 = bits 0..12, b11 = bits 13..23" but the code never reads the b11 num_rows field. We rely on the presence bitmap inside each group instead. Adding the unused-field comment would help the next reader understand we deliberately skip it.

### C9. `pdb_reader.read_pdb` reads the whole file into memory
**File:** `pdb_reader.py:300`
`data = p.read_bytes()`. For a 4 MB .pdb this is fine; for a hypothetical 1 GB library it would OOM. Documented constraint; flag only.

### C10. `set_memory.py:_run_query` does not handle the `usb` kind's `analyse` arg signature mismatch
**File:** `set_memory.py:350-351`
`return _query_usb(conn, analyse)` - `analyse` is the *module* here, not an `AnalysisResult`. Works because `_query_usb` does `analyse_module.usb_drive_summary(conn)`. But the naming is confusing. Rename `analyse` → `analyse_module` at line 351 for clarity.

### C11. `digest.py` doesn't render the v0.9 generator output
**File:** `digest.py`
`render()` only includes the legacy `analyse` surfaces (forgotten, never-played, recent-unplayed, prep, co-appearance, deleted-candidates, distribution). The GUI consumes `playlist_suggester.generate_all` directly. The markdown digest has stopped being a complete summary - the user reading `digest.md` sees an outdated view of what Set Memory thinks. Decide: either (a) extend the digest to include the top-N suggestions per kind, or (b) explicitly document that the digest is the legacy view and the GUI is the live surface.

### C12. Test coverage gaps
**Tests directory:** `tests/`
- `playlist_suggester.py` has **zero** dedicated tests. None of the 25 v0.9 generators is exercised. The 89 passing tests cover only the original `analyse` surfaces, ingest plumbing, digest format, notify escaping, rekordbox writer plain-sqlite path, and pdb reader smoke (skipped without USB).
- `ingest.sync_playlists` (added today) has no test - the `rb_local_deleted` fallback, the leaf-vs-folder filter (Attribute=0), and the per-playlist canonicalisation are all uncovered.
- `dedup_key_for` parens/whitespace edge cases (B6) are uncovered.
- `_migrate_v3_dedup` is uncovered for the multi-USB cross-merge case (only tested implicitly via single-USB ingest tests).
- `canonical_content_id` lookup-chain has no test.
- `_recompute_session_fingerprints` collision-and-merge path is uncovered.
- `_run_create_playlist` JSON envelope (error codes 1/2/3/4/5) has no test.
- `discover_rekordbox_usbs` correctly handles `.pdb`-only USBs - covered.
- `_open_state_db` corruption recovery (A6) is uncovered.

**Recommended new test files:**
- `tests/test_playlist_suggester.py` - at minimum a smoke test "generate_all on the synthetic db returns N suggestions without raising"; per-generator tests for the singletons and the loop generators.
- `tests/test_dedup.py` - cover `dedup_key_for`, `_migrate_v3_dedup`, `canonical_content_id`, fingerprint-collision-after-rename.
- `tests/test_sync_playlists.py` - synthetic master.db with djmdPlaylist + djmdSongPlaylist, cover folder vs leaf, deleted, multi-track canonical merge.

### C13. `_FAKE_REKORDBOX_RUNNING` / `_FAKE_MAC_DB_PATH` module globals
**File:** `rekordbox_writer.py:198-203`
Test hooks via module globals risk leaking between tests. The `monkeypatch.setattr` use in `test_rekordbox_writer.py` is safe, but a `pytest` failure mid-test can leave the global in the modified state for the rest of the session.
**Fix:** wrap the hook in a context manager (`@contextlib.contextmanager fake_running(): ... yield; reset`). Lower priority - tests already pass.

### C14. `notify._applescript_escape` ordering already battle-tested
**File:** `notify.py:91-92`
`replace("\\", "\\\\").replace('"', '\\"')` - order matters (backslash first or escapes double). Covered by `test_applescript_escape_handles_quotes_and_backslashes`. No fix; commendation.

### C15. Privacy / outbound traffic audit - clean
Searched for `urllib`, `http`, `requests`, `socket`, `subprocess` invocations of network tools. The only subprocess calls are `pgrep`, `osascript`, `terminal-notifier`, `open`. No telemetry. No outbound HTTP. Backup writes stay under `PROJECT_ROOT/rekordbox-backups/`. State DB writes stay under `state_db_path` (resolved relative to `PROJECT_ROOT`). File-path traversal risk: `config.json` is user-controlled, so a `state_db_path: "../../../etc/passwd"` would write there - but the file is created/owned by Rob and only Rob's shell has access, so threat surface ≈ zero. No action needed.

### C16. `_open_mac_db_readonly` returns a tuple but type hint says `sqlite3.Connection`
**File:** `rekordbox_writer.py:116-131`
Signature: `-> sqlite3.Connection`. Body: `return raw, db`. Type lies. Callers unpack the tuple correctly, but `mypy` / IDEs will silently mislead.
**Fix:** `-> tuple[sqlite3.Connection, "Rekordbox6Database"]`.

### C17. `digest.py` re-imports analyse types at module level
**File:** `digest.py:19-29`
Tight coupling. If the analysis pipeline evolves, the digest's import block breaks loudly. Fine, but worth noting as a layering trap: digest depends on analyse depends on (nothing); ingest depends on (nothing); suggester depends on nothing. Keep that direction.

### C18. `_query_distribution` joins `appearances → tracks`, ignoring tracks with no appearances (correct) but does not exclude `total_appearances = 0` library tracks that ended up in appearances somehow
**File:** `analyse.py:409-414`
Should be invariant-safe (no track has appearances without total_appearances > 0). Confirmed in live db (no orphan rows).

### C19. `_iso_offset` uses `datetime.date.today()` and produces a local-date string
**File:** `playlist_suggester.py:1465-1467`
Compared via SQL string-comparison against `session_date`, which is stored as ISO datetime with `T` separator and timezone offset (live evidence: `2026-05-27T02:29:06.654579+00:00`). String comparison of `"2026-03-03"` against `"2026-05-27T02:29:06.654579+00:00"` works lexicographically (date prefix sorts correctly), but mixed-format old rows (`"2022-06-10 00:15:12"` with a space separator) also compare correctly because the date portion sorts first. So **no bug**, but a comment should call out the implicit assumption that all dates are ISO-prefixed.

---

## Summary scoreboard

| Surface | Status |
|--------|--------|
| Schema migration safety | OK - idempotent for v1→v5. v5 column add does not back-fill (A2). |
| Dedup correctness | OK for the happy path. Edge: orphan session row not cleaned (A4). Edge: `dedup_key_for` may over-merge mixes (B6). |
| Suggestion quality (25 generators) | ~14 actionable, ~6 redundant (A3, C2, C3, C4), ~6 dead until master.db re-ingest (A2). |
| SQL correctness | LEAD bigram, Jaccard, decay all correct. EXP/LOG portability flag (B3). |
| CLI | Subcommand routing solid. Error envelopes consistent JSON. `--suggestion` doesn't honour dismissed entries (B14). |
| rekordbox_writer | Lock handling, backups, idempotence solid. Race between `is_rekordbox_running` and write (B11). No backup pruning (B12). |
| pdb_reader | Solid; defensive on file size, cycles, page boundaries. Reads whole file into memory (C9). |
| Privacy / security | Clean. Single SQL-injection risk in PRAGMA key (A5). No outbound traffic. |
| Test coverage | Strong on analyse + ingest legacy paths. Zero coverage of v0.9 generators, sync_playlists, dedup edges. |

Of the 70-odd suggestions `generate_all` emits on Rob's live data, conservatively **40-45 are actionable**, **15-20 are noise from the three redundancy clusters** (forgotten variants, canon vs role packs, clique vs seed_companions), and **6-10 are dead** because the v5 fields aren't populated.

The single highest-leverage fixes are A1 (dedup anniversary set), A2 + C1 (back-fill v5 fields or surface the gap), A3 (genuinely orthogonalise the forgotten variants), and A6 (don't silently nuke state.db on transient `DatabaseError`).
