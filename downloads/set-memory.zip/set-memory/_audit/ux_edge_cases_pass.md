# Set Memory - UX edge-cases / "just work" audit

Scope: SwiftUI app under `gui/Sources/`, `README.md`, `scripts/install.sh`, `Info.plist`, `build.sh`. Audit dimensions per brief.

Severity rubric:
- P0 = first-run blocker or actively wrong; user will bounce
- P1 = breaks "just work" promise; user can recover but it sticks out
- P2 = polish, missing-affordance, native-conventions
- P3 = nice-to-have

Engineering cost: S = under a day, M = 1-3 days, L = >3 days or design work needed.

---

## Top "just work" gaps (executive summary)

The app is dense and tasteful, but every entry point assumes the user already knows what `state.db`, a CDJ-export USB, the `PIONEER/Master/master.db` layout, or "Sync" mean. The first-run surface, the Playlist Lab framing, the create-in-rekordbox handoff, and the search experience are all carrying explanatory copy that the "just work" principle says shouldn't exist. The Settings sheet exposes 12 stepper rows, none of which a typical user will know how to tune. macOS conventions (window restoration, About panel, Help menu, Reveal-in-Finder for the digest, Notification Center actions) are mostly absent. Voiceover / keyboard-only / reduce-motion / colour-blindness are not handled at all.

Top 15:

1. P0 - first run with no `state.db` shows a one-line error in the bottom status bar (`AppState.swift:174`); there is no welcome surface, no guidance, no Mount USB illustration, no "what does this app do" sentence
2. P0 - "Sync" button greys out with no explanation when no USB is mounted, but the tooltip is the only place the user learns the prerequisite (`MainView.swift:196-200`); a typical user will click and be confused
3. P0 - Playlist Lab is labelled "Suggested Playlists" in the sidebar but the empty-state copy says "Plug in a CDJ USB and sync to seed" (`ContentView.swift:45`); the dual-headline framing from the README never lands in the UI itself - "Set Memory" the heading and "Set Memory" the app share a name and the user can't tell what is what
4. P0 - "CREATE IN REKORDBOX" button does not check whether rekordbox.app is running, does not warn that rekordbox holds an exclusive write lock on its own DB, does not offer to quit-and-relaunch rekordbox; failure surfaces only as a one-line "rekordbox: ..." banner (`AppState.swift:489`, `ContentView.swift:163`)
5. P0 - Suggestions panel renders all ~70 cards in a single `LazyVStack` with no grouping, no filter, no sort control, no kind facets (`ContentView.swift:47`); the user has no way to find "the closer pool" without scrolling past 60 others
6. P1 - Auto-sync on mount fires 600ms after the volume appears (`AppState.swift:151`); there is no progress indicator, no "we're syncing X now" toast, no way to cancel - the user only knows by watching the bottom-bar SYNC pill turn into SYNCING
7. P1 - Search is title+artist `LIKE %term%` only (`StateDB.swift:179-191`); no genre, no label, no comment, no BPM range, no key, no diacritic folding, no remix-tag stripping; ranking is `total_appearances DESC, title ASC` which buries new tracks
8. P1 - Settings sheet has 12 steppers across 6 sections (`SettingsView.swift:27-77`); per the "Settings has 40 toggles" anti-tell, this is a wall of knobs the typical user will never touch - it should collapse to "Advanced" behind a disclosure and the surface should default to zero visible knobs
9. P1 - Dismiss/Restore is a tiny 10pt grey text button (`ContentView.swift:151-156`); the affordance is below the accessibility floor and below the "obvious" floor; no undo toast on dismiss, no keyboard shortcut, no swipe gesture
10. P1 - Window does not restore size/position across launches; `App.swift:13` uses default `WindowGroup`, no `defaultPosition`, no `defaultSize` beyond min, no `WindowGroup` id, no scene storage; sidebar group expansion state and sidebar width are also not persisted (`Sidebar.swift:8`, `MainView.swift:16`)
11. P1 - No menu bar items beyond defaults; no File menu (Export digest / Reveal state.db / Open logs), no View menu (toggle sidebar groups, jump to section), no Help menu (link to README / open log folder), no proper About panel with version+credits (Info.plist is at `0.2.0` while README is `0.9.0`)
12. P1 - No keyboard navigation between sidebar items; arrow keys do nothing, Tab cycles only through focusable controls, no `⌘1..⌘9` to jump to a section, no `j/k` row movement in tables (`Sidebar.swift`, `ContentView.swift`)
13. P1 - VoiceOver labels missing across the board; `BPMCell` reads "128", `CamelotChip` reads "8A", neither announces what they mean; the sparkline, tempo ramp, key bars have no accessibility values; cyan/coral are the only signal for selection/danger, which fails colour-blind users with no shape/text fallback
14. P1 - "Possibly Deleted" is a destructive-sounding section that offers no action - the user sees the list and can't restore, can't confirm, can't remove from history, can't even reveal where the file used to live (`ContentView.swift:768-794`)
15. P1 - `lastError` is the only error surface, lives at `StatusBar` bottom-right with `lineLimit(1)` and no expand/copy/dismiss (`MainView.swift:233-238`); ingest stderr is truncated to the last 3 lines joined by spaces (`AppState.swift:326`) and there is no path to the full log from the UI

---

## 1. First-run experience

### 1.1 Empty `state.db` shows bottom-bar error string, nothing else (P0, M)
- Where: `AppState.swift:174` writes `lastError = "No state.db at …"`; `MainView.swift:233-238` renders it as a one-line coral string in the bottom-right status bar.
- Currently: The user opens SetMemory.app with no `state.db`. The main centre pane shows the default `selectedSection = .forgotten` (`AppState.swift:23`) which renders `EmptyState("Nothing at ≥5 plays and >90d cold. Loosen the threshold in Settings (⌘,).")`. This is not the empty-state for "no data ever"; it's the empty state for "you have data but the thresholds excluded everything." A first-run user sees a sentence about thresholds before they know what a session is.
- Just-work: full-window onboarding card on first launch. Three-step illustration: (1) Plug in your CDJ USB, (2) we'll scan automatically, (3) results appear here. Show real-time "watching /Volumes for a rekordbox USB…" indicator. Dismiss once `state.db` has any sessions.
- Cost: M (new view, gated by `stats.totalSessions == 0`).

### 1.2 "Just-work" install gap: rekordbox USB schema check is skipped silently (P1, S)
- Where: `scripts/install.sh:86-110`.
- Currently: If no USB is mounted at install time, the installer just prints "Plug one in any time to trigger the first sync." There is no follow-up - the next time a USB is plugged in, the launchd agent runs but the user gets no signal that ingest worked.
- Just-work: post-install, write a `~/Library/LaunchAgents/com.mord58562.setmemory.first-mount-onboarding.plist` that fires once on the next mount and surfaces a "first sync complete - open Set Memory" notification with click-through to the app. Or simpler: the GUI opens on first mount with a "first sync in progress" overlay.
- Cost: S in the GUI (auto-open on first ingest); the launchd plist already opens the app per the README "App auto-surfaces on USB mount" but I can't confirm the plist behaviour from the GUI code alone.

### 1.3 Playlist Lab vs Set Memory framing collapses (P0, M)
- Where: `Sidebar.swift:13-17`, README:71-117 vs GUI labels.
- Currently: Sidebar groups are PLAYLIST LAB / SET MEMORY / LIBRARY in 9pt tracked caps. App title is "Set Memory". Section title for the Playlist Lab surface is "Suggested Playlists." The dual-headline framing from 0.9.0 doesn't read at all - a user looking at the sidebar sees "Set Memory" twice in different sizes and "Playlist Lab" once.
- Just-work: hero-level intro on first visit to each surface explaining what it is in one sentence; use the README copy ("ready-to-deploy rekordbox playlists" / "every track and session, searchable"). Either rename the app or rename the inner section to disambiguate.
- Cost: M (rename decision + intro cards + onboarding flow).

### 1.4 The dual headline never appears in the top bar (P2, S)
- Where: `MainView.swift:63-72`.
- Currently: Wordmark is a single "SET MEMORY" + glyph. No tab/segmented control between Playlist Lab and Set Memory.
- Just-work: top-bar segmented control "Playlist Lab | Set Memory" that switches the sidebar context, like Mail's mailbox/folder split.
- Cost: S-M.

---

## 2. Empty / partial / error states

### 2.1 Forgotten-favourites empty state telegraphs Settings as the answer (P1, S)
- Where: `ContentView.swift:251-253`.
- Currently: "Nothing at ≥5 plays and >90d cold. Loosen the threshold in Settings (⌘,)."
- Just-work: an actionable inline "Lower to 3" button right in the empty state - no Settings round-trip. Same for "Never Played" and "Played Together".
- Cost: S.

### 2.2 Corrupt state.db: README says auto-recreates, GUI says "Couldn't open state.db" (P1, S)
- Where: `AppState.swift:183`, README:320-322.
- Currently: GUI's `StateDB.init` throws if `sqlite3_open_v2` fails; the user sees a string in the status bar but no recovery action. README documents Python-side auto-recreate but the GUI doesn't kick that off.
- Just-work: on `SQLITE_CORRUPT` / `SQLITE_NOTADB`, show a sheet "Database damaged. Recreate? You'll lose accumulated history but can rebuild it from any mounted USB." with Recreate / Show in Finder / Cancel.
- Cost: S.

### 2.3 Ingest fails mid-way - no resume signal, no log link (P1, S)
- Where: `AppState.swift:323-329`.
- Currently: Non-zero exit -> last 3 stderr lines collapsed onto one line into `lastError`. If `proc.run()` throws, message says "Couldn't launch sync." No way to open `~/Downloads/set-memory/logs/stderr.log` from the UI.
- Just-work: error toast with "Show log" / "Try again" / "Report" buttons; chunked stderr capture so partial-ingest tells the user "synced sessions 1..7 of 12 before X failed."
- Cost: S for the toast; M for resumable ingest (Python side).

### 2.4 Rekordbox open during Create-in-Rekordbox is unhandled (P0, S)
- Where: `AppState.swift:469-507`, `rekordbox_writer.py` (not read - referenced).
- Currently: Click "CREATE IN REKORDBOX" while rekordbox.app is running. rekordbox holds an exclusive SQLCipher write lock; the Python writer will fail, and the user gets a one-line "rekordbox: <error>" banner.
- Just-work: pre-flight check using `NSWorkspace.shared.runningApplications` for `com.pioneerdj.rekordbox`. If running, modal: "Rekordbox is open. Quit it and we'll write the playlist, then you can reopen." with Quit-and-Continue / Cancel.
- Cost: S.

### 2.5 Suggestion with 0 reachable tracks has no UI tell (P1, S)
- Where: `ContentView.swift:106-141`, `AppState.swift:517-530`.
- Currently: Suggestion card shows `\(suggestion.contentIDs.count) TRACKS` but doesn't validate any of them resolve. CREATE writes the playlist; "unmatched" count is buried in the post-create banner.
- Just-work: pre-resolve count badge: "70 tracks · 14 reachable now" with amber tint if reachable < 50%. Tooltip explains "tracks live on a USB that isn't mounted."
- Cost: S; this is one batch call to `resolveFile` per card, throttled.

### 2.6 Dismiss everything -> stuck on empty (P2, S)
- Where: `ContentView.swift:62-63`.
- Currently: "All suggestions dismissed. Toggle above to bring them back." The toggle is a 9pt label in the top bar. Fine, but no "Restore all" CTA in the empty state itself.
- Just-work: put a prominent Restore All button in the empty state.
- Cost: S.

### 2.7 No `state.db` at all - `StateDB.init` opens RW (P2, S)
- Where: `StateDB.swift:19`.
- Currently: comment says `SQLITE_OPEN_READWRITE` is chosen so SQLite can manage WAL/SHM. But there is no `SQLITE_OPEN_CREATE` flag, so opening when no file exists fails (good). However the error message surfaces as a generic NSError, not a user-meaningful "state.db missing."
- Just-work: distinguish file-missing vs corrupt vs locked at the `init` boundary so the GUI can branch.
- Cost: S.

---

## 3. Suggestion UX

### 3.1 70 cards, no facets, no sort (P0, M)
- Where: `ContentView.swift:41-104`.
- Currently: a single LazyVStack of all suggestions, ordered by whatever the Python suggester returns. No filter chips by kind (markov / opener / closer / canon / anniversary / energy-arc etc.), no "show me only X" surface, no sort by score / track-count / freshness.
- Just-work: kind-chip filter row at the top (`MARKOV · OPENERS · CLOSERS · CANON · ANNIVERSARY · …`), each toggleable. Sort menu (Score / Newest / Most tracks / Highest reachable %). Optionally a per-kind grouped view ("Today's anniversary" pinned to the top).
- Cost: M.

### 3.2 Suggestion card under-conveys for a decide-without-clicking choice (P1, M)
- Where: `ContentView.swift:106-141`.
- Currently: name, description, track count, rationale, kind badge. No BPM range, no key range, no example track names, no representative artwork, no reachable-count, no "energy arc" preview.
- Just-work: add a 3-track preview strip (top-played examples) on hover; BPM-range chip ("122-128 BPM"); key-cluster chip; reachable badge.
- Cost: M.

### 3.3 Create-in-rekordbox button copy and microinteraction (P2, S)
- Where: `ContentView.swift:163-186`.
- Currently: amber pill says "CREATE IN REKORDBOX" / "CREATING…". After success a green checkmark banner appears at the top of the panel. The banner is one global slot - if two cards complete it overwrites.
- Just-work: per-card success/failure state ("Created · open in rekordbox") replacing the button for 5s, then reverting. Add "open in rekordbox" link that uses `NSWorkspace.shared.open(URL(string: "rekordbox://playlist/<id>"))` if any such scheme exists, else launches rekordbox.
- Cost: S for per-card state; the deep-link is research dependent.

### 3.4 No undo on dismiss (P1, S)
- Where: `ContentView.swift:144-161`, `AppState.swift:439-449`.
- Currently: dismiss is one-click and immediate; restore lives behind the "Show dismissed" toggle.
- Just-work: 5-second "Dismissed - Undo" toast at the bottom; standard `⌘Z` undo handler. Keep the toggle for bulk recovery.
- Cost: S.

### 3.5 Suggestions reload after dismiss is a full Python subprocess (P2, S)
- Where: `AppState.swift:451-464`.
- Currently: `dismissSuggestion` shells out, then immediately re-runs the suggester. 200-800ms cold start every dismiss.
- Just-work: optimistic local hide; reconcile on next throttled refresh.
- Cost: S.

---

## 4. Search

### 4.1 LIKE-only, no diacritic folding, no remix-tag stripping (P1, M)
- Where: `StateDB.swift:179-191`.
- Currently: `WHERE title LIKE ? OR artist LIKE ?`. Searching "Beyonce" misses "Beyoncé". Searching "Higher Love" returns "Higher Love (Kygo Remix)" but ranks it below the original. No FTS5, no `COLLATE NOCASE` mentioned (SQLite is case-insensitive for ASCII by default but not for diacritics).
- Just-work: FTS5 virtual table with `unicode61 remove_diacritics 2` tokenizer, optional column-weighted ranking, accent folding so "Beyonce" finds "Beyoncé", parentheticals indexed both with and without.
- Cost: M (schema migration + ingest wiring on Python side).

### 4.2 Search ignores genre / label / comment / BPM / key (P1, M)
- Where: `StateDB.swift:179-191`, README mentions these fields are now available in state.db v5.
- Currently: title and artist only.
- Just-work: tokenised query language: `bpm:124-128 key:8A genre:tech-house high-life`. Or, less ambitious, faceted search panel with BPM slider + Camelot wheel + genre/label dropdowns.
- Cost: M-L depending on ambition.

### 4.3 Search ranking buries new tracks (P2, S)
- Where: `StateDB.swift:188`.
- Currently: `ORDER BY total_appearances DESC, title ASC`. A track you just added that exactly matches your query sits below every prior favourite.
- Just-work: hybrid score = recency + match-strength + plays. Or surface "new matches" as a separate cluster above the playcount-ranked main results.
- Cost: S.

### 4.4 Search defocus is fragile (P2, S)
- Where: `MainView.swift:139-170`.
- Currently: two hidden buttons for `⌘F` focus and Escape blur. Works, but the comment admits "Escape catcher that fires even when the textfield isn't first responder" implies the focus model is fighting SwiftUI.
- Just-work: idiomatic `@FocusState` driven only by the text field's first-responder; let Escape clear+blur via a single `.onKeyPress` modifier (macOS 14+).
- Cost: S.

### 4.5 Search results don't say where the match came from (P2, S)
- Where: `ContentView.swift:659-670`.
- Currently: a plain TrackTable.
- Just-work: highlight the matched substring in title/artist. Show "2 in your library, 38 in history-only."
- Cost: S.

### 4.6 No "search across sessions" affordance (P1, M)
- Where: search returns tracks only.
- Currently: To find "what session did I drop this in," the user has to click the track in search, see its play count, then go to Sessions and scroll.
- Just-work: search a query like "2024-12-31" or "new years" against session source labels and dates; right-rail "sessions containing this track" when a search result is selected.
- Cost: M.

---

## 5. Settings

### 5.1 12 knobs, none of which a typical user needs (P0, M)
- Where: `SettingsView.swift:27-77`.
- Currently: every threshold from `Thresholds` exposed as a stepper with a helper sentence.
- Just-work: collapse to a single "Sensitivity" slider (relaxed / balanced / strict) that scales every threshold proportionally; put the 12 individual steppers behind an "Advanced" disclosure that defaults closed. Per Apple's HIG, the first-class settings should be the 1-3 things a user might actually want to change.
- Cost: M.

### 5.2 No "where is my data" / "open digest folder" / "uninstall" affordance in Settings (P1, S)
- Where: `SettingsView.swift`.
- Currently: nothing.
- Just-work: a small "Data" group with Reveal state.db / Reveal digest / Reveal logs / Reset state.db / Uninstall buttons. Removes the README dependency for the uninstall path.
- Cost: S.

### 5.3 Settings doesn't expose suggestion-related controls (P1, M)
- Where: `SettingsView.swift` exposes only the original Set Memory thresholds; nothing for Playlist Lab.
- Currently: half-life, family variant counts, anniversary lookback, Markov walk-length, energy-arc shape, suggestion cap - all hidden in Python.
- Just-work: a "Playlist Lab" group with the 3-4 dials a user might actually want (cap on suggestions, time-of-year emphasis, "include cold-start clusters" toggle).
- Cost: M.

### 5.4 Apply vs Done vs Cancel button confusion (P2, S)
- Where: `SettingsView.swift:14-93`.
- Currently: top-right "Done" commits; bottom-right has "Cancel" and "Apply" (cmd-S). Two ways to commit, one with `defaultAction`. Standard macOS sheet pattern is single Done that commits and dismisses.
- Just-work: drop "Apply", keep "Done" + "Cancel". Restore Defaults stays.
- Cost: S.

### 5.5 Live preview missing (P3, S)
- Where: `SettingsView.swift:135-139`.
- Currently: changes apply only on Done; the user can't see how a threshold tweak changes the list.
- Just-work: as the user steps, throttle a live preview against the active surface behind the sheet.
- Cost: S.

---

## 6. macOS native conventions

### 6.1 No menu bar items beyond defaults (P1, M)
- Where: `App.swift:19-29`.
- Currently: replaces `.newItem` with empty; adds Sync now + Refresh under `.toolbar`. No File, no View, no Help.
- Just-work: 
  - File: Export Digest as Markdown… (⌘E), Reveal state.db (⌥⌘D), Reveal Digest (⌥⌘G), Reveal Logs (⌥⌘L), Close Window (⌘W)
  - Edit: standard copy/paste/select-all (currently inherited but verify)
  - View: Show/Hide Sidebar (⌃⌘S), Jump to Playlist Lab/Forgotten/Recent/.../USB (⌘1..⌘9)
  - Help: Set Memory Help (opens README on github), Report Issue, View Log, About Set Memory
- Cost: M.

### 6.2 About panel uses default with stale version (P1, S)
- Where: `Info.plist:19-22`, README is at 0.9.0.
- Currently: `CFBundleShortVersionString` = `0.2.0`. Default About panel shows that.
- Just-work: bump to 0.9.0; customise about with credits, link to repo, link to release notes.
- Cost: S.

### 6.3 No window restoration (P1, S)
- Where: `App.swift:13-17`.
- Currently: no `defaultSize`, `defaultPosition`, scene storage, no `@SceneStorage` for sidebar group expansion or selected section.
- Just-work: `@SceneStorage("sm.selectedSection")`, `@SceneStorage("sm.sidebarExpanded")`, `WindowGroup` with id, `.defaultSize`. Restore last selected section, last opened sidebar groups, last selected track.
- Cost: S.

### 6.4 No Dock badge / icon updates (P2, S)
- Where: no `NSApp.dockTile` usage.
- Currently: dock icon static, no badge.
- Just-work: badge with count of new suggestions since last view, or unread sessions. Mute when window is foreground.
- Cost: S.

### 6.5 Notifications system not visible from GUI (P2, S)
- Where: `notify.py` exists, fires from Python after launchd ingest.
- Currently: no UNUserNotificationCenter integration in the Swift app; no Notification Center permission prompt; no "Sync complete" notification when triggered from the GUI itself (only from the launchd path).
- Just-work: request notification permission on first launch; fire local notifications when ingest finishes from the GUI sync button; deep-link from notification to the suggestions surface.
- Cost: S.

### 6.6 Quit / re-open behaviour (P2, S)
- Where: no `applicationShouldTerminateAfterLastWindowClosed` handler.
- Currently: closing the window quits or hides depending on SwiftUI defaults.
- Just-work: declare a `MenuBarExtra` or keep app alive in the dock with a way to re-open the main window; standard Cmd-W closes window, app remains running.
- Cost: S.

### 6.7 Right-click context menus incomplete (P2, S)
- Where: `ContentView.swift:403-427` for tracks.
- Currently: TrackContextMenu has Play, Reveal, Copy x3, plus an info line. Pair rows (`PairRow`), Session rows, Suggestion cards, USB rows, Deleted rows have no context menu.
- Just-work: full context menu on every row. PairRow: "Make a playlist of just these two and adjacents." SessionRow: "Re-create this session as a rekordbox playlist", "Copy tracklist". SuggestionCard: "Open in rekordbox", "Copy tracklist", "Why this suggestion?", "Don't show this kind." Deleted: "Forget this track", "Reveal last-seen USB."
- Cost: S-M.

### 6.8 No drag-and-drop (P2, M)
- Where: nothing.
- Currently: cannot drag a track row out to rekordbox / Finder; cannot drag a session onto a playlist target; cannot drag a USB icon onto the window to "sync this one."
- Just-work: 
  - Track row drag = file URL (when reachable) + plain text "Title - Artist" - drop into rekordbox, Finder, Notes
  - Session drag = m3u/text tracklist
  - Drop a USB icon onto the window = treat as sync target
- Cost: M.

### 6.9 Sheet-based Settings vs preferences window (P2, S)
- Where: `MainView.swift:27-29`.
- Currently: modal sheet attached to main window.
- Just-work: macOS convention is a separate preferences window with toolbar tabs, opened via Cmd-,. Sheets are for transient confirmations.
- Cost: S.

### 6.10 Forced dark mode (P2, S)
- Where: `MainView.swift:26` `.preferredColorScheme(.dark)`.
- Currently: app is dark regardless of system setting.
- Just-work: respect system appearance; if the design only works in dark, the README should say so; ideally provide a light variant or let the user opt in via Settings.
- Cost: S for the toggle; M for a real light theme.

---

## 7. Accessibility

### 7.1 No VoiceOver labels anywhere (P1, M)
- Where: every view file.
- Currently: BrandGlyph, BPMCell, CamelotChip, sparkline bars, tempo ramp, key bars, USB indicator dots, kind badges, suggestion cards - none have `.accessibilityLabel` / `.accessibilityValue`. The cyan/coral indicator dots in StatusBar and Sidebar carry meaning that VoiceOver can't read.
- Just-work: `.accessibilityElement(children: .combine)` on cards, explicit labels on data cells ("BPM 128"), grouped elements on sparkline ("April 2026, 4 sessions").
- Cost: M.

### 7.2 Keyboard-only navigation broken (P1, M)
- Where: `Sidebar.swift`, `ContentView.swift`.
- Currently: Tab cycles focusable controls; arrow keys do not move between sidebar rows or table rows. No `.focusable()` on rows, no `.onMoveCommand`, no `⌘1..⌘9` mapping.
- Just-work: standard List with selection bound to `selectedSection`; arrow keys move; Return activates; `⌘[number]` jumps; J/K row navigation in tables.
- Cost: M.

### 7.3 Dynamic Type ignored (P2, M)
- Where: `Theme.swift:73-81` uses fixed point sizes.
- Currently: 9, 11, 12, 13, 14, 28 - all hard-coded. User's "Larger Text" setting has no effect.
- Just-work: use `Font.system(.body)` / `Font.body.weight(.medium)` etc., with `.dynamicTypeSize(.medium...accessibility3)` clamps where the dense layout requires it.
- Cost: M (palette/layout rework).

### 7.4 Colour-blindness on the tempo ramp + Camelot wheel (P1, S)
- Where: `Theme.swift:31-39`, `Theme.swift:122-130`.
- Currently: tempo ramp is teal→green→yellow→orange→coral (red-green axis). Camelot uses hue rotation. A deuteranope sees the 100-119 and 120-127 buckets as nearly identical, and Camelot 5 / 7 collide.
- Just-work: add a non-colour signal (numerical label is already there for tempo, good; add a small icon shape varying by bucket; for Camelot add wheel-position glyph). Ship a "high-contrast colour" alt palette behind Settings.
- Cost: S for the toggle; M for redesign.

### 7.5 Reduce-motion ignored (P3, S)
- Where: sparkline + sidebar chevron animations.
- Currently: chevron rotates, sparkline bars resize without `@Environment(\.accessibilityReduceMotion)` check.
- Just-work: branch on the env value.
- Cost: S.

### 7.6 Hit-target sizes below recommendation (P2, S)
- Where: dismiss button `.padding(.horizontal, 8).padding(.vertical, 5)` at 10pt, cross button at 9pt, BrandGlyph 14x18.
- Currently: several touch targets are well under 44x44pt (or even 24x24pt for trackpad).
- Just-work: pad to 28x28 minimum.
- Cost: S.

---

## 8. Cross-feature integration

### 8.1 Selecting a track in Set Memory doesn't surface related suggestions (P1, M)
- Where: `AppState.swift` has `selectedTrack` but nothing observes it across surfaces.
- Currently: selecting "X" in Forgotten Favourites doesn't update Suggestions to highlight "suggestions containing X." Selecting it doesn't pull "From X you usually go…" (which Markov has computed but isn't surfaced contextually).
- Just-work: a right-rail "Related" panel that, when any track is selected anywhere, shows: suggestions containing this track, top 5 Markov successors, sessions this track is in, played-together pairs.
- Cost: M.

### 8.2 No detection of playlists created in rekordbox by other means (P1, M)
- Where: ingest reads `djmdHistory` only (per README); does not seem to read `djmdPlaylist` directly.
- Currently: README:94-95 mentions "Editorial co-occurrence from your own rekordbox playlists - the cleanest taste signal you produce, finally read." So this is wired in 0.9.0. But there is no UI on the Set Memory side that shows "your playlists" as a first-class entity.
- Just-work: a "My Playlists" surface in the sidebar that lists user-created rekordbox playlists with track counts, last-modified, and a "Use as suggestion seed" CTA.
- Cost: M.

### 8.3 Anniversary suggestion isn't pinned/highlighted (P1, S)
- Where: `ContentView.swift:41-104` treats all suggestions equally.
- Currently: "Your set, 1 year ago today" gets the same card as everything else.
- Just-work: pin time-sensitive suggestions to the top with a date badge ("On this day - 1 year ago"); add a calendar-aware home screen.
- Cost: S.

### 8.4 Session pages can't become playlists (P1, S)
- Where: `SessionRow` (`ContentView.swift:697-766`).
- Currently: expanding a session shows the tracklist. No button to "Save this session as a rekordbox playlist."
- Just-work: a "Save as playlist" button in the expanded session view that calls the same writer the suggestion CREATE button uses.
- Cost: S.

### 8.5 No "open Track in Beatport / SoundCloud / YouTube" zero-click integration (P2, S)
- Where: `TrackContextMenu`.
- Currently: only Play / Reveal / Copy.
- Just-work: per the zero-click integration rule, public lookup URLs are zero-click: `https://www.beatport.com/search?q=...`, `https://www.youtube.com/results?search_query=...`, `https://www.discogs.com/search?q=...`. Add as right-click submenu "Search on…".
- Cost: S.

---

## 9. Performance under stress

### 9.1 PairTable self-join is O(N²) on appearances (P1, M)
- Where: `StateDB.swift:108-136`.
- Currently: `JOIN appearances a JOIN appearances b ON same session AND a.content_id < b.content_id GROUP BY pair HAVING shared >= ?`. For 500 sessions × 50 tracks each = 25k appearances, the join cardinality is ~625k. Acceptable. For 50k library / heavy users with 2000 sessions, pairs explode.
- Just-work: precompute pairs into a `track_pairs(content_a, content_b, shared)` table on each ingest; serve from that. Background-rebuild only when `appearances` changes.
- Cost: M.

### 9.2 Distribution query joins every appearance to tracks (P2, S)
- Where: `StateDB.swift:263-268`.
- Currently: `JOIN tracks t ON t.content_id = a.content_id GROUP BY bpm, key`. Fine for now, but the GROUP BY on a Double bpm creates a wide cardinality. Faster to bucket in SQL.
- Just-work: `GROUP BY CASE WHEN bpm < 100 THEN '<100' WHEN bpm < 120 THEN '100-119'...` to collapse buckets in-DB.
- Cost: S.

### 9.3 File watcher fires on every WAL write (P2, S)
- Where: `AppState.swift:346-376`.
- Currently: 450ms coalesce window. During ingest of a large USB, this still fires multiple reloads.
- Just-work: extend coalesce to 1500ms during active ingest (when `syncing == true`).
- Cost: S.

### 9.4 Resolve-file walks every mounted USB on every render (P2, S)
- Where: `AppState.swift:517-530`, called from `TrackRow.copyActions` (`ContentView.swift:374`) and `TrackContextMenu` (`ContentView.swift:407`).
- Currently: each TrackRow expansion calls `resolveFile` on render to grey the buttons. For visible-only rows this is fine; with 100 expanded rows it becomes O(rows × mounted).
- Just-work: memoise resolution per (content_id, mounted_set_signature) for the duration of the mount.
- Cost: S.

### 9.5 Intel Mac baseline not stated (P2, M)
- Where: `gui/build.sh:35` `-target arm64-apple-macos13.0`.
- Currently: arm64-only. Intel Macs cannot run this build.
- Just-work: universal binary `-target x86_64-apple-macos13.0` parallel build + `lipo -create`. Or document arm64-only and the README implies it.
- Cost: S.

### 9.6 sessionsByMonth recomputes 12 months on every distribution view (P3, S)
- Where: `StateDB.swift:227-248`.
- Currently: SQL groups all sessions then post-processes; reads every session_date row.
- Just-work: filter `WHERE session_date >= ?` with computed cutoff.
- Cost: S.

---

## 10. Brand / personality

### 10.1 Brand glyph deployed once (P2, S)
- Where: `Theme.swift:87-104`, used only in TopBar wordmark.
- Currently: BrandGlyph is a tasteful three-bar mark, three vertical capsules. Empty states, splash, About panel, app icon - none reuse it.
- Just-work: BrandGlyph at 96pt as the empty-state hero. About panel hero. Subtle BrandGlyph watermark behind the suggestions empty list.
- Cost: S.

### 10.2 Copy voice is mostly absent (P2, S)
- Where: throughout.
- Currently: micro-copy is dry, factual ("Nothing at ≥5 plays and >90d cold"). No voice, no character.
- Just-work: settle a tone (precise, DJ-native, never cute). Examples: "These were heaters. Let's bring them back." / "Your warm-up bench is empty - everything's been played." / "1 year ago today you played this set. Want it back?"
- Cost: S.

### 10.3 Wordmark could carry tempo/key signature (P3, S)
- Where: TopBar.
- Currently: static.
- Just-work: subtle wordmark animation tied to last-sync activity (one bar pulse on new sync). Restrained, not decorative.
- Cost: S.

### 10.4 App icon (P2, S)
- Where: `gui/Resources/AppIcon.icns` (not inspected; build script generates from a SVG if Tools/MakeAppIcon.swift exists).
- Currently: unknown quality; build falls back silently if missing.
- Just-work: ensure icon ships, ensure dark/light tinted variants for the macOS Sonoma tinted-icon mode, ensure it reads at 16pt in the menu bar / Spotlight.
- Cost: S.

---

## 11. Other / cross-cutting

### 11.1 Version drift between README and Info.plist (P1, S)
- README is 0.9.0, Info.plist is 0.2.0.
- Cost: S.

### 11.2 Bundle id is `com.mord58562.SetMemory` (correct pseudonym, good); launchd Label uses `com.mord58562.setmemory` (lower-case). Naming consistency check (P3, S).

### 11.3 Hard-coded paths assume `~/Downloads/set-memory/` (P2, M)
- Where: `AppState.swift:72-75`, `ContentView.swift:760`.
- Currently: the app cannot relocate. If the user moves the project folder, the GUI silently breaks.
- Just-work: read `state.db` path from a UserDefaults key, populate from a one-time "Where did you install Set Memory?" picker or by reading the launchd plist that install.sh wrote.
- Cost: S.

### 11.4 Force-unwrap in SQLite binding (P3, S)
- Where: `StateDB.swift:318` `unsafeBitCast(OpaquePointer(bitPattern: -1)!, ...)`.
- Currently: works but the force-unwrap is fragile-looking.
- Just-work: define `SQLITE_TRANSIENT` once at file scope as a constant.
- Cost: S.

### 11.5 Suggestions empty-state copy assumes CDJ USB context (P2, S)
- Where: `ContentView.swift:45`.
- Currently: "No suggestions yet. Plug in a CDJ USB and sync to seed." Even after a successful sync that produced zero suggestions (small library), the user still sees "plug in a USB."
- Just-work: branch on `stats.totalSessions == 0` vs `stats.totalSessions > 0 && suggestions.empty`.
- Cost: S.

### 11.6 No error path when Python script is missing or wrong version (P2, S)
- Where: `AppState.swift:312-341`.
- Currently: if `~/miniconda3/bin/python` doesn't exist or `set_memory.py` is missing, the error is "Couldn't launch sync: …" which doesn't tell the user how to fix it.
- Just-work: at app start, run a one-shot health check ("can I find python? can I find the script? can pyrekordbox import?") and surface a clear "install incomplete - run scripts/install.sh" onboarding if anything is missing.
- Cost: S.

### 11.7 `lastReloadAt` is published but not surfaced (P3, S)
- Where: `AppState.swift:35`.
- Currently: tracked but the StatusBar shows `stats.lastSyncAt` (last ingest), not last GUI reload. Subtle but inconsistent.
- Cost: S.

### 11.8 Forgotten favourites uses `JOIN sessions s ON s.session_id = t.last_seen_session` (P2, S)
- Where: `StateDB.swift:65`.
- Currently: tracks with `last_seen_session` pointing to a deleted session row return no result. Edge case but exists.
- Just-work: `LEFT JOIN` + null-handling; or compute `last_seen` from `appearances` directly.
- Cost: S.

### 11.9 Co-appearance pairs don't surface the tracks' BPM/key (P2, S)
- Where: `PairRow` (`ContentView.swift:471-501`).
- Currently: just title/artist. A DJ choosing whether a co-occurrence is interesting wants tempo/key compatibility at a glance.
- Just-work: add BPM and Camelot chips to both halves of the pair row.
- Cost: S.

### 11.10 Sessions table truncates source label with naive path parsing (P2, S)
- Where: `StateDB.swift:201-203`.
- Currently: tries to strip `/Volumes/PIONEER/Master/master.db` segments and pick the first remaining component. If the path doesn't match the expected pattern, the label is the full path.
- Just-work: parse `/Volumes/<label>/PIONEER/...` with regex and fall back to the basename.
- Cost: S.

---

## Prioritised remediation table

| # | Item | Sev | Cost |
|---|---|---|---|
| 1 | First-run onboarding card | P0 | M |
| 2 | Sync button tooltip → in-line guidance | P0 | S |
| 3 | Playlist Lab vs Set Memory disambiguation | P0 | M |
| 4 | Pre-flight rekordbox-running check | P0 | S |
| 5 | Suggestion facets + sort + filters | P0 | M |
| 6 | Mid-sync progress + cancellable ingest | P1 | M |
| 7 | Search: FTS5 + diacritics + remix-tag handling | P1 | M |
| 8 | Settings: Sensitivity slider + Advanced disclosure | P1 | M |
| 9 | Dismiss/Restore: undo toast + visible affordance | P1 | S |
| 10 | Window/scene state restoration | P1 | S |
| 11 | Menu bar items (File / View / Help / About) | P1 | M |
| 12 | Keyboard navigation through sidebar + tables | P1 | M |
| 13 | VoiceOver labels + colour-blind alt | P1 | M |
| 14 | "Possibly Deleted" actions | P1 | S |
| 15 | Error surface: toast + Show Log + Try Again | P1 | S |
| 16 | Suggestion card: BPM/key range, reachable badge | P1 | M |
| 17 | Per-card create-success / open-in-rekordbox state | P2 | S |
| 18 | Save session as playlist | P1 | S |
| 19 | Related panel (cross-surface track context) | P1 | M |
| 20 | Drag-and-drop tracks/sessions out | P2 | M |
| 21 | Notification Center integration | P2 | S |
| 22 | Dock badge | P2 | S |
| 23 | Light mode or system-appearance respect | P2 | S |
| 24 | Universal binary (Intel support) | P2 | S |
| 25 | Pair table self-join precomputed | P1 | M |
| 26 | Resolve-file memoisation | P2 | S |
| 27 | Hard-coded ~/Downloads/set-memory paths | P2 | S |
| 28 | App health check on launch | P2 | S |
| 29 | Version sync (0.9.0 in Info.plist) | P1 | S |
| 30 | Right-click menus on every row type | P2 | S |
| 31 | Brand glyph in empty states / About | P2 | S |
| 32 | Copy voice pass | P2 | S |
| 33 | Settings: Reveal data, Reset, Uninstall buttons | P1 | S |
| 34 | Live-preview thresholds | P3 | S |
| 35 | "Search on Beatport/Discogs/YouTube" submenu | P2 | S |
| 36 | Dynamic Type support | P2 | M |
| 37 | Reduce-motion respect | P3 | S |
| 38 | Suggestions: optimistic local dismiss | P2 | S |
| 39 | Anniversary pin / on-this-day surface | P1 | S |
| 40 | App icon for tinted / menu-bar at 16pt | P2 | S |
