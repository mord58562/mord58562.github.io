# Set Memory - AI Tells Audit Pass

Audit date: 2026-06-01
Files audited (UI surfaces only):
- `gui/Sources/App.swift`
- `gui/Sources/AppState.swift` (view-relevant copy only - data layer skipped)
- `gui/Sources/ContentView.swift`
- `gui/Sources/MainView.swift`
- `gui/Sources/Models.swift` (sidebar titles + symbol map only)
- `gui/Sources/SettingsView.swift`
- `gui/Sources/Sidebar.swift`
- `gui/Sources/Theme.swift`
- `gui/Sources/StateDB.swift` (skipped - no UI; error strings audited in callers)

Reference: 75-item ban list in `feedback_ai_design_tells.md`. Tells reference that file's numbering.

---

## Overall verdict

The main shell (Top bar, Sidebar, ContentView, TrackRow, BPMCell, CamelotChip, BpmRamp, StatusBar, Theme) has clearly fought the ban list and lands on the right side of most of it: restrained 3-accent palette, deliberate type scale, monospaced data, custom brand glyph, asymmetric weighting, voice copy in empty states, tempo-meaningful gradient, BPM/Camelot custom components. The "rekordbox-inspired" intent shows.

**The biggest break in the gestalt is the Settings sheet** (`SettingsView.swift`). It commits ~10 tells in a single surface that would not look out of place in a v0/Cursor one-shot: sheet-as-settings, "Settings" headline + Done/Cancel/Apply triumvirate, `.borderedProminent`, `formStyle`-shaped grouped rows, `.system(.body)` defaults instead of the project's `Type.*` scale, `HStack(label, Spacer, value)` form rows, helper text under every group. It is jarringly off-brand against everything else.

The secondary breaks are concentrated in: (a) **uppercase-tracked label overuse** across the main shell (the shadcn-page-header trifecta in subtler form, applied to BPM column headers, "TRACK A / B / SHARED", "SESSIONS / LIBRARY / UNIQUE PLAYED / DRIVES SEEN", "PLAYS / LAST PLAYED / ADDED" detail rows, "DISMISS / RESTORE / RESTORE ALL / CREATE IN REKORDBOX" buttons, "SET MEMORY" wordmark, "TRACKS" badge); (b) **SF Symbols defaults on every sidebar row and most chrome icons**, with the symbol map at `Models.swift:119-132` giving every section a Heroicons-by-Apple stamp; (c) **lack of an empty-state recommendation in most sections**, and (d) the **always-on top bar + always-on sidebar + always-on status bar** sandwich, which is the "stock chrome" assembly even though each individual piece has personality.

---

## Per-surface walkthrough

### Top bar (`MainView.swift:38-217`)

**PASS**
- Asymmetric: wordmark + USB picker LEFT, search CENTER, sync + settings RIGHT. Not symmetric toolbar slots. (Avoids #2.)
- Custom brand glyph `BrandGlyph` (`Theme.swift:87-104`) - earns the anchor element. (Counters #29, #59.)
- `keyboardShortcut("f")` for search, `⌘,` for settings, `⌘R` for sync - app-specific, not just file/edit defaults. (Counters #63.)
- Hidden escape catcher on search (`MainView.swift:166-170`) - real interaction polish. (Counters #61.)
- Sync button is a custom amber chip, not a stock `.borderedProminent` Button. (Counters #33, #56.)

**TELLS COMMITTED**

| Tell # | Surface | File:Line | Evidence | Fix |
|---|---|---|---|---|
| #15, #38 | Wordmark | `MainView.swift:67-69` | `"SET MEMORY"` uppercase + tracking 2.4 + 11pt - the literal "AI loves UPPER tracked for wordmark" tell. Combined with the brand glyph it screams template logotype. | Use mixed-case "Set Memory" in a real display weight (say 13/600 with tighter tracking ~-0.2), let the glyph carry the category-marker job. UPPER+tracked is reserved for column heads. |
| #25, #26 | Sync icon | `MainView.swift:181-183` | `Image(systemName: "arrow.triangle.2.circlepath")` at default weight + size. Generic SF Symbol. | Hand-draw a 10px "two-arc cycle" in `Path { }` that picks up the amber from the button. Or drop the icon - the SYNC label is already strong. |
| #25 | Settings icon | `MainView.swift:208-211` | `Image(systemName: "slider.horizontal.3")` is the most generic settings glyph in SF Symbols. | A single hand-drawn 11px three-dot glyph, or a single horizontal slider mark. Or no icon at all - the `⌘,` tooltip + position carry it. |
| #25, #28 | Search icon | `MainView.swift:129-131` | `Image(systemName: "magnifyingglass")` raw. | Acceptable in this one place (universal convention), but if the rest of the chrome moves off SF Symbols this should too for coherence. |
| #28 | USB picker | `MainView.swift:109-111` | Chevron-down SF Symbol next to the picker label. The dot+label already says "click me"; the chevron is the v0 "every dropdown gets a chevron" default. | Drop the chevron and rely on hover/cursor + position. Or replace with a 1x3px tick mark. |
| #46 | Tooltips | `MainView.swift:197-199, 214` | `"Sync the selected USB · ⌘R"`, `"Tune thresholds · ⌘,"`, `"Which CDJ-export USB Sync should look at"` - the last one is in narrator voice and explains rather than adds. | Drop the explainers; the position + label already make it self-evident. Keep only `⌘R` / `⌘,` keybinds in tooltips. |

**Impact:** MEDIUM. The top bar mostly fights the tells; the SF Symbols default weight + the UPPER wordmark are the two that read AI-generated in a screenshot.

### USB Picker menu (`MainView.swift:74-118`)

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #44, #41 | `MainView.swift:86` | `"No CDJ USB detected"` empty state in menu is bare statement of fact. | "Plug in a CDJ-export USB" - directive matching the empty-state voice elsewhere. |
| #25 | `MainView.swift:80, 93` | Conditional `"checkmark"` SF Symbol with empty-string fallback - stock menu pattern. | Use a leading 4px cyan dot (matches mounted/unmounted indicator dots elsewhere) instead of SF Symbol checkmark. |

**Impact:** LOW.

### Sidebar (`Sidebar.swift`, with titles + symbols from `Models.swift:104-132`)

**PASS**
- Three custom collapsible groups (`PLAYLIST LAB / SET MEMORY / LIBRARY`), not stock `NavigationSplitView`. (Counters #2.)
- Selected state = left-edge 2px cyan strip + filled background + bold text weight. Real custom row. (Counters #38.)
- No stats panel at the bottom of the sidebar - stats live in StatusBar. (Counters #4 explicitly.)
- Badge counts in monospaced `Type.data` to the right - tabular-aligned. (Counters #13, #51.)

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #15, #B | `Sidebar.swift:42-44` | All three section headers are UPPER + tracking 1.4 (`PLAYLIST LAB`, `SET MEMORY`, `LIBRARY`). The shadcn page-header pattern applied as sidebar group heads - exactly the "ALL-CAPS section labels above every list" listed in the extended catalogue. | Mixed-case "Playlist Lab / Set Memory / Library" in `Type.bodyStrong` at the project's normal body size, with the chevron carrying the open/closed signal. Reserve UPPER+tracked for column headers in tables only (the catalogue's "one place max" rule). |
| #25, #30 | `Sidebar.swift` (rows use `section.sfSymbol` indirectly via Models) | But - looking at `Sidebar.swift:73-82`, the sidebar rows themselves use TEXT-ONLY labels, not `Label(systemImage:)`. Good. | N/A - the SF Symbol map in `Models.swift:119-132` is only used elsewhere (and may not be used at all in the visible sidebar). |
| #51 | `Sidebar.swift:91-103` | Every row badged with a raw count. Generic "Total X: 42" stat-panel pattern shrunk into the sidebar. | Suppress badges below a threshold (only show when > 0 AND has user-actionable signal). Or use a single small bar/dot indicating "fresh items since last reload" instead of total count. |
| #38 (counter) | `Sidebar.swift:73-83` | Row is `Text(title) + Spacer + Text(badge)` - which is exactly the "HStack(label, Spacer, value)" form-row default (#37). | Tune per-section: Suggestions could show a tiny amber dot if there's a fresh suggestion since last seen; Forgotten could show last refresh time; Sessions could show "12 this month" not a count of all-time. Vary by data shape. |

Section titles in `Models.swift:104-117` mix sentence case strings ("Forgotten Favourites", "Played Together", "Possibly Deleted") which then get displayed AS-IS in the sidebar - so the title-case in `Models.swift` is fine. The Tell #15 hit is only on the **group** headers, not the row titles.

**Impact:** MEDIUM. The UPPER group headers are the loudest item on this surface.

### ContentView dispatcher (`ContentView.swift:1-35`)

Minimal switch. No tells. `.padding(.horizontal, 0).padding(.top, 0)` is a code smell (modifiers doing nothing) but not a UI tell.

### SuggestionsPanel (`ContentView.swift:41-104`)

**PASS**
- Custom `SuggestionCard` (`ContentView.swift:106-196`) with hover state, real opacity treatment for dismissed, real per-card layout.
- Voice empty state at line 45: `"No suggestions yet. Plug in a CDJ USB and sync to seed."` - actionable.

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #42, #15 | `ContentView.swift:94, 151, 175` | Action labels `"RESTORE ALL"`, `"DISMISS"`, `"RESTORE"`, `"CREATING…"`, `"CREATE IN REKORDBOX"` all UPPER+tracked. This is the v0 button-label aesthetic - everything shouting. | Mixed case: `"Restore all"`, `"Dismiss"`, `"Restore"`, `"Creating…"`, `"Create in rekordbox"`. The amber background already carries the action weight; UPPER is doing duplicate work. |
| #54, #G | `ContentView.swift:182, 194, 359` | Multiple corner radii in one card: button = 3, kindBadge = 2, hover surface = 0 (no radius), CamelotChip = 3, copy-button = 3. Inconsistent: 2 / 3 / nothing. | Pick a 2-value system (e.g. 2 for inline pills/chips, 4 for clickable surfaces) and apply uniformly. The "every component decides its own radius" pattern reads as AI. |
| #25 | `ContentView.swift:51, 172` | `"checkmark.circle.fill"` and `"plus.rectangle.on.rectangle"` SF Symbols. The plus.rectangle.on.rectangle is a particularly generic "add to collection" glyph. | Hand-drawn 10px "+→box" glyph; the checkmark.circle could be a 4px cyan dot + relative-time text. |
| #41, #C | `ContentView.swift:127-129` | `Text(suggestion.rationale)` displayed at body size in `Theme.ink3`. The rationale strings come from Python - many of them have AI-narrator voice ("These tracks share a tempo range and key family..."). | Out of scope for the GUI tells audit but worth flagging - the Python rationale generator should be audited against #41/#46 separately. |
| #B (extended) | `ContentView.swift:113-126` | Card top-row = title (semibold 13) + description (body) + spacer + "N TRACKS" tracked label. This IS the shadcn card-header trifecta (title / subtitle / right-aligned count). | Drop "N TRACKS" or move it inline at the end of the description. The kindBadge already serves as the right-aligned chip; doubling up reads as template. |

**Impact:** HIGH. This is the headline surface and it has the most uppercase shouting + the card-header trifecta. The corner-radius inconsistency reads on close inspection.

### TrackTable + TrackRow + expansion (`ContentView.swift:215-401`)

**PASS**
- `BPMCell` tempo-coloured, monospaced, right-aligned, 36px width: real custom data cell. (Counters #13, #31, #65.)
- `CamelotChip` per-key hue. Domain-meaningful colour. (Counters #17, #21, #65.)
- Inline-expanding row (no separate inspector pane) is real editorial restraint. (Counters #1, #73.)
- Voice empty states with actionable hint:
  - `forgotten`: "Loosen the threshold in Settings (⌘,)" (line 252)
  - `recentUnplayed`: "Every track added in the last N days has been played." (line 254)
  - `neverPlayed`: "...no CDJ-export USB has been synced yet."

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #15, #B | `ContentView.swift:233-236, 244-247` | Column headers `"BPM"`, `"KEY"`, `"TITLE  /  ARTIST"`, `"LAST" / "ADDED" / "PLAYS"` UPPER+tracked 1.0. This is the one place the catalogue ALLOWS UPPER+tracked - so this is actually fine *if* it's the only place. It is not - see Sidebar group heads, kindBadge, button labels, status bar stats, expansion detail labels. | Keep UPPER+tracked here, remove from every other surface. |
| #15 | `ContentView.swift:363-364` | Detail-column labels `"PLAYS"`, `"LAST PLAYED"`, `"ADDED"`, `"FILE MTIME"`, `"HOT CUES"`, `"MEMORY CUES"` UPPER+tracked. Duplicate UPPER inside an expansion that's already inside a row inside a table. | Sentence case ("Plays", "Last played", "Added"...) in `Type.body` at `ink3`. The 100px fixed width column already provides visual grouping. |
| #67 | `ContentView.swift:317, 320, 346-348` | `shortDate()` returns `String(iso.prefix(10))` = `"2026-06-01"` format. Generic ISO truncation. Catalogue says: use compact context-appropriate forms ("15/01", "Mon", "3d ago"). | For the LAST/ADDED columns in track rows use relative ("3d ago", "8mo ago"). For absolute use "01 Jun" or "Jun 1, 2024" only when year != current. The same `relative()` formatter already exists for the USB row and status bar - reuse it. |
| #45 | `ContentView.swift:158-160` | Help text: `"Bring this suggestion back into the list"` / `"Hide this suggestion from future runs"` - explains what the button literally does, then says it again with a tiny twist. | If the button label is "Dismiss" / "Restore", the tooltip adds nothing. Drop or replace with the regret-recovery info (e.g. "Restore via ⌥-click on any dismissed row"). |
| #G | `ContentView.swift:182, 392` | `cornerRadius(3)` on amber button and copy buttons; `cornerRadius(3)` on CamelotChip; `cornerRadius(2)` on kindBadge. The "3 vs 2" split has no semantic basis. | Two-value system: 2 for inline data pills, 4 for action surfaces. Document the rule in `Theme.swift`. |
| #46 | `ContentView.swift:327-328, 420-421` | `"Not in current library - possibly deleted"`, `"File not currently reachable — mount the USB it lives on"` - the second uses an em-dash (banned per Rob's standing rules) AND is in narrator voice. | "File not on any mounted USB" - matter-of-fact, no em-dash, no "currently". |

**Impact:** HIGH - this is the main data surface and the UPPER detail-column labels + ISO date truncation are visible on every row expansion.

### EmptyState (`ContentView.swift:429-439`)

**PASS** - text only, voice copy, max-width 520 left-aligned, no icon-plus-headline-plus-body-plus-button quartet. Counters #7, #43.

**TELL**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #7 (partial) | `ContentView.swift:430-438` | The message strings vary by section but are not always actionable. `"No sessions in state.db yet."` (line 676) and `"Type at least 2 characters in the search field above."` (663, 258) are statements. The first has no recovery; the second restates what would be obvious from focusing the field. | All-data-empty case should suggest the recovery ("Plug in a CDJ-export USB and hit ⌘R"). The search prompt should be the field's placeholder, not an empty state. |

**Impact:** LOW.

### PairTable / PairRow (`ContentView.swift:445-501`)

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #15 | `ContentView.swift:453, 456, 459` | `"TRACK A"`, `"TRACK B"`, `"SHARED"` UPPER+tracked column headers. Allowed by catalogue rule, but `TRACK A`/`TRACK B` is generic labelling that masks what's actually a played-together pair. | "Track" / "Pair" / "Together" or just two unlabelled columns with a `×` divider between them - the visual layout already implies pairing. |
| #57 | `ContentView.swift:483-485, 489-491` | The two track columns are exactly 50/50 (each `frame(maxWidth: .infinity)`). Symmetric split, no asymmetry to indicate ordering or hierarchy. | If `aTitle` is consistently the "anchor" track and `bTitle` is the "co-player", weight 60/40 with a small connector glyph (a 6px cyan dot or tick) between them. Or stack vertically with a "+" between, leaving more horizontal room for the shared-sessions stat. |

**Impact:** MEDIUM.

### UsbTable / UsbRow (`ContentView.swift:507-546`)

**PASS** - the mounted indicator (cyan/grey 6px circle + relative-time text) is genuine custom row design. (Counters #31.)

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #15, #28 | `ContentView.swift:538-540` | `"\(drive.librarySize) TRACKS"` UPPER+tracked right-aligned. Yet another UPPER label in a surface that already has a strong custom row. | Mixed case `"2,341 tracks"` in `Type.data` at `ink3`. The tabular-mono is the marker; UPPER is redundant. |

**Impact:** LOW.

### DistributionPanel / BpmRamp / KeyBars / MonthSpark (`ContentView.swift:552-648`)

**PASS** - exemplary custom data viz:
- BpmRamp uses the tempoRamp colour ladder - data-meaningful colour. (Counters #65.)
- KeyBars uses CamelotChip - domain-specific colour. (Counters #65.)
- MonthSpark is a real custom sparkline. (Counters #66.)
- Counts shown as monospaced `Type.data`. (Counters #13, #J.)
- Percent labels alongside counts (`pctString` line 588). (Counters #51.)

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #69 | `ContentView.swift:567-595` | No reference lines, no peak callout, no comparison overlay. Just bar+count+pct rows. The catalogue calls this out specifically. | Add a thin vertical line at the median bucket; or callout the modal bucket with the BPM label highlighted. For KeyBars, mark Camelot keys adjacent to current top-3 with a faint linking arc. |
| #67 | `ContentView.swift:638` | Month label `String(ym.suffix(2))` - just the year's last two digits. Hard to read when months 1-12 of `2025` show 12 identical `"25"` labels. | Show month initial ("J F M A M J J A S O N D") on every bar; year label only at year boundaries. Or `"3/25"` compact form. |

**Impact:** MEDIUM. The viz itself is strong; the month labelling is the one weak spot.

### SearchPanel (`ContentView.swift:659-670`)

**PASS** - delegates to TrackTable. No new tells beyond TrackTable's.

### SessionsTable / SessionRow (`ContentView.swift:672-766`)

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #15 | `ContentView.swift:680-687` | `"ID"`, `"DATE"`, `"SOURCE"`, `"TRACKS"` UPPER+tracked - acceptable as column headers in a table (#15 catalogue exception). | Keep. |
| #67 | `ContentView.swift:709` | `session.sessionDate.prefix(19)` = `"2026-06-01T14:32:11"` with ISO `T` separator shown raw. | Format as `"01 Jun · 14:32"` or `"Today 14:32"` / `"Yesterday 14:32"` / `"Mon 14:32"` based on age. |
| #51 | `ContentView.swift:680, 706` | `"#42"` session IDs shown for every row. These are internal DB ids; they communicate nothing about the session. | Drop the ID column entirely (or move to expansion). The date IS the natural session identifier. |

**Impact:** MEDIUM.

### DeletedTable (`ContentView.swift:768-794`)

**PASS** - coral dot + relative-time line.

**TELL**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #41 | `ContentView.swift:772` | Empty state: `"Every track Set Memory has ever seen is still in at least one recently-synced library."` - real voice, but ends as a statement. | Add what the user might do: "Nothing to clean up. Last library scan: 3d ago." |

**Impact:** LOW.

### StatusBar (`MainView.swift:223-280`)

**PASS** - asymmetric (stats left, error mid, mount+sync time right), monospaced data, custom indicator dot.

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #15, #51 | `MainView.swift:228-231, 257-266` | `"SESSIONS"`, `"LIBRARY"`, `"UNIQUE PLAYED"`, `"DRIVES SEEN"` UPPER+tracked at 0.8 then the value. This is the catalogue's #51 "Total X: 42, Active Y: 17" stat-panel pattern, executed restrainedly but still the pattern. | Drop the labels entirely. Status-bar real estate is for monospaced numbers + ambient context. `"1,238 sessions · 4,201 in library · 2,890 played · 3 drives"` with periods as separators and a single sentence-case word per stat. |
| #44 (mild) | `MainView.swift:268-273` | `"no USB mounted"`, `"2 USBs mounted"` - sentence-case, fine; but the cyan dot already carries the mounted state. | `"USB ●"` or `"3 USBs ●"` - the dot does the work, the text just sizes. |

**Impact:** MEDIUM. The four UPPER labels are the single most-visible UPPER+tracked grouping in the app because StatusBar is always on.

### SettingsView (`SettingsView.swift`)

**This is the surface where the audit fails hardest.** It looks lifted from a v0/Cursor one-shot.

**TELLS COMMITTED**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #35, #I | `SettingsView.swift:1-140` (entire file) | Sheet-as-Settings is named in the extended catalogue as a "near-universal AI tell" (sec I). Should be a `Settings { ... }` SwiftUI Scene. | Convert to `Settings { ... }` scene in `App.swift`. `⌘,` triggers it natively. |
| #6 | `SettingsView.swift:16-21` | `"Settings"` title + `Done` button = the literal "hero with title + CTA" template, in modal form. | Drop the title bar entirely (the window chrome is the title) or replace with the first group's title. |
| #33 | `SettingsView.swift:83-90` | The `Restore defaults` / `Cancel` / `Apply` triumvirate at the footer is the exact #33 case (`primary/secondary/destructive uniformly applied`). Plus the `Done` button up top. FOUR action buttons on one settings sheet. | One button: `"Save"` (or auto-save on stepper change with no buttons, which is Norman-correct). `Cancel` is the window-close. `Restore defaults` lives in a single `…` overflow menu, not as a peer button. |
| #34, #I | `SettingsView.swift:90` | `.buttonStyle(.borderedProminent)` - the default macOS prominent style. Inconsistent with the custom amber Sync button in TopBar. | If kept at all, custom-style to match the TopBar's amber chip OR drop in favour of auto-save. |
| #37, #5 | `SettingsView.swift:116-133` | `stepperRow` is `HStack(label, Spacer, value, Stepper)` - the catalogue's exact #37 form-row default. Every row identical. | Per-threshold custom: "Forgotten plays" gets a SLIDER (1-100 with mid-snap at 5); "Days since last" gets a histogram-of-current-distribution behind a slider so the user sees what their threshold catches; "Limit" gets a number field with up/down (no need for label - it's universal). |
| #9, #14 | `SettingsView.swift:17, 107, 109, 127` | `font(.system(size: 16, weight: .semibold))`, `font(.system(size: 13, weight: .semibold))`, `font(.system(size: 11))`, `font(.system(.body, design: .monospaced))`. NONE use the project's `Type.*` scale. Settings is typographically a different app. | Use `Type.sectionTitle`, `Type.body`, `Type.micro`, `Type.data`. The scale exists - use it. |
| #41 | `SettingsView.swift:31, 40, 48, 56, 64, 72` | Group helpers: `"Tracks you've played a lot, but not recently. Lower the play threshold if the list is empty."`, `"Window for the buy-regret signal. Days since added."`, `"Library tracks with zero appearances. Min days since add filters out tracks added in the last week or so."`, `"Track pairs that appear together in many sessions."`, `"Tracks Set Memory has seen but haven't appeared in any synced library lately."`, `"How many months back to plot session activity."`. Some are insightful ("buy-regret signal" - good); others are restatement ("Track pairs that appear together in many sessions" - tautology). | Audit each helper. Keep "buy-regret signal", "Lower the play threshold if the list is empty" (actionable). Drop the rest - users tuning a stepper named "Minimum shared sessions" don't need a sentence explaining "track pairs that appear together in many sessions". |
| #56 | `SettingsView.swift:95` | `.frame(width: 520, height: 640)` - tall narrow sheet. | Settings-as-Scene auto-sizes. If kept as sheet, the height padding feels iOS-borrowed; tighten. |
| #5 | `SettingsView.swift:23, 77, 92` | `.padding(.horizontal, 20)` / `.padding(20)` / `.padding(.vertical, 14)` - the symmetric 20/20 padding the catalogue flags as #5. | Project uses 14/12 elsewhere; align. |
| #59 (lack-of-anchor) | (entire file) | None of the brand glyph, cyan strip, custom button, amber chip appear here. Open the sheet and you're in a different product. | Add `BrandGlyph` to the header; use `Theme.cyan` for focus rings on stepper controls; the Apply button must visually match the Sync amber chip in TopBar. |

**Impact:** HIGH. This single surface has roughly as many tells as the rest of the app combined.

### App entry (`App.swift`)

**TELLS**

| Tell # | File:Line | Evidence | Fix |
|---|---|---|---|
| #2 | `App.swift:18` | `.windowToolbarStyle(.unified)` - default macOS toolbar style. The whole point of building a custom TopBar is to NOT use the system toolbar. | Use `.windowToolbarStyle(.unifiedCompact)` or set the hosting `NSWindow.titlebarAppearsTransparent = true` and let the custom TopBar own the chrome end-to-end. Currently both exist (system toolbar bar above the custom TopBar). |
| #63 (counter) | `App.swift:22-26` | `⌘R` for Sync and `⌘⇧R` for Refresh - both app-specific. Good. | Keep. |
| #40 | `App.swift:13` | `WindowGroup("Set Memory")` is fine but the missing About panel customisation (catalogue: "Custom About panel via `NSApp.orderFrontStandardAboutPanel(options:)`") means About-this-app shows the default stock panel. | Add custom About options with credits attributed string. |

**Impact:** LOW (one-time chrome).

---

## The 10 loudest tells for THIS app

Ranked by gestalt contribution to AI-generated impression on Set Memory specifically:

1. **#35 (sheet-as-Settings) + entire SettingsView being typographically off-system** - opening Settings reveals a different app. (`SettingsView.swift` entire file)
2. **#15 UPPER+tracked overuse across non-table surfaces** - sidebar group heads, kindBadge, suggestion-card buttons, expansion detail-row labels, status-bar stat labels, USB row "TRACKS" label, wordmark. Six surfaces commit it; the catalogue allows it in ONE (column headers). (`Sidebar.swift:42-44`, `ContentView.swift:94,151,175,363,538`, `MainView.swift:67,228`)
3. **#33 four-button Settings footer** (`Restore defaults / Cancel / Apply` + `Done` up top) (`SettingsView.swift:19, 83-90`)
4. **#25 generic SF Symbols across the top bar** (`arrow.triangle.2.circlepath`, `slider.horizontal.3`, `magnifyingglass`, `chevron.down`, `checkmark`) (`MainView.swift:129, 181, 208`)
5. **#67 raw ISO date strings** (`shortDate` returns `prefix(10)`; `SessionRow` shows `prefix(19)` with `T` separator) (`ContentView.swift:709, 800-803`)
6. **#37 form-row HStack(label, Spacer, value, Stepper) repeated for every threshold** (`SettingsView.swift:116-133`)
7. **#G inconsistent corner radii** (`cornerRadius(2)` / `(3)` / `(4)` scattered without semantic basis) (`ContentView.swift:182, 194, 392`; `MainView.swift:159, 192`)
8. **#51 stat-panel pattern in StatusBar** (four UPPER labels with counts, always visible) (`MainView.swift:228-231`)
9. **#B the card-header trifecta on SuggestionCard** (title + description + right-aligned `"N TRACKS"` UPPER badge) (`ContentView.swift:113-126`)
10. **#9/#14 SettingsView using `Font.system(...)` raw instead of the project's `Type.*` scale** - five separate font definitions in one short file, none touching `Type` (`SettingsView.swift:17, 107, 109, 127`)

---

## 30-second pre-ship smell test

1. **Could a designer name what maker built this from a thumbnail?**
   - **Main shell (TopBar + Sidebar + TrackTable + StatusBar):** Borderline pass. The cyan/amber/coral palette, the BrandGlyph, the BPM tempo ramp, the Camelot chip, the inline-expanding rows - these signal a single editorial hand. A designer who knew rekordbox would recognise the influence. **Verdict: identifiable.**
   - **Settings sheet:** Fail. Could be any v0 settings panel.
   - **Suggestions panel:** Borderline. The amber `CREATE IN REKORDBOX` chip is distinctive but the UPPER button shouting weakens it.

2. **Counts (bad if > 1 / > 3 / > 2 / 0):**
   - Accent regions visible on the main screen: cyan (sidebar selection strip, mounted dot, search submit) + amber (Sync button) + coral (only if error present) + tempo ramp colours (BPM column). Roughly **3-4 accent regions** visible at once - over the catalogue's "1 accent per region" rule.
   - Distinct radii in use: 2, 3, 4. **3 radii** (at catalogue ceiling). Settings adds the system default → 4.
   - Distinct fonts in use: SF Pro UI (5 sizes) + SF Mono (3 sizes). **2 faces, 8 sizes**. Fonts pass; size count is on the high end.
   - Items with tabular-nums: BPM column, badge counts, sparkline values, detail-column data values, status-bar stats. **Many.** Passes.

3. **Read all copy aloud:**
   - Wins: "Loosen the threshold in Settings", "Plug in a CDJ USB and sync to seed", "buy-regret signal", "Two tracks need to share at least N sessions before they show up"
   - Losses: "DISMISS" / "RESTORE" / "CREATE IN REKORDBOX" / "CREATING…" (shouting), "Bring this suggestion back into the list" (tautological tooltip), `"Sync the selected USB · ⌘R"` (explainer tooltip), `"File not currently reachable — mount the USB it lives on"` (narrator voice + em-dash)

4. **Resize the window:**
   - Sidebar locked at 218px. Track table flexes. No deliberate breakpoints - this is on the AI-default side but acceptable for a 1100-minimum-width app. **Pass with reservation.**

5. **Empty states:**
   - Most have an action/insight ("Plug in a CDJ USB", "Loosen the threshold"). **Pass.**
   - Exceptions: SessionsTable ("No sessions in state.db yet."), DeletedTable ("Every track... still in...") - statements only.

6. **Signature element?**
   - The **`BrandGlyph` three-bar mark** + the **tempo-ramp BPM column** + the **CamelotChip per-key hue**. Three signature details. **Pass.** All visible on the primary surface.

7. **Audit "earning its place":**
   - Most UPPER+tracked headers are NOT earning their place outside column headers - flagged above as #15.
   - The chevron in the USB picker - not earning.
   - The slider.horizontal.3 settings glyph - not earning.

---

## "Would a designer name the maker from a thumbnail of any one screen?" verdict

**Main app screen (TopBar + Sidebar + TrackTable showing Forgotten + StatusBar):** YES, BORDERLINE. The combination of (a) dark-blue-grey 4-layer palette, (b) BrandGlyph + "SET MEMORY" wordmark, (c) tempo-coloured BPM column with monospaced numbers and Camelot pill, (d) coloured indicator dots in StatusBar, and (e) the editorial choice to inline-expand rows rather than open an inspector, IS enough to mark this as "Rob Russell's Set Memory" by a designer familiar with the rekordbox/Pioneer reference frame. **Pass.**

**Suggestions screen:** MAYBE. The amber `CREATE IN REKORDBOX` chip + dismissed-opacity treatment + kind badge are distinctive but the UPPER shouting moves it 60% toward "v0 template card". **Marginal.**

**Settings sheet:** NO. This screen is generic SwiftUI grouped-form layout. A designer would name the toolkit (SwiftUI) but not the maker. **Fail.**

**Distribution panel:** YES. The data-meaningful tempo ramp + camelot bars + monospaced percent column is a strong signature surface. **Pass.**

**Verdict:** the app is **identifiable on its primary surface and on Distribution**, **marginal on Suggestions**, and **anonymous on Settings**. Fixing Settings + retiring UPPER+tracked from non-table surfaces would lift it from "mostly recognisable" to "consistently recognisable".

---

## Cross-walk with positive design principles

- **Section 1.2 (purpose-first):** PASS. Every section name implies its job ("Forgotten Favourites", "Played Together", "Possibly Deleted").
- **Section 4.10 (Miller chunking):** PASS. Sidebar's three groups respect chunk limits.
- **Section 5.5 (colour as system):** PASS, except Settings.
- **Section 5.6 (typography hierarchy):** PASS in shell, FAIL in Settings.
- **Section 11.1 (loading/empty/error states):** Loading state is `ProgressView().controlSize(.mini)` only - catalogue #36. Acceptable here because reloads are <500ms and skeleton would flash, but worth an explicit comment in the code that this is intentional per the catalogue rule.
