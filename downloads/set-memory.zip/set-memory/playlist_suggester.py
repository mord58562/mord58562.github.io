"""
playlist_suggester.py - Deterministic playlist suggestions from state.db.

Draws across every track + session Set Memory has ever ingested (per-USB
data is already collapsed into canonical rows by the v3 dedup migration).

Each suggestion has:
  - id        slug used to refer to the suggestion in the CLI
  - name      human-readable name (used as the rekordbox playlist name)
  - kind      one of "clique" | "forgotten" | "recent" | "key_chain" |
              "bpm_ramp" | "prep" | "seed_companions"
  - description  one-sentence what-this-is
  - content_ids  ordered list of canonical track content_ids
  - rationale    short why-these-tracks string
  - score        sort key (higher = more confident / interesting)

Algorithms favour deterministic, explainable picks over clever ML.
Music is taste; the tool surfaces options, the DJ picks the keepers.
"""

from __future__ import annotations

import math
import sqlite3
from dataclasses import dataclass, field
from typing import Iterable, Optional


def _sqlite_has_exp() -> bool:
    """SQLite EXP() / LOG() require build 3.35+ (Python 3.11+ on macOS).
    Probe once at import so older sqlite distributions fall through to
    Python-side scoring instead of crashing the suggester."""
    try:
        sqlite3.connect(":memory:").execute("SELECT EXP(0), LOG(1)").fetchone()
        return True
    except sqlite3.OperationalError:
        return False


_HAS_SQL_MATH = _sqlite_has_exp()


@dataclass
class Suggestion:
    id: str
    name: str
    kind: str
    description: str
    content_ids: list[str]
    rationale: str = ""
    score: float = 0.0
    extra: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

# Suggestion kinds whose explicit purpose IS to surface favourites
# (Forgotten Favourites, Personal Canon, Heavy Rotation, role canons).
# Every OTHER suggestion is capped at <=5% overlap with the favourites
# set per Rob's 2026-06-02 rule: "cap all playlists at no more than 5%
# favourites unless it is specifically designed to be a favourites
# playlist".
_FAVS_BY_PURPOSE_KINDS: set[str] = {
    "forgotten",     # Forgotten Favourites + variants
    "canon",         # Personal Canon
    "rotation",      # Heavy Rotation Right Now
    "opener",        # Opener Pool (last-N at start position)
    "peak",          # Peak-Time Anchors
    "closer",        # Closer Pool
    "role_opener",   # Position-based opener role
    "role_peak",     # Position-based peak role
    "role_closer",   # Position-based closer role
}


def _favourites_set(conn: sqlite3.Connection, top_n: int = 50) -> set[str]:
    """The user's favourites: top-N most-played canonical tracks. Used
    to cap every non-favourites suggestion at <=5% overlap.

    Returns an empty set when the played-track pool is too small for
    the cap to make sense (would otherwise eat the entire library on
    small fixtures). The threshold is intentionally generous - real
    DJ libraries are thousands of tracks so this only short-circuits
    in tests or on a fresh install before the first sync."""
    played = conn.execute(
        "SELECT COUNT(*) FROM tracks WHERE in_library = 1 AND total_appearances > 0"
    ).fetchone()
    played_n = int(played[0]) if played else 0
    if played_n < max(100, top_n * 3):
        return set()
    rows = conn.execute("""
        SELECT content_id FROM tracks
        WHERE in_library = 1 AND total_appearances > 0
        ORDER BY total_appearances DESC
        LIMIT ?
    """, (top_n,)).fetchall()
    return {str(r[0]) for r in rows}


def _cap_favs(s: Suggestion, favs: set, ratio: float = 0.05) -> Suggestion:
    """Trim a suggestion's content_ids so the OUTPUT ratio of favs to
    total is <= `ratio`. Computes max_favs against the non-fav count so
    the post-trim ratio is strict (vs the naive `int(N * 0.05)` which
    leaks a percent or two over the cap once excess favs are removed).

    For ratio=0.05 with 38 non-favs: max_favs = floor(38 * 0.05/0.95)
    = floor(2.0) = 2. Output: 40 tracks, 2 favs = exactly 5.0%."""
    if not s.content_ids:
        return s
    non_fav_count = sum(1 for cid in s.content_ids if cid not in favs)
    max_favs = int(non_fav_count * ratio / (1.0 - ratio)) if ratio < 1.0 else len(s.content_ids)
    kept: list[str] = []
    fav_kept = 0
    for cid in s.content_ids:
        if cid in favs:
            if fav_kept >= max_favs:
                continue
            fav_kept += 1
        kept.append(cid)
    if kept == s.content_ids:
        return s
    return Suggestion(
        id=s.id, name=s.name, kind=s.kind,
        description=s.description, content_ids=kept,
        rationale=s.rationale, score=s.score, extra=dict(s.extra),
    )


def generate_all(state_conn: sqlite3.Connection,
                 limit_per_kind: int = 12,
                 include_dismissed: bool = False) -> list[Suggestion]:
    """
    Run every suggestion algorithm and return all suggestions sorted by
    score desc. The pool is deliberately deep (multiple variants per
    singleton kind, generous limit for clique/seed/key-chain families)
    so that dismissing a suggestion always reveals a new one rather
    than thinning the list.

    Dismissed suggestion ids are excluded by default; pass
    include_dismissed=True to surface them (used by the GUI's
    "Show dismissed" toggle).
    """
    out: list[Suggestion] = []
    # Compute the favourites set up front. Tonight recipes get it as
    # an initial exclude so the arc-shape construction sources from
    # below the top-50 by play count; every non-favs-by-purpose
    # suggestion gets trimmed to <=5% favs after construction.
    favs = _favourites_set(state_conn, top_n=50)

    # Threaded `used` set across every generator. Tonight is seeded
    # with the favs set so the recipes avoid favourites entirely
    # (per Rob's 5%-cap rule applied at construction time, not just
    # post-trim - cleaner arc shape).
    used: set[str] = set(favs)

    def add(s: Optional[Suggestion]) -> None:
        if s is None or not s.content_ids:
            return
        out.append(s)
        used.update(s.content_ids)

    def add_all(suggestions: Iterable[Suggestion]) -> None:
        for s in suggestions:
            add(s)

    # Tier 1 - tonight's set + the headline pools. Tonight claims
    # first since it's the most-used surface; Forgotten then excludes
    # the Tonight pool so it surfaces genuinely-cold tracks Rob isn't
    # already going to play tonight. Personal Canon + Current Rotation
    # likewise exclude what's already been claimed. favs (top-50 by
    # play count) is seeded into Tonight's initial exclude so the
    # recipes are constructed below the heavy-rotation band - the
    # post-cap is then a no-op on Tonight, just a guard.
    add_all(_full_set_recipes(state_conn, exclude_initial=favs))
    add_all(_forgotten_variants(state_conn, exclude=used))
    add(_personal_canon(state_conn, exclude=used))
    add(_current_rotation(state_conn, exclude=used))

    # Tier 2 - role-position packs. They want headline-class tracks
    # too; exclusion forces them to pick the SECOND-best at each role
    # which is exactly the value (the un-obvious openers, etc.).
    add(_closer_canon(state_conn, exclude=used))
    add(_opener_canon(state_conn, exclude=used))
    add(_peak_canon(state_conn, exclude=used))
    add_all(_position_role_packs(state_conn, exclude=used))

    # Tier 3 - co-occurrence. Cliques first; everything else in this
    # tier excludes clique members + headline pool so the co-play
    # signal surfaces second-tier cohesion patterns.
    add_all(_cliques(state_conn, limit=limit_per_kind, exclude=used))
    add_all(_seed_companions(state_conn, limit=limit_per_kind,
                              blocked_seed_pool=used))
    add_all(_transition_chains(state_conn, limit=limit_per_kind, exclude=used))

    # Tier 4 - arcs. Now stratified within each BPM/key band so they
    # don't all reduce to "most-played track in 128-bpm zone". Excludes
    # the headline pool so the arc is filled with un-obvious choices.
    add_all(_key_chains(state_conn, limit=limit_per_kind, exclude=used))
    add(_bpm_ramp(state_conn, exclude=used))
    add_all(_energy_arc_presets(state_conn, exclude=used))

    # Tier 5 - discovery. Deliberately long-tail packs that pull from
    # medium / cold strata; the user's "surprise me" surface. These
    # don't exclude `used` (they want the long tail by construction).
    add(_rested_heroes(state_conn, exclude=used))
    add(_hidden_gems(state_conn, exclude=used))
    add(_long_tail_companions(state_conn, exclude=used))
    add(_unloved_library(state_conn, exclude=used))
    add(_buy_and_bury(state_conn))
    add_all(_cold_cliques(state_conn, limit=max(3, limit_per_kind // 2),
                          exclude=used))
    add_all(_recently_added_variants(state_conn))

    # Tier 6 - ambient / anchored. Each is deliberately anchored to a
    # specific signal (calendar, exact past session) so they're allowed
    # to overlap the headline pool when that's the data.
    add(_this_month_last_year(state_conn))
    add_all(_anniversary_sets(state_conn))
    add(_half_time_doubles(state_conn, exclude=used))
    add_all(_similar_sessions(state_conn, limit=3))

    # Tier 7 - v5 (rekordbox-field generators). These use their OWN
    # editorial signals (star ratings, color tags, playlist groupings,
    # rekordbox playcount); they're not appearance-ranked, so the
    # exclude set is less helpful here. Still apply to playlist
    # co-occurrence so Rob sees editorial groups he hasn't already
    # been shown in the headline packs.
    add(_starred_cold(state_conn))
    add_all(_genre_packs(state_conn, limit=limit_per_kind))
    add_all(_color_packs(state_conn, limit=limit_per_kind))
    add(_loved_but_unplayed(state_conn))
    add_all(_playlist_co_occurrence(state_conn, limit=limit_per_kind,
                                     exclude=used))
    add(_neglected_playlist(state_conn))
    out = [s for s in out if s and s.content_ids]
    if not include_dismissed:
        dismissed = dismissed_ids(state_conn)
        out = [s for s in out if s.id not in dismissed]
    # Apply the 5%-favs cap to every suggestion EXCEPT the kinds whose
    # explicit purpose is to surface favourites. Tonight recipes were
    # built with favs already excluded but trim them anyway as a
    # belt-and-braces guard in case the recipe pulled mid-stratum
    # tracks that crept into the top-50 since favs was computed.
    out = [s if s.kind in _FAVS_BY_PURPOSE_KINDS else _cap_favs(s, favs)
           for s in out]
    out = [s for s in out if s.content_ids]
    out.sort(key=lambda s: s.score, reverse=True)
    return out


def _forgotten_variants(conn: sqlite3.Connection,
                        exclude: Optional[set] = None) -> list[Suggestion]:
    """Three forgotten-favourite variants that are GENUINELY orthogonal.
    Each subsequent variant excludes anything the prior variants
    surfaced AND anything passed in via exclude (typically the
    Tonight recipes' content_ids) so the Forgotten Favourites pack
    doesn't just re-surface tracks already in Rob's Tonight set."""
    out: list[Suggestion] = []
    used: set[str] = set(exclude or set())

    def take(min_plays: int, days_cold: int, limit: int,
             sid: str, name: str, suffix: str,
             order_by_recency_asc: bool = False) -> Optional[Suggestion]:
        cutoff = _iso_offset(-days_cold)
        if used:
            placeholders = ",".join("?" * len(used))
            where_excl = f" AND t.content_id NOT IN ({placeholders})"
            params: list = [min_plays, cutoff, *used, limit]
        else:
            where_excl = ""
            params = [min_plays, cutoff, limit]
        order = ("s.session_date ASC, t.total_appearances DESC"
                 if order_by_recency_asc
                 else "t.total_appearances DESC")
        rows = conn.execute(f"""
            SELECT t.content_id
            FROM tracks t
            JOIN sessions s ON s.session_id = t.last_seen_session
            WHERE t.total_appearances >= ?
              AND s.session_date < ?{where_excl}
            ORDER BY {order}
            LIMIT ?
        """, params).fetchall()
        if not rows:
            return None
        ids = [str(r[0]) for r in rows]
        used.update(ids)
        return Suggestion(
            id=sid, name=name, kind="forgotten",
            description=f"Played at least {min_plays} times, cold for {days_cold}+ days.",
            content_ids=ids,
            rationale=f"You played each of these at least {min_plays} times, "
                      f"and haven't touched them in over {days_cold} days.",
            score=85.0,
        )

    # Headline variant: deepest top-of-bank. Highest score.
    if (s := take(min_plays=10, days_cold=180, limit=25,
                  sid="forgotten_pack",
                  name="Forgotten Favourites",
                  suffix="≥10 plays, cold 6+ months")) is not None:
        # Demoted 2026-06-02: Rob's feedback is that the favs (even
        # cold) aren't the goal - discovery is. Forgotten still
        # surfaces but no longer outscores the discovery family.
        s.score = 76.0
        out.append(s)
    if (s := take(min_plays=5, days_cold=90, limit=25,
                  sid="forgotten_pack_revisit",
                  name="Worth Another Spin",
                  suffix="≥5 plays, cold 90+ days",
                  order_by_recency_asc=True)) is not None:
        s.score = 73.0
        out.append(s)
    if (s := take(min_plays=3, days_cold=60, limit=25,
                  sid="forgotten_pack_light",
                  name="Tried Once, Cooled Off",
                  suffix="3-9 plays, cold 60+ days")) is not None:
        s.score = 70.0
        out.append(s)
    return out


def _recently_added_variants(conn: sqlite3.Connection) -> list[Suggestion]:
    """Three mutually-exclusive add-date windows so each variant surfaces
    a different cohort: this week, the previous three weeks, the rest of
    the quarter."""
    out: list[Suggestion] = []

    def window_pack(min_days: int, max_days: int, limit: int,
                    sid: str, name: str, label: str) -> Optional[Suggestion]:
        rows = conn.execute("""
            SELECT content_id
            FROM tracks
            WHERE total_appearances = 0
              AND in_library = 1
              AND COALESCE(added_at, date_created) IS NOT NULL
              AND COALESCE(added_at, date_created) >= ?
              AND COALESCE(added_at, date_created) < ?
            ORDER BY COALESCE(added_at, date_created) DESC
            LIMIT ?
        """, (_iso_offset(-max_days), _iso_offset(-min_days), limit)).fetchall()
        if not rows:
            return None
        ids = [str(r[0]) for r in rows]
        return Suggestion(
            id=sid, name=name, kind="recent",
            description=f"Added in the {label}, never played.",
            content_ids=ids,
            rationale="Buy-regret. Rotate or cut.",
            score=70.0,
        )

    if (s := window_pack(0, 7, 20,
                         "recently_added_pack_week",
                         "This Week's Buys", "last 7 days")) is not None:
        s.score = 73.0
        out.append(s)
    if (s := window_pack(7, 30, 25,
                         "recently_added_pack",
                         "Try These (recent buys, unplayed)",
                         "last 8-30 days")) is not None:
        s.score = 71.0
        out.append(s)
    if (s := window_pack(30, 90, 30,
                         "recently_added_pack_quarter",
                         "This Quarter, Still Unplayed",
                         "last 31-90 days")) is not None:
        s.score = 69.0
        out.append(s)
    return out


def _prep_variants(conn: sqlite3.Connection) -> list[Suggestion]:
    """The combined Prep Me pack plus per-issue splits so users can dismiss
    one without losing the others."""
    out = []
    if (s := _prep_pack(conn, limit=50,
                        sid="prep_pack",
                        name="Prep Me (missing BPM / key / cues)",
                        where_clause="(bpm IS NULL OR key_camelot IS NULL OR hot_cue_count = 0)",
                        desc_suffix="any prep issue")) is not None:
        out.append(s)
    if (s := _prep_pack(conn, limit=40,
                        sid="prep_pack_bpm",
                        name="Needs BPM Analysis",
                        where_clause="bpm IS NULL",
                        desc_suffix="missing BPM")) is not None:
        s.score -= 1
        out.append(s)
    if (s := _prep_pack(conn, limit=40,
                        sid="prep_pack_cues",
                        name="Needs Hot Cues",
                        where_clause="hot_cue_count = 0",
                        desc_suffix="no hot cues set")) is not None:
        s.score -= 2
        out.append(s)
    return out


def dismissed_ids(state_conn: sqlite3.Connection) -> set[str]:
    rows = state_conn.execute(
        "SELECT suggestion_id FROM dismissed_suggestions"
    ).fetchall()
    return {str(r[0]) for r in rows}


def dismiss(state_conn: sqlite3.Connection, suggestion_id: str) -> None:
    """Hide a suggestion from future generate_all() calls."""
    import datetime
    state_conn.execute(
        "INSERT OR REPLACE INTO dismissed_suggestions "
        "(suggestion_id, dismissed_at) VALUES (?, ?)",
        (suggestion_id, datetime.datetime.now(datetime.timezone.utc).isoformat()),
    )
    state_conn.commit()


def undismiss(state_conn: sqlite3.Connection, suggestion_id: str) -> None:
    """Unhide one suggestion."""
    state_conn.execute(
        "DELETE FROM dismissed_suggestions WHERE suggestion_id = ?",
        (suggestion_id,),
    )
    state_conn.commit()


def clear_dismissed(state_conn: sqlite3.Connection) -> int:
    """Drop every dismissal; returns the count."""
    cur = state_conn.execute("DELETE FROM dismissed_suggestions")
    state_conn.commit()
    return cur.rowcount


# ---------------------------------------------------------------------------
# Forgotten favourites pack
# ---------------------------------------------------------------------------

def _forgotten_pack(conn: sqlite3.Connection,
                    min_appearances: int = 5,
                    days_since_last: int = 90,
                    limit: int = 30,
                    sid: str = "forgotten_pack",
                    name: str = "Forgotten Favourites",
                    desc_suffix: Optional[str] = None) -> Optional[Suggestion]:
    cutoff = _iso_offset(-days_since_last)
    rows = conn.execute("""
        SELECT t.content_id, t.total_appearances
        FROM tracks t
        JOIN sessions s ON s.session_id = t.last_seen_session
        WHERE t.total_appearances >= ?
          AND s.session_date < ?
        ORDER BY t.total_appearances DESC
        LIMIT ?
    """, (min_appearances, cutoff, limit)).fetchall()
    if not rows:
        return None
    ids = [str(r[0]) for r in rows]
    # desc_suffix intentionally dropped from the user-facing copy
    # 2026-06-02 - the algorithmic parenthetical ("≥5 plays, cold
    # 90+ days") read as AI-template and Rob asked them out.
    desc_extra = ""
    _ = desc_suffix  # kept in the call signature for back-compat
    return Suggestion(
        id=sid,
        name=name,
        kind="forgotten",
        description=f"At least {min_appearances} plays each, last seen over {days_since_last} days ago.",
        content_ids=ids,
        rationale="The cold-canon pool.",
        score=80.0 + min(20, len(ids)),
    )


# ---------------------------------------------------------------------------
# Recently-added pack
# ---------------------------------------------------------------------------

def _recently_added_pack(conn: sqlite3.Connection,
                          window_days: int = 30,
                          limit: int = 30,
                          sid: str = "recently_added_pack",
                          name: str = "Try These (recent buys, unplayed)",
                          window_label: Optional[str] = None) -> Optional[Suggestion]:
    cutoff = _iso_offset(-window_days)
    rows = conn.execute("""
        SELECT content_id
        FROM tracks
        WHERE total_appearances = 0
          AND in_library = 1
          AND COALESCE(added_at, date_created) IS NOT NULL
          AND COALESCE(added_at, date_created) >= ?
        ORDER BY COALESCE(added_at, date_created) DESC
        LIMIT ?
    """, (cutoff, limit)).fetchall()
    if not rows:
        return None
    ids = [str(r[0]) for r in rows]
    label = window_label or f"last {window_days} days"
    return Suggestion(
        id=sid,
        name=name,
        kind="recent",
        description=f"Added in the {label}, still untouched.",
        content_ids=ids,
        rationale="Buy-regret signal. Either rotate these in or admit you're not feeling them.",
        score=70.0,
    )


# ---------------------------------------------------------------------------
# Prep audit pack (legacy - retained for backward compat; not surfaced by
# generate_all per the 2026-06-01 scope change that removed prep audit).
# ---------------------------------------------------------------------------

def _prep_pack(conn: sqlite3.Connection,
               limit: int = 50,
               sid: str = "prep_pack",
               name: str = "Prep Me (missing BPM / key / cues)",
               where_clause: str = "(bpm IS NULL OR key_camelot IS NULL OR hot_cue_count = 0)",
               desc_suffix: Optional[str] = None) -> Optional[Suggestion]:
    sql = f"""
        SELECT content_id
        FROM tracks
        WHERE in_library = 1
          AND {where_clause}
        ORDER BY total_appearances DESC, title ASC
        LIMIT ?
    """
    rows = conn.execute(sql, (limit,)).fetchall()
    if not rows:
        return None
    ids = [str(r[0]) for r in rows]
    # desc_suffix intentionally dropped from the user-facing copy
    # 2026-06-02 - the algorithmic parenthetical ("≥5 plays, cold
    # 90+ days") read as AI-template and Rob asked them out.
    desc_extra = ""
    _ = desc_suffix  # kept in the call signature for back-compat
    return Suggestion(
        id=sid,
        name=name,
        kind="prep",
        description="Library tracks needing prep, most-played first.",
        content_ids=ids,
        rationale="Load this playlist in rekordbox, hit Analyse, set hot cues, you're done.",
        score=60.0,
    )


# ---------------------------------------------------------------------------
# Co-occurrence cliques - groups of 3-8 tracks that all play together
# ---------------------------------------------------------------------------

def _cliques(conn: sqlite3.Connection,
             min_pair_sessions: int = 4,
             min_clique: int = 3,
             max_clique: int = 8,
             limit: int = 5,
             exclude: Optional[set] = None) -> list[Suggestion]:
    """
    Greedy clique discovery on the track co-occurrence graph.
    Builds an adjacency map from `appearances`, picks the heaviest
    edge as a seed, grows the clique by adding the node whose minimum
    co-session-count with current members is highest, stops when no
    candidate meets the pair threshold or the clique hits max size.
    Excludes already-included tracks from later seeds to keep results
    distinct.
    """
    excl = exclude or set()
    pairs = conn.execute("""
        SELECT a.content_id, b.content_id, COUNT(DISTINCT a.session_id) AS shared
        FROM appearances a
        JOIN appearances b
          ON a.session_id = b.session_id AND a.content_id < b.content_id
        GROUP BY a.content_id, b.content_id
        HAVING shared >= ?
    """, (min_pair_sessions,)).fetchall()
    if not pairs:
        return []
    # Drop pairs where either side is already claimed by a prior pack.
    pairs = [(a, b, n) for a, b, n in pairs
             if str(a) not in excl and str(b) not in excl]
    if not pairs:
        return []

    adj: dict[str, dict[str, int]] = {}
    for a, b, n in pairs:
        a, b, n = str(a), str(b), int(n)
        adj.setdefault(a, {})[b] = n
        adj.setdefault(b, {})[a] = n

    sorted_pairs = sorted(pairs, key=lambda r: -r[2])
    used: set[str] = set(excl)  # don't grow a clique through claimed tracks
    suggestions: list[Suggestion] = []

    for a_raw, b_raw, _ in sorted_pairs:
        if len(suggestions) >= limit:
            break
        a, b = str(a_raw), str(b_raw)
        if a in used or b in used:
            continue
        clique = [a, b]
        clique_set = {a, b}
        while len(clique) < max_clique:
            best: tuple[Optional[str], int] = (None, 0)
            candidates = set(adj.get(clique[0], {}).keys())
            for m in clique[1:]:
                candidates &= set(adj.get(m, {}).keys())
            for cand in candidates - clique_set - used:
                min_shared = min(adj[cand].get(m, 0) for m in clique)
                if min_shared > best[1]:
                    best = (cand, min_shared)
            if best[0] is None or best[1] < min_pair_sessions:
                break
            clique.append(best[0])
            clique_set.add(best[0])
        if len(clique) < min_clique:
            continue
        used.update(clique)
        titles = _titles_for(conn, clique[:3])
        teaser = " + ".join(titles)
        suggestions.append(Suggestion(
            id=f"clique_{len(suggestions) + 1}",
            name=f"Cluster: {teaser}",
            kind="clique",
            description="Tracks that keep turning up in the same sets.",
            content_ids=clique,
            rationale="Tracks that keep turning up in the same sets as each other. "
                      f"Every pair has shared at least {min_pair_sessions} sessions.",
            score=50.0 + len(clique),
        ))
    return suggestions


# ---------------------------------------------------------------------------
# Seed + companions - take a top forgotten track and surround it with its
# most frequent session mates
# ---------------------------------------------------------------------------

def _decay_scored(conn: sqlite3.Connection,
                  half_life_days: int,
                  min_session_age_days: Optional[int] = None,
                  max_session_age_days: Optional[int] = None,
                  min_score: float = 0.0,
                  limit: int = 50) -> list[tuple]:
    """Recency-weighted play scoring. Uses SQLite EXP() when available;
    falls back to a Python aggregate when SQLite is too old (<3.35)."""
    lam = 0.693 / half_life_days
    if _HAS_SQL_MATH:
        clauses = ["s.session_date IS NOT NULL"]
        if max_session_age_days is not None:
            clauses.append(f"s.session_date >= date('now', '-{max_session_age_days} days')")
        if min_session_age_days is not None:
            clauses.append(f"s.session_date < date('now', '-{min_session_age_days} days')")
        where = " AND ".join(clauses)
        sql = f"""
            SELECT a.content_id,
                   SUM(EXP(-? * (julianday('now') - julianday(s.session_date)))) AS w
            FROM appearances a
            JOIN sessions s ON s.session_id = a.session_id
            WHERE {where}
            GROUP BY a.content_id
            HAVING w >= ?
            ORDER BY w DESC
            LIMIT ?
        """
        return conn.execute(sql, (lam, min_score, limit)).fetchall()
    # Python fallback: pull raw rows, aggregate, sort.
    clauses = ["s.session_date IS NOT NULL"]
    if max_session_age_days is not None:
        clauses.append(f"s.session_date >= date('now', '-{max_session_age_days} days')")
    if min_session_age_days is not None:
        clauses.append(f"s.session_date < date('now', '-{min_session_age_days} days')")
    where = " AND ".join(clauses)
    raw = conn.execute(f"""
        SELECT a.content_id, julianday('now') - julianday(s.session_date) AS days_ago
        FROM appearances a JOIN sessions s ON s.session_id = a.session_id
        WHERE {where}
    """).fetchall()
    scores: dict[str, float] = {}
    for cid, days_ago in raw:
        scores[str(cid)] = scores.get(str(cid), 0.0) + math.exp(-lam * float(days_ago))
    ranked = sorted(
        ((c, w) for c, w in scores.items() if w >= min_score),
        key=lambda r: -r[1],
    )
    return ranked[:limit]


def _seed_companions(conn: sqlite3.Connection,
                     limit: int = 5,
                     companions_per_seed: int = 14,
                     blocked_seed_pool: Optional[set] = None) -> list[Suggestion]:
    seeds = conn.execute("""
        SELECT t.content_id, t.title, t.artist, t.total_appearances
        FROM tracks t
        WHERE t.total_appearances >= 6
          AND t.in_library = 1
        ORDER BY t.total_appearances DESC
        LIMIT ?
    """, (limit * 4,)).fetchall()
    out: list[Suggestion] = []
    # Block both seeds AND companions from anchoring subsequent suggestions;
    # otherwise "Around X" and "Around Y" share most of their bodies when
    # X and Y are heavy co-mates. Pre-seed `blocked` with anything the
    # clique pass already surfaced so seed_companions explores a
    # different slice of the co-occurrence graph rather than echoing it.
    blocked: set[str] = set(blocked_seed_pool or set())
    for r in seeds:
        if len(out) >= limit:
            break
        seed_id, seed_title, seed_artist, _plays = str(r[0]), r[1], r[2], int(r[3])
        if seed_id in blocked:
            continue
        # Pull the seed's most-frequent session-mates, EXCLUDING anything
        # already attached to a prior suggestion. Without this filter,
        # heavy clusters produce three near-identical "Around X / Around
        # Y / Around Z" packs.
        if blocked:
            placeholders = ",".join("?" * len(blocked))
            extra_filter = f"AND b.content_id NOT IN ({placeholders})"
            params: list = [seed_id, *blocked, companions_per_seed]
        else:
            extra_filter = ""
            params = [seed_id, companions_per_seed]
        rows = conn.execute(f"""
            SELECT b.content_id, COUNT(DISTINCT a.session_id) AS shared
            FROM appearances a
            JOIN appearances b
              ON a.session_id = b.session_id AND b.content_id != a.content_id
            WHERE a.content_id = ?
              {extra_filter}
            GROUP BY b.content_id
            ORDER BY shared DESC
            LIMIT ?
        """, params).fetchall()
        ids = [seed_id] + [str(r[0]) for r in rows]
        if len(ids) < 4:
            continue
        blocked.update(ids)
        out.append(Suggestion(
            id=f"seed_{len(out) + 1}",
            name=f"Around {seed_title or 'Unknown'}",
            kind="seed_companions",
            description=f"{seed_title or 'Unknown'} and the tracks that most often share its sets.",
            content_ids=ids,
            rationale=f"Anchored on {seed_title or 'Unknown'} ({seed_artist or 'Unknown'}); "
                      "companions are the tracks that most often share sets with it.",
            score=40.0 + len(ids),
        ))
    return out


# ---------------------------------------------------------------------------
# Key chain - walk the Camelot wheel from a popular seed
# ---------------------------------------------------------------------------

def _key_chains(conn: sqlite3.Connection,
                target_length: int = 18,
                limit: int = 3,
                exclude: Optional[set] = None) -> list[Suggestion]:
    """
    Build harmonically-compatible chains. From a seed track, alternate:
      - same key
      - +1 hour same letter (energy step)
      - -1 hour same letter
      - relative major/minor (swap A<->B same number)
    Greedy: pick the most-played unused track in any compatible key.
    """
    excl = exclude or set()
    tracks = conn.execute("""
        SELECT content_id, title, key_camelot, total_appearances
        FROM tracks
        WHERE in_library = 1 AND key_camelot IS NOT NULL
          AND key_camelot GLOB '[0-9]*'
    """).fetchall()
    if not tracks:
        return []
    by_key: dict[str, list[tuple[str, str, int]]] = {}
    for cid, title, key, plays in tracks:
        if str(cid) in excl:
            continue
        by_key.setdefault(str(key), []).append((str(cid), title or "", int(plays)))
    for k in by_key:
        by_key[k].sort(key=lambda t: -t[2])
    # Heuristic seeds: most-played track in each of a few keys
    seed_keys = sorted(by_key, key=lambda k: -by_key[k][0][2])[:limit]
    out: list[Suggestion] = []
    used_globally: set[str] = set()
    for k in seed_keys:
        chain: list[str] = []
        used: set[str] = set()
        key = k
        for _ in range(target_length):
            candidates = []
            for compat in _camelot_compatible(key):
                for cid, _title, _plays in by_key.get(compat, []):
                    if cid in used or cid in used_globally:
                        continue
                    candidates.append((compat, cid, _plays))
            if not candidates:
                break
            candidates.sort(key=lambda c: -c[2])
            picked_key, picked_id, _ = candidates[0]
            chain.append(picked_id)
            used.add(picked_id)
            key = picked_key
        if len(chain) < 8:
            continue
        used_globally.update(chain)
        seed_title = by_key[k][0][1] if by_key[k] else ""
        out.append(Suggestion(
            id=f"key_chain_{len(out) + 1}",
            name=f"Key chain from {k} ({seed_title})",
            kind="key_chain",
            description=f"Harmonic walk anchored on Camelot {k}.",
            content_ids=chain,
            rationale="Harmonically-compatible walk along the Camelot wheel (±1 hour and "
                      "relative major/minor). Picks your most-played track at each step.",
            score=30.0 + len(chain),
        ))
    return out


def _camelot_compatible(key: str) -> list[str]:
    """Adjacent keys on the Camelot wheel: same, ±1 hour, swap A↔B."""
    if not key or len(key) < 2:
        return [key]
    try:
        n = int("".join(c for c in key if c.isdigit()))
    except ValueError:
        return [key]
    letter = key[-1].upper()
    other_letter = "B" if letter == "A" else "A"
    plus = ((n - 1 + 1) % 12) + 1
    minus = ((n - 1 - 1) % 12) + 1
    return [
        f"{n}{letter}",
        f"{plus}{letter}",
        f"{minus}{letter}",
        f"{n}{other_letter}",
    ]


# ---------------------------------------------------------------------------
# BPM ramp - warm-up curve
# ---------------------------------------------------------------------------

def _bpm_ramp(conn: sqlite3.Connection,
              target_length: int = 24,
              exclude: Optional[set] = None) -> Optional[Suggestion]:
    """
    Build a tempo arc: low → peak → cooldown. Picks the most-played
    track in each BPM bucket along the curve so the result is at least
    half familiar.
    """
    arc = [110, 115, 120, 123, 125, 127, 128, 130, 132, 134, 138, 142,
           146, 148, 150, 152, 150, 145, 138, 130, 125, 120, 115, 110]
    arc = arc[:target_length]
    out: list[str] = []
    used: set[str] = set(exclude or set())
    for target_bpm in arc:
        # No `NOT IN track_aliases` filter needed: v3 dedup deletes the
        # alias row from tracks entirely (aliases live only in
        # track_aliases), so the filter was a per-iteration no-op scan.
        row = conn.execute("""
            SELECT content_id
            FROM tracks
            WHERE in_library = 1 AND bpm IS NOT NULL
              AND ABS(bpm - ?) <= 1.5
            ORDER BY total_appearances DESC, ABS(bpm - ?) ASC
            LIMIT 5
        """, (target_bpm, target_bpm)).fetchall()
        for r in row:
            cid = str(r[0])
            if cid in used:
                continue
            out.append(cid)
            used.add(cid)
            break
    if len(out) < 6:
        return None
    return Suggestion(
        id="bpm_ramp",
        name="Warm-up → Peak → Cooldown",
        kind="bpm_ramp",
        description="A BPM arc, warm-up through peak to cooldown.",
        content_ids=out,
        rationale="A warm-up→peak→cooldown BPM arc, filled at each step with your "
                  "most-played track within ±1.5 BPM of the target tempo.",
        score=25.0,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# v0.9 generators (2026-06-01) - data-derived from the ordered appearances
# graph + session-similarity + decay models. See _research/ briefs for the
# design rationale; each function is a single SQL recipe with a tight
# Python post-process.
# ---------------------------------------------------------------------------

# Family A1: Markov-bigram transition chains. "What you actually played
# after track X." The single biggest gap in the prior tool: track_no was
# entirely unused in suggestion generation.
def _transition_chains(conn: sqlite3.Connection,
                       limit: int = 5,
                       chain_length: int = 14,
                       min_pair: int = 2,
                       exclude: Optional[set] = None) -> list[Suggestion]:
    # Build the bigram table once.
    rows = conn.execute("""
        WITH ordered AS (
          SELECT session_id, content_id, track_no,
                 LEAD(content_id) OVER (
                   PARTITION BY session_id ORDER BY track_no
                 ) AS next_cid
          FROM appearances
        )
        SELECT content_id, next_cid, COUNT(*) AS n
        FROM ordered
        WHERE next_cid IS NOT NULL AND next_cid != content_id
        GROUP BY content_id, next_cid
        HAVING n >= ?
    """, (min_pair,)).fetchall()
    if not rows:
        return []
    nxt: dict[str, list[tuple[str, int]]] = {}
    for a, b, n in rows:
        nxt.setdefault(str(a), []).append((str(b), int(n)))
    for k in nxt:
        nxt[k].sort(key=lambda r: -r[1])
    excl = exclude or set()
    # Pull a deep candidate seed list, then narrow to seeds that
    # ACTUALLY have transition data (mid-stratum seeds often don't
    # have any bigram with count >= min_pair), then stratify so the
    # chains anchor on a spread of depths rather than always the
    # heaviest few.
    seed_rows = conn.execute("""
        SELECT t.content_id, t.title, t.artist
        FROM tracks t
        WHERE t.in_library = 1 AND t.total_appearances >= 4
        ORDER BY t.total_appearances DESC
        LIMIT ?
    """, (max(120, limit * 16),)).fetchall()
    filtered = [r for r in seed_rows
                if str(r[0]) not in excl and str(r[0]) in nxt]
    seed_ids = [str(r[0]) for r in filtered]
    seed_order = _stratify(seed_ids,
                           anchor_n=2, mid_n=limit * 2, stretch_n=limit,
                           anchor_band=(0, 5),
                           mid_band=(5, 30),
                           stretch_band=(30, 120),
                           seed_key="transition_chain_seeds")
    seed_lookup = {str(r[0]): r for r in filtered}
    seed_rows = [seed_lookup[sid] for sid in seed_order if sid in seed_lookup]
    out: list[Suggestion] = []
    used_seeds: set[str] = set(excl)
    for r in seed_rows:
        if len(out) >= limit:
            break
        seed = str(r[0])
        if seed in used_seeds or seed not in nxt:
            continue
        used_seeds.add(seed)
        chain: list[str] = [seed]
        used: set[str] = {seed}
        cursor = seed
        for _ in range(chain_length - 1):
            options = nxt.get(cursor, [])
            picked = next((c for c, _ in options if c not in used), None)
            if picked is None:
                break
            chain.append(picked)
            used.add(picked)
            cursor = picked
        if len(chain) < 5:
            continue
        used_seeds.update(chain)
        title = r[1] or "Unknown"
        out.append(Suggestion(
            id=f"transition_chain_{len(out) + 1}",
            name=f"From {title}, you usually go…",
            kind="transition_chain",
            description="Every adjacent pair is a back-to-back you've actually mixed.",
            content_ids=chain,
            rationale=f"Walk of the transitions you've actually played out of \"{title}\". "
                      f"Each step is a back-to-back you've done at least {min_pair} times before.",
            score=78.0 + len(chain),
        ))
    return out


# Family A3: position-based role pools. Open/peak/close are slots; each
# DJ cycles a small stable through them.
def _position_role_packs(conn: sqlite3.Connection,
                         exclude: Optional[set] = None) -> list[Suggestion]:
    rows = conn.execute("""
        SELECT a.content_id,
               AVG(CAST(a.track_no AS REAL) / NULLIF(s.track_count, 0)) AS mean_pos,
               COUNT(*) AS n
        FROM appearances a
        JOIN sessions s ON s.session_id = a.session_id
        WHERE s.track_count >= 6
        GROUP BY a.content_id
        HAVING n >= 3
    """).fetchall()
    if not rows:
        return []
    excl = exclude or set()
    by_band: dict[str, list[tuple[str, int]]] = {"opener": [], "peak": [], "closer": []}
    for cid, mean_pos, n in rows:
        if mean_pos is None or str(cid) in excl:
            continue
        if mean_pos <= 0.18:
            by_band["opener"].append((str(cid), int(n)))
        elif 0.40 <= mean_pos <= 0.70:
            by_band["peak"].append((str(cid), int(n)))
        elif mean_pos >= 0.82:
            by_band["closer"].append((str(cid), int(n)))
    out: list[Suggestion] = []
    band_meta = [
        ("opener", "Opener Pool", "openers", "opener",
         "Average position in the first 18% of your sets."),
        ("peak",   "Peak-Time Anchors", "peak picks", "peak",
         "Mid-set staples - average position 40-70%."),
        ("closer", "Closer Pool", "closers", "closer",
         "Average position in the last 18% of your sets."),
    ]
    for band_key, name, _, sid_kind, rationale in band_meta:
        items = sorted(by_band[band_key], key=lambda r: -r[1])[:25]
        if len(items) < 4:
            continue
        ids = [c for c, _ in items]
        out.append(Suggestion(
            id=f"role_{band_key}",
            name=name,
            kind=f"role_{sid_kind}",
            description=f"Reliably placed in the {band_key} slot of your sets.",
            content_ids=ids,
            rationale=rationale,
            score=72.0,
        ))
    return out


# Family G4: personal canon (top tracks by recency-weighted plays).
def _personal_canon(conn: sqlite3.Connection,
                    half_life_days: int = 270,
                    limit: int = 50,
                    exclude: Optional[set] = None) -> Optional[Suggestion]:
    # Over-fetch when excluding so we still get `limit` results after
    # filtering. 3× is enough headroom on personal libraries.
    raw_rows = _decay_scored(conn, half_life_days=half_life_days,
                             min_session_age_days=None,
                             limit=limit * 3 if exclude else limit)
    excl = exclude or set()
    rows = [r for r in raw_rows if str(r[0]) not in excl][:limit]
    if not rows:
        return None
    ids = [str(r[0]) for r in rows]
    return Suggestion(
        id="personal_canon",
        name="Personal Canon",
        kind="canon",
        description="Most-active in your current rotation.",
        content_ids=ids,
        rationale="Recency-weighted top of your play history.",
        # Demoted - Rob already knows his canon; this surfaces it but
        # doesn't outrank the discovery family.
        score=68.0,
    )


def _closer_canon(conn: sqlite3.Connection, limit: int = 25,
                  exclude: Optional[set] = None) -> Optional[Suggestion]:
    # Tracks played in the last 5 tracks of any session (the closers Rob
    # actually used). Stratified: anchors are reliably-deployed closers,
    # mid + stretch surface less-obvious end-of-night material from
    # under his closer canon.
    excl = exclude or set()
    over_fetch = max(60, limit * 3)
    if excl:
        ph = ",".join("?" * len(excl))
        sql = f"""
            SELECT a.content_id, COUNT(*) AS n
            FROM appearances a
            JOIN sessions s ON s.session_id = a.session_id
            WHERE s.track_count >= 10
              AND a.track_no > s.track_count - 5
              AND a.content_id NOT IN ({ph})
            GROUP BY a.content_id
            ORDER BY n DESC
            LIMIT ?
        """
        rows = conn.execute(sql, [*excl, over_fetch]).fetchall()
    else:
        rows = conn.execute("""
            SELECT a.content_id, COUNT(*) AS n
            FROM appearances a
            JOIN sessions s ON s.session_id = a.session_id
            WHERE s.track_count >= 10
              AND a.track_no > s.track_count - 5
            GROUP BY a.content_id
            ORDER BY n DESC
            LIMIT ?
        """, (over_fetch,)).fetchall()
    if len(rows) < 4:
        return None
    cands = [str(r[0]) for r in rows]
    ids = _stratify(cands, anchor_n=4, mid_n=12, stretch_n=6,
                    seed_key="closer_canon")[:limit]
    return Suggestion(
        id="closer_canon",
        name="Last-5-of-the-Night Closers",
        kind="closer",
        description="Tracks that have actually closed your sets.",
        content_ids=ids,
        rationale="Each one of these has actually closed one of your sets (last five slots).",
        score=64.0,
    )


def _opener_canon(conn: sqlite3.Connection, limit: int = 20,
                  exclude: Optional[set] = None) -> Optional[Suggestion]:
    excl = exclude or set()
    over_fetch = max(60, limit * 3)
    if excl:
        ph = ",".join("?" * len(excl))
        sql = f"""
            SELECT a.content_id, COUNT(*) AS n
            FROM appearances a
            JOIN sessions s ON s.session_id = a.session_id
            WHERE s.track_count >= 8 AND a.track_no <= 4
              AND a.content_id NOT IN ({ph})
            GROUP BY a.content_id ORDER BY n DESC LIMIT ?
        """
        rows = conn.execute(sql, [*excl, over_fetch]).fetchall()
    else:
        rows = conn.execute("""
            SELECT a.content_id, COUNT(*) AS n
            FROM appearances a
            JOIN sessions s ON s.session_id = a.session_id
            WHERE s.track_count >= 8 AND a.track_no <= 4
            GROUP BY a.content_id ORDER BY n DESC LIMIT ?
        """, (over_fetch,)).fetchall()
    if len(rows) < 4:
        return None
    cands = [str(r[0]) for r in rows]
    ids = _stratify(cands, anchor_n=3, mid_n=10, stretch_n=5,
                    seed_key="opener_canon")[:limit]
    return Suggestion(
        id="opener_canon",
        name="First-4-of-the-Night Openers",
        kind="opener",
        description="Tracks that have actually opened your sets.",
        content_ids=ids,
        rationale="Each one of these has actually opened one of your sets (first four slots).",
        score=60.0,
    )


def _peak_canon(conn: sqlite3.Connection, limit: int = 30,
                exclude: Optional[set] = None) -> Optional[Suggestion]:
    # Peak slot = tracks routinely placed in the middle 40-70% of sets.
    excl = exclude or set()
    over_fetch = max(80, limit * 3)
    if excl:
        ph = ",".join("?" * len(excl))
        sql = f"""
            SELECT a.content_id, COUNT(*) AS n
            FROM appearances a
            JOIN sessions s ON s.session_id = a.session_id
            WHERE s.track_count >= 10
              AND a.track_no >= CAST(s.track_count * 0.40 AS INTEGER)
              AND a.track_no <= CAST(s.track_count * 0.70 AS INTEGER)
              AND a.content_id NOT IN ({ph})
            GROUP BY a.content_id ORDER BY n DESC LIMIT ?
        """
        rows = conn.execute(sql, [*excl, over_fetch]).fetchall()
    else:
        rows = conn.execute("""
            SELECT a.content_id, COUNT(*) AS n
            FROM appearances a
            JOIN sessions s ON s.session_id = a.session_id
            WHERE s.track_count >= 10
              AND a.track_no >= CAST(s.track_count * 0.40 AS INTEGER)
              AND a.track_no <= CAST(s.track_count * 0.70 AS INTEGER)
            GROUP BY a.content_id ORDER BY n DESC LIMIT ?
        """, (over_fetch,)).fetchall()
    if len(rows) < 4:
        return None
    cands = [str(r[0]) for r in rows]
    ids = _stratify(cands, anchor_n=4, mid_n=18, stretch_n=8,
                    seed_key="peak_canon")[:limit]
    return Suggestion(
        id="peak_canon",
        name="Peak-Slot Workhorses",
        kind="peak",
        description="Mid-set peak picks.",
        content_ids=ids,
        rationale="Tracks you reach for mid-set.",
        score=62.0,
    )


# Family E1: current rotation - sharp 60-day half-life surfaces what's
# actually live right now, distinct from the broader 270-day canon.
def _current_rotation(conn: sqlite3.Connection,
                      half_life_days: int = 60,
                      limit: int = 30,
                      exclude: Optional[set] = None) -> Optional[Suggestion]:
    excl = exclude or set()
    raw_rows = _decay_scored(conn, half_life_days=half_life_days,
                              max_session_age_days=180,
                              min_score=0.5,
                              limit=limit * (3 if excl else 1))
    rows = [r for r in raw_rows if str(r[0]) not in excl][:limit]
    if len(rows) < 5:
        return None
    ids = [str(r[0]) for r in rows]
    return Suggestion(
        id="current_rotation",
        name="In Heavy Rotation Right Now",
        kind="rotation",
        description="Alive in the last 60 days of your sets.",
        content_ids=ids,
        rationale="What's actually live in the last couple of months of your sets.",
        score=65.0,
    )


# Variant on forgotten: same idea but ranked by revival-leverage
# (high prior strength × long cold gap).
def _rested_heroes(conn: sqlite3.Connection,
                   min_appearances: int = 6,
                   days_cold: int = 120,
                   limit: int = 25,
                   exclude: Optional[set] = None) -> Optional[Suggestion]:
    cutoff = _iso_offset(-days_cold)
    excl = exclude or set()
    over_fetch = limit * 4 if excl else limit
    if _HAS_SQL_MATH:
        raw_rows = conn.execute("""
            SELECT t.content_id,
                   t.total_appearances * (1.0 +
                     LOG(MAX(1, julianday('now') - julianday(s.session_date)))) AS revival_score
            FROM tracks t
            JOIN sessions s ON s.session_id = t.last_seen_session
            WHERE t.total_appearances >= ?
              AND s.session_date < ?
            ORDER BY revival_score DESC
            LIMIT ?
        """, (min_appearances, cutoff, over_fetch)).fetchall()
    else:
        raw = conn.execute("""
            SELECT t.content_id, t.total_appearances,
                   (julianday('now') - julianday(s.session_date)) AS days_ago
            FROM tracks t
            JOIN sessions s ON s.session_id = t.last_seen_session
            WHERE t.total_appearances >= ? AND s.session_date < ?
        """, (min_appearances, cutoff)).fetchall()
        raw_rows = sorted(
            ((r[0], r[1] * (1.0 + math.log(max(1.0, r[2])))) for r in raw),
            key=lambda r: -r[1],
        )[:over_fetch]
    rows = [r for r in raw_rows if str(r[0]) not in excl][:limit]
    if not rows:
        return None
    ids = [str(r[0]) for r in rows]
    return Suggestion(
        id="rested_heroes",
        name="Rested Heroes",
        kind="rested",
        description="Muscle-memory tracks gone cold long enough to land fresh.",
        content_ids=ids,
        rationale=f"Tracks you used to lean on hard (≥{min_appearances} plays) but haven't "
                  f"touched in {days_cold}+ days. Rested long enough to land fresh again.",
        # Promoted - this is a key discovery angle for Rob.
        score=92.0,
    )


# --- Discovery family (deliberately target the medium / long tail) ---

def _hidden_gems(conn: sqlite3.Connection,
                 min_plays: int = 2,
                 max_plays: int = 5,
                 days_cold: int = 90,
                 limit: int = 30,
                 exclude: Optional[set] = None) -> Optional[Suggestion]:
    """Tracks you've played a HANDFUL of times (not many, not zero)
    and haven't touched in 90+ days. The medium-stratum tail that
    every other generator's ORDER-BY-plays-DESC structurally ignores.
    This is the "surprise me from outside my obvious favourites" pack."""
    excl = exclude or set()
    cutoff = _iso_offset(-days_cold)
    over = limit * (5 if excl else 2)
    rows = conn.execute("""
        SELECT t.content_id
        FROM tracks t
        JOIN sessions s ON s.session_id = t.last_seen_session
        WHERE t.in_library = 1
          AND t.total_appearances BETWEEN ? AND ?
          AND s.session_date < ?
        ORDER BY t.total_appearances DESC, s.session_date ASC
        LIMIT ?
    """, (min_plays, max_plays, cutoff, over)).fetchall()
    ids = [str(r[0]) for r in rows if str(r[0]) not in excl][:limit]
    if len(ids) < 6:
        return None
    return Suggestion(
        id="hidden_gems",
        name="Hidden Gems",
        kind="discovery",
        description=f"Played {min_plays}-{max_plays} times, then dropped.",
        content_ids=ids,
        rationale="Crossed the decks a handful of times then disappeared.",
        # Promoted to top of the suggestion list. Rob's "I want to
        # discover things I've missed" sits exactly here: tracks he
        # played a few times, never integrated, deserve another shot.
        score=95.0,
    )


def _long_tail_companions(conn: sqlite3.Connection,
                          limit: int = 25,
                          exclude: Optional[set] = None) -> Optional[Suggestion]:
    """Companions of mid-stratum seeds. Picks seeds with 3-8 plays
    (the un-obvious anchors), then finds tracks that have shared a
    session with them at least twice. Surfaces co-play structure that
    lives below the heavy-rotation graph."""
    excl = exclude or set()
    seed_rows = conn.execute("""
        SELECT content_id FROM tracks
        WHERE in_library = 1 AND total_appearances BETWEEN 3 AND 8
        ORDER BY total_appearances DESC
        LIMIT 60
    """).fetchall()
    if not seed_rows:
        return None
    seed_ids = [str(r[0]) for r in seed_rows if str(r[0]) not in excl][:30]
    if len(seed_ids) < 4:
        return None
    placeholders = ",".join("?" * len(seed_ids))
    rows = conn.execute(f"""
        SELECT b.content_id, COUNT(DISTINCT a.session_id) AS n
        FROM appearances a
        JOIN appearances b
          ON a.session_id = b.session_id AND a.content_id != b.content_id
        WHERE a.content_id IN ({placeholders})
        GROUP BY b.content_id
        HAVING n >= 2
        ORDER BY n DESC
        LIMIT ?
    """, [*seed_ids, limit * 4]).fetchall()
    ids = [str(r[0]) for r in rows if str(r[0]) not in excl][:limit]
    if len(ids) < 6:
        return None
    return Suggestion(
        id="long_tail_companions",
        name="Off-Headline Mates",
        kind="discovery",
        description="Orbit the second-tier tracks in your history, not your canon.",
        content_ids=ids,
        rationale="Co-occurrence anchored on second-tier tracks.",
        score=93.0,
    )


def _unloved_library(conn: sqlite3.Connection,
                     min_days_in_library: int = 60,
                     limit: int = 30,
                     exclude: Optional[set] = None) -> Optional[Suggestion]:
    """Library tracks that have been around 60+ days with ZERO plays.
    Distinct from buy_and_bury (which is 120+ days + verdict-oriented)
    and from recently_added_unplayed (which is <30 days). The
    middle-aged unplayed cohort that may just need permission."""
    excl = exclude or set()
    early = _iso_offset(-365)
    cutoff = _iso_offset(-min_days_in_library)
    rows = conn.execute("""
        SELECT content_id FROM tracks
        WHERE in_library = 1
          AND total_appearances = 0
          AND COALESCE(added_at, date_created) IS NOT NULL
          AND COALESCE(added_at, date_created) BETWEEN ? AND ?
        ORDER BY COALESCE(added_at, date_created) DESC
        LIMIT ?
    """, (early, cutoff, limit * (3 if excl else 1))).fetchall()
    ids = [str(r[0]) for r in rows if str(r[0]) not in excl][:limit]
    if len(ids) < 6:
        return None
    return Suggestion(
        id="unloved_library",
        name="Library Tail",
        kind="discovery",
        description="Library tracks bought two months to a year ago, never played.",
        content_ids=ids,
        rationale="Past the recent-buys window, not yet at verdict time.",
        score=90.0,
    )


# Family E4: tracks bought, ignored, never played (>120d).
def _buy_and_bury(conn: sqlite3.Connection, days_old: int = 120) -> Optional[Suggestion]:
    cutoff = _iso_offset(-days_old)
    rows = conn.execute("""
        SELECT content_id
        FROM tracks
        WHERE total_appearances = 0
          AND in_library = 1
          AND COALESCE(added_at, date_created) IS NOT NULL
          AND COALESCE(added_at, date_created) < ?
        ORDER BY COALESCE(added_at, date_created) ASC
        LIMIT 60
    """, (cutoff,)).fetchall()
    if not rows:
        return None
    ids = [str(r[0]) for r in rows]
    return Suggestion(
        id="buy_and_bury",
        name="Buy or Bury",
        kind="bury",
        description=f"Added over {days_old} days ago, never played. Deploy or delete.",
        content_ids=ids,
        rationale="Verdict pack: spin them once, or cut them.",
        score=86.0,
    )


# Family G3: cliques that haven't surfaced in 60+ days.
def _cold_cliques(conn: sqlite3.Connection,
                  min_pair_sessions: int = 3,
                  min_clique: int = 3,
                  max_clique: int = 7,
                  cold_days: int = 60,
                  limit: int = 3,
                  exclude: Optional[set] = None) -> list[Suggestion]:
    cutoff = _iso_offset(-cold_days)
    pairs = conn.execute("""
        SELECT a.content_id, b.content_id, COUNT(DISTINCT a.session_id) AS shared
        FROM appearances a
        JOIN appearances b
          ON a.session_id = b.session_id AND a.content_id < b.content_id
        JOIN sessions s ON s.session_id = a.session_id
        WHERE s.session_date < ?
        GROUP BY a.content_id, b.content_id
        HAVING shared >= ?
    """, (cutoff, min_pair_sessions)).fetchall()
    if not pairs:
        return []
    # Drop any pair where EITHER side has been played within the cutoff.
    recent_rows = conn.execute("""
        SELECT DISTINCT a.content_id
        FROM appearances a
        JOIN sessions s ON s.session_id = a.session_id
        WHERE s.session_date >= ?
    """, (cutoff,)).fetchall()
    recent_set = {str(r[0]) for r in recent_rows}
    excl = (exclude or set()) | recent_set
    pairs = [(str(a), str(b), int(n)) for a, b, n in pairs
             if str(a) not in excl and str(b) not in excl]
    if not pairs:
        return []
    adj: dict[str, dict[str, int]] = {}
    for a, b, n in pairs:
        adj.setdefault(a, {})[b] = n
        adj.setdefault(b, {})[a] = n
    sorted_pairs = sorted(pairs, key=lambda r: -r[2])
    used: set[str] = set(excl)
    out: list[Suggestion] = []
    for a, b, _ in sorted_pairs:
        if len(out) >= limit:
            break
        if a in used or b in used:
            continue
        clique = [a, b]
        clique_set = {a, b}
        while len(clique) < max_clique:
            cands = set(adj.get(clique[0], {}).keys())
            for m in clique[1:]:
                cands &= set(adj.get(m, {}).keys())
            best = None
            best_min = 0
            for c in cands - clique_set - used:
                m = min(adj[c].get(x, 0) for x in clique)
                if m > best_min:
                    best, best_min = c, m
            if best is None or best_min < min_pair_sessions:
                break
            clique.append(best)
            clique_set.add(best)
        if len(clique) < min_clique:
            continue
        used.update(clique)
        titles = _titles_for(conn, clique[:3])
        out.append(Suggestion(
            id=f"cold_clique_{len(out) + 1}",
            name=f"Cold cluster: {' + '.join(titles)}",
            kind="cold_clique",
            description=f"Used to play together, dormant {cold_days}+ days.",
            content_ids=clique,
            rationale=f"These tracks used to play together, but nothing in the cluster has "
                      f"surfaced since {cutoff}. Group revival candidate.",
            score=65.0 + len(clique),
        ))
    return out


# Family F2: same calendar month, prior year(s).
def _this_month_last_year(conn: sqlite3.Connection,
                          limit: int = 30) -> Optional[Suggestion]:
    rows = conn.execute("""
        SELECT a.content_id, COUNT(*) AS n
        FROM appearances a
        JOIN sessions s ON s.session_id = a.session_id
        WHERE strftime('%m', s.session_date) = strftime('%m', 'now')
          AND s.session_date < date('now', '-300 days')
        GROUP BY a.content_id
        HAVING n >= 1
        ORDER BY n DESC
        LIMIT ?
    """, (limit,)).fetchall()
    if len(rows) < 4:
        return None
    ids = [str(r[0]) for r in rows]
    return Suggestion(
        id="this_month_last_year",
        name="This Month, Previous Years",
        kind="seasonal",
        description="Tracks you've played in this calendar month in prior years.",
        content_ids=ids,
        rationale="Tracks you played in this calendar month last year (or earlier). "
                  "Seasonal memory cue.",
        score=60.0,
    )


# Family F3: anniversary sets (exactly N years ago today).
def _anniversary_sets(conn: sqlite3.Connection,
                      years: tuple[int, ...] = (1, 2, 3)) -> list[Suggestion]:
    out: list[Suggestion] = []
    for n in years:
        # ±2-day window around the exact anniversary handles missing dates.
        rows = conn.execute("""
            SELECT s.session_id, s.session_date, s.track_count
            FROM sessions s
            WHERE date(s.session_date) BETWEEN
                  date('now', ?) AND date('now', ?)
            ORDER BY s.track_count DESC
            LIMIT 1
        """, (f"-{n*365 + 2} days", f"-{n*365 - 2} days")).fetchall()
        if not rows:
            continue
        session_id, session_date, _track_count = rows[0]
        track_rows = conn.execute("""
            SELECT content_id FROM appearances
            WHERE session_id = ? ORDER BY track_no ASC
        """, (session_id,)).fetchall()
        # CDJ history occasionally records the same track twice within
        # one session (loop or accidental restart); pushing those into a
        # rekordbox playlist would create literal duplicate rows. Dedupe
        # while preserving the first-occurrence order.
        seen: set[str] = set()
        ids: list[str] = []
        for r in track_rows:
            cid = str(r[0])
            if cid in seen:
                continue
            seen.add(cid)
            ids.append(cid)
        if len(ids) < 5:
            continue
        nice_date = str(session_date)[:10]
        label = "1 year ago today" if n == 1 else f"{n} years ago today"
        out.append(Suggestion(
            id=f"anniversary_{n}y",
            name=f"Your set, {label}",
            kind="anniversary",
            description=f"The set you played on {nice_date}, in order.",
            content_ids=ids,
            rationale=f"The set you actually played on {nice_date} (session #{session_id}), "
                      "in original order.",
            score=68.0,
        ))
    return out


# Family C5: half-time / double-time pairs at the same Camelot key.
def _half_time_doubles(conn: sqlite3.Connection,
                       limit: int = 24,
                       exclude: Optional[set] = None) -> Optional[Suggestion]:
    excl = exclude or set()
    rows = conn.execute("""
        SELECT a.content_id, b.content_id, a.bpm, b.bpm
        FROM tracks a JOIN tracks b
          ON a.content_id < b.content_id
          AND a.in_library = 1 AND b.in_library = 1
          AND a.key_camelot IS NOT NULL AND a.key_camelot = b.key_camelot
          AND a.bpm IS NOT NULL AND b.bpm IS NOT NULL
          AND ABS(a.bpm * 2 - b.bpm) <= (0.025 * b.bpm)
          AND a.total_appearances + b.total_appearances > 0
        ORDER BY a.total_appearances + b.total_appearances DESC
        LIMIT ?
    """, (limit * 3,)).fetchall()
    if len(rows) < 3:
        return None
    seen: set[str] = set()
    ids: list[str] = []
    for a, b, _, _ in rows:
        if str(a) in excl or str(b) in excl:
            continue
        for cid in (str(a), str(b)):
            if cid not in seen:
                seen.add(cid)
                ids.append(cid)
            if len(ids) >= limit:
                break
    return Suggestion(
        id="half_time_doubles",
        name="Half-time / Double-time Bridges",
        kind="bridges",
        description="Paired across BPM doublings at matching Camelot keys.",
        content_ids=ids,
        rationale="Track pairs at exactly double or half the BPM and the same Camelot key. "
                  "Bridges between tempo zones (70↔140, 80↔160) without breaking the mix.",
        score=55.0,
    )


# Family B1: session similarity. Pick the most-recent N sessions; find
# the most-similar past session by Jaccard; surface the diff tracks.
def _similar_sessions(conn: sqlite3.Connection, limit: int = 3,
                      candidate_pool: int = 60) -> list[Suggestion]:
    """Compare each of the most-recent `limit` sessions against the
    `candidate_pool` most-recent OTHER sessions (not the entire history).
    On a 5-year DJ history this turns an O(sessions²) appearances scan
    into O(limit × candidate_pool), keeping the suggester sub-100ms even
    when the user has 500+ sessions stored. The cutoff still surfaces
    the genuinely-similar sessions in practice because vibes drift; a
    set from 4 years ago rarely matches a set from last week."""
    sess_rows = conn.execute("""
        SELECT session_id, session_date, track_count
        FROM sessions
        WHERE track_count >= 8
        ORDER BY session_date DESC
        LIMIT ?
    """, (limit,)).fetchall()
    if not sess_rows:
        return []
    target_ids = [int(r[0]) for r in sess_rows]
    pool_rows = conn.execute("""
        SELECT session_id FROM sessions
        WHERE track_count >= 8
        ORDER BY session_date DESC
        LIMIT ?
    """, (candidate_pool,)).fetchall()
    relevant_session_ids = set(target_ids) | {int(r[0]) for r in pool_rows}
    placeholders = ",".join("?" * len(relevant_session_ids))
    rows = conn.execute(
        f"SELECT session_id, content_id FROM appearances "
        f"WHERE session_id IN ({placeholders})",
        list(relevant_session_ids),
    ).fetchall()
    by_session: dict[int, set[str]] = {}
    for sid, cid in rows:
        by_session.setdefault(int(sid), set()).add(str(cid))
    out: list[Suggestion] = []
    for sid, sdate, tcount in sess_rows:
        target = by_session.get(int(sid), set())
        if not target:
            continue
        best_sid: Optional[int] = None
        best_score = 0.0
        for other_sid, other_set in by_session.items():
            if other_sid == int(sid) or not other_set:
                continue
            inter = len(target & other_set)
            if inter == 0:
                continue
            jac = inter / len(target | other_set)
            if jac > best_score:
                best_score, best_sid = jac, other_sid
        if best_sid is None or best_score < 0.10:
            continue
        diff = sorted(by_session[best_sid] - target)
        if len(diff) < 4:
            continue
        # Order the diff by historical play count to put strongest first.
        place = conn.execute(
            f"SELECT content_id FROM tracks "
            f"WHERE content_id IN ({','.join(['?']*len(diff))}) "
            f"ORDER BY total_appearances DESC",
            diff,
        ).fetchall()
        ids = [str(r[0]) for r in place]
        nice = str(sdate)[:10]
        out.append(Suggestion(
            id=f"similar_to_{sid}",
            name=f"More like your {nice} set",
            kind="similar_session",
            description="Tracks from your most-similar past set you haven't reused.",
            content_ids=ids,
            rationale=f"Set #{best_sid} is the most-similar past set to your #{sid}. "
                      "Here are the tracks from that one you haven't reused recently.",
            score=74.0,
        ))
    return out


# Family C1: target energy/BPM arcs derived from documented set shapes.
def _energy_arc_presets(conn: sqlite3.Connection,
                        exclude: Optional[set] = None) -> list[Suggestion]:
    # Each preset describes a curve over 6 positions. For each position
    # we ask SQLite for the best-fitting track in that band that isn't
    # already in the chain.
    presets = [
        ("warm_up", "Warm-up Arc",
         "Slow build for an opener slot.",
         [(110, 118), (115, 122), (118, 124), (120, 126), (122, 128), (124, 130)]),
        ("peak_time", "Peak-time Arc",
         "Settled-in club arc once the floor is warm.",
         [(124, 128), (126, 130), (128, 132), (128, 132), (126, 130), (124, 128)]),
        ("sunset_closer", "Sunset Closer Arc",
         "Wind-down close from peak through cool-off.",
         [(128, 132), (124, 128), (120, 124), (115, 120), (110, 115), (104, 110)]),
    ]
    out: list[Suggestion] = []
    for sid, name, desc, bands in presets:
        chain: list[str] = []
        used: set[str] = set(exclude or set())
        for lo, hi in bands:
            row = conn.execute("""
                SELECT t.content_id
                FROM tracks t
                WHERE t.in_library = 1 AND t.bpm IS NOT NULL
                  AND t.bpm BETWEEN ? AND ?
                ORDER BY t.total_appearances DESC
                LIMIT 6
            """, (lo, hi)).fetchall()
            picked = next((str(r[0]) for r in row if str(r[0]) not in used), None)
            if picked:
                chain.append(picked)
                used.add(picked)
        if len(chain) < 4:
            continue
        out.append(Suggestion(
            id=f"arc_{sid}",
            name=name,
            kind="arc",
            description=f"Shaped along the {sid.replace('_', '-')} curve.",
            content_ids=chain,
            rationale=desc + " Filled at each position with your most-played track in the BPM band.",
            score=52.0 + len(chain),
        ))
    return out


# ---------------------------------------------------------------------------
# K1: Full-set composite generator
# ---------------------------------------------------------------------------

def _full_set_recipes(conn: sqlite3.Connection,
                      exclude_initial: Optional[set] = None) -> list[Suggestion]:
    """Tonight's-set generator. Composes the other generators into a
    single setlist with proper arc shape.

    Three duration presets with DELIBERATELY DIFFERENT curation
    characters - the previous version produced 60 ⊂ 90 ⊂ 120
    (each was a subset of the next, all top-tracks-per-slot). Now:

      Short (~60 min)   "Tight & Tested" - anchor-heavy.
                          Safe set; mostly heavy-rotation per slot.
      Standard (~90)    "Balanced Night" - canon anchors + mid-tier
                          discovery; the workhorse set.
      Long (~120)       "Deep Dig" - leans mid + stretch picks; the
                          experimental long-form set.

    Each recipe excludes the prior recipe's picks so the three are
    materially different - if a closer surfaces in Tight & Tested it
    won't reappear in Balanced or Deep Dig.

    Within each slot, tracks are stratified across appearance bands
    (anchor = top 5, mid = positions 6-20, stretch = positions 21-50)
    so the recipe pulls from the body of your history, not just the
    head. The mix-per-slot is what makes each duration's character
    distinct.
    """
    sessions_with_arc = conn.execute("""
        SELECT COUNT(*) FROM sessions WHERE track_count >= 6
    """).fetchone()
    if not sessions_with_arc or int(sessions_with_arc[0]) < 8:
        return []

    def stratified_slot(where_clause: str, params: tuple,
                        anchor_n: int, mid_n: int, stretch_n: int,
                        used: set[str], exclude: set[str]) -> list[str]:
        """Pull up to 50 candidates for the slot, then sample
        anchor / mid / stretch from positions 0-4, 5-19, 20-49. Skips
        tracks already in `used` or in the cross-recipe `exclude`."""
        rows = conn.execute(f"""
            SELECT a.content_id, COUNT(*) AS n
            FROM appearances a
            JOIN sessions s ON s.session_id = a.session_id
            WHERE {where_clause}
            GROUP BY a.content_id
            ORDER BY n DESC
            LIMIT 250
        """, params).fetchall()
        cands = [str(r[0]) for r in rows
                 if str(r[0]) not in used and str(r[0]) not in exclude]
        picks: list[str] = []
        anchor_pool  = cands[0:5]
        mid_pool     = cands[5:30]
        stretch_pool = cands[30:120]
        # Use deterministic shuffling within each stratum (seeded on
        # the slot's where_clause + sizing) so the picks feel
        # personalised but stay stable across refreshes within a day.
        import random as _r
        rng = _r.Random(hash((where_clause, anchor_n, mid_n, stretch_n)))
        rng.shuffle(mid_pool)
        rng.shuffle(stretch_pool)
        picks.extend(anchor_pool[:anchor_n])
        picks.extend(mid_pool[:mid_n])
        picks.extend(stretch_pool[:stretch_n])
        # Top up from whatever's left in case any stratum was thin.
        seen = set(picks)
        for c in cands:
            if c in seen:
                continue
            seen.add(c)
            picks.append(c)
            if len(picks) >= anchor_n + mid_n + stretch_n:
                break
        return picks

    # Each preset gives a different (anchor, mid, stretch) shape per
    # slot. Rebalanced 2026-06-02 per Rob's "favs already in my sets,
    # I want to discover things I've missed" feedback - anchor counts
    # cut hard, mid + stretch now dominate every preset. The Tonight
    # surface is now a discovery-led setlist generator anchored on
    # role-position history (the un-obvious openers, the unfamiliar
    # peak-time picks etc.), not a top-tracks-by-slot regurgitator.
    presets = [
        # (mins,  name,            opener,    build,     peak,      cool,      closer)
        (60,   "Familiar 60",    (1, 3, 0), (1, 3, 1), (2, 4, 1), (1, 2, 1), (1, 2, 0)),
        (90,   "Discovery 90",   (0, 3, 2), (1, 4, 2), (1, 5, 3), (0, 3, 2), (0, 2, 2)),
        (120,  "Deep Crate 120", (0, 2, 3), (0, 3, 4), (1, 4, 5), (0, 3, 3), (0, 2, 2)),
    ]

    out: list[Suggestion] = []
    # Seed cross-recipe exclusion with the favs set (passed by
    # generate_all) so Tonight recipes never source from the user's
    # heavy rotation. Plus the de-overlap-across-the-three-recipes
    # role this set has always played.
    cross_recipe_excl: set[str] = set(exclude_initial or set())

    for total_min, name, op_mix, bu_mix, pk_mix, co_mix, cl_mix in presets:
        used: set[str] = set()
        excl = set(cross_recipe_excl)

        opener = stratified_slot(
            "s.track_count >= 8 AND a.track_no <= 4", (),
            *op_mix, used=used, exclude=excl)
        used.update(opener)
        build = stratified_slot(
            "s.track_count >= 10 AND a.track_no > 4 "
            "AND a.track_no < CAST(s.track_count * 0.40 AS INTEGER)", (),
            *bu_mix, used=used, exclude=excl)
        used.update(build)
        peak = stratified_slot(
            "s.track_count >= 10 "
            "AND a.track_no >= CAST(s.track_count * 0.40 AS INTEGER) "
            "AND a.track_no <= CAST(s.track_count * 0.70 AS INTEGER)", (),
            *pk_mix, used=used, exclude=excl)
        used.update(peak)
        cool = stratified_slot(
            "s.track_count >= 10 "
            "AND a.track_no > CAST(s.track_count * 0.70 AS INTEGER) "
            "AND a.track_no <= s.track_count - 5", (),
            *co_mix, used=used, exclude=excl)
        used.update(cool)
        closer = stratified_slot(
            "s.track_count >= 10 AND a.track_no > s.track_count - 5", (),
            *cl_mix, used=used, exclude=excl)

        chain = opener + build + peak + cool + closer
        if len(chain) < 8:
            continue

        descriptors = {
            "Familiar 60":     "Mostly tracks you've placed in these positions "
                               "but never leaned on.",
            "Discovery 90":    "Almost no canon. Tracks you've tried in these "
                               "slots a few times and let go.",
            "Deep Crate 120":  "Long-form set from the deep tail of your slot "
                               "history. Stretch picks across every position.",
        }

        # De-overlap subsequent recipes: 90-min skips 60-min's picks,
        # 120-min skips both. Critical for the "Tonight isn't just top
        # tracks" complaint - without this, all three converge.
        cross_recipe_excl.update(chain)

        out.append(Suggestion(
            id=f"full_set_{total_min}",
            name=f"{name}",
            kind="full_set",
            description=descriptors[name],
            content_ids=chain,
            rationale=f"{len(opener)} opener / {len(build)} build / "
                      f"{len(peak)} peak / {len(cool)} cool / "
                      f"{len(closer)} closer.",
            score=102.0 + (0.01 * total_min),
        ))
    return out


# ---------------------------------------------------------------------------
# v5 generators (use rekordbox fields ingested by ingest.py v5)
# ---------------------------------------------------------------------------

def _has_table(conn: sqlite3.Connection, table: str) -> bool:
    return bool(conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name = ?",
        (table,),
    ).fetchone())


def _stratify(candidates: list[str],
              anchor_n: int = 5, mid_n: int = 12, stretch_n: int = 6,
              anchor_band: tuple[int, int] = (0, 5),
              mid_band: tuple[int, int] = (5, 20),
              stretch_band: tuple[int, int] = (20, 50),
              seed_key: str = "") -> list[str]:
    """Pick from three appearance bands so a generator's output is a
    blend of canon anchors + mid-tier picks + stretch material, not a
    pure top-N. Pulls deterministically from a stable RNG seeded on
    seed_key so picks survive refreshes within a data state, but
    differ across generators (each passes a unique seed_key)."""
    import random as _r
    rng = _r.Random(seed_key)
    anchors = candidates[anchor_band[0]:anchor_band[1]]
    mids    = candidates[mid_band[0]:mid_band[1]]
    stretch = candidates[stretch_band[0]:stretch_band[1]]
    mids    = list(mids);    rng.shuffle(mids)
    stretch = list(stretch); rng.shuffle(stretch)
    picks: list[str] = []
    picks.extend(anchors[:anchor_n])
    picks.extend(mids[:mid_n])
    picks.extend(stretch[:stretch_n])
    # Top up from the remaining pool in case any stratum was thin.
    seen = set(picks)
    for c in candidates:
        if c in seen:
            continue
        seen.add(c)
        picks.append(c)
        if len(picks) >= anchor_n + mid_n + stretch_n:
            break
    return picks


def _has_column(conn: sqlite3.Connection, table: str, column: str) -> bool:
    return any(r[1] == column for r in conn.execute(f"PRAGMA table_info({table})").fetchall())


def _starred_cold(conn: sqlite3.Connection,
                  days_cold: int = 90, min_rating: int = 4,
                  limit: int = 30) -> Optional[Suggestion]:
    if not _has_column(conn, "tracks", "rating"):
        return None
    cutoff = _iso_offset(-days_cold)
    rows = conn.execute("""
        SELECT t.content_id
        FROM tracks t
        LEFT JOIN sessions s ON s.session_id = t.last_seen_session
        WHERE t.rating >= ?
          AND t.in_library = 1
          AND (s.session_date IS NULL OR s.session_date < ?)
        ORDER BY t.rating DESC, t.total_appearances DESC
        LIMIT ?
    """, (min_rating, cutoff, limit)).fetchall()
    if len(rows) < 3:
        return None
    ids = [str(r[0]) for r in rows]
    return Suggestion(
        id="starred_cold",
        name=f"{min_rating}-Star But Cold",
        kind="rated",
        description=f"Starred {min_rating}+ in rekordbox, cold {days_cold}+ days.",
        content_ids=ids,
        rationale="Tracks you starred but haven't pulled out lately.",
        score=84.0,
    )


def _genre_packs(conn: sqlite3.Connection, limit: int = 5,
                 min_size: int = 8) -> list[Suggestion]:
    if not _has_column(conn, "tracks", "genre"):
        return []
    rows = conn.execute("""
        SELECT genre, COUNT(*) AS n,
               SUM(total_appearances) AS plays
        FROM tracks
        WHERE genre IS NOT NULL AND genre != '' AND in_library = 1
        GROUP BY genre
        HAVING n >= ?
        ORDER BY plays DESC, n DESC
        LIMIT ?
    """, (min_size, limit)).fetchall()
    out: list[Suggestion] = []
    for genre, count, plays in rows:
        track_rows = conn.execute("""
            SELECT content_id FROM tracks
            WHERE genre = ? AND in_library = 1
            ORDER BY total_appearances DESC, title ASC
            LIMIT 40
        """, (genre,)).fetchall()
        if not track_rows:
            continue
        ids = [str(r[0]) for r in track_rows]
        out.append(Suggestion(
            id=f"genre_{genre.lower().replace(' ', '_')[:20]}",
            name=f"Genre: {genre}",
            kind="genre",
            description=f"Library tracks tagged {genre} ({plays} plays total).",
            content_ids=ids,
            rationale=f"Most-played tracks tagged {genre} in rekordbox.",
            score=48.0,
        ))
    return out


def _color_packs(conn: sqlite3.Connection, limit: int = 4,
                 min_size: int = 6) -> list[Suggestion]:
    if not _has_column(conn, "tracks", "color_name"):
        return []
    rows = conn.execute("""
        SELECT color_name, COUNT(*) AS n
        FROM tracks
        WHERE color_name IS NOT NULL AND color_name != '' AND in_library = 1
        GROUP BY color_name
        HAVING n >= ?
        ORDER BY n DESC
        LIMIT ?
    """, (min_size, limit)).fetchall()
    out: list[Suggestion] = []
    for color, _n in rows:
        track_rows = conn.execute("""
            SELECT content_id FROM tracks
            WHERE color_name = ? AND in_library = 1
            ORDER BY total_appearances DESC, title ASC
            LIMIT 30
        """, (color,)).fetchall()
        if not track_rows:
            continue
        ids = [str(r[0]) for r in track_rows]
        out.append(Suggestion(
            id=f"color_{color.lower().replace(' ', '_')[:18]}",
            name=f"Color tag: {color}",
            kind="color",
            description=f"Tagged {color} in rekordbox.",
            content_ids=ids,
            rationale="Pulled straight from your rekordbox color tags.",
            score=44.0,
        ))
    return out


def _loved_but_unplayed(conn: sqlite3.Connection) -> Optional[Suggestion]:
    """High rekordbox DJPlayCount on tracks Set Memory hasn't seen in a
    session - i.e. heavily played at home / on the CDJ but never made it
    through to one of Rob's logged sets. Strong revival candidates."""
    if not _has_column(conn, "tracks", "play_count"):
        return None
    rows = conn.execute("""
        SELECT content_id FROM tracks
        WHERE in_library = 1
          AND play_count IS NOT NULL AND play_count >= 5
          AND total_appearances <= 1
        ORDER BY play_count DESC
        LIMIT 30
    """).fetchall()
    if len(rows) < 3:
        return None
    ids = [str(r[0]) for r in rows]
    return Suggestion(
        id="loved_but_unplayed",
        name="Loved at Home, Never Played Out",
        kind="loved",
        description="High rekordbox playcount, almost never out at a gig.",
        content_ids=ids,
        rationale="You play these at home but rarely out.",
        # Promoted - "loved at home, never played out" is pure
        # discovery: rekordbox knows you spin them, your set history
        # doesn't. Perfect for the "things I've missed" surface.
        score=88.0,
    )


def _playlist_co_occurrence(conn: sqlite3.Connection, limit: int = 4,
                            min_playlists: int = 2,
                            exclude: Optional[set] = None) -> list[Suggestion]:
    """The biggest single editorial signal Rob has produced: tracks he
    manually grouped into the same rekordbox playlist. Surface the
    tightest co-occurrence pairs as ready-to-deploy mini-packs."""
    if not _has_table(conn, "playlist_tracks"):
        return []
    pairs = conn.execute("""
        SELECT pa.content_id AS a, pb.content_id AS b,
               COUNT(DISTINCT pa.playlist_id) AS shared
        FROM playlist_tracks pa
        JOIN playlist_tracks pb
          ON pa.playlist_id = pb.playlist_id
          AND pa.content_id < pb.content_id
        GROUP BY a, b
        HAVING shared >= ?
        ORDER BY shared DESC
        LIMIT 200
    """, (min_playlists,)).fetchall()
    if not pairs:
        return []
    excl = exclude or set()
    # Grow seeds into small co-playlist packs.
    adj: dict[str, dict[str, int]] = {}
    for a, b, n in pairs:
        if str(a) in excl or str(b) in excl:
            continue
        adj.setdefault(str(a), {})[str(b)] = int(n)
        adj.setdefault(str(b), {})[str(a)] = int(n)
    used: set[str] = set(excl)
    out: list[Suggestion] = []
    for a, b, _ in sorted(pairs, key=lambda r: -r[2]):
        a, b = str(a), str(b)
        if a in used or b in used or len(out) >= limit:
            continue
        pack = [a, b]
        used_set = {a, b}
        while len(pack) < 8:
            cands = set(adj.get(pack[0], {}).keys())
            for m in pack[1:]:
                cands &= set(adj.get(m, {}).keys())
            best, best_n = None, 0
            for c in cands - used_set - used:
                m = min(adj[c].get(x, 0) for x in pack)
                if m > best_n:
                    best, best_n = c, m
            if best is None or best_n < min_playlists:
                break
            pack.append(best)
            used_set.add(best)
        if len(pack) < 3:
            continue
        used.update(pack)
        titles = _titles_for(conn, pack[:3])
        out.append(Suggestion(
            id=f"playlist_co_{len(out) + 1}",
            name=f"You grouped these: {' + '.join(titles)}",
            kind="playlist_co",
            description=f"You placed these in {min_playlists}+ of the same rekordbox playlists.",
            content_ids=pack,
            rationale="You placed these into the same rekordbox playlists yourself - "
                      "the cleanest editorial signal you produce.",
            score=86.0,
        ))
    return out


def _neglected_playlist(conn: sqlite3.Connection,
                        cold_days: int = 60) -> Optional[Suggestion]:
    """A rekordbox playlist whose tracks haven't surfaced in Rob's recent
    sessions - candidate for revival or pruning."""
    if not _has_table(conn, "playlist_tracks"):
        return None
    cutoff = _iso_offset(-cold_days)
    rows = conn.execute("""
        SELECT p.playlist_id, p.name, p.track_count,
               (SELECT COUNT(*) FROM playlist_tracks pt
                JOIN appearances ap ON ap.content_id = pt.content_id
                JOIN sessions s ON s.session_id = ap.session_id
                WHERE pt.playlist_id = p.playlist_id
                  AND s.session_date >= ?) AS recent_plays
        FROM playlists p
        WHERE p.track_count >= 8
        ORDER BY recent_plays ASC, p.track_count DESC
        LIMIT 1
    """, (cutoff,)).fetchall()
    if not rows or rows[0][3] > 0:
        return None
    pid, name, _ct, _rp = rows[0]
    track_rows = conn.execute("""
        SELECT content_id FROM playlist_tracks
        WHERE playlist_id = ? ORDER BY track_no ASC
    """, (pid,)).fetchall()
    if len(track_rows) < 4:
        return None
    ids = [str(r[0]) for r in track_rows]
    return Suggestion(
        id=f"neglected_playlist_{pid}",
        name=f"Neglected playlist: {name}",
        kind="neglected_playlist",
        description=f"From \"{name}\" - nothing in here has played in {cold_days}+ days.",
        content_ids=ids,
        rationale="A rekordbox playlist you built yourself but haven't drawn from recently.",
        score=64.0,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _titles_for(conn: sqlite3.Connection, ids: Iterable[str]) -> list[str]:
    out: list[str] = []
    for cid in ids:
        row = conn.execute(
            "SELECT title FROM tracks WHERE content_id = ?", (cid,)
        ).fetchone()
        out.append(str(row[0]) if row and row[0] else "Unknown")
    return out


def _iso_offset(days: int) -> str:
    import datetime
    return (datetime.date.today() + datetime.timedelta(days=days)).isoformat()
