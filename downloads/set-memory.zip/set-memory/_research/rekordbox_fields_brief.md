# Rekordbox 6 / 7 master.db + .pdb / ANLZ field catalogue

Exhaustive field inventory for Set Memory ingest expansion, sourced from:
- pyrekordbox `masterdb/models.py` (SQLAlchemy schema), `masterdb/smartlist.py`, `anlz/tags.py`, `anlz/structs.py` (commit at HEAD, ~v0.4.4 + unreleased rename to `masterdb`)
- Deep-Symmetry `crate-digger` kaitai schema `rekordbox_pdb.ksy`, `rekordbox_anlz.ksy`
- Existing Set Memory `ingest.py` and `pdb_reader.py`

Definitions referenced by SQL type, default-nullness, and a "Set Memory uses?" column. Every recommendation is sized for "make playlist suggestions smarter," not for full mirror.

---

## 0. Currently ingested vs. ignored - one-line audit

Set Memory's current `tracks` table stores: `content_id, title, artist, bpm, key_camelot, energy, date_created, stock_date, file_path, hot_cue_count, memory_cue_count, in_library, dedup_key`. Everything else in djmd* is **dropped**, including the entire playlist tree, MyTags, Rating, Comment, PlayCount, auto-gain, related-tracks lists, beatgrid, and all ANLZ data.

---

## 1. djmdContent - the track table (the big miss)

`djmdContent` has 60+ columns. Set Memory uses 9. Highest-value unused fields:

| Column | SQL type | UI meaning | DJ use | Reliable? | Set Memory? | Priority |
|---|---|---|---|---|---|---|
| `Rating` | INTEGER (0-5) | 0-5 stars | Quality flag - "have I committed to this track?" Top distractor for suggestion ranking. | High (DJ-controlled) | NO | **HIGH** |
| `Commnt` | TEXT | Free-text Comment field | DJs encode genre/style tags, hot-cue plans, energy notes, "DROP-AT-32", subgenre, decade. Most tags hide here. | High (when used) | NO | **HIGH** |
| `DJPlayCount` | VARCHAR | Cumulative play counter from CDJ + Rekordbox | Direct "loved/used" signal; surface beats every other proxy. | High where syncing | NO | **HIGH** |
| `ColorID` -> `djmdColor.Commnt` | VARCHAR | User colour tag (Pink/Red/Orange/Yellow/Green/Aqua/Blue/Purple + name) | Rob's primary set-organisation system (genre, vibe, "tested live", energy class). | High (when used) | partial (only id) | **HIGH** |
| `MyTagIDs` via `djmdSongMyTag` | join | User-defined hierarchical tags | Rekordbox's only structured curation - explicit "Components/Situation/Genre/Mood" axes. | High (when used) | NO | **HIGH** |
| `GenreID` -> `djmdGenre.Name` | VARCHAR | Genre | Filter by adjacent genres for compatibility ranking. | Medium (often messy) | NO | **HIGH** |
| `LabelID` -> `djmdLabel.Name` | VARCHAR | Record label | Strong style proxy (Defected, Anjuna, Hessle Audio etc.); great affinity edge. | Medium | NO | **MED** |
| `RemixerID` -> `djmdArtist.Name` | VARCHAR | Remixer | Remix relationships ("Original vs. Joris Voorn rmx"). | Medium | NO | **MED** |
| `OrgArtistID` -> `djmdArtist.Name` | VARCHAR | Cover original artist | Cover/remake clustering. | Low | NO | LOW |
| `ComposerID` -> `djmdArtist.Name` | VARCHAR | Composer / producer | Smart-playlist uses this as "Producer". | Low-Med | NO | LOW |
| `Lyricist` | VARCHAR (FK to djmdArtist) | Lyricist | Rarely used in dance music. | Low | NO | SKIP |
| `Subtitle` | VARCHAR | Subtitle line on metadata | Sometimes carries "VIP / Dub / Inst". | Low-Med | NO | LOW |
| `ReleaseYear` | INTEGER | Year | Era affinity ("90s house only"). | Med | NO | **MED** |
| `ReleaseDate` | VARCHAR (date) | Full release date | Same as year, finer grain. | Med | NO | LOW |
| `Length` | INTEGER (seconds) | Track duration | Set-pacing math, "skip the 8-min ambient track in peak hour". | High | NO | **HIGH** |
| `BitRate` | INTEGER | kbps | Quality gate; mark <256k as "rip" | High | NO | LOW |
| `BitDepth` | INTEGER | 16/24 | Quality gate. | High | NO | SKIP |
| `SampleRate` | INTEGER (Hz) | 44100/48000/etc | Quality gate. | High | NO | SKIP |
| `FileType` | INTEGER (1=MP3, 4=M4A, 5=FLAC, 11=WAV, 12=AIFF) | Format | Filter "play FLAC/WAV only at the bigger gigs". | High | NO | LOW |
| `FileSize` | INTEGER (bytes) | File size | Crude quality + uniqueness flag. | High | NO | SKIP |
| `DiscNo`, `TrackNo` | INTEGER | Album disc / track no. | Album-order playback (rare in DJ context). | High | NO | SKIP |
| `Mix` | not a single column - `mix_name` lives in .pdb only OR is stored via `Subtitle`/Commnt in master.db | "Original Mix" / "Extended Mix" | Mix-version disambiguation. | Med | NO | MED |
| `ISRC` | VARCHAR | International Standard Recording Code | Hard dedup across collections + spotify/wikidata linkage. | Med (often null) | NO | **MED** (dedup) |
| `StockDate` | VARCHAR (yyyy-mm-dd) | "Stock" / inbox date | Already used. | High | YES | - |
| `DateCreated` | VARCHAR | Added-to-library timestamp | Already used. | High | YES | - |
| `DisableQuantize` | INTEGER (0/1) | Per-track quantise off | Signals "beatgrid is unreliable"; deprioritise as transition target. | High | NO | LOW |
| `Analysed` | INTEGER | Analysis status flag | If 0 -> no beatgrid, no waveform, hot cues incomplete. Gate auto-suggestions. | High | NO | **MED** |
| `HotCueAutoLoad` | VARCHAR ("ON"/"") | Auto-load hot cues toggle | Indicates Rob considered the cues finalised. | Med | NO | LOW |
| `MasterDBID`, `MasterSongID` | VARCHAR | Rekordbox cloud / master link IDs | Cross-device dedup; valuable for multi-USB merging. | Med | NO | **MED** |
| `AnalysisDataPath` | VARCHAR | Path to ANLZ DAT/EXT file on disk | Direct pointer if we ever ingest ANLZ. | High | NO | MED (gated on ANLZ work) |
| `SrcID/SrcTitle/SrcArtistName/SrcAlbumName/SrcLength` | VARCHAR/INT | Streaming-source metadata (Beatport/SoundCloud/TIDAL imports) | Differentiate own-files vs. streaming bait. | Low | NO | SKIP |
| `ImagePath` | VARCHAR | Artwork path | Not useful for suggestion. | High | NO | SKIP |
| `Tag` | VARCHAR | A legacy single-tag field (NOT MyTag) | Sometimes carries colour-tag pre-color-id. | Low | NO | SKIP |
| `ContentLink` | INTEGER | Cross-link to djmdContent | Tracks marked as "related"/"duplicate" by Rekordbox. | Low | NO | LOW |
| `CueUpdated`, `AnalysisUpdated`, `TrackInfoUpdated` | VARCHAR | Update timestamps | Cache invalidation only. | High | NO | SKIP |
| `Reserved1..4`, `ExtInfo` | TEXT | Reserved / extension | Skip. | - | NO | SKIP |

### djmdContent shape recommended for state.db (Phase 1 - HIGH only)

```sql
ALTER TABLE tracks ADD COLUMN rating              INTEGER;
ALTER TABLE tracks ADD COLUMN comment             TEXT;
ALTER TABLE tracks ADD COLUMN play_count          INTEGER;
ALTER TABLE tracks ADD COLUMN color_name          TEXT;       -- denormalised
ALTER TABLE tracks ADD COLUMN color_code          INTEGER;
ALTER TABLE tracks ADD COLUMN genre               TEXT;       -- denormalised
ALTER TABLE tracks ADD COLUMN label               TEXT;       -- denormalised  (priority bumped from MED if Rob tags heavily)
ALTER TABLE tracks ADD COLUMN remixer             TEXT;
ALTER TABLE tracks ADD COLUMN release_year        INTEGER;
ALTER TABLE tracks ADD COLUMN length_sec          INTEGER;
ALTER TABLE tracks ADD COLUMN isrc                TEXT;       -- dedup
ALTER TABLE tracks ADD COLUMN analysed            INTEGER;
ALTER TABLE tracks ADD COLUMN master_song_id      TEXT;
CREATE INDEX idx_tracks_isrc          ON tracks (isrc) WHERE isrc IS NOT NULL;
CREATE INDEX idx_tracks_master_song   ON tracks (master_song_id) WHERE master_song_id IS NOT NULL;
```

---

## 2. djmdCue - cue points (currently aggregated to counts only)

```
djmdCue (one row per cue point per track)
  ID, ContentID                FK -> djmdContent
  InMsec, InFrame, InMpegFrame, InMpegAbs    -- in time (msec is the useful one)
  OutMsec, OutFrame, OutMpegFrame, OutMpegAbs -- out time (for loops; -1 if not a loop)
  Kind                INTEGER  -- 0 = memory cue, 1..8 = hot cue A..H (DJM/CDJ buttons)
  Color               INTEGER  -- 0..7 from cue palette, -1 if none
  ColorTableIndex     INTEGER  -- newer palette (16+ slots) on rb6.6+
  ActiveLoop          INTEGER  -- 1 if loop is active on load
  Comment             VARCHAR  -- DJ-typed label: "INTRO", "DROP", "BREAK", "VOX", "BUILD"
  BeatLoopSize        INTEGER  -- beats (1,2,4,8,16,32) for beat-loop cues
  CueMicrosec         INTEGER  -- sub-ms precision for nxs2
  InPointSeekInfo, OutPointSeekInfo  -- compressed-format seek metadata
```

Currently Set Memory aggregates `Kind` to (hot_cue_count, memory_cue_count). Everything else is lost.

### What unlocking djmdCue enables for suggestions

- **Intro/outro length** (gap between InMsec=0 and first memory cue; track length minus last memory cue). Lets suggester pick tracks with intros >= 16 bars when the current track has a long outro.
- **Phrase-aware suggestions**: cues named "DROP"/"BREAK"/"BUILD" identify section transitions. Suggest tracks with a drop within a transition window matching the current track's outro length.
- **Loop-ready flag**: any cue with `OutMsec > 0` or `BeatLoopSize > 0` -> track can be looped at that point; surface "good loop tracks" for stretching sets.
- **Hot-cue count by colour**: Rob's colour palette likely encodes section type (e.g. green = drop, blue = vox). Distribution per-track is a fingerprint.
- **Cue density**: tracks with 6+ memory cues are "mapped" - Rob trusts them more.
- **ActiveLoop tracks**: tracks with a default-on loop are typically tools/loops/edits - prefer or deprefer based on slot.

### Schema migration (Phase 2)

```sql
CREATE TABLE track_cues (
  content_id    TEXT NOT NULL,
  cue_id        TEXT NOT NULL,
  kind          INTEGER NOT NULL,  -- 0=memory, 1..8=hot A..H
  in_msec       INTEGER NOT NULL,
  out_msec      INTEGER,           -- NULL or -1 if not a loop
  color         INTEGER,
  comment       TEXT,
  beat_loop     INTEGER,
  active_loop   INTEGER,
  PRIMARY KEY (content_id, cue_id)
);
CREATE INDEX idx_track_cues_content ON track_cues (content_id);

-- Derived rollup columns on tracks for fast filtering:
ALTER TABLE tracks ADD COLUMN intro_msec      INTEGER;  -- first memory cue
ALTER TABLE tracks ADD COLUMN outro_msec      INTEGER;  -- last memory cue
ALTER TABLE tracks ADD COLUMN has_loop_cue    INTEGER;
ALTER TABLE tracks ADD COLUMN cue_density     INTEGER;  -- count(memory cues) per minute
ALTER TABLE tracks ADD COLUMN drop_msec       INTEGER;  -- first cue with Comment matching ^DROP
```

Priority: **HIGH** for the rollup columns, **MED** for the full `track_cues` table. The rollups give 80% of the suggestion value at 5% of the join cost.

---

## 3. djmdBeatGrid / Beatgrid - NOT in master.db

Important finding: **beatgrid data is NOT stored in master.db**. The track's tempo is in `djmdContent.BPM` only. Per-beat grids live in ANLZ `.DAT/.EXT` files (PQTZ / PQT2 tags) referenced by `djmdContent.AnalysisDataPath`.

Implications:
- Variable-BPM tracks expose only their start-BPM in master.db. Set Memory thinks they're constant.
- Downbeat-aware transition planning (e.g. "current track ends on a downbeat at 6:42, suggest a track whose first downbeat is at the start") requires reading PQTZ from ANLZ.

Priority: **LOW** for now (ANLZ ingest is large surface area, only valuable for very advanced features). Defer until phrase-aware/PSSI work happens.

---

## 4. djmdMyTag + djmdSongMyTag - the structured-tag table (huge miss)

```
djmdMyTag
  ID, ParentID (self-FK -> djmdMyTag.ID, forms a tree)
  Seq                   -- ordering
  Name                  -- e.g. "Peak time", "Acid", "Tested live"
  Attribute             -- list type (0=tag, 1=folder/category)

djmdSongMyTag
  ID
  MyTagID  -> djmdMyTag.ID
  ContentID -> djmdContent.ID
  TrackNo (order)
```

Rekordbox ships with four built-in MyTag categories: **Genre, Components, Situation, Mood** (see Rekordbox 6 docs); users add their own. Tracks can carry any number of MyTags.

Pre-populated suggested tag values (per Pioneer docs, validated against fresh installs):
- **Genre**: Rock, Pop, Dance/Electro, Hip Hop, Jazz, Latin, Reggae, R&B, World, Other.
- **Components**: Vocal, Instrumental, Intro, Outro, Break, Melodic, Bass, Synth, Acapella.
- **Situation**: Warm-up, Build-up, Peak time, Cool-down, Closing, Festival, Club, Lounge, Bar, Wedding.
- **Mood**: Happy, Sad, Sexy, Aggressive, Chill, Dark, Bright, Energetic, Romantic, Dreamy.

These are NOT enforced; if Rob uses MyTags he likely has a custom list.

### Why this is gold for suggestion

MyTags are the only **structured, explicit DJ-authored categorical signal** in Rekordbox. Every other tag-like field is free text. They map directly to "what should come next" questions: "current = peak-time + dark + synth -> suggest peak-time + (dark | aggressive) + synth-or-bass".

### Schema migration (Phase 2)

```sql
CREATE TABLE mytag_categories (
  category_id   TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  parent_id     TEXT REFERENCES mytag_categories(category_id),
  seq           INTEGER
);
CREATE TABLE mytags (
  tag_id        TEXT PRIMARY KEY,
  category_id   TEXT REFERENCES mytag_categories(category_id),
  name          TEXT NOT NULL,
  seq           INTEGER
);
CREATE TABLE track_mytags (
  content_id    TEXT NOT NULL,
  tag_id        TEXT NOT NULL,
  PRIMARY KEY (content_id, tag_id)
);
CREATE INDEX idx_track_mytags_tag ON track_mytags (tag_id);
```

Priority: **HIGH** if Rob uses MyTags at all; trivial overhead.

---

## 5. djmdPlaylist + djmdSongPlaylist - manual playlists (the second-biggest miss)

```
djmdPlaylist
  ID, ParentID            -- tree of folders + playlists
  Name
  Seq, ImagePath
  Attribute               -- 0=playlist, 1=folder, 4=smart playlist
  SmartList               -- XML criteria text for smart playlists

djmdSongPlaylist
  ID
  PlaylistID -> djmdPlaylist.ID
  ContentID  -> djmdContent.ID
  TrackNo                 -- explicit user-set order within playlist
```

### Why this is enormous

Set Memory currently has only ONE training signal: history playlists (auto-recorded performances). Manual playlists are vastly larger, vastly cleaner, and represent Rob's **deliberate curation** at multiple granularities ("crate by genre", "crate by gig", "next gig shortlist", "warmup material"). Every playlist is a co-occurrence cluster the suggester can mine:

- **Co-playlist affinity**: "tracks Rob has put together in 3+ playlists" => strong suggestion edge.
- **Playlist-based filtering**: when current track sits in playlist "Sunday Closer Set", surface other tracks in that playlist before global suggestions.
- **Playlist-as-vibe-vector**: tag each playlist with its dominant features (avg BPM, key cluster, dominant MyTags), then "current track is in 'Deep+Dub' playlist -> suggest tracks from same playlist OR tracks in playlists with similar feature vectors".
- **Folder hierarchy**: parent folder context ("Tech house" parent -> all child playlists share genre).
- **Smart-list criteria**: parse `SmartList` XML (pyrekordbox already has the parser - `masterdb/smartlist.py`) to extract Rob's own rules ("BPM 122-126 AND MyTag contains Driving") and reuse the rules as suggestion templates.

Note: smart-playlist XML properties Rekordbox supports (per pyrekordbox): artist, album, albumArtist, originalArtist, bpm, grouping (=ColorID), comments, producer (=composer), stockDate, dateCreated, counter (=DJPlayCount), fileName, genre, key, label, mixName, myTag, rating, dateReleased, remixedBy, duration, name, year. Operators: equal, not-equal, greater, less, in-range, in-last, not-in-last, contains, not-contains, starts-with, ends-with.

### Schema migration (Phase 2)

```sql
CREATE TABLE playlists (
  playlist_id    TEXT PRIMARY KEY,
  parent_id      TEXT REFERENCES playlists(playlist_id),
  name           TEXT NOT NULL,
  attribute      INTEGER NOT NULL,  -- 0/1/4
  smartlist_xml  TEXT,              -- only for attribute=4
  seq            INTEGER,
  -- denormalised vibe vector (recomputed nightly):
  track_count    INTEGER,
  avg_bpm        REAL,
  dominant_key   TEXT,
  dominant_color INTEGER
);
CREATE TABLE playlist_tracks (
  playlist_id    TEXT NOT NULL,
  content_id     TEXT NOT NULL,
  track_no       INTEGER NOT NULL,
  PRIMARY KEY (playlist_id, content_id)
);
CREATE INDEX idx_playlist_tracks_content ON playlist_tracks (content_id);
```

Priority: **HIGH** - bigger lift than any single field-level change.

---

## 6. djmdMixerParam - auto-gain + peak

```
djmdMixerParam  (one row per content)
  ContentID
  GainHigh, GainLow            -- packed into a float, surfaced as .Gain in dB
  PeakHigh, PeakLow            -- packed into a float, surfaced as .Peak in dB
```

The packed encoding (16-bit high/low pair forming a 32-bit IEEE float for the gain factor, then 20*log10) is in `pyrekordbox/masterdb/models.py:_get_db()`. Rob's Earshot project already does this kind of math.

### Why this matters

- **Auto-gain** is Rekordbox's analysed loudness offset (the value of the gain knob in the Grid Edit panel). Two tracks with very different auto-gains will sound at completely different volumes when mixed. Suggester should match within a tolerance band (e.g. +/- 3 dB) to avoid jarring transitions.
- **Peak** is the peak amplitude. Combined with auto-gain it estimates crest factor / perceived loudness.

Priority: **MED** - real value for transition quality scoring, but only matters if Rob doesn't gain-stage manually at the mixer.

### Schema

```sql
ALTER TABLE tracks ADD COLUMN auto_gain_db  REAL;
ALTER TABLE tracks ADD COLUMN peak_db       REAL;
```

---

## 7. djmdRelatedTracks + djmdSongRelatedTracks - "intelligent playlists" v2

```
djmdRelatedTracks
  ID, ParentID, Name, Seq, Attribute
  Criteria             -- XML rule similar to SmartList

djmdSongRelatedTracks
  RelatedTracksID, ContentID, TrackNo
```

Rekordbox 6.5+ feature: "Related Tracks" lists are pre-built groupings (e.g. "Same BPM +/- 2", "Same key", "Same artist") that Rekordbox computes per track. Rob may have custom Related Tracks defined. The `Criteria` XML uses the same schema as `SmartList`.

Priority: **LOW** - useful as a sanity baseline ("does my suggester agree with Rekordbox's Related Tracks?") but not a primary input.

---

## 8. djmdHotCueBanklist + DjmdSongHotCueBanklist + HotCueBanklistCue

Hot-Cue Banks are user-defined banks of cue points stored *separately* from the track they were captured on. Modern feature; rarely used by most DJs. Each bank can have up to 8 cues per track.

Priority: **SKIP** unless Rob uses them.

---

## 9. djmdSampler + djmdSongSampler

Sampler bank assignments (for the DJM/CDJ sampler decks). Each entry is a sample slot.

Priority: **SKIP** for suggestions.

---

## 10. djmdHistory + djmdSongHistory - already used

Currently the only input. One extra column worth grabbing:

| Column | type | use |
|---|---|---|
| `djmdHistory.Attribute` | INTEGER | Distinguishes "performance" vs. "playlist export". Use to filter junk. |
| `djmdHistory.ParentID` | VARCHAR | History folders (you can group sessions by night/gig in rb). Adds gig grouping. |

Priority: **MED** - small improvement to session filtering.

---

## 11. djmdSongTagList - the static "Tag List" (the cart on the right of Rekordbox)

```
djmdSongTagList
  ContentID, TrackNo
```

This is the in-app "Tag List" queue (drag-here-to-prepare). Snapshot only - it's a working buffer, not a curated label. If Rob keeps shortlists here mid-session it's a real-time intent signal.

Priority: **LOW**.

---

## 12. djmdActiveCensor + ContentActiveCensor - radio-edit / mute markers

```
djmdActiveCensor
  ContentID
  InMsec, OutMsec        -- mute region
  Info                   -- censor type/mode
  ParameterList          -- censor params
```

These are explicit mute zones (the rekordbox "Active Censor" feature - mutes profanity for radio-safe play). Useful as a "track is radio-edit-marked" flag if Rob does radio. Otherwise skip.

Priority: **SKIP**.

---

## 13. ContentCue / ContentFile - serialised blobs

`ContentCue.Cues` and `HotCueBanklistCue.Cues` are big serialised TEXT blobs duplicating djmdCue. Don't ingest - use `djmdCue` rows.

`ContentFile` carries file hash + size + sync state. `Hash` is useful as **the** dedup key across drives:

| Column | use |
|---|---|
| `Hash` | exact-file-content dedup across USBs (better than title+artist) |
| `Size` | dedup tiebreaker |

Priority: **HIGH** for `Hash` if it's reliably populated. Adds a third dedup tier: ISRC > Hash > title+artist.

```sql
ALTER TABLE tracks ADD COLUMN file_hash TEXT;
CREATE INDEX idx_tracks_file_hash ON tracks (file_hash) WHERE file_hash IS NOT NULL;
```

---

## 14. ANLZ files (`.DAT` / `.EXT` / `.2EX` on USB, plus on desktop next to source files)

Per `pyrekordbox/anlz/tags.py` the tag inventory is:

| Tag | Type | File | Content | Suggestion-value |
|---|---|---|---|---|
| PQTZ | beat_grid | DAT | per-beat: beat-in-bar (1..4), tempo (cBPM), time (ms) | downbeat-aware transitions, variable-BPM detection |
| PQT2 | beat_grid2 | EXT | nxs2 extended grid | as above |
| PCOB | cue_list | DAT | classic cue list (DJ-set cues only, 3 hot + memory) | redundant with djmdCue |
| PCO2 | cue_list2 | EXT | nxs2 extended cue list (8 hot + memory + colors) | redundant with djmdCue (mostly) |
| PPTH | path | DAT | source-file path | dedup, useful when scanning USBs without master.db |
| PVBR | vbr | DAT | VBR seek-time index | not for suggestions |
| **PSSI** | **structure / phrase tags** | **EXT** | song structure: mood, end_beat, bank, list of structure entries (each = beat + kind: intro/verse/chorus/breakdown/etc.) | **phrase-aware transitions - rekordbox 6.5+ flagship feature** |
| PWAV | wf_preview | DAT | small monochrome waveform | not for suggestions |
| PWV2 | wf_tiny_preview | DAT | tiny waveform (browser thumbnail) | not for suggestions |
| PWV3 | wf_detail | EXT | high-res monochrome waveform | not for suggestions |
| PWV4 | wf_color | EXT | low-res colour waveform (RGB+luma) | could estimate energy/density per section |
| PWV5 | wf_color_detail | EXT | high-res colour waveform | as above |
| PWV6/PWV7/PWVC | newer 2EX waveform variants | 2EX | rb7 ultra-detailed | as above |

### PSSI (song structure / phrase tags) deserves special call-out

PSSI is Pioneer's "Phrase Analysis". Each track gets a `mood` (1=High, 2=Mid, 3=Low) and a list of phrases each labelled INTRO / VERSE / BRIDGE / CHORUS / OUTRO / BREAKDOWN / etc. with beat positions. This is the closest thing to ML-derived structure data in the entire Pioneer stack. The PSSI tag is obfuscated (XOR mask, deobfuscation logic in pyrekordbox 0.4.4+; older versions return garbled PSSI).

### Suggestion value of PSSI

Lets you build a real phrase-aware transitioner: "current track is in 'outro' phrase at 6:30 -> suggest a track whose 'intro' phrase matches that mood and aligns at the start". Plus "tracks tagged mood=high" is a cleaner energy signal than a manual EnergyLevel comment.

### Ingest recommendation

Priority: **MED** (PSSI mood + structure summary), **LOW** (everything else in ANLZ). Defer PSSI to a Phase 3; needs binary parser and large per-track payloads. Persist only:

```sql
ALTER TABLE tracks ADD COLUMN phrase_mood        INTEGER;  -- 1=high, 2=mid, 3=low
ALTER TABLE tracks ADD COLUMN phrase_end_beat    INTEGER;
ALTER TABLE tracks ADD COLUMN intro_phrase_beats INTEGER;  -- length of first intro phrase
ALTER TABLE tracks ADD COLUMN outro_phrase_beats INTEGER;
ALTER TABLE tracks ADD COLUMN phrase_count       INTEGER;
```

Full per-phrase table is overkill for now.

---

## 15. .pdb (CDJ export DeviceSQL) field comparison

`.pdb` is the read-only DeviceSQL export the CDJ actually reads. It's a subset of master.db with different field names, plus a few CDJ-only fields. From `crate-digger/src/main/kaitai/rekordbox_pdb.ksy`:

### track_row (`.pdb`) carries:

`subtype, index_shift, bitmask, sample_rate, composer_id, file_size, artwork_id, key_id, original_artist_id, label_id, remixer_id, bitrate, track_number, tempo (cBPM), genre_id, album_id, artist_id, id, disc_number, play_count, year, sample_depth, duration, color_id, rating, ofs_strings[21]`

Plus 21 inline strings: `isrc, texter, unknown_string_2..4, message, kuvo_public, autoload_hot_cues, unknown_string_5..6, date_added, release_date, mix_name, unknown_string_7, analyze_path, analyze_date, comment, title, unknown_string_8, filename, file_path`.

### `.pdb` vs master.db delta - what's on the USB that desktop doesn't have

- `play_count` is a **u4 integer here** vs. `DJPlayCount` is VARCHAR in master.db - the USB version is more reliable for arithmetic.
- `mix_name` exists as a first-class string (master.db hides it in subtitle/comment).
- `kuvo_public`, `autoload_hot_cues` as strings ("ON"/"") (master.db has them too as VARCHAR).
- `analyze_path` + `analyze_date` direct.

### What master.db has that `.pdb` doesn't

- MyTags (entirely - tag categories live in `exportExt.pdb` but the lists Rob built do not survive export).
- SmartList criteria.
- All `rb_*` sync metadata.
- ContentLink/RelatedTracks.
- MixerParams (auto-gain/peak).
- Most history beyond what the player wrote during this gig.

### `.pdb` playlist + history rows

- `playlist_tree_row`: parent_id, sort_order, id, raw_is_folder, name
- `playlist_entry_row`: entry_index, track_id, playlist_id
- `history_playlist_row`: id, name (no date - already noted in pdb_reader)
- `history_entry_row`: track_id, playlist_id, entry_index

`.pdb` carries the **manual playlist tree** that was exported to the USB. Set Memory's pdb_reader currently only reads history rows; **adding playlist rows would let us mine playlists from USBs we never see master.db for**.

### `exportExt.pdb` - the extension file

`tag_row` (MyTags) and `tag_track_row` are **exportExt-only**. So MyTag ingest from USB requires reading `exportExt.pdb`, not the main `export.pdb`.

Priority: **HIGH** for adding playlist rows + tag rows to pdb_reader.

---

## 16. Pre-populated subgenre / mood / situation values

Rekordbox does NOT ship a master subgenre vocabulary. The only pre-populated lists are:
- the four MyTag categories listed above (Genre/Components/Situation/Mood with ~10 suggested values each),
- the colour palette (8 named colours: Pink/Red/Orange/Yellow/Green/Aqua/Blue/Purple, plus 2 newer slots in rb6.6+ via `ColorTableIndex`).

Everything else (genre, label, comment vocabulary) is user-entered or imported from file tags / Beatport.

---

## 17. Recommended ingest phases

### Phase 1 - cheap wins on djmdContent (HIGH priority)
Columns: `Rating, Commnt, DJPlayCount, ColorID->name+code, GenreID->name, LabelID->name, RemixerID->name, ReleaseYear, Length, ISRC, Analysed, MasterSongID`.
Plus rollups from djmdCue: `intro_msec, outro_msec, has_loop_cue, cue_density, drop_msec`.
Plus `ContentFile.Hash`.

Effort: one SQL widening pass + extended SELECT in `read_content()`. ~1 day. Unlocks: better dedup (ISRC + Hash), Rating-based ranking, Comment regex parsing, colour-class filters, length-based pacing, played-count weighting.

### Phase 2 - relational signals (HIGH priority)
- **Manual playlists** (`djmdPlaylist` + `djmdSongPlaylist`) -> co-playlist affinity table.
- **MyTags** (`djmdMyTag` + `djmdSongMyTag`) -> structured-tag overlay.

Effort: three new tables + relationships, plus suggester refactor to use co-playlist count as primary edge. ~2-3 days. Biggest single suggestion-quality lift on the list.

### Phase 3 - mixing-quality signals (MED priority)
- `djmdMixerParam` -> auto-gain/peak.
- Full `djmdCue` rows (not just rollups) for phrase-aware transitions.

### Phase 4 - ANLZ for phrase awareness (MED priority)
- PSSI tag parser (pyrekordbox.anlz already does it).
- Per-track `phrase_mood`, intro/outro phrase length.

### Phase 5 - advanced (LOW priority)
- PQTZ beatgrid for variable-BPM tracks.
- Related Tracks criteria.
- Hot Cue Banklists.

### Phase 6 - pdb_reader extensions (HIGH priority)
- Add `playlist_tree_row` + `playlist_entry_row` to `pdb_reader.py`. Mines manual playlists from USB-only sources.
- Add `tag_row` + `tag_track_row` from `exportExt.pdb` (separate file).

---

## 18. pyrekordbox version pinning

Pin to `pyrekordbox >= 0.4.4` (current latest tagged) for these specific reasons:

| Version | Brings |
|---|---|
| 0.3.x | base `Rekordbox6Database` handler, SmartList parser. Sufficient for current Set Memory. |
| 0.4.0 (Feb 2025) | **Rekordbox 7 support** (essential if Rob upgrades); pre-built sqlcipher wheels (no compile gymnastics); track-creation API; smartlist MyTag bitshift fix. |
| 0.4.1 (Apr 2025) | timezone correctness on date columns. |
| 0.4.3 (May 2025) | full type hints; deletion safety on playlist-songs. |
| **0.4.4** (Aug 2025) | **PSSI deobfuscation improvements** (essential for any phrase work); robust DB key handling without the deprecated `download_key` CLI; `appdata` cleanup. |
| Unreleased (post-0.4.4) | Package renamed `db6` -> `masterdb`; class renamed `Rekordbox6Database` -> `MasterDatabase`. `Device Library Plus` support (the new export DB format - relevant if Rob's CDJs use it). |

**Recommendation: pin `pyrekordbox==0.4.4`** (or `~=0.4.4`) for stability. Avoid the unreleased rename until it tags - the `db6` package still works in 0.4.4 and matches Set Memory's existing imports. Plan a follow-up bump to the `masterdb` package once 0.5.0 ships.

If Rob's collection ever moves to **Device Library Plus** format (the new export format for upcoming CDJs / Opus Quad), the `devicelib_plus` module in unreleased will be needed.

---

## 19. Suggestion ideas unlocked by each field (cheat-sheet)

| Unlocked field | New suggestion type |
|---|---|
| Rating | "5-star untouched in 90 days" |
| Commnt regex | parse Rob's shorthand ("BUILD-AT-16", "DROP", "STEM") into structured flags |
| DJPlayCount | "played in studio 5+ times but never live" / "live-only crowdpleasers" |
| Color | per-colour pacing rules ("blue=closer, never in warm-up") |
| MyTag | "next track in same Situation but different Mood" |
| Genre | adjacency graph (House <-> Tech House <-> Minimal); never jump >2 hops mid-set |
| Label | label-set runs ("Drumcode block") |
| Remixer | "Joris Voorn run" |
| ReleaseYear | era-locked sets / 90s-only / decade pacing |
| Length | "next track length matches outro length of current" |
| ISRC + Hash | hard cross-USB dedup |
| Intro/outro msec | bar-length-matched transition windows |
| Cue density / drop_msec | structure-matched suggestions |
| Manual playlist co-occurrence | the single biggest improvement available |
| MyTag vector | similarity-based ranking |
| Auto-gain dB | only suggest tracks within +/- 3 dB |
| PSSI mood + phrase len | phrase-aware sequencer (Phase 4 dream) |
| .pdb playlist tree | usable USB-only suggestion paths |

---

## 20. Source files reviewed (absolute paths)

- `/tmp/pyrekordbox/pyrekordbox/masterdb/models.py` (1643 lines, every table + column)
- `/tmp/pyrekordbox/pyrekordbox/masterdb/smartlist.py` (372 lines, smart-playlist XML parser)
- `/tmp/pyrekordbox/pyrekordbox/anlz/tags.py` (538 lines, ANLZ tag handlers)
- `/tmp/pyrekordbox/pyrekordbox/anlz/structs.py` (297 lines, PSSI struct + others)
- `/tmp/pyrekordbox/CHANGELOG.md` (version diffs)
- `/tmp/crate-digger/src/main/kaitai/rekordbox_pdb.ksy` (.pdb DeviceSQL schema)
- `/tmp/crate-digger/src/main/kaitai/rekordbox_anlz.ksy` (.dat/.ext binary schema)
- `/Users/robrussell/Downloads/set-memory/ingest.py` (current ingest SQL surface)
- `/Users/robrussell/Downloads/set-memory/pdb_reader.py` (current .pdb scope)
