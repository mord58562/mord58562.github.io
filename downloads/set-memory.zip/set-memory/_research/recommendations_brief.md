# Set Memory - Playlist Suggestion Research Brief

Date: 2026-06-01
Scope: net-new playlist suggestion ideas, signals, and algorithms for Set Memory beyond the existing six (forgotten favourites, recently added unplayed, co-occurrence cliques, seed + companions, Camelot key chain, BPM ramp).

State.db fields available, per the live schema and codebase:
- `tracks`: content_id, title, artist, bpm, key_camelot, energy, date_created, stock_date, added_at, first_seen_session, last_seen_session, total_appearances, in_library, hot_cue_count, memory_cue_count, file_path, dedup_key
- `sessions`: session_id, session_date, fingerprint, source_db_path, track_count
- `appearances`: session_id, content_id, track_no, title, artist (the ordered per-session list - this is the gold-mine that the current algorithms barely touch)
- `usb_drives`: per-USB metadata
- `track_aliases`: cross-USB dedup
- `dismissed_suggestions`: user-feedback signal

Existing-six gaps the catalogue below targets:
1. The current algorithms ignore `track_no` (track position within a session) entirely - no a-to-b transition mining, no opener/closer/peak classification.
2. Recency is binary ("cold > 90d") rather than a continuous decay.
3. No use of `energy`, `hot_cue_count`, `memory_cue_count` as ranking signals beyond the prep pack.
4. No session-level similarity, only track-pair co-occurrence.
5. No time-of-year, time-of-week, or temporal-cycle awareness.
6. No diversity / serendipity counterweight - everything is "most played in band X".
7. Cliques are global and timeless; cold clusters can't surface separately from hot ones.

The catalogue below lists 38 net-new avenues, each with: what it is, signals consumed, why a working DJ cares, implementation sketch, impact, cost, and caveats. Avenues are grouped by family; within each family, ordered roughly by expected impact.

References used for the broader DJ-craft framing are listed at the foot.

---

## Family A: Session-sequence mining (uses `appearances.track_no` - currently untouched)

### A1. Real-transition Markov chain ("what you actually played after X")

What: For every ordered pair (a, b) where Rob actually played b immediately after a in any historical session, count occurrences. Use the resulting transition matrix to answer "given track X is loaded, what's the next track Rob has historically reached for?" Surface as a per-seed suggestion: pick a high-play seed, walk the chain 12-18 steps greedily (or sample top-k weighted by transition count to add controlled randomness).

Signals: `appearances.track_no` (ordering, currently ignored), `session_id` (boundary).

Why useful: cliques tell you what plays together; transitions tell you what plays *after* what. DJs build muscle-memory transition pairs ("track A always rolls into track B"). Resurfacing those exact pairs is the single most-actionable session output - the suggested playlist is half a setlist already.

Sketch:
```
WITH ordered AS (
  SELECT session_id, content_id, track_no,
         LEAD(content_id) OVER (PARTITION BY session_id ORDER BY track_no) AS next_cid
  FROM appearances
)
SELECT content_id AS a, next_cid AS b, COUNT(*) AS n
FROM ordered WHERE next_cid IS NOT NULL
GROUP BY a, b HAVING n >= 2;
```
Walk: greedy `argmax_b P(b|a)` with already-used filter; stop at 16 tracks or when no successor with `n >= 2` exists.

Impact: HIGH. Cost: SMALL. Caveats: pure greedy will degenerate into Rob's most-frequent 2-track loop; add a "no-repeat within 30 tracks" filter and back off to second-best when chain stalls. Order-1 Markov is the documented baseline in session-based recommendation; FPMC and higher orders are the next step (see A2).

### A2. Higher-order transition mining (bigram and trigram windows)

What: Extend A1 to "given the last two tracks were (a, b), what came next?" Use trigram counts when supported by data (n >= 2), back off to bigram (A1), back off to unigram (overall popularity).

Signals: same as A1 but with two-step lookback.

Why: order-1 Markov captures pair habits, but DJs often play three-track motifs (intro -> peak -> exit). Trigram capture is exactly the Factorized Personalized Markov Chain idea adapted to a single-user setting.

Sketch: `LEAD(content_id, 1)` and `LEAD(content_id, 2)` partitioned by session, group by (a, b, c). Stupid-backoff at query time when trigram count is below threshold.

Impact: MEDIUM-HIGH. Cost: SMALL. Caveats: trigram data sparsity is real for a personal library; backoff to A1 is essential. Validation: hold out a recent session, predict its sequence from prior sessions only, measure hit-rate at k=5.

### A3. Opener / closer / bridge / peak classifier by typical track-position

What: For every track with >=3 plays, compute its average normalised position in the session (track_no / track_count). Classify into bands: opener (mean <= 0.15), early (0.15-0.35), peak (0.35-0.65), late (0.65-0.85), closer (>= 0.85). Surface four packs: "Your Openers", "Your Peak-time Anchors", "Your Closers", "Your Bridges" (high-variance position tracks that float around).

Signals: `track_no`, `sessions.track_count`, `total_appearances`.

Why: openers and closers are role-defined slots most DJs cycle a small stable of tracks through. Surfacing the stable as a pack makes the next gig's first and last picks trivial. Dubspot's "narrative arc" article frames the entire set as opener -> build -> peak -> closer; this lets the tool think in those slots.

Sketch:
```
SELECT content_id,
       AVG(CAST(track_no AS REAL) / NULLIF(s.track_count, 0)) AS mean_pos,
       COUNT(*) AS n
FROM appearances a JOIN sessions s USING (session_id)
GROUP BY content_id HAVING n >= 3;
```
Then bucket by mean_pos and rank within bucket by n.

Impact: HIGH. Cost: SMALL. Caveats: a track that closes one set and opens another averages out to "peak"; consider also stdev and surface bimodal tracks as "bridges/utility".

### A4. Pair-as-bridge detection

What: Find tracks that frequently appear between two otherwise-disconnected cliques. Formally: for each track t, compute the betweenness centrality on the co-session graph, restricted to tracks t bridges. Surface a "Bridge Tracks" pack and, for each, the two clusters they bridge.

Signals: `appearances` (co-session graph), derived clique membership.

Why: bridge tracks are gold for genre-pivots. The track that lets you walk from disco edits to house, or from melodic to peak techno, is what makes a set feel curated. Hand-finding them is exhausting; computing betweenness centrality on a few-hundred-node graph is trivial.

Sketch: build the co-session adjacency (already done for cliques), run `networkx.betweenness_centrality` or implement the simple Brandes algorithm. Threshold the top 5 percent.

Impact: HIGH. Cost: MEDIUM (depends on whether networkx is acceptable; Brandes in pure Python on a few-hundred-node graph is sub-second). Caveats: small graphs make betweenness noisy; require min-degree >= 4 to qualify.

### A5. Streak detection (played in N consecutive sessions then dropped)

What: For each track, find its longest run of consecutive sessions where it appeared, plus the gap that followed. Surface "Stopped a Streak" - tracks with a >=4-session streak that haven't been played since, with the streak end dated.

Signals: `appearances.session_id`, `sessions.session_date` ordered.

Why: a 4-set run almost always means the track is in heavy rotation in Rob's head. The drop-off is usually accidental (lost the USB folder, new music distracted) rather than intentional. Surfacing these is psychologically distinct from "forgotten favourites" because the user *just* stopped, and the prompt is "did you mean to?".

Sketch: window function over `(content_id, session_date ORDER BY session_date)` to compute gap groups; aggregate streak length and trailing-gap days.

Impact: MEDIUM. Cost: SMALL. Caveats: false positives when Rob played a one-off genre night that conflicted with a streak; weight by streak-length over total-appearances.

### A6. Comeback-window detection

What: Among tracks with multiple "rest periods" between play clusters, find ones whose rest periods are roughly periodic (e.g. always 3-6 months between revivals). Predict the next revival window and surface those tracks when the window opens.

Signals: `appearances.session_date` per track, derived inter-cluster gaps.

Why: many DJs have unconscious seasonal cycles. A summer-only opener, a winter ambient closer. The tool spotting this and reminding Rob in the right month is "just-work" magic he wouldn't ask for explicitly.

Sketch: cluster a track's session_dates with a 30-day max-gap; if it has >=3 clusters and gap-stdev/gap-mean < 0.3, mark as periodic; if `(today - last_cluster_end)` is within ±20% of mean gap, surface.

Impact: MEDIUM. Cost: MEDIUM. Caveats: small N; require >=3 cycles and consider showing the historical pattern in the rationale.

---

## Family B: Set similarity and session-based retrieval

### B1. "Sets like this one" - session-similarity over track sets

What: Represent each session as a set of content_ids (or a TF-IDF-weighted vector where rarer tracks weigh more). Compute Jaccard or cosine similarity between sessions. Pick a recent or favourite session, return the N most-similar past sessions, and recommend tracks present in those but missing from the seed.

Signals: `appearances.content_id` grouped by `session_id`.

Why: this is the DJ-tool answer to "discover weekly". Spotify's collaborative filter works because users-who-liked-X-also-liked-Y; the within-DJ analogue is sessions-that-shared-X-also-contained-Y. Pampalk-style TF-IDF over tracks gives rare-track-heavy similarity which is exactly the discrimination you want (everyone's heard the anthems; the deep cuts are the signal).

Sketch:
```
-- TF-IDF: idf = log(total_sessions / sessions_containing_track)
-- similarity = cosine of tf-idf vectors between session pairs
```
Or, simpler v1: Jaccard `|A∩B| / |A∪B|` over content_id sets.

Impact: HIGH. Cost: MEDIUM. Caveats: cold-start for one-off sessions; require seed-session track_count >= 12. Suggestion presents both the similar past session reference (transparency) and the recommended diff tracks.

### B2. Session-embedding clustering (set-of-the-day reconstruction)

What: Group all historical sessions into K vibe clusters (K-means on TF-IDF session vectors, or simple agglomerative on Jaccard). Each cluster is a "type of night Rob plays". When Rob asks for tonight's suggestion, pick a cluster and build a representative set by sampling the cluster's most-frequent tracks weighted by their typical position (A3) so the result has an arc.

Signals: session TF-IDF vectors from B1, A3 position bands.

Why: instead of one giant library, the tool says "here are your six recurring set-types; want a fresh one in mode 3?". Mode-typing is how human DJs already think (warm-up Thursday vs. peak-time Friday).

Sketch: vectorize sessions, cluster, store cluster_id per session in a new table. Per cluster, compute top tracks by appearance + their A3 position. To "reconstruct": draw an opener from cluster's openers, three peak-tracks from cluster's peaks, etc., assembled into an arc.

Impact: HIGH. Cost: MEDIUM-LARGE. Caveats: requires enough sessions for meaningful clusters (probably 40+); use elbow method or fix K=5-7 by hand.

### B3. Around-this-gig (anchor on one specific past session)

What: User picks a past session ("that good Saturday in March"). Tool returns: (a) tracks from that session not played since, (b) tracks from the most-similar 3 sessions, (c) the actual order with one or two suggested swaps based on A1 transition data.

Signals: one anchor session_id + B1 similarity + A1 transitions.

Why: most DJs have a small list of "good sets" they'd love to half-recreate. This is the recreate-and-iterate workflow.

Sketch: pick anchor session, compute B1 similarity to others, union top-3 similar sessions' tracks, exclude tracks last played within 30 days (freshness), surface as ordered playlist.

Impact: MEDIUM-HIGH. Cost: SMALL (composes B1). Caveats: needs a session-picker UI; in v1 surface for the top-5 highest-track-count sessions automatically.

### B4. Suggested-by-omission (frequent mate of frequent mate, not yet co-played)

What: Two-hop walk on the co-session graph: for each top-N track t Rob plays often, find t's frequent companions, then for each companion find ITS frequent companions, exclude tracks Rob has already played with t directly. The output is "you play these two clusters separately; here are the bridge candidates".

Signals: `appearances` co-occurrence graph.

Why: classic collaborative-filtering "people who liked X liked Y, you have X but not Y". Within a personal library this surfaces the un-tried combinations.

Sketch: two SQL JOINs on `appearances` self-joined. Score by `freq(t,m1) * freq(m1,m2) - freq(t,m2)`. Top 30 per seed.

Impact: MEDIUM-HIGH. Cost: SMALL. Caveats: quadratic in worst case; cap intermediate node count.

---

## Family C: Energy and arc-construction

### C1. Energy-curve session arc (target shape)

What: Mine each historical session for its `(track_no, energy)` curve. Fit a coarse 4-band shape (low/mid-low/mid-high/high) per position quartile. Provide preset target curves ("Warm-up", "Peak-time", "Festival", "Sunset closer") matching documented DJ arcs (DJ Tech Tools, Dubspot narrative arc). To generate: walk target shape, pick best-fitting track per position bucket from library where energy, BPM, and key all fit.

Signals: `energy` (the existing colour/energy field), `bpm`, `key_camelot`, `track_no`, `sessions.track_count`.

Why: the current `_bpm_ramp` is a fixed array of BPMs. C1 is the same idea but multidimensional and tied to actual published arc shapes. The Mixed In Key documentation explicitly describes a curve from Level 5 -> 6 -> 7 -> 9 over the course of a club set; this generalises that.

Sketch: for each preset shape, iterate positions, query `tracks WHERE energy BETWEEN ? AND ? AND bpm BETWEEN ? AND ? ORDER BY total_appearances DESC LIMIT 5`, dedupe, return 18-24 tracks.

Impact: HIGH. Cost: SMALL-MEDIUM. Caveats: energy column needs to be populated (Rob uses MIK which writes it); document the fallback when energy is NULL (use BPM-only ramp).

### C2. Per-cluster energy trajectory mining

What: Combine B2 (session clusters) with energy curves. Per cluster, learn the mean energy-by-position curve. When reconstructing in that cluster's style, the arc is data-derived not preset.

Signals: cluster_id, energy, track_no.

Why: Rob's "Saturday peak" arc and "Sunday afternoon" arc are different shapes; one-size-fits-all presets miss this.

Sketch: aggregate `AVG(energy) GROUP BY cluster_id, position_quintile`; use as target shape for generation.

Impact: MEDIUM-HIGH. Cost: MEDIUM. Caveats: requires B2 first.

### C3. Crowd-tested anchor identification

What: A track is a "tested peak anchor" if it appears in the top-energy quartile of >=3 sessions whose overall energy curve was high (so it survived peak-time pressure). Surface separately from generic high-play tracks.

Signals: per-session energy stats, per-track energy-quartile-position membership.

Why: a track played heavily in warm-up isn't a peak track; a track that's been deployed at peak across multiple high-energy sets is a verified weapon.

Sketch: compute session "peakness score" (mean energy of top-quartile tracks). For each track-session appearance, mark if it was in that session's top quartile AND the session's peakness > some threshold. Count per-track; rank.

Impact: MEDIUM. Cost: SMALL. Caveats: small-N noisy; require >= 3 verifications.

### C4. Break and breakdown placement (low-energy interludes mining)

What: Mine sessions for tracks Rob plays as deliberate energy drops mid-set (track whose energy is >=2 levels below the surrounding 4 tracks' average). Surface those as "Interlude / Breather" pack.

Signals: `track_no`, `energy`.

Why: pacing is the differentiator between competent and good. Knowing your library's deliberate breather tracks is critical for not gassing the floor.

Sketch: window function: for each appearance, compute mean energy of ±2 surrounding tracks in same session; flag tracks consistently >=2 below.

Impact: MEDIUM. Cost: SMALL. Caveats: requires energy field; ignore sessions with <8 tracks.

### C5. Double-time / half-time crossover packs

What: Pair tracks where BPM(a) ≈ 2 × BPM(b) (within 2%) AND they share Camelot key. This unlocks the documented half-time double-time transition trick (e.g. 70 BPM hip-hop into 140 BPM bass).

Signals: `bpm`, `key_camelot`.

Why: legitimate DJ technique with documented transitions; lets Rob bridge BPM zones (70->140, 80->160, 90->180). Useful when warm-up is downtempo and peak is fast.

Sketch:
```
SELECT a.content_id, b.content_id
FROM tracks a JOIN tracks b
  ON ABS(a.bpm * 2 - b.bpm) <= 0.04 * b.bpm
  AND a.key_camelot = b.key_camelot
WHERE a.in_library AND b.in_library;
```
Surface as paired transitions, not a single playlist.

Impact: MEDIUM. Cost: SMALL. Caveats: half-time relationships are intentional; show only when both tracks have >=1 play (filter out noise pairs).

---

## Family D: Mix-compatibility refinements (beyond ±1 hour Camelot)

### D1. Full Camelot move catalogue per chain

What: Extend `_camelot_compatible` from {same, +1, -1, swap A/B} to include: +2 hour (energy boost, common technique per Mixed In Key docs), +7 hour ("perfect fifth"), -7 hour ("perfect fourth"), +3/-3 hour (mood shift). Each chain variant uses one move-set as constraint; surface them as named packs ("Energy Boost Chain", "Fifth-Walk Chain").

Signals: `key_camelot`.

Why: the current ±1 chain is "safe harmonic mixing"; advanced DJs use the entire wheel deliberately. Documented techniques (ZIPDJ, Mixed In Key wiki) name specific moves with specific effects.

Sketch: parameterise `_camelot_compatible(key, move_set)` where move_set is a list of (delta, swap) tuples. Generate 5 named chain variants.

Impact: MEDIUM. Cost: SMALL. Caveats: don't surface +7 chains without explaining; rationale must name the move.

### D2. Modal mixture and relative major/minor walks

What: Restrict chain to ONLY relative major/minor swaps (A<->B at same number) for the "feel shift" pack - alternating mood without changing tonal centre.

Signals: `key_camelot`.

Why: pure A<->B walks produce subtle emotional pivots that pure-pitch walks don't. Useful for melodic techno / progressive house.

Sketch: variant of D1 with move-set = [(0, swap)].

Impact: LOW-MEDIUM. Cost: TINY. Caveats: data-sparse for many keys.

### D3. Compatibility-optimal reordering of a manual playlist

What: Given a manual rekordbox playlist (or any user-selected track list), compute an optimised order that maximises sum of pairwise compatibility scores (Camelot move legality + BPM delta penalty + energy continuity). Solve as TSP-on-small-N (≤30 tracks) with nearest-neighbour heuristic + 2-opt.

Signals: `bpm`, `key_camelot`, `energy` for tracks in the user-supplied set.

Why: DJs often have a rough "what I want to play tonight" pile and need it ordered. Mixed In Key Pro and DJ.Studio's Harmonize both market this; Set Memory can do it offline without subscription.

Sketch: brute-force for N <= 8; nearest-neighbour + 2-opt for N <= 30; bail to greedy-by-key for larger. Score: `compat(a,b) = w_key * key_legal + w_bpm * exp(-|bpm_a - bpm_b|/3) + w_energy * (1 - |e_a - e_b|/10)`.

Impact: HIGH (genuinely useful workflow). Cost: MEDIUM. Caveats: not a "suggestion" in the current sense; needs a new entry point. Could be triggered when user dismisses a generated pack ("reorder these N tracks instead").

### D4. Transition-legality scoring on existing chains

What: Annotate each suggestion with a legality score for every adjacent pair. Bad transitions (key clash + >4 BPM jump + energy step >3) get flagged in the rationale. Allows Rob to spot a 1-track wart in an otherwise good chain.

Signals: derived per-pair from existing track fields.

Why: any generated playlist's quality is governed by its weakest link. Flagging it gives the user the choice to swap one track instead of dismissing the whole suggestion.

Sketch: add `transition_warnings: list[(int, str)]` to Suggestion; computed on render.

Impact: MEDIUM. Cost: SMALL. Caveats: thresholds are taste-dependent; expose via config.

---

## Family E: Behavioural decay and recency models

### E1. Exponential-decay popularity (replace `total_appearances` ranking)

What: Replace raw appearance count with a recency-weighted score: `score(t) = Σ exp(-λ * days_ago(s)) for s in t's sessions`. λ tuned so a play 90 days ago counts ~0.5 of a play today. This becomes the default ranking signal across most algorithms.

Signals: `appearances` joined to `sessions.session_date`.

Why: Ebbinghaus-style decay is the documented baseline for any taste-changes-over-time domain. Right now "most played" forever-favours tracks Rob hammered in 2023 and ignores his current vibe. A decay constant turns the same algorithm into "what's hot in your current rotation".

Sketch: SQL `SUM(EXP(-0.0077 * julianday('now') - julianday(s.session_date)))` (λ ≈ 0.0077 gives 90-day half-life). Add as `tracks.recency_weighted_appearances`, refreshed in analyse pass.

Impact: HIGH (touches every ranking-by-popularity surface). Cost: SMALL. Caveats: too-aggressive λ kills the forgotten-favourites signal (which depends on cold-and-old being countable). Use a longer half-life (180-360 day) for ranking and keep raw count for forgotten-pack filter.

### E2. Forgetting-curve revival prioritisation

What: For tracks past a threshold of "forgottenness", model the probability Rob would re-recognise / re-deploy them as a forgetting curve `R(t) = e^(-t/S)` where S is a per-track strength derived from `total_appearances`. Tracks with high S and high t are "still in your head but cold" - the highest-leverage revival targets.

Signals: `total_appearances`, last_seen_session date.

Why: a tightly-defined refinement of the existing forgotten pack; surfaces the tracks where the play-cost is lowest (Rob already knows them) and the freshness gain is highest.

Sketch: `revival_score = appearances * log(days_since_last + 1)`. Top N.

Impact: MEDIUM. Cost: TINY. Caveats: similar to existing forgotten pack; differentiate by ranking criterion not just filter.

### E3. ABBA-style rotation hygiene (anti-recency cap)

What: Hard-cap any generated playlist's overlap with the last 30 days' played tracks at <=20%. Prevents the tool surfacing tracks Rob just played at last week's gig.

Signals: `appearances`, `sessions.session_date`.

Why: working DJs avoid burning the same tracks repeatedly to the same crowd. The documented "freshness" principle (DJ Tech Tools, Digital DJ Tips) is exactly this hygiene constraint.

Sketch: post-filter on every generator: `if recent_play_count(content_id, 30) > 0: drop with prob 0.7`. Configurable.

Impact: MEDIUM-HIGH. Cost: TINY. Caveats: blunt-instrument; combine with E1 so the suggestion list still has options after filtering.

### E4. Buy-and-bury detection (added but never played at all)

What: Strictly stricter than existing "recently added unplayed": find tracks added >=120 days ago with zero appearances ever. These are buy-regret artefacts that deserve a one-time decisive prompt: spin or delete.

Signals: `tracks.added_at`, `total_appearances`.

Why: working DJs accumulate hundreds of buys that never get played. A "Library Hygiene" pack of >=120-day buried tracks is a different psychological prompt than "try this recent buy" - it's "make a verdict".

Sketch: trivial WHERE filter.

Impact: MEDIUM. Cost: TINY. Caveats: the right response is sometimes delete-not-play; the suggestion's rationale should be honest about this.

### E5. Time-since-purchase ROI metric

What: Per track: `roi = total_appearances / (days_in_library / 30)`. Plays per library-month. Surface low-ROI buys (long-held, low-played) as a "low ROI" pack distinct from buy-and-bury.

Signals: `tracks.added_at`, `total_appearances`.

Why: gives a continuous metric instead of E4's binary cutoff. Useful for thinning the library.

Sketch: derived column; rank ascending.

Impact: LOW-MEDIUM. Cost: TINY. Caveats: penalises slow-burners that took a year to find their spot; combine with "play count in last 60d > 0" exception.

---

## Family F: Temporal cycles (weekday, season, anniversary)

### F1. Day-of-week vibe matching

What: Tag each session with weekday from `session_date`. For each weekday, compute the typical track pool. When suggesting today, weight by today's weekday match. "Friday Rob" plays different tracks than "Sunday Rob".

Signals: `sessions.session_date`.

Why: weekday gigs often have different audiences and energy expectations.

Sketch: `strftime('%w', session_date)`; aggregate per-weekday track-pools; compute weekday-IDF (track common to one weekday but rare elsewhere).

Impact: MEDIUM. Cost: SMALL. Caveats: assumes session_date correlates with actual gig date (true for Set Memory's data flow).

### F2. This-month-last-year nostalgia pack

What: Find sessions from the same calendar month, prior year(s). Surface tracks from those sessions that Rob hasn't played in >=180 days.

Signals: `sessions.session_date`, `appearances`.

Why: seasonal memory triggers are emotionally resonant ("this song was my June 2024 closer"); also taps documented year-cycle behaviours in DJ track selection.

Sketch: `WHERE strftime('%m', session_date) = strftime('%m', 'now') AND session_date < date('now', '-300 days')`.

Impact: MEDIUM. Cost: TINY. Caveats: only meaningful once data spans >=18 months.

### F3. Anniversary set reconstruction

What: For any past session N years ago today, reconstruct it and present as a one-click "play your set from [date]". Surface as a special suggestion type.

Signals: `sessions.session_date`, `appearances`.

Why: emotional / shareable / fun. Aligns with the "just-work" Apple-style invisible thoughtfulness principle.

Sketch: trivial query for `session_date = date('now', '-N years')`; emit one suggestion per matching anniversary.

Impact: LOW-MEDIUM. Cost: TINY. Caveats: novelty value; surfacing every day is noisy, fire only on exact anniversaries.

### F4. Seasonal energy-curve drift detection

What: Detect whether Rob's mean session energy / mean BPM drifts seasonally (e.g. winter is darker / slower). If so, when suggesting this week, weight library tracks whose energy/BPM matches the current seasonal centre.

Signals: `sessions.session_date`, aggregated per-session energy and BPM means.

Why: subtle, but the "right" track for July is not the same as for December for many DJs; matching the seasonal centre keeps the suggestion in the pocket.

Sketch: monthly aggregates; centre-bias the candidate pool's BPM/energy filters by ±10% toward this month's historical centre.

Impact: MEDIUM. Cost: MEDIUM. Caveats: requires multiple years of data; degrades to no-op otherwise.

---

## Family G: Coverage, diversity, and blind-spot detection

### G1. Library blind-spot diagnostic (under-played BPM/key cells)

What: 2D heatmap (BPM bucket × Camelot key) of `total_appearances`. Cells where library size is >= 5 tracks but plays per track is <= 0.5 the library mean are "blind spots". Surface as a diversification pack: top 3 tracks from each blind-spot cell.

Signals: `tracks.bpm`, `tracks.key_camelot`, `tracks.total_appearances`, `tracks.in_library`.

Why: every DJ has accidental dead zones. Visualising and resurrecting them widens the playbook. Documented in DJ library-management guides as the value of smart-playlist coverage analytics (Lexicon, Rekordbox smart playlists).

Sketch: GROUP BY bpm_bucket(round to 4), key_camelot. Compute per-cell `count(*)` and `sum(plays)`. Cells where `count >= 5 AND avg_plays < 0.5 * global_avg` flagged.

Impact: MEDIUM-HIGH. Cost: SMALL. Caveats: empty cells are not blind spots (Rob doesn't have those tracks); only filled-but-cold cells qualify.

### G2. Diversification pack (force-explore weak zones)

What: Generated playlist that deliberately spans the 5 lowest-explored cells from G1. Differs from a normal pack in that it's optimised for breadth not depth.

Signals: G1 output.

Why: complements personal-canon detection. Documented in recommender research as the diversity / novelty axis (ISMIR diversity-by-design).

Sketch: pick 4 tracks per under-explored cell from G1, dedupe, order by BPM. Score lower than mainstream packs but always present.

Impact: MEDIUM. Cost: SMALL. Caveats: produces deliberately uncomfortable suggestions; brand it that way.

### G3. Cold-cluster reactivation (cliques dormant 60+ days)

What: Re-run the existing clique algorithm but on the sub-graph of co-sessions older than 60 days, with the additional constraint that no clique member has been played in 60 days. Surface cold cliques as a distinct pack from hot cliques.

Signals: `appearances` ∩ `sessions WHERE session_date < today-60`.

Why: the current clique algorithm doesn't distinguish "always plays together, including last week" from "used to play together 6 months ago"; both surface identically. The cold ones are the surprise resurrection candidates.

Sketch: same as existing `_cliques` but with date-filtered appearance pool; additional filter ensuring no member has appeared post-cutoff.

Impact: MEDIUM-HIGH. Cost: SMALL (composes existing). Caveats: small data after filter; lower min_pair_sessions threshold for cold pool (e.g. 3 instead of 4).

### G4. Personal-canon identification (the always-played 50)

What: The N tracks (15-50) with appearance counts in the top decile AND played in at least 50% of the last 12 sessions. These are Rob's reliable canon. Surface as a reference list (with a "are these still right?" hygiene angle: any canon track absent from the last 5 sessions might be due for evaluation).

Signals: `appearances`, `sessions` ordered by date.

Why: knowing your canon explicitly is meta-useful. Also feeds H1 below.

Sketch: rank by `(total_appearances + 3 * recent_count)`, filter to "in >=50% of last 12 sessions".

Impact: HIGH (the canon is a constant reference; many other algorithms can use it). Cost: SMALL. Caveats: define cleanly so canon membership is stable across runs (small fluctuations otherwise feel buggy).

### G5. Track-fitness for current canon

What: For a candidate old/forgotten track, measure co-occurrence with the current G4 canon. Tracks that historically co-played with the current canon are "still in the family"; tracks that only co-played with retired canon members are out of style.

Signals: G4 canon + `appearances` co-occurrence.

Why: distinguishes "good revival" from "stylistically dated" forgotten favourites. Higher-confidence revival targets.

Sketch: for each candidate, sum of co-session counts with current canon, normalised by candidate's total appearances. Threshold >= 0.3.

Impact: MEDIUM. Cost: SMALL (composes G4 + co-occurrence). Caveats: penalises genuinely-evolved sound; offer the low-fitness candidates as a separate "evolved away from" reflection.

---

## Family H: Performance-readiness and prep scoring

### H1. Performance-readiness composite score

What: Per track, compute a readiness score: hot_cue_count (≥4 = ready) + memory_cue_count (≥2) + has_BPM + has_key + not in `prep_pack`. Surface a "Tonight-Ready" filter on every other suggestion - tracks the candidate-pool defaults to readiness-passed.

Signals: `hot_cue_count`, `memory_cue_count`, `bpm`, `key_camelot`.

Why: a suggested playlist full of unprepared tracks is useless on the night. Soft-prioritising prepared tracks across all algorithms gives the user a "what could I actually play tonight" view without losing the broader suggestions.

Sketch: post-filter or post-rank across all generators; weight = `0.4 * normalised(hot_cues) + 0.3 * normalised(memory_cues) + 0.3 * has_analysis`.

Impact: HIGH. Cost: SMALL. Caveats: penalises new tracks Rob hasn't prepped; pair with a separate "prep these first" pack so the prep work itself is surfaced.

### H2. Memory-cue cluster pack (well-prepped + co-played)

What: Tracks with `memory_cue_count >= 4` (Rob has invested prep effort) grouped by co-session cluster. These are the cliques Rob has effectively pre-set as performance units.

Signals: `memory_cue_count`, co-occurrence graph.

Why: prep effort is itself a signal of intent; tracks Rob bothered to memory-cue heavily are ones he meant to keep performing. Surfacing them in their natural cluster groups is double-signal validation.

Sketch: filter to memory-cue-rich subset, run clique algorithm on this subset only.

Impact: MEDIUM. Cost: SMALL. Caveats: depends on Rob's memory-cue behaviour being signal-bearing (mostly true for prep-heavy DJs).

### H3. Hot-cue-rich opener candidates

What: Tracks classified as openers (A3) AND with hot_cue_count >= 4 - performable openers ready to go.

Signals: A3 + `hot_cue_count`.

Why: openers especially benefit from hot cues (cold start under pressure). Cross-cuts H1 and A3 to produce a tactical pack.

Sketch: intersect A3 opener bucket with `hot_cue_count >= 4`.

Impact: MEDIUM. Cost: TINY. Caveats: composes existing.

---

## Family I: Library cross-cutting and per-source views

### I1. Per-USB pack (neglected drive)

What: For each USB drive in `usb_drives`, list tracks unique to that drive (or with that drive as primary source) and play count. Surface "Tracks only on [USB Label] you haven't played in 90 days" - reminds Rob of forgotten USBs.

Signals: `usb_drives`, `tracks.dedup_key`, `track_aliases.source_db_path`.

Why: Rob has multiple USBs across CDJ exports; one is likely under-used. Surfacing this rotates the rotation.

Sketch: for each usb, tracks where `source_db_path` only matches that usb AND last_seen > 90d.

Impact: LOW-MEDIUM. Cost: SMALL. Caveats: requires per-USB source tracking to be reliable post-dedup.

### I2. Genre-comment harvesting

What: Mine the `Comment` field (read via pdb_reader / ingest extension) for free-text genre/mood tags. Build per-tag track pools. Surface "Your Disco/Edits/etc." packs based on harvested tags.

Signals: `djmdContent.Commnt` on USB (needs ingest extension).

Why: many DJs use Comment as a tag bag (subgenres, mood, era). Mining this turns implicit structure into explicit packs. Documented in Rekordbox smart-playlist guides as the cheap labelling primitive.

Sketch: extend ingest to capture Comment; tokenise on common separators (/, |, comma, space-prefix #); cluster tokens by frequency; build per-tag packs above N=10.

Impact: MEDIUM (depends on whether Rob uses Comment field). Cost: MEDIUM (ingest schema change). Caveats: needs to confirm Rob's tagging habit before building.

### I3. Rating-based packs

What: Read `djmdContent.Rating` (1-5 stars). Surface a "5-star but cold" pack: tracks Rob explicitly starred but hasn't played in 90+ days.

Signals: `Rating` (needs ingest).

Why: stars are explicit positive feedback - the most-trusted signal in the implicit-vs-explicit feedback literature. A starred track gone cold is a high-confidence revival.

Sketch: trivial filter on the joined column.

Impact: MEDIUM (depends on rating discipline). Cost: SMALL (schema change). Caveats: only meaningful if Rob rates.

### I4. Colour-tag packs

What: Read `djmdContent.ColorID` (rekordbox colour labels). Surface per-colour packs. Cross-DJ this is well-documented as the fastest visual tagging.

Signals: `ColorID`.

Why: colours encode any taxonomy Rob set up; surfacing per-colour groups respects the user's existing organisation.

Sketch: GROUP BY ColorID, rank within.

Impact: LOW-MEDIUM. Cost: SMALL. Caveats: depends on colour discipline.

---

## Family J: Artist and string-pattern signals

### J1. Artist-cluster discovery

What: Build artist co-play graph (two artists co-occur in a session). Find clusters of artists Rob plays together. Surface as "Artists you cluster: A, B, C - here's the union of their tracks".

Signals: `appearances.artist` aggregated by session.

Why: artist-level clustering generalises track cliques and survives swapping individual tracks; useful for "in the mood for the [B, C, D] sound".

Sketch: build artist-pair counts from sessions; run same clique algorithm on artist graph.

Impact: MEDIUM. Cost: SMALL. Caveats: noisy artist field (featured artists, remixers); normalise heavily.

### J2. Remix and edit detection by title pattern

What: Detect remix / edit / extended-mix variants via title regex. Cluster the canonical track with its variants. Surface "you have 3 versions of [Track] - here's how each performed".

Signals: `tracks.title` regex.

Why: Rob may forget he owns the extended mix while regularly playing the original. Cross-version surfacing is a one-off insight per track but high-value when it hits.

Sketch: regex on title for `(\(.*remix\)|\(.*edit\)|\(extended.*\)|\(.*dub\))`; group by normalised base title + artist.

Impact: LOW-MEDIUM. Cost: SMALL. Caveats: regex misses; manual verification needed before promoting variants.

### J3. Title/artist-string "sounds like" fallback

What: When no audio/MIK features are available for a new track, find similar-titled or same-label tracks Rob has played as a cold-start signal.

Signals: `title`, `artist`, optionally `label` (needs ingest).

Why: pure cold-start; better than nothing for never-played new buys.

Sketch: simple SQL LIKE on artist; trigram similarity on title using `unicodedata` normalisation.

Impact: LOW. Cost: SMALL. Caveats: weak signal; surfacing should be heavily down-ranked.

---

## Family K: Composite generation modes

### K1. Full-set auto-generation (60/90/120 minute targets)

What: Given a target duration and a target arc (preset from C1 or cluster-derived from B2), compose a complete set by walking the arc, picking a track per arc-position with constraints: BPM continuity (±4), Camelot legality (D1 chain rules), no-repeat in 30, prefer high-readiness (H1). Track durations sum to ~target minutes.

Signals: composes A1 (transitions for tie-breaks), C1 (target arc), D1 (key compat), E3 (freshness cap), H1 (readiness), G4 (canon weight).

Why: this is the headline output. Every other suggestion is a fragment; this is "here's tonight's plan".

Sketch: simulated-annealing or beam search over candidates; objective = compatibility sum + arc-fit + freshness + readiness; constraint: sum of durations within ±10% of target. Beam width 5, depth = expected track count.

Impact: VERY HIGH. Cost: LARGE. Caveats: needs track-duration field (ingest extension); produces a single suggestion with many moving parts so the rationale must be careful.

### K2. B2B preparation mode (two-DJ scope-merge)

What: Take Rob's history and a second DJ's playlist export (rekordbox XML or simple text). Compute overlap, suggest divisions ("you take the deep cuts, they take the anthems"), build a shared candidate pool with the union and a do-not-double list with the intersection.

Signals: `tracks` + external playlist import.

Why: documented B2B planning practice; tool can pre-do the painful "compare two libraries" homework.

Sketch: parser for rekordbox XML; set diff on (title, artist) or content_id where available; output three lists.

Impact: MEDIUM (event-driven; only matters when Rob has a B2B). Cost: MEDIUM. Caveats: identity matching across libraries is the hard part (no shared content_id).

### K3. Surprise-me randomiser

What: Sample one track from each of: under-played cell (G1), forgotten favourite (existing), cold clique (G3), opener with hot cues (H3), recent buy unplayed (existing). Returns 5 tracks across orthogonal corners.

Signals: composes existing + new.

Why: cheap serendipity injection; the documented exploration-vs-exploitation balance in music recommendation.

Sketch: union of one row from each generator's top-5; randomise within.

Impact: MEDIUM. Cost: TINY. Caveats: avoid surfacing the same exact 5 daily; seed with date.

### K4. Year-in-review pack

What: At year-end (configurable trigger), generate "Your 2026" - the 25 tracks that defined the year by `appearances` count. Plus "Newcomer of 2026" (added this year + most played).

Signals: `sessions.session_date YEAR`, `appearances`, `tracks.added_at`.

Why: shareable, reflective, sticky. Aligns with the public-update "what's new" / year-end ritual.

Sketch: trivial date filters.

Impact: MEDIUM (annual). Cost: TINY. Caveats: fire on configurable date; bury in archive rest of year.

---

## Family L: Quality and validation infrastructure

### L1. Hold-out evaluation harness

What: Hide the last 3 sessions, run suggestion generators on the earlier data, check what fraction of each hidden session's tracks appear in the top-K of each generator. Per-generator hit-rate is the quality metric.

Signals: any.

Why: today every algorithm fires blind; no idea which actually predicts Rob's real behaviour. Holding out 3 sessions and measuring is the documented baseline (sequence-aware recommender evaluation, Quadrana 2018).

Sketch: temporary view excluding latest N sessions; run generators; intersect output content_ids with hidden sessions; report hit-rate@k per generator.

Impact: HIGH (improves every other algorithm by enabling tuning). Cost: MEDIUM. Caveats: not a user-facing suggestion - infra; sell as "tunable defaults".

### L2. Dismissal signal incorporation

What: The `dismissed_suggestions` table is currently only used to filter. Extend: when a clique is dismissed, lower the priors of its constituent tracks; when a recently-added pack is dismissed track-by-track (needs per-track dismissal), demote that track in future packs. Implicit-negative-feedback model.

Signals: `dismissed_suggestions`, new `dismissed_tracks` table.

Why: documented in sequential music recommendation (negative-feedback-informed contrastive learning); the only currently-stored explicit signal goes unused for ranking.

Sketch: schema add `dismissed_tracks (content_id, kind, dismissed_at)`; subtract weighted prior per dismissal in generator scoring; full-rebuild rank if 5+ new dismissals.

Impact: MEDIUM-HIGH. Cost: MEDIUM. Caveats: needs UI for track-level dismissal; risk of over-pruning if dismissal means "show me different not avoid forever".

---

## Top recommendations to implement first

Based on impact × cost ratio and the most-pressing gap (transition data goes wholly unused):

1. **A1 (real-transition Markov)** - the single highest-leverage gap; turns ordered session data into actionable a-to-b suggestions; small SQL change; immediate visible improvement.
2. **B1 (session similarity / "sets like this")** - reframes the entire tool around "more of that night" rather than "more of that track"; uses already-stored data; medium effort, high impact.
3. **E1 (exponential-decay popularity)** - one-line scoring change that improves the ranking of nearly every existing and proposed generator; recency-aware tool feels live; small effort, broad impact.
4. **C1 (energy-curve arc targeting)** - generalises the existing BPM ramp into multidimensional arc construction with documented DJ arc shapes; medium effort, high taste-fit.
5. **K1 (full-set auto-generation)** - composes A1 + B1 + E1 + C1 + H1 into a headline "here's tonight's set" output - this is the deliverable that justifies the whole tool.

Honourable mentions for early follow-up: A3 (opener/closer classifier), G4 (personal canon), L1 (evaluation harness so the rest of the catalogue can be tuned rather than guessed).

---

## Sources

DJ-craft and harmonic mixing:
- [ZIPDJ: The Camelot Wheel For DJs 2026](https://www.zipdj.com/blog/camelot-wheel)
- [Mixed In Key: Energy Boost mixing tutorial](https://mixedinkey.com/harmonic-mixing-guide/energy-boost-dj-mixing-tutorial/)
- [Mixed In Key: Sorting playlists by Energy Level](https://mixedinkey.com/harmonic-mixing-guide/sorting-playlists-by-energy-level/)
- [Mixed In Key: Control The Energy Level book](https://mixedinkey.com/book/control-the-energy-level-of-your-dj-sets/)
- [Digital DJ Tips: Mixed In Key 5.5 Energy](https://www.digitaldjtips.com/mixed-in-key-5-5-helps-you-control-dancefloor-energy/)
- [Dubspot: Building An Arc - Narrative structure in DJ sets](https://blog.dubspot.com/building-an-arc-bringing-narrative-structure-to-your-dj-sets)
- [Digital DJ Tips: 5 Essential Warm-Up Set Tips](https://www.digitaldjtips.com/5-essential-tips-for-playing-a-great-warm-up-set/)
- [ZIPDJ: How To Structure A DJ Set 2026](https://www.zipdj.com/blog/how-to-structure-a-dj-set)
- [Sokolovskiy: The bridge technique in DJ mixes](https://dsokolovskiy.com/blog/all/the-bridge-technique-in-dj-mixes/)
- [DJ TechTools: Digital crate digging guide](https://djtechtools.com/2023/02/24/how-i-dig-a-djs-guide-to-digital-crate-digging/)
- [Pioneer DJ: How to DJ back-to-back](https://blog.pioneerdj.com/djtips/how-to-dj-back-to-back/)
- [Mixmag: How to B2B feature](https://mixmag.net/feature/b2b-back-to-back-dj-set-artist-wisdom-sharing-decks)

Library management and rule-based playlists:
- [DeeJay Plaza: Rekordbox Intelligent Playlists tutorial](https://www.deejayplaza.com/en/articles/rekordbox-intelligent-playlist)
- [Lexicon DJ: Smartlists manual](https://www.lexicondj.com/manual/smartlists)
- [Lexicon DJ: Custom Tags manual](https://www.lexicondj.com/manual/tags)
- [Vibes: Smart Playlists for DJs](https://vibesdj.io/learn/techniques/smart-playlist-creation)

Automatic DJ systems and sequencing research:
- [ISMIR 2017: Automatic Playlist Sequencing and Transitions](https://archives.ismir.net/ismir2017/paper/000086.pdf)
- [Springer 2018: From raw audio to a seamless mix (automated DJ Drum & Bass)](https://link.springer.com/article/10.1186/s13636-018-0134-8)
- [Dagstuhl 2025: Temporal Considerations in DJ Mix IR and Generation](https://drops.dagstuhl.de/storage/00lipics/lipics-vol355-time2025/LIPIcs.TIME.2025.20/LIPIcs.TIME.2025.20.pdf)
- [DJ.Studio: Automix by Key & BPM with the Camelot Wheel](https://dj.studio/automix)

Music recommendation / MIR theory:
- [arxiv: Sequence-Aware Recommender Systems (Quadrana 2018)](https://arxiv.org/pdf/1802.08452)
- [Springer 2022: Dynamic session-based music recommendation IR](https://link.springer.com/article/10.1007/s11257-022-09343-w)
- [arxiv 2408.16578: Transformers Meet ACT-R - Repeat-Aware Listening Session Recommendation](https://arxiv.org/pdf/2408.16578)
- [arxiv 2409.07367: Sequential Music Recommendation with Negative Feedback Contrastive](https://arxiv.org/pdf/2409.07367)
- [Medium: Markov Chains in recommendation systems](https://medium.com/@sharetonschool/what-are-markov-chains-and-how-are-they-applied-in-recommendation-systems-or-nlp-119e06a4be5d)
- [arxiv 2312.16868: Pareto-based Multi-Objective Recommender with Forgetting Curve](https://arxiv.org/pdf/2312.16868)
- [Wikipedia: Forgetting curve](https://en.wikipedia.org/wiki/Forgetting_curve)
- [TISMIR: Diversity by Design in Music Recommender Systems](https://transactions.ismir.net/articles/10.5334/tismir.106)
- [ACM TIIS: Diversity, Serendipity, Novelty, Coverage survey](https://dl.acm.org/doi/10.1145/2926720)
- [EPJ Data Science 2025: Coherence in user-curated music playlists](https://link.springer.com/article/10.1140/epjds/s13688-025-00531-3)
- [ISMIR 2005: Pampalk music similarity tutorial](https://ismir2005.ismir.net/documents/pampalk_ismir_05_similarity_tutorial_c.pdf)
- [ACM MIR 2006: Audio similarity + web data for playlist generation](https://dl.acm.org/doi/10.1145/1178677.1178699)

Spotify / industry algorithm references:
- [PyImageSearch: Spotify song recommendation systems](https://pyimagesearch.com/2023/10/30/spotify-music-recommendation-systems/)
- [Medium: Sound of AI - Discover Weekly explained](https://medium.com/the-sound-of-ai/spotifys-discover-weekly-explained-breaking-from-your-music-bubble-or-maybe-not-b506da144123)
- [TechAhead: Spotify recommendation system](https://www.techaheadcorp.com/blog/spotify-recommendation-system/)
