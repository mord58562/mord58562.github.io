# DJ Workflow Patterns for Set Memory

Research brief on how working DJs actually prepare for, construct, and remember sets. Each pattern includes: what it is, what signals Set Memory's `state.db` already exposes (or is missing), a concrete suggested-playlist idea, and a source.

`state.db` recap (as of 2026-06-01):
- `tracks` (6878 rows, 6878 in_library) - `bpm`, `key_camelot`, `energy` (1-10, ~99% populated), `date_created`, `first_seen_session`, `last_seen_session`, `total_appearances`, `added_at`, `hot_cue_count`, `memory_cue_count`, `file_path`
- `sessions` (481 rows) - dated rekordbox HISTORY playlists with timestamp
- `appearances` - per-session ordered track list (track_no = position in the played set)
- `dismissed_suggestions`, `track_aliases`, `usb_drives`, `meta`

That last point matters: Set Memory has the **rarest dataset most DJ tools don't** - a complete play-order history. Track_no in `appearances` lets us infer set position (opener/peak/closer) without any extra tagging. Most patterns below lean on that.

---

## 1. The Set Arc (opener -> builder -> peak -> comedown -> closer)

**Description.** The dominant macro-framework. Energy starts moderate, rises through a build phase (small dips for breathing room, plateaus of 3-4 tracks at similar level), reaches a controlled peak, then a 3-4 track descent. Mixed In Key's 1-10 energy scale codifies it: warm-up at 5, rising to 7 mid-set, 8-9 at peak, 6 on closeout. Three energy modes: ramp-up (most common, build to climax), wave (sophisticated, for 2hr+ sets - peaks and valleys), and steady plateau.

**Signals in state.db.** Strong. `appearances.track_no` joined to `tracks.energy` lets us reconstruct the energy curve of every past session. We can:
- compute Rob's typical opener-energy, peak-energy, closer-energy distributions
- detect his preferred macro shape (ramp vs wave) per session-length bucket
- find tracks that consistently appear at a given position (anchor tracks)

**Suggested playlist.** `Tonight: 90min Arc` - 6 openers (energy 4-6, low hot-cue use), 12 builders (energy 6-7), 8 peak (energy 8-9, high `total_appearances`), 4 closers (energy 5-7, tracks Rob has historically played in the last 5 of >=3 sessions). Order by suggested track_no with key/BPM compatibility within each band.

**Source.** [Mixed In Key - Sorting playlists by Energy Level](https://mixedinkey.com/harmonic-mixing-guide/sorting-playlists-by-energy-level/); [Dubspot - Building An Arc](https://blog.dubspot.com/building-an-arc-bringing-narrative-structure-to-your-dj-sets); [Mixgraph - Energy Flow Guide](https://www.mixgraph.io/learn/energy-flow-guide).

---

## 2. Pre-Gig Crate Long-list -> Shortlist (200 -> 80-150)

**Description.** Pros build a candidate "crate" of roughly 2x the tracks they'll actually play, then prune. Common heuristic: a 2hr set at ~5min avg = ~24 tracks played, so prepare ~50. For larger gigs, long-list of 150-200, narrow to a 80-120 working crate plus a 30-track "wild card / insurance" reserve. The pruning step uses venue context (room size, slot time, who's before/after) and "would I be embarrassed to play this here" filtering.

**Signals.** Strong for the long-list, partial for context. We have play frequency and recency per track; we have no venue tag yet (could add `sessions.venue_name` later). For now: rank by `total_appearances` weighted by recency.

**Suggested playlist.** `Crate: [Genre] Long-list` - top 150 tracks in a chosen tempo+key window, deduped by artist (max 3 per artist), with `last_seen_session` no older than N sessions ago OR `added_at` within 90 days (new music gets a shot). Plus a shadow playlist `Crate: Insurance Reserve` - 30 highest-frequency historical bangers.

**Source.** [DJ TechTools - The Art of Prep](https://djtechtools.com/2012/04/15/the-art-of-prep-5-principles-every-dj-should-know/); [The DJ Revolution - Reading a crowd](https://www.thedjrevolution.com/reading-a-crowd-as-a-dj/) ("prepare twice the tracks you think you'll need").

---

## 3. Energy Sub-Crates Per Slot (warm-up / peak / wind-down)

**Description.** Industry-standard library structure: a parent genre folder (`HOUSE`), with sub-crates `HOUSE - Warm Up`, `HOUSE - Peak`, `HOUSE - Classics`, `HOUSE - End of Night`. Lets DJs grab the right pool in seconds when the room shifts. DJs with structured tag systems locate target tracks ~40% faster.

**Signals.** Strong. `energy` field + inferred position-in-set from `appearances` gives us empirical warm-up / peak / closer pools without manual tagging. We can even split by genre once we add a genre column (currently absent in `tracks` - candidate for ingest enrichment from the rekordbox export).

**Suggested playlist.** Auto-maintained trio per dominant genre: `[Genre] - Warm-up Auto` (tracks Rob has played in positions 1-6 across >=2 sessions, energy <=7), `[Genre] - Peak Auto` (positions 7-15, energy >=7), `[Genre] - Closer Auto` (last 5 of session, energy 5-7). Rebuilt nightly.

**Source.** [SetFlow - Complete Guide to Tagging Tracks in Rekordbox](https://setflow.app/blog/complete-guide-tagging-tracks-rekordbox); [DJOID - How to prepare for a DJ Set](https://www.djoid.io/articles/how-to-prepare-for-a-dj-set-music-curation-and-playlist-preparation-tips).

---

## 4. Harmonic Mixing Beyond +/-1 Camelot

**Description.** Real Camelot use extends well past the basic +/-1 / A<->B rules:
- **Energy boost** = mix up +2 semitones (or +7 Camelot steps via the perfect-fifth lift) for a clear lift.
- **Diagonal mix** = +/-1 number AND swap A<->B in one move (8A -> 9B). Stacks mood-flip on key-lift.
- **Mood switch** = same number, swap letter (8A -> 8B). Same root, minor -> major or vice versa.
- **Plus-4 wildcard** = jump +4 (10B -> 2B). Dissonant on paper, sometimes magic. Track-dependent.
- **Acapella/instrumental layering** = vocal stem in same key over an instrumental in same number; pitch-shift the vocal +/-1-2 semitones for fit.

**Signals.** Strong. We have `key_camelot` for ~99.8% of tracks. We can compute Rob's historical Camelot transitions from consecutive `appearances` rows in the same session, and detect his *preferred* transition signatures (probably not just +/-1 - we should measure his actual taste). 

**Suggested playlist.** `Harmonic Bridge from [seed track]` - for any anchor track, generate 12-20 candidates spanning: 3 perfect matches, 3 +/-1, 2 energy-boost (+2 semitones), 2 diagonal, 2 mood-switch, 1 plus-4 wildcard. Rank by Rob's historical transition preference learnt from his own sets.

**Source.** [Mixed In Key - Advanced Harmonic Mixing](https://mixedinkey.com/book/use-advanced-harmonic-mixing-techniques/); [MixOrMiss Camelot Wheel](https://www.mixormiss.com/wheel); [Mixed In Key - Energy Boost tutorial](https://mixedinkey.com/harmonic-mixing-guide/energy-boost-dj-mixing-tutorial/).

---

## 5. BPM Ramp Rules Per Genre

**Description.** Acceptable tempo nudge without pitch-warping the listener:
- House: ~120-130 BPM, +/-2 BPM transitions clean, +/-3 acceptable
- Techno: ~125-135 BPM, +/-3 BPM
- DnB/Jungle: ~165-180 BPM, +/-4 BPM
- Pitch-bend more than +/-2 BPM in tech-house starts to deform
- Genre jumps via half/double-time: 70 bpm hip-hop -> 140 bpm house; 87 bpm dnb halftime feel -> 174 bpm full; this is one of the *only* clean ways to cross genre boundaries

**Signals.** Strong. We have `bpm` everywhere. We can detect Rob's habitual BPM-ramp slope by computing successive-pair deltas in past sessions, then constrain candidate suggestions to within his observed comfort zone for the genre.

**Suggested playlist.** `Tempo Bridge: [from BPM] -> [to BPM]` - given a target tempo (e.g. closing 124 BPM, want to land at 135 BPM techno), suggest a ladder of 3-5 tracks each +/-2-3 BPM that key-chain together. Also a `Genre Pivot` playlist that uses half/double-time mathematics to cross BPM islands cleanly.

**Source.** [Pioneer DJ - How DJs think about tempo and genre](https://blog.pioneerdj.com/djtips/how-djs-think-about-tempo-and-genre/); [BCHillmix - BPM by Genre Guide](https://bchillmix.com/pages/bpm-by-genre); [Digital DJ Tips - Half/Double Time Mixing](https://www.digitaldjtips.com/2019/06/how-to-mix-using-half-time-and-double-time-bpms/); [Crossfader - Genre Transitions 128->150](https://wearecrossfader.co.uk/blog/creative-trick-for-genre-transitions-128bpm-150bpm/).

---

## 6. Rotation Hygiene / Burn-out Avoidance

**Description.** Don't replay the same banger every gig - it burns out for both crowd and DJ. Common conventions: don't repeat a peak-time signature track within 3 gigs at the same venue; don't repeat any track within the same gig; rest a heavily-played track for 2-3 months before reviving it as a "haven't heard this in ages" moment. Pros track this mentally; the DJ-Times "rotate the dancefloor" piece notes monotony in any one direction (BPM, gender of vocal, mood) for >5 tracks signals the crowd will check out.

**Signals.** Excellent. `appearances` lets us compute per-track "gigs-since-last-played" and a per-track frequency-decay score. We can flag burn-out candidates (played in 4 of last 5 sessions) and rest-revival candidates (heavy historical use, untouched 90+ days).

**Suggested playlists.**
- `Rested Heroes` - top 30 tracks by lifetime `total_appearances` where `last_seen_session` is >90 days ago. These are revival candidates with proven crowd response.
- `Cooling Off` - tracks played in >=3 of Rob's last 5 sessions. Visible warning, not banned - just makes overuse legible.
- `Fresh This Quarter` - `added_at` within 90 days AND `total_appearances` <=1. The test-track pool.

**Source.** [DJ Times - How to DJ: Reading and Rotating Your Dancefloor](https://www.djtimes.com/2017/06/how-to-dj-set-rotate-read-dancefloor/); [Wikipedia - Rotation (music)](https://en.wikipedia.org/wiki/Rotation_(music)).

---

## 7. Test-Track Slots for New Music

**Description.** Pros never debut a track at peak. New music goes into the warm-up window (positions 1-6) where a flop costs little, or into the wind-down where the crowd is forgiving. A track needs 2-3 successful warm-up plays before it earns a peak slot. This protects the headline moments and builds an evidence base for which new tracks are dance-floor-real.

**Signals.** Strong. `added_at` (when the track entered Rob's library) + `appearances.track_no` (where it gets played) lets us tell whether new tracks have been "battle-tested" yet.

**Suggested playlist.** `Untested - Warm-up Candidates` - tracks with `added_at` within 60 days and `total_appearances` == 0, filtered to energy 4-7 and within Rob's habitual warm-up BPM band. Plays them into rotation in safe slots. Once a track racks up 2-3 appearances without dismissal, it auto-graduates to the `Peak-eligible` pool.

**Source.** [DJ.Studio - DJ Set Preparation Workflow](https://dj.studio/blog/dj-set-preparation); [DJ Gym - How to Perform a Warm Up DJ Set](https://www.djgym.co.uk/post/how-to-perform-a-warm-up-dj-set).

---

## 8. The Personal Canon / Anchor Tracks

**Description.** Every working DJ has 30-50 forever-favourites that recur across years - tracks they'll always reach for in specific moments. These are *anchors*: they earn placement at positions 8-12 of a 15-track set (mid-peak), or at the final 1-2 slots. The Pulse/Mixgraph guidance is explicit: place anchor tunes at known peak moments and arrange other tracks to support them.

**Signals.** Excellent. `total_appearances` (lifetime count) is the canon signal. Cross-reference with the *position* they appear at to identify which are peak anchors vs closer anchors vs opener anchors.

**Suggested playlists.**
- `Personal Canon - Peak Anchors` - top 15 tracks by `total_appearances` whose median `track_no` falls in the middle third of session length.
- `Personal Canon - Openers` - top 10 with median track_no in first third.
- `Personal Canon - Closers` - top 10 with median track_no in last third.

These give Rob a constantly-refreshed view of "what am I actually about, structurally?" - and the system can suggest contemporary tracks that pair well with each anchor (key/BPM/energy compatible).

**Source.** [Mixgraph - DJ Set Planning Guide](https://www.mixgraph.io/learn/dj-set-planning-guide); [WePresent - How a DJ chooses the last song of the night](https://wepresent.wetransfer.com/stories/how-a-dj-chooses-the-last-song-of-the-night).

---

## 9. Time-of-Night Role Awareness (warm-up / peak / close)

**Description.** Three distinct mental modes:
- **Warm-up DJ:** patience and restraint, push-pull, build floor energy without spending it. NOT impressing the crowd. Quietly setting up the next DJ.
- **Peak DJ:** keep them on the floor. Bangers and tension/release. Less restraint.
- **Closing DJ:** start at high energy (handed over from headliner), spend the next 60-90 min slowly bleeding it down, prepare the crowd for the end rather than the climax.

Different track pools per role, different mixing density (warm-up = longer blends, peak = shorter swaps, closer = longer and more emotional).

**Signals.** Partial. We have no per-session role tag. We could add: at session ingest, prompt Rob (optional) to label session as warm-up / peak / close. Or infer from energy curve shape (rising = warm-up; high-then-fall = closer; high-flat = peak). 

**Suggested playlists.** Three pools generated from past sessions classified by curve shape:
- `Role: Warm-up` - tracks Rob plays in sessions whose energy curve rises monotonically
- `Role: Peak` - tracks from sessions with sustained energy 8+ for >60% of duration
- `Role: Closer` - tracks from sessions with descending energy in final third

**Source.** [DJ Times - DJ Etiquette Openers and Closers](https://www.djtimes.com/2020/05/dj-etiquette-advice-for-openers-and-closers-from-a-club-owner/); [Digital DJ Tips - How To DJ Warm Up Sets](https://www.digitaldjtips.com/how-to-dj-warm-up-sets/); [TRILLVO - DJ Roles 101](https://trillvo.wordpress.com/2019/01/17/dj-roles-101-opening-direct-support-headlining-closing/).

---

## 10. Venue-Type Playlists (club / festival / bar / afterparty)

**Description.** Sets are not interchangeable across venue types:
- **Festival** = short (45-90 min), dramatic transitions, crowd-pleaser-heavy, must land big within 15 minutes
- **Club** = 2-4 hours, slow build, deeper cuts, journey-led
- **Bar** = restrained energy, conversation-permitting, recognisable tracks, BPM rarely above 124
- **Afterparty / aftershow** = oddball tracks the artist hasn't played for ages, weird tempo experiments, "trust the room" gambits

**Signals.** Missing. We have no venue-type column. *Recommendation:* add an optional `sessions.context` enum (club/festival/bar/afterparty/practice) prompted at ingest or inferred from session duration + average energy. Until then, infer from session length and energy profile.

**Suggested playlist.** Once labelled: `Venue Profile: [Type]` showing the top 50 tracks Rob has historically played in that context, plus 20 new-but-similar candidates ranked by BPM/key/energy similarity to his historical profile for that venue type.

**Source.** [ExperienceZound - Differences Between DJs' Festival, Nightclub, and Tour Sets](https://experiencezound.com/blogs/partylonger-blog/the-differences-between-djs-festival-nightclub-and-tour-sets); [Gentone Events - Bar DJ vs Club DJ](https://www.gentone-events.co.uk/blog/bar-dj-vs-club-dj-a-look-at-the-contemporary-differences-in-music-and-vibe).

---

## 11. Genre-Specific Norms (Rob plays house / techno / disco / jungle / DnB)

**Description.** Each genre has its own conventions:
- **House (120-130):** smooth blends, vocal hooks earn peak slots, classic Frankie Knuckles-era tracks act as universal warm-ups, anthemic moments around 124-128 BPM
- **Techno (125-140):** less vocal, more tension/release, longer blends, peaks via filter/EQ ride, hardgroove and rave-techno sub-styles diverging in Sydney/Melbourne scene right now
- **Disco (110-125):** rare blending mid-set with house, ramp-up via edits, key matters more (vocal-heavy)
- **Jungle/DnB (160-180):** rapid track turnover, drops more frequent (every 4-8 mins not 30s), halftime moments as breathers, vinyl-tradition still strong
- Australian scene context: Boiler Room Sydney 2025 featuring Skin On Skin (hardgroove/techno), Mincy, Anna Lunoe + Nina Las Vegas b2b - hardgroove and Aussie-flavoured house/techno are the current moment. Chinese Laundry (Sydney) runs across house, electro, tech, bass, breaks. Newer Melbourne scene less captured in search results but festival/warehouse format dominant.

**Signals.** Missing genre column in `tracks` (current schema has no genre field). *Recommendation:* enrich at ingest from rekordbox export (genre is a standard ID3/rekordbox column). Until then we can BPM-bin as a proxy.

**Suggested playlist.** Genre-aware variants of every other playlist in this brief. The biggest one: `Cross-genre Tempo Bridge` - because Rob plays house AND jungle/DnB, half/double-time bridges (e.g. 125 BPM house -> halftime feel into 167 BPM DnB) are *the* signature transition for his palette.

**Source.** [Boiler Room Sydney 2025](https://boilerroom.tv/city/sydney/); [milkymilkymilky - Boiler Room Sydney curated by Mincy](https://www.milkymilkymilky.com/post/playlist-boiler-room-sydney-curated-by-mincy); [Pioneer DJ - How DJs think about tempo and genre](https://blog.pioneerdj.com/djtips/how-djs-think-about-tempo-and-genre/).

---

## 12. The "Ten Tracks I Always Have Ready" Pattern

**Description.** Battle-tested fallback tracks every working DJ keeps loaded. "If the room dies in 30 seconds, I drop this." 10-15 tracks max, refreshed every 6-12 months. Usually mid-peak energy (7-8), highly recognisable, broadly key-compatible. Function: insurance against a misread room.

**Signals.** Strong. Compute: tracks with `total_appearances` >= median, that have appeared in >=3 distinct sessions, with energy 7-8, where their position-in-set is *variable* (median std dev > 4) - meaning Rob deploys them flexibly, not as fixed openers/closers. That flexibility = insurance.

**Suggested playlist.** `Always Ready (Top 12)` - 12 tracks meeting the above + spread across 3-4 Camelot codes for harmonic flexibility. Rebuilt monthly. Bonus: highlight any of these that haven't been played in 60+ days as "polish these, they're due."

**Source.** [The DJ Revolution - Reading a crowd](https://www.thedjrevolution.com/reading-a-crowd-as-a-dj/); [DJ.Studio - DJ Set Preparation](https://dj.studio/blog/dj-set-preparation).

---

## 13. Last 5 of the Night Planning

**Description.** The end of the set is what gets remembered. Pros plan their last 3-5 tracks ahead of time and only the middle is improvised. Closer-track choice carries massive weight - Rufus Du Sol's "Innerbloom", Alphaville "Forever Young", emotional/euphoric or unexpectedly nostalgic. The room is melted; you can play anything that lands a feeling.

**Signals.** Excellent. `appearances.track_no` joined to `sessions.track_count` lets us find tracks Rob has played as positions (N-4..N) in past sessions - his actual personal closer canon.

**Suggested playlist.** `Closer Library` - all tracks ever played in the last 5 positions of any session, ranked by frequency. Sub-grouped by mood/energy. When generating a "Tonight" arc, the last 5 slots draw from this pool only (with a deliberate "wild card final track" slot allowing anything).

**Source.** [Ticketswap - Epic Closing Tracks](https://www.ticketswap.com/magazine/article/best-tracks-end-party-DJ-set); [WePresent - DJs explain what the last song means](https://wepresent.wetransfer.com/stories/how-a-dj-chooses-the-last-song-of-the-night); [ZIPDJ - 20 Best DJ Closing Songs](https://www.zipdj.com/blog/dj-closing-songs).

---

## 14. The Drop: Cadence and Density

**Description.** "The drop" (release of built tension) has macro and micro scales. Macro = the whole-set peak (one or two big moments per 90 min). Micro = within each track, energy spike at 16-32 bars after a build. Too many max-intensity peaks = nothing hits. House/techno drops sparse and earned; DnB drops dense; festival sets sacrifice macro for back-to-back micro drops. Rule of thumb: at least 5:1 ratio of regular to peak tracks.

**Signals.** Partial. Energy field is the proxy. We can detect Rob's drop cadence: how often (in minutes / track positions) does he go to energy 9+? Is the 5:1 ratio his norm? Then suggest tracks that maintain it.

**Suggested playlist.** `Tonight: Peak Spacing Check` - takes a draft set, computes interval between energy-9+ tracks, flags any cluster of 3+ peaks within 5 tracks as "burn risk", suggests an energy-7 "breather" insertion between them from the same key.

**Source.** [DJ City - Building Tension and Release](https://djcity.com.au/blog/building-tension-release-in-your-dj-sets/); [Techno-Music - The Art of the Drop](https://techno-music.com/the-art-of-the-drop-how-top-producers-craft-peak-moments-in-techno-sets/); [DJ.Studio - Anatomy of a Great DJ Mix](https://dj.studio/blog/anatomy-great-dj-mix-structure-energy-flow-transition-logic).

---

## 15. Set Notes / Comment-Field Conventions

**Description.** Pros encode metadata in the rekordbox Comments field using compact codes: `[DEEP]`, `[BIGROOM]`, `{OPENER}`, `{PEAK}`, `{CLOSER}`, energy bullets, "VOX" for vocal-heavy, "NRG9" for energy. Letters in brackets are scannable on CDJ screens during a set. Many DJs sync My Tags into Comments so the codes survive across software. Some keep only the catalog ID in Comments and store everything else as My Tags.

**Signals.** Missing today - we don't ingest the Comments field. *Recommendation:* add to ingest: parse the Comments field for bracketed codes and store as `tracks.comment_tags` (TEXT array). Big unlock - this is structured human-curated context Rob is probably already adding.

**Suggested playlist.** Once we ingest Comments: `Tag: [user-typed-code]` virtual playlists, e.g. `Tag: PEAK`, `Tag: VOX` - mirror Rob's existing tagging vocabulary without making him retag.

**Source.** [DJ TechTools - Tagging Tracks: Develop A Coding System](https://djtechtools.com/2016/08/15/breaking-the-code-coding-system-for-your-library/); [DJ Courses Online - Comment tagging your DJ library](http://djcoursesonline.com/dj-blog/2020/1/7/comment-tagging-your-dj-library); [Lexicon DJ - Custom Tags](https://www.lexicondj.com/manual/tags).

---

## 16. Memory + Hot Cue Counts as Readiness Signal

**Description.** A track with 0-1 hot cues isn't gig-ready. A track with 4-8 hot cues + memory cues has been actively prepped - intro point, drop, breakdown, key transition points marked. Cue-count is a *strong* implicit signal of "the DJ has spent time with this track and is ready to mix it under pressure". Hot-cue placement convention: top row = phrasing markers, bottom row = performance triggers.

**Signals.** Excellent and underused. We have `hot_cue_count` and `memory_cue_count` in tracks. We're not using them yet. Cue-count = a readiness/intimacy score.

**Suggested playlists.**
- `Gig-Ready` - tracks with `hot_cue_count >= 3` AND `memory_cue_count >= 1`. The actually-deployable library.
- `Needs Prep` - tracks `in_library = 1` AND `hot_cue_count <= 1` AND `added_at` > 30 days ago. Tracks Rob meant to prep but didn't. Surface them as a weekly nudge.
- Weight every other suggestion playlist by cue-count: a "Peak Anchor" with 0 hot cues is suspicious; demote.

**Source.** [We Are Crossfader - Hot Cues Complete Guide](https://wearecrossfader.co.uk/blog/hot-cues-complete-guide/); [DJ.Studio - DJ Cue Points](https://dj.studio/blog/dj-cue-points).

---

## 17. The Memory-of-Past-Sets Pattern (operationalising "I remember when I played X")

**Description.** Working DJs tell stories about specific gigs: "I played track X after track Y at venue Z and the room exploded." That memory is the closest thing the craft has to product-knowledge. The opportunity for Set Memory: surface those moments as first-class entities, not just rows in a play history.

**Signals.** Excellent and unique. We have full ordered play history across 481 sessions. We can extract:
- **Transition memories** - track-pair sequences (A->B) Rob has played multiple times. The most-repeated pairs are his signature transitions.
- **Cluster memories** - runs of 3-4 consecutive tracks Rob has played together >once across different sessions. These are *mini-set patterns* he leans on.
- **First-time moments** - which session/date a track first appeared. Lets him say "I've been playing this since session #234 on 2024-11-12."

**Suggested playlists.**
- `Signature Transitions` - top 20 track-pair sequences by repeat count. Click any pair and see all sessions where it was played.
- `Recurring Runs` - 3-4 track sequences Rob has used >=2 times. Branded as "your DJ signatures."
- `Tonight: Build from a Memory` - pick any past session; system suggests a new set that *evokes* its arc (similar energy curve, similar genre split, but new track choices where possible).

**Source.** Inferred from [Mixmag - How to B2B](https://mixmag.net/feature/b2b-back-to-back-dj-set-artist-wisdom-sharing-decks); [Electronic Groove - Beyond the Spotlight: Resident DJs](https://electronicgroove.com/beyond-the-spotlight-the-essential-role-of-resident-djs/) (residents develop "deep storytelling abilities and memory of their audiences through repeated performances").

---

## 18. B2B Mode (back-to-back sets)

**Description.** Common modes: 2-for-2 trade (first track blends, second steers), variable warmup-to-tight (15 min each early, 2-for-2 mid, 1-for-1 late), or one-for-one all night. Signal exchange: hand sigs, eye contact, headphone mics. Etiquette: let the other DJ's track breathe; don't slam in. Pre-agree on tempo and key bands.

**Signals.** Missing - we have no concept of B2B sessions. *Recommendation:* optional `sessions.is_b2b` boolean + `sessions.partner_name` text at ingest. Until then, this pattern is parked.

**Suggested playlist.** Once flagged: `B2B with [partner]` - tracks Rob has historically played in b2b sessions, sub-split by whether his partner's last track was higher or lower energy. Plus a `B2B Common Ground` view of tracks both DJs (if their libraries were merged) would key/BPM-overlap on.

**Source.** [Mixmag - How to B2B](https://mixmag.net/feature/b2b-back-to-back-dj-set-artist-wisdom-sharing-decks); [Pioneer DJ - How to DJ back-to-back](https://blog.pioneerdj.com/djtips/how-to-dj-back-to-back/).

---

## 19. Track-Pair Signature Detection (the killer Set Memory feature)

**Description.** Every working DJ has 30-100 *track pair* signatures - sequences they keep returning to because they work. These are more specific than "I love these tracks"; they're "I love THIS into THAT." Pros don't write them down; the muscle memory lives in their fingers. Set Memory has the data to make them explicit.

**Signals.** Excellent. Bi-gram analysis over `appearances` ordered by `track_no` within each `session_id`. Compute pair frequency, only count pairs that recur across >=2 distinct sessions (filter out the noise of any single session order).

**Suggested playlist.** `Your Signature Pairs` - top 30 track-pair bigrams ordered by recurrence count. For each: show all sessions where it was used, energy delta, key delta, BPM delta. This is the headline feature - no other tool can do this for Rob.

**Source.** Original to this brief; inferred from the pattern in [WeAreCrossfader - How DJs Prepare a Routine](https://wearecrossfader.co.uk/blog/how-djs-prepare-a-routine/) ("a few favourite track combinations form the spine of most sets") and resident-DJ literature on developing signature blends.

---

## Cross-cutting recommendations for ingest enrichment

Three columns missing from `tracks` that would unlock most patterns above:
1. `genre` (TEXT) - already in rekordbox export, easy add. Unlocks patterns 3, 5, 10, 11.
2. `comment_tags` (TEXT) - parse the Comments field for bracketed codes. Unlocks pattern 15 and gives Rob a no-extra-work tagging surface.
3. `sessions.context` (TEXT, optional - club/festival/bar/afterparty/practice/b2b) - prompt at ingest. Unlocks patterns 10 and 18.

Two derived/materialised tables that would speed up suggestion generation:
1. `track_position_stats` (content_id, min_pos, median_pos, max_pos, pos_stddev, sessions_count) - precompute once per ingest, lets opener/peak/closer classification be a single index lookup.
2. `transition_bigrams` (from_content_id, to_content_id, session_count, sessions_list, avg_bpm_delta, avg_energy_delta, key_relationship) - the signature-pair table. Drives pattern 19 directly.
