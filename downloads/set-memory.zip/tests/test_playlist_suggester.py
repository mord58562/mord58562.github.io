"""
test_playlist_suggester.py - Smoke + invariant tests for the v0.9
playlist generators. The pre-audit version had ZERO tests covering this
module; A1 (anniversary dupes) and A3 (forgotten-variant overlap)
shipped because the contract was unspecified. These tests lock the
invariants in.
"""
from __future__ import annotations

import datetime
import sqlite3

import pytest

import ingest
import playlist_suggester as ps


def _seed_state(state_conn: sqlite3.Connection) -> None:
    """Build a small but realistic state.db: 3 sessions, 12 tracks,
    deliberate within-session duplicate (track played twice in one set)
    so the dedup property has something to bite on."""
    ingest.ensure_schema(state_conn)
    now = datetime.datetime(2026, 5, 1).isoformat()
    cur = state_conn.cursor()
    # 12 tracks
    for i in range(1, 13):
        cur.execute(
            "INSERT INTO tracks (content_id, title, artist, bpm, key_camelot, "
            "in_library, added_at, total_appearances) "
            "VALUES (?, ?, ?, ?, ?, 1, ?, 0)",
            (f"T{i:03d}", f"Track {i}", f"Artist {(i-1)//3 + 1}",
             120.0 + i, f"{((i-1) % 12) + 1}A", "2026-01-01"),
        )
    # 3 sessions
    for session_no, days_ago in enumerate([200, 100, 5], start=1):
        date = (datetime.date(2026, 5, 1) - datetime.timedelta(days=days_ago)).isoformat()
        cur.execute(
            "INSERT INTO sessions "
            "(raw_history_id, fingerprint, session_date, source_db_path, "
            " ingested_at, track_count) VALUES (?, ?, ?, ?, ?, ?)",
            (f"sess{session_no}", f"fp{session_no}", date, "test.db", now, 10),
        )
        sid = cur.lastrowid
        # 10 tracks per session, with a deliberate dupe in session 1
        # to exercise the anniversary dedup contract.
        track_ids = [f"T{((i + session_no) % 12) + 1:03d}" for i in range(10)]
        if session_no == 1:
            track_ids[5] = track_ids[2]   # play the same track twice
        for track_no, cid in enumerate(track_ids, start=1):
            cur.execute(
                "INSERT INTO appearances (session_id, content_id, track_no) "
                "VALUES (?, ?, ?)",
                (sid, cid, track_no),
            )
            cur.execute(
                "UPDATE tracks SET total_appearances = total_appearances + 1, "
                "first_seen_session = COALESCE(first_seen_session, ?), "
                "last_seen_session = ? WHERE content_id = ?",
                (sid, sid, cid),
            )
    state_conn.commit()


@pytest.fixture
def seeded_state(state_db: sqlite3.Connection) -> sqlite3.Connection:
    _seed_state(state_db)
    return state_db


def test_generate_all_returns_suggestions(seeded_state):
    """Smoke: at least one suggestion comes out of a tiny seeded db,
    and every suggestion has the contracted shape."""
    out = ps.generate_all(seeded_state)
    assert len(out) >= 1
    for s in out:
        assert s.id and isinstance(s.id, str)
        assert s.name and isinstance(s.name, str)
        assert s.kind and isinstance(s.kind, str)
        assert s.content_ids and len(s.content_ids) > 0
        assert all(isinstance(c, str) for c in s.content_ids)


def test_no_suggestion_contains_duplicate_content_ids(seeded_state):
    """A1 regression: every generator must dedupe its content_ids
    before returning. Pushing a duplicate-bearing list to rekordbox
    produces literal duplicate playlist rows."""
    out = ps.generate_all(seeded_state)
    for s in out:
        assert len(s.content_ids) == len(set(s.content_ids)), (
            f"Suggestion {s.id} ({s.kind}) contains duplicate content_ids: "
            f"{[c for c in s.content_ids if s.content_ids.count(c) > 1]}"
        )


def test_forgotten_variants_are_mutually_exclusive(seeded_state):
    """A3 regression: dismissing one Forgotten variant must reveal
    different tracks, not a clone of the same top-N list."""
    out = ps.generate_all(seeded_state)
    forgotten = [s for s in out if s.kind == "forgotten"]
    seen_overall: set[str] = set()
    for s in forgotten:
        for cid in s.content_ids:
            assert cid not in seen_overall, (
                f"Forgotten variant {s.id} reuses content_id {cid} "
                "from a prior variant; variants must be mutually exclusive."
            )
            seen_overall.add(cid)


def test_recent_variants_are_mutually_exclusive(seeded_state):
    """Same invariant as forgotten, for the recently-added variants."""
    out = ps.generate_all(seeded_state)
    recent = [s for s in out if s.kind == "recent"]
    seen_overall: set[str] = set()
    for s in recent:
        for cid in s.content_ids:
            assert cid not in seen_overall, (
                f"Recent variant {s.id} reuses content_id {cid}; "
                "windowed variants must not overlap."
            )
            seen_overall.add(cid)


def test_seed_companions_dont_overlap_pairwise(seeded_state):
    """B2 regression: companions of one suggestion must not appear as
    seeds or companions of another. Without this, several 'Around X'
    packs surface near-identical bodies."""
    out = ps.generate_all(seeded_state)
    seeds = [s for s in out if s.kind == "seed_companions"]
    for i, a in enumerate(seeds):
        for b in seeds[i + 1:]:
            overlap = set(a.content_ids) & set(b.content_ids)
            assert not overlap, (
                f"Seed_companions overlap: {a.id} ∩ {b.id} = {overlap}"
            )


def test_dismissed_suggestion_is_excluded_by_default(seeded_state):
    """Sanity check on the dismiss flow used by the GUI."""
    out = ps.generate_all(seeded_state)
    if not out:
        pytest.skip("Seeded DB produced no suggestions to dismiss.")
    target = out[0]
    ps.dismiss(seeded_state, target.id)
    again = ps.generate_all(seeded_state)
    assert all(s.id != target.id for s in again)
    # And include_dismissed=True surfaces it again.
    with_dismissed = ps.generate_all(seeded_state, include_dismissed=True)
    assert any(s.id == target.id for s in with_dismissed)


def test_orphan_sessions_dropped_on_ensure_schema(state_db):
    """A4 regression: ensure_schema must clean up sessions with zero
    appearances every time it runs."""
    ingest.ensure_schema(state_db)
    # Insert a session with no appearances rows.
    state_db.execute(
        "INSERT INTO sessions "
        "(raw_history_id, fingerprint, session_date, source_db_path, "
        " ingested_at, track_count) VALUES (?, ?, ?, ?, ?, ?)",
        ("orphan", "orphan_fp", "2024-01-01", "x", "2024-01-01", 0),
    )
    state_db.commit()
    n_before = state_db.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
    assert n_before == 1
    ingest.ensure_schema(state_db)
    n_after = state_db.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
    assert n_after == 0


def test_dedup_key_preserves_version_markers():
    """B6 regression: 'Track (Original Mix)' and 'Track (DJ X Remix)'
    must produce DIFFERENT dedup keys so they don't collapse into one
    canonical row."""
    original = ingest.dedup_key_for("Speed It Up (Original Mix)", "Caviar")
    remix = ingest.dedup_key_for("Speed It Up (DR BOUNCE remix)", "Caviar")
    extended = ingest.dedup_key_for("Speed It Up (Extended)", "Caviar")
    catalog = ingest.dedup_key_for("Speed It Up (Free Download)", "Caviar")
    bare = ingest.dedup_key_for("Speed It Up", "Caviar")
    assert original is not None
    assert remix is not None
    assert extended is not None
    assert original != remix
    assert original != extended
    assert remix != extended
    # Catalog-only parens (no version keyword) SHOULD dedupe with bare.
    assert catalog == bare
