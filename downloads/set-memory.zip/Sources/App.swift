import SwiftUI
import AppKit

@main
struct SetMemoryApp: App {
    @StateObject private var state = AppState()

    init() {
        NSApplication.shared.setActivationPolicy(.regular)
    }

    /// Custom About panel: opens with brand-aligned text rather than the
    /// stock "Copyright © 2026 mord58562" alone. Both co-headline
    /// surfaces are named so a user reading the panel understands what
    /// the app does in 8 seconds.
    private func openAboutPanel() {
        let credits = NSMutableAttributedString(string: """
        Set Memory turns every CDJ-export USB into one searchable, deduped record of every track and session you have ever played. \
        Playlist Lab mines that record for ready-to-deploy rekordbox playlists: Markov walks of your real transitions, \
        opener / peak / closer canon by mean track-position, anniversaries, dormant cliques, energy arcs. \
        On-machine, no cloud.
        """)
        credits.addAttribute(.foregroundColor,
                             value: NSColor.secondaryLabelColor,
                             range: NSRange(location: 0, length: credits.length))
        credits.addAttribute(.font,
                             value: NSFont.systemFont(ofSize: 11),
                             range: NSRange(location: 0, length: credits.length))
        let options: [NSApplication.AboutPanelOptionKey: Any] = [
            .applicationName:    "Set Memory",
            .applicationVersion: "0.10.0",
            .credits: credits,
        ]
        NSApp.orderFrontStandardAboutPanel(options: options)
        NSApp.activate(ignoringOtherApps: true)
    }

    var body: some Scene {
        WindowGroup("Set Memory") {
            MainView()
                .environmentObject(state)
                .frame(minWidth: 1100, minHeight: 640)
        }
        // SwiftUI restores window frames automatically when the
        // WindowGroup has a stable identifier and we've opted in to the
        // platform's state-restoration semantics. .defaultSize gives
        // first-launch dimensions; subsequent launches restore the
        // user's last frame.
        .defaultSize(width: 1280, height: 800)
        .windowResizability(.contentMinSize)
        .windowToolbarStyle(.unified)
        .commands {
            CommandGroup(replacing: .newItem) {} // No File > New
            CommandGroup(replacing: .appInfo) {
                Button("About Set Memory") { openAboutPanel() }
            }
            CommandGroup(replacing: .help) {
                Button("Set Memory on GitHub") {
                    if let url = URL(string: "https://github.com/mord58562/set-memory") {
                        NSWorkspace.shared.open(url)
                    }
                }
                Button("Open Logs") {
                    let path = NSString(string: "~/Downloads/set-memory/logs").expandingTildeInPath
                    NSWorkspace.shared.open(URL(fileURLWithPath: path))
                }
                Button("Reveal state.db") {
                    let path = NSString(string: "~/Downloads/set-memory/state.db").expandingTildeInPath
                    NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: path)])
                }
            }
            CommandGroup(after: .toolbar) {
                Button("Sync now") { state.runSync() }
                    .keyboardShortcut("r", modifiers: [.command])
                    .disabled(state.syncing || state.mountedRekordboxUsbs.isEmpty)
                Button("Refresh from state.db") { state.reloadAll() }
                    .keyboardShortcut("r", modifiers: [.command, .shift])
            }
            CommandMenu("Jump") {
                // ⌘1..⌘9 jump straight to a sidebar section. The order
                // matches the Sidebar.swift display order: Playlist Lab
                // first (the Suggestions surface is the headline), then
                // the six Set Memory surfaces, then Distribution.
                let jumpOrder: [(KeyEquivalent, SidebarSection, String)] = [
                    ("1", .suggestions,    "Playlist Lab"),
                    ("2", .forgotten,      "Forgotten favourites"),
                    ("3", .recentUnplayed, "Recently added"),
                    ("4", .neverPlayed,    "Never played"),
                    ("5", .together,       "Played together"),
                    ("6", .sessions,       "All sessions"),
                    ("7", .search,         "Search"),
                    ("8", .distribution,   "Distribution"),
                    ("9", .usb,            "USB drives"),
                ]
                ForEach(jumpOrder, id: \.1) { key, section, label in
                    Button(label) {
                        state.selectedSection = section
                        state.ensureSectionLoaded(section)
                    }
                    .keyboardShortcut(key, modifiers: [.command])
                }
            }
        }

        // The Settings SCENE is the macOS-native home for preferences -
        // not a `.sheet`. Wiring it here gives us the standard ⌘, and
        // gets the window into the regular Window menu / app menu chain.
        Settings {
            SettingsView()
                .environmentObject(state)
        }
    }
}
