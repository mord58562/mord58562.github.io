import SwiftUI

/// Modal settings sheet. Tunes the analysis thresholds, writes them to
/// config.json (preserving keys the GUI doesn't know about), and
/// re-runs the in-process analysis after save. The launchd agent picks
/// up the same config.json on the next mount, so behaviour stays
/// consistent across GUI tweaks and on-mount runs.
struct SettingsView: View {
    @EnvironmentObject var state: AppState
    @Environment(\.dismiss) private var dismiss
    @State private var draft = Thresholds()

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("Settings")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(Theme.ink)
                Spacer()
                Button("Done") { commit() }
                    .keyboardShortcut(.defaultAction)
            }
            .padding(.horizontal, 20)
            .padding(.top, 18)
            .padding(.bottom, 12)
            Divider()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    group(
                        title: "Forgotten favourites",
                        helper: "Tracks you've played a lot, but not recently. Lower the play threshold if the list is empty."
                    ) {
                        stepperRow("Minimum plays", value: $draft.forgottenMinAppearances, range: 1...100, suffix: "×")
                        stepperRow("Not seen in (days)", value: $draft.forgottenDaysSinceLast, range: 7...3650)
                        stepperRow("Limit", value: $draft.forgottenLimit, range: 1...500)
                    }

                    group(
                        title: "Recently added, unplayed",
                        helper: "Window for the buy-regret signal. Days since added."
                    ) {
                        stepperRow("Window (days)", value: $draft.recentlyAddedWindowDays, range: 1...365)
                        stepperRow("Limit", value: $draft.recentlyAddedLimit, range: 1...500)
                    }

                    group(
                        title: "Never played",
                        helper: "Library tracks with zero appearances. Min days since add filters out tracks added in the last week or so."
                    ) {
                        stepperRow("Min days since added", value: $draft.neverPlayedMinDaysSinceAdd, range: 0...3650)
                        stepperRow("Limit", value: $draft.neverPlayedLimit, range: 1...1000)
                    }

                    group(
                        title: "Played-together pairs",
                        helper: "Track pairs that appear together in many sessions."
                    ) {
                        stepperRow("Minimum shared sessions", value: $draft.coAppearanceMinSessions, range: 1...100)
                    }

                    // Possibly-Deleted and Activity-sparkline groups
                    // intentionally cut from Settings - the defaults
                    // (60d stale window, 12 months back) work for
                    // everyone and exposing knobs neither user is
                    // tuning was AI-tell #49 ("Settings has 40 toggles").
                    // Limit + bar-count fields stay on the underlying
                    // config.json for power-users who want to edit it.
                }
                .padding(20)
            }

            Divider()

            HStack {
                Button("Restore defaults") {
                    draft = Thresholds()
                }
                Spacer()
                Button("Cancel") { dismiss() }
                Button("Apply") { commit() }
                    .keyboardShortcut("s", modifiers: [.command])
                    .buttonStyle(.borderedProminent)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 14)
        }
        .frame(width: 520, height: 640)
        .onAppear { draft = state.thresholds }
    }

    @ViewBuilder
    private func group<Content: View>(
        title: String,
        helper: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        // Use the project type scale rather than ad-hoc Font.system calls;
        // five different inline font definitions in 140 lines reads as
        // template (AI-tell #9, #14).
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(Type.bodyStrong)
                .foregroundColor(Theme.ink)
            Text(helper)
                .font(Type.body)
                .foregroundColor(Theme.ink3)
                .fixedSize(horizontal: false, vertical: true)
            content()
        }
    }

    private func stepperRow(
        _ label: String,
        value: Binding<Int>,
        range: ClosedRange<Int>,
        suffix: String = ""
    ) -> some View {
        HStack {
            Text(label)
                .font(Type.body)
                .foregroundColor(Theme.ink)
                .frame(width: 220, alignment: .leading)
            Spacer()
            Text("\(value.wrappedValue)\(suffix)")
                .font(Type.data)
                .foregroundColor(Theme.mono)
                .frame(width: 60, alignment: .trailing)
            Stepper("", value: value, in: range)
                .labelsHidden()
                .controlSize(.small)
        }
    }

    private func commit() {
        state.thresholds = draft
        state.saveThresholdsToDisk()
        dismiss()
    }
}
