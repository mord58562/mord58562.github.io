import SwiftUI

/// Restrained palette. Three layered neutrals (bg / surface / hover),
/// two text weights, three deliberate accents with split roles:
///   • cyan  = selected state, brand wordmark
///   • amber = primary action (sync), warnings, attention-needed
///   • coral = danger, deletion candidates
/// Nothing else uses colour. BPM is the only place gradients live
/// (the tempo ramp - meaningful gradient, not decorative).
enum Theme {
    // Backgrounds (three layers, intentional z-axis)
    static let bg          = Color(hex: 0x0B0D11)
    static let surface     = Color(hex: 0x13161C)
    static let hover       = Color(hex: 0x1B1F27)
    static let selected    = Color(hex: 0x202632)
    static let stroke      = Color(hex: 0x232832)
    static let strokeBright = Color(hex: 0x3A4150)

    // Text
    static let ink         = Color(hex: 0xEEF0F4)
    static let ink2        = Color(hex: 0x9CA3B0)   // metadata
    static let ink3        = Color(hex: 0x5B6373)   // dimmed
    static let mono        = Color(hex: 0xC0C6D0)   // numerical readouts

    // Accents - one job each, never doubled up
    static let cyan        = Color(hex: 0x4FB4C7)   // selection, brand, sparkline
    static let amber       = Color(hex: 0xD89B4D)   // action, warning, missing-prep
    static let coral       = Color(hex: 0xD96A6E)   // deletion, error

    // BPM tempo ramp (the one meaningful gradient in the app)
    static let tempoRamp: [(label: String, color: Color)] = [
        ("<100",    Color(hex: 0x6BBBCD)),
        ("100-119", Color(hex: 0x6BAFA0)),
        ("120-127", Color(hex: 0x7DB871)),
        ("128-134", Color(hex: 0xC3BC68)),
        ("135-144", Color(hex: 0xD8AB60)),
        ("145-159", Color(hex: 0xCC8458)),
        ("160+",    Color(hex: 0xC76164)),
    ]

    static func tempoColor(for bpm: Double?) -> Color {
        guard let bpm = bpm else { return ink3 }
        for (label, color) in tempoRamp {
            switch label {
            case "<100":    if bpm < 100   { return color }
            case "100-119": if bpm < 120   { return color }
            case "120-127": if bpm < 128   { return color }
            case "128-134": if bpm < 135   { return color }
            case "135-144": if bpm < 145   { return color }
            case "145-159": if bpm < 160   { return color }
            case "160+":    return color
            default: break
            }
        }
        return ink3
    }
}

extension Color {
    init(hex: UInt32, alpha: Double = 1.0) {
        self.init(.sRGB,
                  red:   Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >>  8) & 0xFF) / 255,
                  blue:  Double( hex        & 0xFF) / 255,
                  opacity: alpha)
    }
}

/// Type scale - 5 deliberate sizes / weights, no more. body is the
/// workhorse; micro is the only place UPPER+tracked labels live (table
/// column headers), data is the only mono. Mono variants pin
/// monospacedDigit() so numeric updates don't jitter the column width
/// (AI-tell #J / #13).
enum Type {
    static let body         = Font.system(size: 12, weight: .regular,  design: .default)
    static let bodyStrong   = Font.system(size: 12, weight: .medium,   design: .default)
    static let micro        = Font.system(size:  9, weight: .semibold, design: .default)
    static let data         = Font.system(size: 11, weight: .regular,  design: .monospaced).monospacedDigit()
    static let dataMid      = Font.system(size: 12, weight: .medium,   design: .monospaced).monospacedDigit()
}

/// Two-value radius system: chip (inline pill / key / BPM band) and
/// action (button-shaped surface). AI-tell #G / #54 - one radius
/// everywhere reads as a template. Two with a clear semantic split
/// reads as intentional.
enum Radius {
    static let chip:   CGFloat = 2
    static let action: CGFloat = 4
}

/// Single brand glyph - three vertical bars of varying height, used
/// only in the top-left wordmark. Suggests both waveform (audio) and
/// the dual-data shape (library + sessions). Never reused as an
/// accent or row icon.
struct BrandGlyph: View {
    var body: some View {
        GeometryReader { geo in
            let s = min(geo.size.width, geo.size.height)
            let bw = s * 0.16
            let gap = s * 0.08
            HStack(alignment: .center, spacing: gap) {
                Capsule().fill(Theme.cyan)
                    .frame(width: bw, height: s * 0.55)
                Capsule().fill(Theme.ink)
                    .frame(width: bw, height: s * 0.95)
                Capsule().fill(Theme.cyan)
                    .frame(width: bw, height: s * 0.40)
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
    }
}

// MARK: - Hand-drawn toolbar icons
// SF Symbols at default weight are an AI-tell when deployed as the
// whole visual identity (#25, #26). The wordmark already proves the
// app can draw its own marks; the toolbar carries them too, so the
// chrome is internally consistent rather than half-bespoke /
// half-stock.

/// Sync glyph - two arcs forming a circular flow with a tick mark
/// inside. Reads as "loop + checkpoint" rather than the iOS default
/// "arrow.triangle.2.circlepath" which is a generic refresh.
struct SyncGlyph: View {
    let color: Color
    let active: Bool
    var body: some View {
        Canvas { ctx, size in
            let s = min(size.width, size.height)
            let lw = max(1.2, s * 0.12)
            let r = s * 0.40
            let centre = CGPoint(x: size.width / 2, y: size.height / 2)
            // Top arc + opening tick on the right
            var top = Path()
            top.addArc(center: centre, radius: r,
                       startAngle: .degrees(210), endAngle: .degrees(30),
                       clockwise: false)
            ctx.stroke(top, with: .color(color),
                       style: StrokeStyle(lineWidth: lw, lineCap: .round))
            // Bottom arc with the opposite opening
            var bot = Path()
            bot.addArc(center: centre, radius: r,
                       startAngle: .degrees(30), endAngle: .degrees(210),
                       clockwise: true)
            ctx.stroke(bot, with: .color(color.opacity(active ? 0.45 : 1.0)),
                       style: StrokeStyle(lineWidth: lw, lineCap: .round))
            // Centre dot for confidence / "checkpoint"
            let dot = CGRect(x: centre.x - lw, y: centre.y - lw,
                             width: lw * 2, height: lw * 2)
            ctx.fill(Path(ellipseIn: dot), with: .color(color))
        }
    }
}

/// Settings glyph - three horizontal levels of varying length (a knob
/// stack), echoing the BPM/key/energy threshold sliders inside.
struct SettingsGlyph: View {
    let color: Color
    var body: some View {
        Canvas { ctx, size in
            let s = min(size.width, size.height)
            let lw = max(1.0, s * 0.09)
            let inset = lw
            let usable = size.width - inset * 2
            let rows: [CGFloat] = [0.30, 0.50, 0.70]   // y positions
            let widths: [CGFloat] = [0.50, 0.78, 0.36] // fractions
            let dotXs: [CGFloat] = [0.62, 0.30, 0.78]  // knob positions
            for i in 0..<3 {
                let y = size.height * rows[i]
                let w = usable * widths[i]
                var line = Path()
                line.move(to: CGPoint(x: inset, y: y))
                line.addLine(to: CGPoint(x: inset + w, y: y))
                ctx.stroke(line, with: .color(color),
                           style: StrokeStyle(lineWidth: lw, lineCap: .round))
                // knob
                let dotR = lw * 1.6
                let dotX = inset + usable * dotXs[i]
                let dot = CGRect(x: dotX - dotR, y: y - dotR,
                                 width: dotR * 2, height: dotR * 2)
                ctx.fill(Path(ellipseIn: dot), with: .color(color))
            }
        }
    }
}

/// Magnifier glyph - intentionally squarer + thicker than SF Symbol's
/// magnifyingglass so it reads in the inline search-field accessory.
struct SearchGlyph: View {
    let color: Color
    var body: some View {
        Canvas { ctx, size in
            let s = min(size.width, size.height)
            let lw = max(1.0, s * 0.13)
            let r = s * 0.30
            let centre = CGPoint(x: size.width * 0.42, y: size.height * 0.42)
            ctx.stroke(
                Path(ellipseIn: CGRect(x: centre.x - r, y: centre.y - r,
                                        width: r * 2, height: r * 2)),
                with: .color(color),
                style: StrokeStyle(lineWidth: lw))
            var stem = Path()
            let start = CGPoint(x: centre.x + r * 0.65, y: centre.y + r * 0.65)
            let end   = CGPoint(x: size.width - lw, y: size.height - lw)
            stem.move(to: start); stem.addLine(to: end)
            ctx.stroke(stem, with: .color(color),
                       style: StrokeStyle(lineWidth: lw, lineCap: .round))
        }
    }
}

/// Small downward chevron used in the USB picker menu trigger.
struct ChevronGlyph: View {
    let color: Color
    var body: some View {
        Canvas { ctx, size in
            let lw = max(1.0, size.height * 0.20)
            var p = Path()
            p.move(to: CGPoint(x: lw, y: size.height * 0.35))
            p.addLine(to: CGPoint(x: size.width / 2, y: size.height - lw))
            p.addLine(to: CGPoint(x: size.width - lw, y: size.height * 0.35))
            ctx.stroke(p, with: .color(color),
                       style: StrokeStyle(lineWidth: lw,
                                          lineCap: .round, lineJoin: .round))
        }
    }
}

/// Camelot key chip - tiny pill with subtle wheel-position colour.
struct CamelotChip: View {
    let key: String?
    var body: some View {
        let value = key ?? "-"
        let color = key.map(camelotColor(for:)) ?? Theme.ink3
        Text(value)
            .font(Type.data)
            .foregroundColor(color)
            .padding(.horizontal, 6)
            .padding(.vertical, 1)
            .background(color.opacity(0.14))
            .cornerRadius(Radius.chip)
    }
}

private func camelotColor(for key: String) -> Color {
    let digits = key.prefix(while: { $0.isNumber })
    guard let n = Int(digits), (1...12).contains(n) else { return Theme.ink2 }
    let hue = Double(n - 1) / 12.0
    let isMajor = key.hasSuffix("B")
    return Color(hue: hue,
                 saturation: isMajor ? 0.45 : 0.36,
                 brightness: isMajor ? 0.88 : 0.74)
}

/// Tempo-coloured BPM cell. Used in every row that shows a track.
struct BPMCell: View {
    let bpm: Double?
    var body: some View {
        let display = bpm.map { String(format: "%.0f", $0) } ?? "-"
        Text(display)
            .font(Type.dataMid)
            .foregroundColor(Theme.tempoColor(for: bpm))
            .frame(width: 36, alignment: .trailing)
    }
}

