import SwiftUI
import AppKit

@main
struct SetMemoryApp: App {
    @StateObject private var state = AppState()

    init() {
        NSApplication.shared.setActivationPolicy(.regular)
    }

    var body: some Scene {
        WindowGroup("Set Memory") {
            MainView()
                .environmentObject(state)
                .frame(minWidth: 1100, minHeight: 640)
        }
        .windowToolbarStyle(.unified)
        .commands {
            CommandGroup(replacing: .newItem) {} // No File > New
            CommandGroup(replacing: .help) {
                Button("Set Memory on GitHub") {
                    if let url = URL(string: "https://github.com/mord58562/set-memory") {
                        NSWorkspace.shared.open(url)
                    }
                }
                Button("Open Logs") {
                    let path = NSString(string: "~/Downloads/set-memory/logs").expandingTildeInPath
                    NSWorkspace.shared.open(URL(fileURLWithPath: path))
                }
                Button("Reveal state.db") {
                    let path = NSString(string: "~/Downloads/set-memory/state.db").expandingTildeInPath
                    NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: path)])
                }
            }
            CommandGroup(after: .toolbar) {
                Button("Sync now") { state.runSync() }
                    .keyboardShortcut("r", modifiers: [.command])
                    .disabled(state.syncing || state.mountedRekordboxUsbs.isEmpty)
                Button("Refresh from state.db") { state.reloadAll() }
                    .keyboardShortcut("r", modifiers: [.command, .shift])
            }
        }

        // The Settings SCENE is the macOS-native home for preferences -
        // not a `.sheet`. Wiring it here gives us the standard ⌘, and
        // gets the window into the regular Window menu / app menu chain.
        Settings {
            SettingsView()
                .environmentObject(state)
        }
    }
}
