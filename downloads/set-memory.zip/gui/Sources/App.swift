import SwiftUI
import AppKit

@main
struct SetMemoryApp: App {
    @StateObject private var state = AppState()

    init() {
        NSApplication.shared.setActivationPolicy(.regular)
    }

    var body: some Scene {
        WindowGroup("Set Memory") {
            MainView()
                .environmentObject(state)
                .frame(minWidth: 1100, minHeight: 640)
        }
        .windowToolbarStyle(.unified)
        .commands {
            CommandGroup(replacing: .newItem) {} // No File > New
            CommandGroup(replacing: .help) {
                Button("Set Memory on GitHub") {
                    if let url = URL(string: "https://github.com/mord58562/set-memory") {
                        NSWorkspace.shared.open(url)
                    }
                }
                Button("Open Logs") {
                    let path = NSString(string: "~/Downloads/set-memory/logs").expandingTildeInPath
                    NSWorkspace.shared.open(URL(fileURLWithPath: path))
                }
                Button("Reveal state.db") {
                    let path = NSString(string: "~/Downloads/set-memory/state.db").expandingTildeInPath
                    NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: path)])
                }
            }
            CommandGroup(after: .toolbar) {
                Button("Sync now") { state.runSync() }
                    .keyboardShortcut("r", modifiers: [.command])
                    .disabled(state.syncing || state.mountedRekordboxUsbs.isEmpty)
                Button("Refresh from state.db") { state.reloadAll() }
                    .keyboardShortcut("r", modifiers: [.command, .shift])
            }
            CommandMenu("Jump") {
                // ⌘1..⌘9 jump straight to a sidebar section. The order
                // matches the Sidebar.swift display order: Playlist Lab
                // first (the Suggestions surface is the headline), then
                // the six Set Memory surfaces, then Distribution.
                let jumpOrder: [(KeyEquivalent, SidebarSection, String)] = [
                    ("1", .suggestions,    "Playlist Lab"),
                    ("2", .forgotten,      "Forgotten favourites"),
                    ("3", .recentUnplayed, "Recently added"),
                    ("4", .neverPlayed,    "Never played"),
                    ("5", .together,       "Played together"),
                    ("6", .sessions,       "All sessions"),
                    ("7", .search,         "Search"),
                    ("8", .distribution,   "Distribution"),
                    ("9", .usb,            "USB drives"),
                ]
                ForEach(jumpOrder, id: \.1) { key, section, label in
                    Button(label) {
                        state.selectedSection = section
                        state.ensureSectionLoaded(section)
                    }
                    .keyboardShortcut(key, modifiers: [.command])
                }
            }
        }

        // The Settings SCENE is the macOS-native home for preferences -
        // not a `.sheet`. Wiring it here gives us the standard ⌘, and
        // gets the window into the regular Window menu / app menu chain.
        Settings {
            SettingsView()
                .environmentObject(state)
        }
    }
}
