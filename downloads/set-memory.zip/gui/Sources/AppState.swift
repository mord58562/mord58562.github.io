import SwiftUI
import Combine
import SQLite3

/// Central observable state. Owns the StateDB connection, kicks off
/// background reloads, watches state.db for changes, and exposes a
/// search throttle. Views observe @Published collections and re-render
/// without knowing about SQL.
@MainActor
final class AppState: ObservableObject {
    @Published var stats = SetMemoryStats()
    @Published var forgotten: [Track] = []
    @Published var recentUnplayed: [Track] = []
    @Published var neverPlayed: [Track] = []
    @Published var coAppearance: [CoAppearancePair] = []
    @Published var deletedCandidates: [DeletedCandidate] = []
    @Published var usbDrives: [UsbDrive] = []
    @Published var sessions: [SessionRecord] = []
    @Published var distribution = Distribution()
    @Published var sessionsByMonth: [(String, Int)] = []
    @Published var searchTerm: String = ""
    @Published var searchResults: [Track] = []
    @Published var thresholds = Thresholds()
    @Published var selectedSection: SidebarSection = .forgotten
    @Published var selectedTrack: Track?
    @Published var selectedSession: SessionRecord?
    @Published var suggestions: [PlaylistSuggestion] = []
    @Published var creatingPlaylistID: String? = nil
    @Published var lastPlaylistResult: String? = nil
    @Published var showDismissedSuggestions: Bool = false
    /// nil = show every family; otherwise restrict the Playlist Lab
    /// surface to one family at a time. Persisted via SceneStorage in
    /// MainView so the user's last selection survives across launches.
    @Published var suggestionFamilyFilter: SuggestionFamily? = nil
    @Published var mountedRekordboxUsbs: [String] = []
    /// Whether rekordbox.app appears to be running right now. Updated
    /// from NSWorkspace.runningApplications on launch + on activity
    /// notifications. When true, the rekordbox master.db is locked
    /// under SQLCipher and Create-in-rekordbox would fail with a
    /// confusing one-line banner; pre-flight disables the button and
    /// shows the user why directly.
    @Published var rekordboxRunning: Bool = false
    /// True when state.db is at v5 but every v5 field is still NULL -
    /// meaning the user upgraded but hasn't replugged a master.db USB
    /// since. Six v5 generators are silently empty in that window;
    /// surface a one-line nudge in the suggestions surface so the user
    /// understands why genre / rating / color packs are missing.
    @Published var v5BackfillPending: Bool = false
    /// nil = sync every mounted USB. Otherwise restrict to the named volume.
    @Published var syncVolumeFilter: String? = nil
    @Published var syncing: Bool = false
    /// Short live-status string surfaced in the Sync button while ingest
    /// is running. Updated from the ingest subprocess's stderr (logging
    /// stream is ingest's progress signal). Empty when no ingest is
    /// running, or the user just kicked one off and we haven't parsed
    /// any progress lines yet.
    @Published var syncProgress: String = ""
    @Published var lastError: String?
    @Published var lastReloadAt: Date = .distantPast

    private let stateDbPath: String
    private let configPath: String
    private let scriptPath: String
    private let pythonPath: String
    private var fileWatcher: DispatchSourceFileSystemObject?
    /// DispatchSource will trap-crash if you call suspend()/resume()
    /// out of balance. Track our own boolean so we never over-suspend
    /// or over-resume regardless of how the OS sends activity events.
    private var fileWatcherSuspended: Bool = false
    private var fileWatcherCoalesce: DispatchWorkItem?
    /// Block-based NSNotificationCenter observers return tokens that
    /// must be removed explicitly; removeObserver(self) doesn't reach
    /// them. Keeping the tokens here so deinit can clean up properly.
    private var notificationTokens: [NSObjectProtocol] = []
    private var searchTask: Task<Void, Never>?
    private var searchSinkCancellable: AnyCancellable?
    /// Last SQLite PRAGMA data_version we observed. Reload passes that
    /// would otherwise re-run every aggregate query skip immediately
    /// when this hasn't moved. Eliminates the dominant background CPU
    /// cost during quiet periods.
    private var lastSeenDataVersion: Int = -1
    /// Whether the app is the active app (front window). When inactive
    /// we suspend the file watcher and skip auto-reloads - the user
    /// can't see updates anyway and the only price is a fresh load
    /// when they come back. Saves significant battery during long idle
    /// stretches with the window hidden behind another app.
    private var appActive: Bool = true
    /// Throttle the Python suggester subprocess. Each invocation pays
    /// 200-800ms of Python interpreter cold-start; the suggestions are
    /// idempotent within a quiet period, so we cap at one per N seconds
    /// unless data_version moves.
    private var lastSuggesterRunAt: Date = .distantPast
    private let suggesterMinInterval: TimeInterval = 12.0
    /// Sections whose data is heavy enough to defer until selected
    /// (distribution does a full appearances × tracks GROUP BY; pairs
    /// does a self-join across the appearance graph).
    private var lazySectionsLoaded: Set<SidebarSection> = []

    init(
        stateDbPath: String = NSString(string: "~/Downloads/set-memory/state.db").expandingTildeInPath,
        configPath: String = NSString(string: "~/Downloads/set-memory/config.json").expandingTildeInPath,
        scriptPath: String = NSString(string: "~/Downloads/set-memory/set_memory.py").expandingTildeInPath,
        pythonPath: String = NSString(string: "~/miniconda3/bin/python").expandingTildeInPath
    ) {
        self.stateDbPath = stateDbPath
        self.configPath = configPath
        self.scriptPath = scriptPath
        self.pythonPath = pythonPath
        loadThresholdsFromDisk()
        reloadAll()
        startFileWatcher()
        detectMountedRekordbox()
        observeSearch()
        startVolumeMonitoring()
        startAppActivityMonitoring()
    }

    deinit {
        // A suspended dispatch source can't be released safely - resume
        // it first so cancel + dealloc are well-defined.
        if fileWatcherSuspended { fileWatcher?.resume() }
        fileWatcher?.cancel()
        // removeObserver(self) only catches target-action observers;
        // block-based addObserver returns tokens we must release here.
        let ws = NSWorkspace.shared.notificationCenter
        let dc = NotificationCenter.default
        for token in notificationTokens {
            ws.removeObserver(token)
            dc.removeObserver(token)
        }
    }

    // MARK: - App active / inactive (battery saver)

    /// Suspend background work while the app is inactive (window hidden,
    /// behind another app, or minimised). Resume + reload one time on
    /// becoming active. Net effect on a typical desktop where SetMemory
    /// sits in the background: near-zero CPU and no file-watcher churn.
    private func startAppActivityMonitoring() {
        let nc = NotificationCenter.default
        let activeToken = nc.addObserver(forName: NSApplication.didBecomeActiveNotification,
                       object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            self.appActive = true
            if self.fileWatcherSuspended, let w = self.fileWatcher {
                w.resume()
                self.fileWatcherSuspended = false
            }
            // Force a refresh on resume so we catch up on anything that
            // happened while we were idle. Bypass the data_version skip
            // by resetting our cached value.
            self.lastSeenDataVersion = -1
            self.reloadAll()
        }
        let inactiveToken = nc.addObserver(forName: NSApplication.didResignActiveNotification,
                       object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            self.appActive = false
            if !self.fileWatcherSuspended, let w = self.fileWatcher {
                w.suspend()
                self.fileWatcherSuspended = true
            }
            self.fileWatcherCoalesce?.cancel()
        }
        notificationTokens.append(contentsOf: [activeToken, inactiveToken])
    }

    // MARK: - Live volume mount/unmount monitoring

    /// Subscribe to NSWorkspace mount/unmount notifications so the app
    /// reflects USB plug-in / pull-out without the user pressing Rescan.
    /// On a CDJ-export USB being mounted, also kick off an auto-sync.
    private func startVolumeMonitoring() {
        let nc = NSWorkspace.shared.notificationCenter
        let mountToken = nc.addObserver(forName: NSWorkspace.didMountNotification,
                       object: nil, queue: .main) { [weak self] note in
            guard let self else { return }
            self.detectMountedRekordbox()
            // If the newly-mounted volume is a CDJ-export USB and we're
            // not already syncing, fire ingest. Slight delay lets the
            // filesystem settle (rekordbox writes a couple of files
            // immediately after mount).
            let url = (note.userInfo?[NSWorkspace.volumeURLUserInfoKey] as? URL)
            let label = url?.lastPathComponent
            if let label, self.mountedRekordboxUsbs.contains(label), !self.syncing {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
                    guard let self, !self.syncing else { return }
                    let saved = self.syncVolumeFilter
                    self.syncVolumeFilter = label
                    self.runSync()
                    self.syncVolumeFilter = saved
                }
            }
        }
        let unmountToken = nc.addObserver(forName: NSWorkspace.didUnmountNotification,
                       object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.detectMountedRekordbox() }
        }
        notificationTokens.append(contentsOf: [mountToken, unmountToken])
    }

    // MARK: - Reload

    func reloadAll() {
        let cachedVersion = lastSeenDataVersion
        let visibleSection = selectedSection
        Task.detached(priority: .userInitiated) { [stateDbPath, thresholds] in
            guard FileManager.default.fileExists(atPath: stateDbPath) else {
                await MainActor.run { [weak self] in
                    self?.lastError = "No state.db at \(stateDbPath). Plug in a rekordbox USB to seed it."
                }
                return
            }
            let db: StateDB
            do {
                db = try StateDB(path: stateDbPath)
            } catch {
                await MainActor.run { [weak self] in
                    self?.lastError = "Couldn't open state.db: \(error.localizedDescription)"
                }
                return
            }
            // Fast skip: if no writer has committed since our last reload,
            // there is nothing new to read. PRAGMA data_version is a single
            // integer read; aborting here saves ~10-50ms of aggregate query
            // work per quiet wake-up.
            let currentVersion = db.dataVersion()
            if currentVersion != 0 && currentVersion == cachedVersion {
                return
            }
            // Run every query in one do/catch. If ANY fails (typically
            // SQLITE_BUSY during an active ingest write), we keep the
            // previous @Published values rather than wiping them, which
            // is what caused the blank↔normal flashing.
            do {
                // Always-fresh lightweight surfaces (cheap, used in the
                // status bar and Library sidebar group).
                let stats = try db.stats()
                let forgotten = try db.forgotten(
                    minAppearances: thresholds.forgottenMinAppearances,
                    daysSinceLast: thresholds.forgottenDaysSinceLast,
                    limit: thresholds.forgottenLimit)
                let recent = try db.recentlyAddedUnplayed(
                    windowDays: thresholds.recentlyAddedWindowDays,
                    limit: thresholds.recentlyAddedLimit)
                let never = try db.neverPlayed(
                    minDaysSinceAdd: thresholds.neverPlayedMinDaysSinceAdd,
                    limit: thresholds.neverPlayedLimit)
                let usbs = try db.usbDrives()
                let backfillPending = db.v5BackfillPending()

                // Heavy sections - only fetched when their sidebar item
                // is selected. Sections not currently visible reuse the
                // previously-loaded slice (and load lazily on selection).
                let co = (visibleSection == .together)
                    ? try db.coAppearance(minSessions: thresholds.coAppearanceMinSessions,
                                          limit: thresholds.coAppearanceLimit)
                    : nil
                let deleted = (visibleSection == .deleted)
                    ? try db.deletedCandidates(staleDays: thresholds.deletedStaleDays,
                                               limit: thresholds.deletedLimit)
                    : nil
                let sessions = (visibleSection == .sessions)
                    ? try db.sessions(limit: 500)
                    : nil
                let byMonth = (visibleSection == .distribution)
                    ? try db.sessionsByMonth(months: thresholds.sparklineMonths)
                    : nil
                let dist = (visibleSection == .distribution)
                    ? try db.distribution()
                    : nil

                await MainActor.run { [weak self] in
                    guard let self else { return }
                    self.stats = stats
                    self.forgotten = forgotten
                    self.recentUnplayed = recent
                    self.neverPlayed = never
                    if let co { self.coAppearance = co }
                    if let deleted { self.deletedCandidates = deleted }
                    self.usbDrives = usbs
                    self.v5BackfillPending = backfillPending
                    if let sessions { self.sessions = sessions }
                    if let byMonth { self.sessionsByMonth = byMonth }
                    if let dist { self.distribution = dist }
                    self.lastReloadAt = Date()
                    self.lastSeenDataVersion = currentVersion
                    self.lastError = nil
                }
                // Suggestions are derived; refresh them after a data change
                // but throttle the Python subprocess - it's the dominant
                // CPU cost in the GUI's loop.
                await MainActor.run { [weak self] in self?.reloadSuggestionsThrottled() }
            } catch {
                // Likely SQLITE_BUSY during ingest. Leave existing @Published
                // values intact and try again on the next file-watcher tick.
                NSLog("StateDB reload skipped (will retry): \(error.localizedDescription)")
            }
        }
    }

    /// Called when the user clicks a sidebar item whose data we may have
    /// deferred. Loads that section's slice immediately, then it stays
    /// fresh across subsequent reloadAll calls.
    func ensureSectionLoaded(_ section: SidebarSection) {
        if lazySectionsLoaded.contains(section) { return }
        lazySectionsLoaded.insert(section)
        // The next reloadAll will pick this section up because
        // visibleSection now matches; force a reload to populate it
        // immediately rather than waiting for the next data_version bump.
        lastSeenDataVersion = -1
        reloadAll()
    }

    // MARK: - Search (debounced)

    private func observeSearch() {
        searchSinkCancellable = $searchTerm
            .removeDuplicates()
            .debounce(for: .milliseconds(180), scheduler: RunLoop.main)
            .sink { [weak self] term in
                self?.runSearch(term: term)
            }
    }

    private func runSearch(term: String) {
        searchTask?.cancel()
        let trimmed = term.trimmingCharacters(in: .whitespaces)
        guard trimmed.count >= 2 else {
            searchResults = []
            return
        }
        searchTask = Task.detached(priority: .userInitiated) { [stateDbPath] in
            // Honour cancellation - typing fast cancels the in-flight
            // search so we don't write stale results over a newer query.
            guard let db = try? StateDB(path: stateDbPath) else { return }
            if Task.isCancelled { return }
            guard let results = try? db.search(term: trimmed, limit: 200) else { return }
            if Task.isCancelled { return }
            await MainActor.run { [weak self] in
                self?.searchResults = results
            }
        }
    }

    // MARK: - Sync trigger

    func runSync() {
        guard !syncing else { return }
        syncing = true
        syncProgress = "Reading USB"
        let py = pythonPath
        let script = scriptPath
        let filter = syncVolumeFilter
        Task.detached(priority: .userInitiated) { [weak self] in
            let proc = Process()
            proc.executableURL = URL(fileURLWithPath: py)
            var args = [script, "--on-mount"]
            if let v = filter { args.append("--volume"); args.append(v) }
            proc.arguments = args
            let errPipe = Pipe()
            proc.standardError = errPipe
            // Stream stderr line-by-line so the Sync button can surface
            // live progress. Lines from set_memory.py's logger contain
            // recognisable progress markers we map to short labels.
            let errHandle = errPipe.fileHandleForReading
            let bufferState = MutableBuffer()
            errHandle.readabilityHandler = { handle in
                let chunk = handle.availableData
                if chunk.isEmpty { return }
                if let s = String(data: chunk, encoding: .utf8) {
                    bufferState.append(s)
                    for line in bufferState.takeLines() {
                        if let label = AppState.parseSyncProgress(line) {
                            Task { @MainActor in self?.syncProgress = label }
                        }
                    }
                }
            }
            do {
                try proc.run()
                proc.waitUntilExit()
                errHandle.readabilityHandler = nil
                if proc.terminationStatus != 0 {
                    let leftover = bufferState.flush()
                    let msg = leftover.isEmpty
                        ? "exit \(proc.terminationStatus)"
                        : leftover
                    let trimmed = msg.split(separator: "\n").suffix(3).joined(separator: " ")
                    await MainActor.run { [weak self] in
                        self?.lastError = "Sync exited \(proc.terminationStatus). \(trimmed)"
                    }
                }
            } catch {
                errHandle.readabilityHandler = nil
                await MainActor.run { [weak self] in
                    self?.lastError = "Couldn't launch sync: \(error.localizedDescription)"
                }
            }
            await MainActor.run { [weak self] in
                self?.syncing = false
                self?.syncProgress = ""
                self?.reloadAll()
                self?.detectMountedRekordbox()
            }
        }
    }

    /// Map the most common set_memory.py log-line patterns to short
    /// button labels. Anything unrecognised returns nil so the button
    /// keeps the last-known label.
    /// nonisolated so the background readabilityHandler can call this
    /// without hopping back to MainActor for every line of stderr.
    nonisolated static func parseSyncProgress(_ line: String) -> String? {
        if line.contains("Found ") && line.contains("CDJ-export USB") {
            return "Reading USB"
        }
        if line.contains("Ingested session") {
            return "Saving sessions"
        }
        if line.contains("v3 dedup") {
            return "Deduping"
        }
        if line.contains("Analysis error") || line.contains("Schema") {
            return "Indexing"
        }
        if line.contains("Done.") {
            return "Done"
        }
        return nil
    }

    // MARK: - File watcher (auto-refresh after launchd sync)

    private func startFileWatcher() {
        let fd = open(stateDbPath, O_EVTONLY)
        guard fd >= 0 else { return }
        let src = DispatchSource.makeFileSystemObjectSource(
            fileDescriptor: fd,
            eventMask: [.write, .extend, .rename, .delete],
            queue: DispatchQueue.global(qos: .utility))
        src.setEventHandler { [weak self] in
            // Coalesce bursts of writes from an active ingest into a single
            // reload after a quiet period - otherwise we fire dozens of
            // overlapping queries per second and the UI thrashes.
            Task { @MainActor in
                self?.scheduleCoalescedReload()
            }
        }
        src.setCancelHandler { close(fd) }
        src.resume()
        fileWatcher = src
    }

    private func scheduleCoalescedReload() {
        fileWatcherCoalesce?.cancel()
        // Skip entirely while the app is inactive - we'll reload on
        // didBecomeActiveNotification with a forced data_version reset.
        guard appActive else { return }
        let item = DispatchWorkItem { [weak self] in
            Task { @MainActor in self?.reloadAll() }
        }
        fileWatcherCoalesce = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45, execute: item)
    }

    // MARK: - Suggestions + rekordbox playlist write

    /// Like reloadSuggestions but obeys a minimum-interval cooldown to
    /// avoid bursting the Python interpreter cold-start cost during
    /// active ingest. Manual refresh entry points should call
    /// reloadSuggestions directly.
    func reloadSuggestionsThrottled() {
        let elapsed = Date().timeIntervalSince(lastSuggesterRunAt)
        if elapsed < suggesterMinInterval { return }
        lastSuggesterRunAt = Date()
        reloadSuggestions()
    }

    /// Run the Python suggester. Results are cached in `suggestions`.
    /// Called automatically after every reloadAll(); also exposed as
    /// `Refresh suggestions` in the GUI.
    func reloadSuggestions() {
        lastSuggesterRunAt = Date()
        let py = pythonPath
        let script = scriptPath
        let includeDismissed = showDismissedSuggestions
        Task.detached(priority: .utility) { [weak self] in
            let proc = Process()
            proc.executableURL = URL(fileURLWithPath: py)
            var args = [script, "suggestions"]
            if includeDismissed { args.append("--include-dismissed") }
            proc.arguments = args
            let out = Pipe()
            proc.standardOutput = out
            proc.standardError = Pipe()  // discard
            do {
                try proc.run()
                proc.waitUntilExit()
                let data = out.fileHandleForReading.readDataToEndOfFile()
                guard let raw = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
                    return
                }
                let parsed: [PlaylistSuggestion] = raw.compactMap { dict in
                    guard let id = dict["id"] as? String,
                          let name = dict["name"] as? String,
                          let kind = dict["kind"] as? String,
                          let description = dict["description"] as? String,
                          let ids = dict["content_ids"] as? [String]
                    else { return nil }
                    return PlaylistSuggestion(
                        id: id, name: name, kind: kind, description: description,
                        contentIDs: ids,
                        rationale: (dict["rationale"] as? String) ?? "",
                        score: (dict["score"] as? Double) ?? 0,
                        dismissed: (dict["dismissed"] as? Bool) ?? false,
                    )
                }
                await MainActor.run { [weak self] in
                    self?.suggestions = parsed
                }
            } catch {
                // suggestions are best-effort; don't surface errors
            }
        }
    }

    func dismissSuggestion(_ suggestion: PlaylistSuggestion) {
        runSuggestionsCommand(["dismiss-suggestion", suggestion.id])
    }

    func undismissSuggestion(_ suggestion: PlaylistSuggestion) {
        runSuggestionsCommand(["undismiss-suggestion", suggestion.id])
    }

    func undismissAllSuggestions() {
        runSuggestionsCommand(["undismiss-suggestion", "--all"])
    }

    /// Drop a "Possibly Deleted" track from state.db entirely. The
    /// audit flagged that the Deleted surface was display-only with no
    /// way for the user to act on its rows. This gives them a direct
    /// "forget this" affordance. Idempotent.
    func forgetDeletedCandidate(_ candidate: DeletedCandidate) {
        let path = stateDbPath
        let cid = candidate.contentID
        Task.detached(priority: .userInitiated) { [weak self] in
            var handle: OpaquePointer?
            guard sqlite3_open_v2(path, &handle,
                                  SQLITE_OPEN_READWRITE, nil) == SQLITE_OK,
                  let h = handle else { return }
            defer { sqlite3_close_v2(h) }
            sqlite3_busy_timeout(h, 3000)
            let twoArgPattern = "track_aliases"
            for sql in [
                "DELETE FROM appearances WHERE content_id = ?",
                "DELETE FROM track_aliases WHERE alias_content_id = ? OR canonical_content_id = ?",
                "DELETE FROM playlist_tracks WHERE content_id = ?",
                "DELETE FROM tracks WHERE content_id = ?",
            ] {
                var stmt: OpaquePointer?
                if sqlite3_prepare_v2(h, sql, -1, &stmt, nil) == SQLITE_OK,
                   let s = stmt {
                    let SQLITE_TRANSIENT = unsafeBitCast(OpaquePointer(bitPattern: -1)!, to: sqlite3_destructor_type.self)
                    sqlite3_bind_text(s, 1, cid, -1, SQLITE_TRANSIENT)
                    if sql.contains(twoArgPattern) {
                        sqlite3_bind_text(s, 2, cid, -1, SQLITE_TRANSIENT)
                    }
                    _ = sqlite3_step(s)
                    sqlite3_finalize(s)
                }
            }
            await MainActor.run { [weak self] in
                self?.lastSeenDataVersion = -1
                self?.reloadAll()
            }
        }
    }

    private func runSuggestionsCommand(_ extraArgs: [String]) {
        let py = pythonPath
        let script = scriptPath
        Task.detached(priority: .userInitiated) { [weak self] in
            let proc = Process()
            proc.executableURL = URL(fileURLWithPath: py)
            proc.arguments = [script] + extraArgs
            proc.standardOutput = Pipe()
            proc.standardError = Pipe()
            try? proc.run()
            proc.waitUntilExit()
            await MainActor.run { [weak self] in self?.reloadSuggestions() }
        }
    }

    /// One-click: hand a suggestion's content_ids to Python's
    /// rekordbox_writer via the create-playlist CLI. Surfaces the JSON
    /// result back as `lastPlaylistResult` so the GUI can show a banner.
    func createPlaylist(from suggestion: PlaylistSuggestion) {
        guard creatingPlaylistID == nil else { return }
        creatingPlaylistID = suggestion.id
        let py = pythonPath
        let script = scriptPath
        let name = suggestion.name
        let sid = suggestion.id
        Task.detached(priority: .userInitiated) { [weak self] in
            let proc = Process()
            proc.executableURL = URL(fileURLWithPath: py)
            proc.arguments = [script, "create-playlist", name, "--suggestion", sid]
            let out = Pipe()
            proc.standardOutput = out
            proc.standardError = Pipe()
            var message = "Created."
            do {
                try proc.run()
                proc.waitUntilExit()
                let data = out.fileHandleForReading.readDataToEndOfFile()
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if let err = json["error"] as? String {
                        message = "rekordbox: \(err)"
                    } else if let added = json["tracks_added"] as? Int {
                        let unmatched = json["unmatched"] as? Int ?? 0
                        message = "\(name): added \(added) track(s)" +
                                  (unmatched > 0 ? "; \(unmatched) unmatched" : "")
                    }
                } else {
                    message = "rekordbox returned unexpected output"
                }
            } catch {
                message = "couldn't launch rekordbox writer: \(error.localizedDescription)"
            }
            await MainActor.run { [weak self] in
                self?.creatingPlaylistID = nil
                self?.lastPlaylistResult = message
            }
        }
    }

    // MARK: - Track file actions

    /// Resolve a track's stored file_path to an absolute reachable URL.
    /// - Pioneer-relative paths ("/Contents/..." from .pdb) are tried
    ///   against every currently-mounted rekordbox USB until one finds
    ///   the file on disk.
    /// - Absolute paths (master.db FolderPath+FileNameL) are used directly.
    /// Returns nil if the file isn't currently reachable.
    func resolveFile(for track: Track) -> URL? {
        guard let raw = track.filePath, !raw.isEmpty else { return nil }
        let fm = FileManager.default
        if raw.hasPrefix("/Volumes/") || raw.hasPrefix("/Users/") {
            let url = URL(fileURLWithPath: raw)
            return fm.fileExists(atPath: url.path) ? url : nil
        }
        // Pioneer-relative: walk mounted USBs.
        for label in mountedRekordboxUsbs {
            let candidate = URL(fileURLWithPath: "/Volumes/\(label)\(raw)")
            if fm.fileExists(atPath: candidate.path) { return candidate }
        }
        return nil
    }

    func playTrack(_ track: Track) {
        guard let url = resolveFile(for: track) else {
            lastError = "Track file not reachable. Plug the USB it lives on, or sync rekordbox to populate the absolute path."
            return
        }
        NSWorkspace.shared.open(url)
    }

    func revealTrackInFinder(_ track: Track) {
        guard let url = resolveFile(for: track) else {
            lastError = "Track file not reachable. Plug the USB it lives on, or sync rekordbox to populate the absolute path."
            return
        }
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }

    // MARK: - Mounted-USB detection

    func detectMountedRekordbox() {
        let fm = FileManager.default
        let volumes = (try? fm.contentsOfDirectory(atPath: "/Volumes")) ?? []
        var labels: [String] = []
        for v in volumes {
            // Two valid CDJ-export USB layouts:
            //   - desktop-rekordbox export: PIONEER/Master/master.db (SQLCipher)
            //   - CDJ export mode:          PIONEER/rekordbox/export.pdb (DeviceSQL)
            // Either qualifies the USB as ingestable.
            let master = "/Volumes/\(v)/PIONEER/Master/master.db"
            let pdb    = "/Volumes/\(v)/PIONEER/rekordbox/export.pdb"
            if fm.fileExists(atPath: master) || fm.fileExists(atPath: pdb) {
                labels.append(v)
            }
        }
        mountedRekordboxUsbs = labels
        detectRekordboxRunning()
    }

    /// Cheap, fast: scan NSWorkspace.runningApplications for a bundle
    /// identifier starting with "com.pioneerdj.rekordbox". No
    /// subprocess; no I/O. Refresh on every USB-event tick so the
    /// Create button gates correctly.
    func detectRekordboxRunning() {
        let running = NSWorkspace.shared.runningApplications.contains { app in
            (app.bundleIdentifier ?? "").hasPrefix("com.pioneerdj.rekordbox")
        }
        if running != rekordboxRunning { rekordboxRunning = running }
    }

    // MARK: - Config / thresholds

    private struct ConfigOnDisk: Codable {
        var forgotten_min_appearances: Int?
        var forgotten_days_since_last: Int?
        var forgotten_limit: Int?
        var never_played_min_days_since_add: Int?
        var never_played_limit: Int?
        var recently_added_window_days: Int?
        var recently_added_limit: Int?
        var prep_limit: Int?
        var co_appearance_min_sessions: Int?
        var co_appearance_limit: Int?
        var deleted_stale_days: Int?
        var deleted_limit: Int?
        var sparkline_months: Int?
    }

    private func loadThresholdsFromDisk() {
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: configPath)),
              let parsed = try? JSONDecoder().decode(ConfigOnDisk.self, from: data) else {
            return
        }
        var t = Thresholds()
        if let v = parsed.forgotten_min_appearances { t.forgottenMinAppearances = v }
        if let v = parsed.forgotten_days_since_last { t.forgottenDaysSinceLast = v }
        if let v = parsed.forgotten_limit { t.forgottenLimit = v }
        if let v = parsed.never_played_min_days_since_add { t.neverPlayedMinDaysSinceAdd = v }
        if let v = parsed.never_played_limit { t.neverPlayedLimit = v }
        if let v = parsed.recently_added_window_days { t.recentlyAddedWindowDays = v }
        if let v = parsed.recently_added_limit { t.recentlyAddedLimit = v }
        if let v = parsed.co_appearance_min_sessions { t.coAppearanceMinSessions = v }
        if let v = parsed.co_appearance_limit { t.coAppearanceLimit = v }
        if let v = parsed.deleted_stale_days { t.deletedStaleDays = v }
        if let v = parsed.deleted_limit { t.deletedLimit = v }
        if let v = parsed.sparkline_months { t.sparklineMonths = v }
        thresholds = t
    }

    func saveThresholdsToDisk() {
        // Preserve any keys we don't know about by merging into existing JSON.
        var dict: [String: Any] = [:]
        if let data = try? Data(contentsOf: URL(fileURLWithPath: configPath)),
           let existing = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            dict = existing
        }
        dict["forgotten_min_appearances"] = thresholds.forgottenMinAppearances
        dict["forgotten_days_since_last"] = thresholds.forgottenDaysSinceLast
        dict["forgotten_limit"] = thresholds.forgottenLimit
        dict["never_played_min_days_since_add"] = thresholds.neverPlayedMinDaysSinceAdd
        dict["never_played_limit"] = thresholds.neverPlayedLimit
        dict["recently_added_window_days"] = thresholds.recentlyAddedWindowDays
        dict["recently_added_limit"] = thresholds.recentlyAddedLimit
        dict["co_appearance_min_sessions"] = thresholds.coAppearanceMinSessions
        dict["co_appearance_limit"] = thresholds.coAppearanceLimit
        dict["deleted_stale_days"] = thresholds.deletedStaleDays
        dict["deleted_limit"] = thresholds.deletedLimit
        dict["sparkline_months"] = thresholds.sparklineMonths
        guard let out = try? JSONSerialization.data(withJSONObject: dict,
                                                    options: [.prettyPrinted, .sortedKeys]) else {
            lastError = "Could not encode config.json"
            return
        }
        do {
            try out.write(to: URL(fileURLWithPath: configPath), options: .atomic)
        } catch {
            lastError = "Could not write config.json: \(error.localizedDescription)"
            return
        }
        reloadAll()
    }
}

/// Tiny buffered line-splitter for stderr-streaming. Pipe
/// readabilityHandlers fire on background queues so we accumulate
/// chunks and emit complete lines as they finalise. Class so the
/// closure can mutate it across firings without `inout`. Locked
/// internally - Sendable via @unchecked because the lock makes that safe.
final class MutableBuffer: @unchecked Sendable {
    private var buffer = ""
    private let lock = NSLock()
    func append(_ s: String) {
        lock.lock(); defer { lock.unlock() }
        buffer.append(s)
    }
    func takeLines() -> [String] {
        lock.lock(); defer { lock.unlock() }
        guard buffer.contains("\n") else { return [] }
        var lines = buffer.split(separator: "\n", omittingEmptySubsequences: false)
            .map(String.init)
        let last = lines.removeLast()
        buffer = last
        return lines
    }
    func flush() -> String {
        lock.lock(); defer { lock.unlock() }
        let out = buffer
        buffer = ""
        return out
    }
}
