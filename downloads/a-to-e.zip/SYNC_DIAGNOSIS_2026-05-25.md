# Cross-device sync diagnosis - 2026-05-25

## (a) What data is supposed to sync across devices?

| Field | Client write | POST to worker | D1 storage | Read back on new device |
|---|---|---|---|---|
| Answer letter chosen (shuffled-back-to-source) | `state.history[q.id]` in `onSubmit` (app.js:1640) | `cloudPostAnswer(qid, sourceLetter, isC)` -> `POST /api/answer` (app.js:1652) | `answers (user_id, question_id, source_letter, correct, ts)` UNIQUE(user_id, question_id) | `GET /api/history` (app.js:126 -> worker.js:592) - but only returns `{lastCorrect, count:1, last_at}` |
| Correct/incorrect flag | same row | same | `correct` column | `lastCorrect` |
| Attempt timestamp | `state.history[q.id].last_at` | implicit (worker stamps server time) | `ts` column (seconds) | `last_at` (ms = ts * 1000) |
| Attempt count | `state.history[q.id].count` | NOT sent | NOT stored | hard-coded as `1` in handleHistory |
| time_ms_total | `state.history[q.id].time_ms_total` | NOT sent | NOT stored | NEVER syncs |
| first_correct | `state.history[q.id].first_correct` | NOT sent | NOT stored | NEVER syncs |
| Question flag (star) | `state.flags[q.id]` in flagBtn.onclick (app.js:1593) | NEVER POSTed | NO TABLE | NEVER syncs |
| Settings (mode/timer/count/disciplines/subtopics/filter) | `saveSettings()` -> `ns(SETTINGS_KEY)` | NEVER POSTed | NO TABLE | NEVER syncs |
| Reminder dismiss / theme / Anki-hover | localStorage only | NEVER POSTed | none | per-device |
| Local pasted questions | `LOCAL_QUESTIONS_KEY` | NEVER POSTed (separate /paste flow is for inbox, not per-user) | none | per-device |
| Display name / email / is_admin | server-owned (set at register/admin promote) | server | `users` table | `/api/me` |

The deployed answer endpoint uses `INSERT OR IGNORE` (worker.js:581), so **only the first answer per (user, question) is ever recorded**. Re-attempts (and any subsequent correctness change) are silently dropped on the server.

## (b) Where does the data flow break? (every failure mode)

### Smoking-gun failure (this is what Rob sees)

1. **/api/history is not deployed.** `curl https://a-to-e-inbox.mord58562.workers.dev/api/history` returns `HTTP 405 {"ok":false,"error":"POST only"}`. The worker.js source has the GET handler (worker.js:53, 592) but Rob has not run `wrangler deploy` since the UI agent added it. `cloudFetchHistory` catches the error silently (app.js:131) and returns `{}` - so the new device hydrates with an empty history and shows everything as unseen.

### Secondary failure modes that would still bite even after deploy

2. **`INSERT OR IGNORE` on /api/answer (worker.js:581).** First-ever answer wins. If the user answered Q42 wrong on device A then right on device B, the D1 row stays `correct=0` forever; "Previously incorrect" keeps surfacing it. There is no write path for correctness updates.

3. **Question flags never POST.** `state.flags[q.id] = !state.flags[q.id]` -> `save(ns(FLAGS_KEY), state.flags)` (app.js:1593-1594). No `cloudPostFlag`, no `/api/flag` endpoint, no `flags` table. Filter=`flagged` on device B sees nothing the user flagged on device A.

4. **Settings never sync.** Mode/timer/count/discipline filters live in `ns(SETTINGS_KEY)` localStorage only. Each device starts at the defaults.

5. **Hydration merge is biased toward stale local.** app.js:541-561: when `local` exists, only `lastCorrect`/`last_at` are refreshed from remote; the merge keeps the LOCAL `count`. If device B had a stale guest-import row with a higher count, device A's authoritative attempt would be ignored. The `merged` flag also doesn't track lastCorrect-only updates as a separate concern.

6. **Race window: pool can be built before history arrives.** `await passGate(); ... await cloudFetchHistory(); await dataPromise; ... showHome()` - this is actually serialized correctly (lines 532-583). Not a real bug post-deploy, but the design relies on success; a slow `/api/history` call now blocks home render with no skeleton.

7. **Legacy guest-history import + cloud hydration order can double-count.** `loadProfileState()` reads localStorage first, then merges remote. If the user signed up earlier and `migrateGuestHistoryIntoCloud` (app.js:1102) ran fire-and-forget `cloudPostAnswer` calls, those writes hit `INSERT OR IGNORE` and may or may not have committed before the new device queries. Mostly harmless, but adds noise.

8. **`source_letter: ""` from guest-replay path.** app.js:1131 calls `cloudPostAnswer(qid, "", !!h.lastCorrect)` with empty letter. The worker rejects that (`if (!"ABCDE".includes(srcLetter)) return 400`). The catch-block in `cloudPostAnswer` swallows the 400 silently, so those guest answers never make it to the server.

9. **No retry queue for offline answers.** `cloudPostAnswer` is fire-and-forget. If the network blips while answering, the local `state.history` records the answer but the server never sees it. New device shows it as unseen.

10. **Question-id drift (`-r2` suffixes).** When a Q is substantively revised, the convention is to suffix `-r2`. Server-side rows are keyed by the OLD id; the new id reads as unseen. Out of scope for this fix (it's an intentional "treat as new" behaviour per the user memory), but worth flagging.

11. **No version column.** D1 has only `ts`. If two devices race the same write, last-writer-wins by row order, not by clock - but the unique constraint + INSERT-OR-IGNORE actually makes it first-writer-wins, which is also wrong.

12. **Stale localStorage between accounts on the same browser.** Sign out of A, sign in as B on the same browser - the `ns()` function does correctly namespace per `cloud-<userId>`, but if B's `/api/history` hydration partially fails, the screen reads from whatever's in `ns(HISTORY_KEY).cloud-<B.id>` which may be a stale fragment from a previous failed hydration. No "replace local with server" semantics; merge is union.

### Failure modes ruled OUT after inspection

- Auth header missing: `apiFetch` correctly attaches Bearer (app.js:82).
- CORS: worker sets `Allow-Origin: *` or env value (worker.js:91); GET/POST/OPTIONS all listed.
- Schema migration / Argon2id: orthogonal to history; login still works on both legacy and migrated rows.
- HTTP cache: worker sets `Cache-Control: no-store` (worker.js:639). Not a stale-cache problem.
- Session token tied to device: it isn't - the token is a Bearer string in localStorage and the same email login on device B gets its own valid token covering the same `user_id`.

### Root cause for the observed symptom

**Failure mode #1 alone explains the entire user-visible bug.** Without `/api/history` deployed, every device that isn't the original sees an empty history and an empty flag set, regardless of what's actually in D1. Modes #3, #4 (flags and settings) compound this even after deploy.

## (c) Correct-by-construction sync model

Principles, in order of importance:

1. **Server is the single source of truth.** Every per-user mutable field (answers, flags, settings) lives in D1; client cache is a read-through read-through copy you can throw away.
2. **Writes are awaited and acknowledged.** No fire-and-forget for state-of-record changes. The UI may show an optimistic flip, but the local cache only commits when the server returns ok. Failures queue for retry and show an indicator.
3. **Every row carries a monotonically increasing `updated_at`** (server-stamped). Conflict resolution is newest-wins per (user, question, field).
4. **`/api/answer` is UPSERT, not INSERT-OR-IGNORE.** Each new attempt updates `correct`, `source_letter`, `ts`, `count`, `updated_at`. Aggregate stats use COUNT(*) over the answers history table (separate from per-user latest state) - or accept that aggregate is "latest-state" only, which is fine for the existing bars.
5. **`/api/history` returns the full per-user state - answers AND flags AND settings - in one round-trip** so the new device has everything before first paint.
6. **On any session start (cloud user), drop the cloud-namespaced localStorage and replace it with the server response.** No "merge" semantics. Local is a cache, not co-equal state.
7. **Question-id namespace is stable.** When a Q is revised with `-r2`, the OLD id is still counted in the user's answered set (so it doesn't reappear as unseen), AND the new id is independent. This is already the project convention; document it.
8. **Network failure -> retry queue.** Pending writes sit in localStorage under a `pending_ops` key. On reconnect, flush in order. UI shows a small "syncing" dot when the queue is non-empty.
9. **Anonymous (guest) progress is explicitly local-only.** On signup, the guest cache is migrated to the cloud account through awaited writes (not fire-and-forget), with retries.
10. **Test:** sign in on browser B immediately after browser A answers a Q. `/api/history` returns the row; pool builder sees it; filter behaves correctly. Repeat for flag and for settings.

## Fix scope chosen for this session

- Deploy-ready `/api/history` (already in source; only needs `wrangler deploy`).
- Replace INSERT-OR-IGNORE with proper UPSERT (`ON CONFLICT ... DO UPDATE`).
- Add `/api/flag` POST + `/api/state` GET (one round-trip for answers + flags + settings).
- Add `flags` and `settings` D1 tables (additive migration).
- Client: replace merge-bias-toward-local with "server wins on session start"; await flag writes; await settings writes.
- Surface sync failures in console (not silent).
- Keep the retry queue as a follow-up (called out in final report) - shipping the schema/UPSERT/state-sync first is the load-bearing change.
