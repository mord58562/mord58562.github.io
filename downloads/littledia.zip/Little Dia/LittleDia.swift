// LittleDia.swift - Floating search window
// Copyright (c) 2026 mord58562 & Claude (Anthropic)
// Licensed under the MIT License. See LICENSE file in the project root.
// Dark mode uses techniques from Dark Reader (MIT License, darkreader.org)
//
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED. IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

import Cocoa
import WebKit
import Carbon.HIToolbox

// ═══════════════════════════════════════════════════════
//  MARK: - Config
// ═══════════════════════════════════════════════════════

struct C {
    static let omniW: CGFloat = 520; static let omniH: CGFloat = 340
    static let defBW: CGFloat = 1007; static let defBH: CGFloat = 666
    static let toolbarH: CGFloat = 30; static let itemH: CGFloat = 24
    static let note = "com.littledia.toggle"; static let bundleId = "com.littledia.app"
    static let chromeUA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    static let bfKey = "ld.bf"; static let opKey = "ld.op"
    static let disabledKey = "ld.disabled"; static let browserKey = "ld.browser"
    static let autoCloseKey = "ld.autoClose"; static let darkModeKey = "ld.darkMode"
    static let lastUsedKey = "ld.lastUsed"
    static let defaultAutoClose: TimeInterval = 300
    static let baseDir = "\(NSHomeDirectory())/.little-dia"
    static let scriptsDir = "\(baseDir)/scripts"
}

// ═══════════════════════════════════════════════════════
//  MARK: - Browser Profiles
// ═══════════════════════════════════════════════════════

struct BrowserProfile {
    let id: String; let name: String; let incognito: String
    let histPaths: [String]; let localState: String?; let isChromium: Bool
    var isInstalled: Bool {
        if NSWorkspace.shared.urlForApplication(withBundleIdentifier: id) != nil { return true }
        for path in histPaths { if FileManager.default.fileExists(atPath: path) { return true } }
        return false
    }
}

let allBrowsers: [BrowserProfile] = {
    let h = NSHomeDirectory()
    return [
        BrowserProfile(id: "so.dia.Dia", name: "Dia", incognito: "--incognito",
            histPaths: ["\(h)/Library/Application Support/Dia/User Data/Default/History"],
            localState: "\(h)/Library/Application Support/Dia/User Data/Local State", isChromium: true),
        BrowserProfile(id: "company.thebrowser.Browser", name: "Arc", incognito: "--incognito",
            histPaths: ["\(h)/Library/Application Support/Arc/User Data/Default/History",
                        "\(h)/Library/Application Support/Arc/User Data/Profile 1/History"],
            localState: "\(h)/Library/Application Support/Arc/User Data/Local State", isChromium: true),
        BrowserProfile(id: "com.apple.Safari", name: "Safari", incognito: "private",
            histPaths: ["\(h)/Library/Safari/History.db"], localState: nil, isChromium: false),
        BrowserProfile(id: "com.google.Chrome", name: "Chrome", incognito: "--incognito",
            histPaths: ["\(h)/Library/Application Support/Google/Chrome/Default/History",
                        "\(h)/Library/Application Support/Google/Chrome/Profile 1/History"],
            localState: "\(h)/Library/Application Support/Google/Chrome/Local State", isChromium: true),
        BrowserProfile(id: "com.brave.Browser", name: "Brave", incognito: "--incognito",
            histPaths: ["\(h)/Library/Application Support/BraveSoftware/Brave-Browser/Default/History"],
            localState: "\(h)/Library/Application Support/BraveSoftware/Brave-Browser/Local State", isChromium: true),
        BrowserProfile(id: "com.operasoftware.Opera", name: "Opera", incognito: "--private",
            histPaths: ["\(h)/Library/Application Support/com.operasoftware.Opera/History"],
            localState: nil, isChromium: true),
        BrowserProfile(id: "com.microsoft.edgemac", name: "Edge", incognito: "--inprivate",
            histPaths: ["\(h)/Library/Application Support/Microsoft Edge/Default/History"],
            localState: "\(h)/Library/Application Support/Microsoft Edge/Local State", isChromium: true),
        BrowserProfile(id: "com.vivaldi.Vivaldi", name: "Vivaldi", incognito: "--incognito",
            histPaths: ["\(h)/Library/Application Support/Vivaldi/Default/History"],
            localState: "\(h)/Library/Application Support/Vivaldi/Local State", isChromium: true),
        BrowserProfile(id: "org.mozilla.firefox", name: "Firefox", incognito: "-private-window",
            histPaths: [], localState: nil, isChromium: false),
    ]
}()

func installedBrowsers() -> [BrowserProfile] { allBrowsers.filter { $0.isInstalled } }
func browserById(_ id: String) -> BrowserProfile? { allBrowsers.first { $0.id.lowercased() == id.lowercased() } }

// ═══════════════════════════════════════════════════════
//  MARK: - Global Hotkey
// ═══════════════════════════════════════════════════════

var hotKeyRef: EventHotKeyRef?; var globalHotkeyCallback: (() -> Void)?
func registerGlobalHotkey(callback: @escaping () -> Void) {
    globalHotkeyCallback = callback
    var evType = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
    InstallEventHandler(GetApplicationEventTarget(), { (_, _, _) -> OSStatus in globalHotkeyCallback?(); return noErr }, 1, &evType, nil, nil)
    let hkID = EventHotKeyID(signature: OSType(0x4C44), id: 1)
    RegisterEventHotKey(UInt32(kVK_ANSI_E), UInt32(cmdKey), hkID, GetApplicationEventTarget(), 0, &hotKeyRef)
}

// ═══════════════════════════════════════════════════════
//  MARK: - Views
// ═══════════════════════════════════════════════════════

class KeyPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

class ToolbarView: NSView {
    override var mouseDownCanMoveWindow: Bool { true }
}

class URLBarView: NSView { override var mouseDownCanMoveWindow: Bool { false } }

class AutoSelectTextField: NSTextField {
    weak var browserWin: BrowserWin?
    private var jf = false
    override func becomeFirstResponder() -> Bool {
        let r = super.becomeFirstResponder()
        if r {
            jf = true
            if let bw = browserWin, let u = bw.webView.url { self.stringValue = u.absoluteString }
            self.textColor = NSColor(white: 1, alpha: 0.90)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { [weak self] in
                self?.currentEditor()?.selectAll(nil); self?.jf = false
            }
        }
        return r
    }
    override func mouseDown(with e: NSEvent) {
        if currentEditor() != nil && !jf { super.mouseDown(with: e) }
        else { window?.makeFirstResponder(self) }
    }
}

// ═══════════════════════════════════════════════════════
//  MARK: - Ad Block
// ═══════════════════════════════════════════════════════

let adBlockJSON = """
[{"trigger":{"url-filter":"googlesyndication\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"doubleclick\\\\.net"},"action":{"type":"block"}},{"trigger":{"url-filter":"adservice\\\\.google"},"action":{"type":"block"}},{"trigger":{"url-filter":"pagead2\\\\.googlesyndication"},"action":{"type":"block"}},{"trigger":{"url-filter":"amazon-adsystem\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"facebook\\\\.com/tr"},"action":{"type":"block"}},{"trigger":{"url-filter":"analytics\\\\.tiktok\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"ad\\\\.doubleclick\\\\.net"},"action":{"type":"block"}},{"trigger":{"url-filter":"cdn\\\\.taboola\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"cdn\\\\.outbrain\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"criteo\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"adnxs\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"pubmatic\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"moatads\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":"hotjar\\\\.com"},"action":{"type":"block"}},{"trigger":{"url-filter":".*\\\\/adsbygoogle"},"action":{"type":"block"}},{"trigger":{"url-filter":".*\\\\/pagead\\\\/"},"action":{"type":"block"}}]
"""
var compiledAdBlockRule: WKContentRuleList?
func compileAdBlock() {
    WKContentRuleListStore.default()?.compileContentRuleList(forIdentifier: "ldAB", encodedContentRuleList: adBlockJSON) { l, _ in
        if let l = l { compiledAdBlockRule = l }
    }
}

// ═══════════════════════════════════════════════════════
//  MARK: - History
// ═══════════════════════════════════════════════════════

struct HistEntry { let url: String; let title: String; var frecency: Double = 0 }

func loadAllHistory(done: @escaping ([HistEntry]) -> Void) {
    DispatchQueue.global(qos: .userInitiated).async {
        var all: [HistEntry] = []; var idx = 0
        for b in installedBrowsers() where b.isChromium {
            all += loadChromiumHist(b.histPaths, idx: &idx)
        }
        all += loadFirefoxHist(&idx)
        let safariDB = "\(NSHomeDirectory())/Library/Safari/History.db"
        if FileManager.default.fileExists(atPath: safariDB) { all += loadSafariHist(&idx) }
        var best: [String: HistEntry] = [:]
        for e in all { if e.frecency > (best[e.url]?.frecency ?? 0) { best[e.url] = e } }
        var result = Array(best.values); result.sort { $0.frecency > $1.frecency }
        DispatchQueue.main.async { done(result) }
    }
}

func loadChromiumHist(_ paths: [String], idx: inout Int) -> [HistEntry] {
    var entries: [HistEntry] = []; let now = Date().timeIntervalSince1970
    for path in paths {
        guard FileManager.default.fileExists(atPath: path) else { continue }
        let tmp = "/tmp/ld_h\(idx).db"; idx += 1
        try? FileManager.default.removeItem(atPath: tmp)
        try? FileManager.default.copyItem(atPath: path, toPath: tmp)
        try? FileManager.default.copyItem(atPath: path + "-wal", toPath: tmp + "-wal")
        try? FileManager.default.copyItem(atPath: path + "-shm", toPath: tmp + "-shm")
        guard let rows = sqliteJSON(tmp, "SELECT url, title, visit_count, typed_count, last_visit_time FROM urls WHERE hidden=0 AND title!='' ORDER BY last_visit_time DESC LIMIT 200;") else { continue }
        for row in rows {
            guard let url = row["url"] as? String, let title = row["title"] as? String else { continue }
            let vc = (row["visit_count"] as? Int) ?? 1
            let tc = (row["typed_count"] as? Int) ?? 0
            let lvt = (row["last_visit_time"] as? Int64) ?? 0
            let ut = Double(lvt) / 1e6 - 11644473600.0
            let age = now - ut
            let r: Double = age < 14400 ? 100.0 : age < 86400 ? 70.0 : age < 604800 ? 50.0 : age < 2592000 ? 30.0 : 10.0
            let vw = min(Double(vc), 10.0) / 2.0 + 1.0
            let tw: Double = tc > 0 ? 2.0 : 1.0
            entries.append(HistEntry(url: url, title: title, frecency: r * vw * tw))
        }
    }
    return entries
}

func loadFirefoxHist(_ idx: inout Int) -> [HistEntry] {
    let dir = "\(NSHomeDirectory())/Library/Application Support/Firefox/Profiles"
    guard let ls = try? FileManager.default.contentsOfDirectory(atPath: dir) else { return [] }
    var entries: [HistEntry] = []
    for d in ls where d.hasSuffix(".default-release") || d.hasSuffix(".default") {
        let db = "\(dir)/\(d)/places.sqlite"
        guard FileManager.default.fileExists(atPath: db) else { continue }
        let tmp = "/tmp/ld_h\(idx).db"; idx += 1
        try? FileManager.default.removeItem(atPath: tmp)
        try? FileManager.default.copyItem(atPath: db, toPath: tmp)
        try? FileManager.default.copyItem(atPath: db + "-wal", toPath: tmp + "-wal")
        guard let rows = sqliteJSON(tmp, "SELECT url, title, frecency FROM moz_places WHERE hidden=0 AND title IS NOT NULL AND title!='' ORDER BY frecency DESC LIMIT 200;") else { continue }
        for row in rows {
            guard let url = row["url"] as? String, let title = row["title"] as? String else { continue }
            let fr = (row["frecency"] as? Int) ?? 0
            entries.append(HistEntry(url: url, title: title, frecency: max(Double(fr) / 16.0, 1.0)))
        }
    }
    return entries
}

func loadSafariHist(_ idx: inout Int) -> [HistEntry] {
    let db = "\(NSHomeDirectory())/Library/Safari/History.db"
    let tmp = "/tmp/ld_h\(idx).db"; idx += 1
    try? FileManager.default.removeItem(atPath: tmp)
    try? FileManager.default.copyItem(atPath: db, toPath: tmp)
    guard let rows = sqliteJSON(tmp, "SELECT hi.url, hv.title, hi.visit_count, hv.visit_time FROM history_items hi JOIN history_visits hv ON hi.id=hv.history_item WHERE hv.title IS NOT NULL AND hv.title!='' GROUP BY hi.url ORDER BY hv.visit_time DESC LIMIT 200;") else { return [] }
    var entries: [HistEntry] = []; let now = Date().timeIntervalSince1970
    for row in rows {
        guard let url = row["url"] as? String, let title = row["title"] as? String else { continue }
        let vc = (row["visit_count"] as? Int) ?? 1
        let vt = (row["visit_time"] as? Double) ?? 0
        let age = now - (vt + 978307200.0)
        let r: Double = age < 14400 ? 100.0 : age < 86400 ? 70.0 : age < 604800 ? 50.0 : age < 2592000 ? 30.0 : 10.0
        entries.append(HistEntry(url: url, title: title, frecency: r * (min(Double(vc), 10.0) / 2.0 + 1.0)))
    }
    return entries
}

func sqliteJSON(_ db: String, _ sql: String) -> [[String: Any]]? {
    let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/sqlite3")
    p.arguments = ["-json", "-readonly", db, sql]
    let pipe = Pipe(); p.standardOutput = pipe; p.standardError = FileHandle.nullDevice
    try? p.run(); p.waitUntilExit()
    let d = pipe.fileHandleForReading.readDataToEndOfFile()
    guard !d.isEmpty else { return nil }
    return try? JSONSerialization.jsonObject(with: d) as? [[String: Any]]
}

var cachedHist: [HistEntry] = []; var histLoaded = false
func refreshHistory(done: @escaping ([HistEntry]) -> Void) {
    loadAllHistory { e in cachedHist = e; histLoaded = true; done(e) }
}

func addToSelectedBrowserHistory(_ url: String, _ title: String, _ browserPaths: [String]) {
    var dbPath: String?
    for path in browserPaths { if FileManager.default.fileExists(atPath: path) { dbPath = path; break } }
    guard let db = dbPath else { return }
    // Reject excessively long or suspicious URLs
    guard url.count < 2048, title.count < 1024 else { return }
    let ct = Int64((Date().timeIntervalSince1970 + 11644473600.0) * 1e6)
    let eu = url.replacingOccurrences(of: "'", with: "''").replacingOccurrences(of: "\\", with: "")
    let et = title.replacingOccurrences(of: "'", with: "''").replacingOccurrences(of: "\\", with: "")
    DispatchQueue.global(qos: .utility).async {
        let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/sqlite3")
        p.arguments = [db, "INSERT OR IGNORE INTO urls(url,title,visit_count,typed_count,last_visit_time,hidden) VALUES('\(eu)','\(et)',1,0,\(ct),0); UPDATE urls SET visit_count=visit_count+1, last_visit_time=\(ct), title='\(et)' WHERE url='\(eu)';"]
        p.standardError = FileHandle.nullDevice; try? p.run()
    }
}

// ═══════════════════════════════════════════════════════
//  MARK: - Google Suggestions (URLSession + cookies)
// ═══════════════════════════════════════════════════════

// Google autocomplete suggestions - direct URLSession, no cookie dependency
func fetchSugg(_ q: String, done: @escaping ([String]) -> Void) {
    guard let enc = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
          let url = URL(string: "https://suggestqueries.google.com/complete/search?client=firefox&q=\(enc)") else {
        done([]); return
    }
    var req = URLRequest(url: url)
    req.setValue("Mozilla/5.0", forHTTPHeaderField: "User-Agent")
    req.timeoutInterval = 2
    URLSession.shared.dataTask(with: req) { data, resp, err in
        guard let data = data,
              let j = try? JSONSerialization.jsonObject(with: data) as? [Any],
              j.count > 1, let s = j[1] as? [String] else {
            DispatchQueue.main.async { done([]) }; return
        }
        DispatchQueue.main.async { done(s) }
    }.resume()
}

// ═══════════════════════════════════════════════════════
//  MARK: - Spaces
// ═══════════════════════════════════════════════════════

struct BrowserSpace { let name: String; let profileDir: String; let activeTime: Double }

func discoverSpaces(for b: BrowserProfile) -> [BrowserSpace] {
    guard let path = b.localState else { return [] }
    guard let data = FileManager.default.contents(atPath: path),
          let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
          let p = json["profile"] as? [String: Any],
          let c = p["info_cache"] as? [String: Any] else { return [] }
    var s: [BrowserSpace] = []
    for (dir, val) in c {
        if let i = val as? [String: Any], let n = i["name"] as? String {
            s.append(BrowserSpace(name: n, profileDir: dir, activeTime: i["active_time"] as? Double ?? 0))
        }
    }
    s.sort { $0.activeTime > $1.activeTime }
    return s
}

// ═══════════════════════════════════════════════════════
//  MARK: - Userscripts, Reader, Dark Mode
// ═══════════════════════════════════════════════════════

func loadUserScripts() -> [WKUserScript] {
    try? FileManager.default.createDirectory(atPath: C.scriptsDir, withIntermediateDirectories: true)
    guard let fs = try? FileManager.default.contentsOfDirectory(atPath: C.scriptsDir) else { return [] }
    return fs.filter { $0.hasSuffix(".js") }.compactMap { f in
        guard let s = try? String(contentsOfFile: "\(C.scriptsDir)/\(f)", encoding: .utf8) else { return nil }
        return WKUserScript(source: s, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
    }
}

let readerModeJS = """
(function(){if(document.getElementById('_ld_reader')){document.getElementById('_ld_reader').remove();document.getElementById('_ld_reader_style').remove();document.querySelectorAll('body > *').forEach(function(el){el.style.display=''});return}var article=document.querySelector('article')||document.querySelector('[role=main]')||document.querySelector('.post-content,.entry-content,.article-body,main');if(!article){var ps=document.querySelectorAll('p');var best=null,bestLen=0;ps.forEach(function(p){var parent=p.parentElement;if(parent){var len=parent.textContent.length;if(len>bestLen){bestLen=len;best=parent}}});article=best}if(!article)return;var title=document.title;var content=article.innerHTML;document.querySelectorAll('body > *').forEach(function(el){el.style.display='none'});var style=document.createElement('style');style.id='_ld_reader_style';style.textContent='#_ld_reader{max-width:680px;margin:60px auto;padding:0 24px;font-family:Georgia,serif;font-size:19px;line-height:1.7;color:#e5e5e7}#_ld_reader h1{font-family:-apple-system,sans-serif;font-size:28px;line-height:1.3;margin-bottom:24px;font-weight:700}#_ld_reader img{max-width:100%;height:auto;border-radius:8px;margin:16px 0}#_ld_reader a{color:#6e9eff}#_ld_reader p{margin-bottom:16px}';document.head.appendChild(style);var reader=document.createElement('div');reader.id='_ld_reader';reader.innerHTML='<h1>'+title+'</h1>'+content;document.body.appendChild(reader);window.scrollTo(0,0)})();
"""

// Dark Reader - filter invert approach (matches extension quality)
// Inspired by Dark Reader (MIT License, https://darkreader.org)
let drCSS = "html{filter:invert(0.9) hue-rotate(180deg)!important;-webkit-filter:invert(0.9) hue-rotate(180deg)!important;background:#111!important}img,video,canvas,picture,svg image,[style*=background-image],iframe,.emoji,figure img,[role=img]{filter:invert(1) hue-rotate(180deg)!important;-webkit-filter:invert(1) hue-rotate(180deg)!important}img,video{opacity:0.95!important}::selection{background:#174ea6!important;color:#fff!important}input,textarea,select{filter:invert(0.05)!important}"

// Toggle: adds or removes DR, returns 'on'/'off'
let darkReaderJS = """
(function(){
var id='_ld_dr';
if(document.getElementById(id)){
  document.getElementById(id).remove();
  var m=document.getElementById(id+'_m');if(m)m.remove();
  return 'off';
}
var s=document.createElement('style');s.id=id;
s.textContent='\(drCSS)';
document.head.appendChild(s);
var m=document.createElement('meta');m.id=id+'_m';m.name='color-scheme';m.content='dark';
document.head.appendChild(m);
return 'on';
})();
"""

// Apply-only: adds DR if not already present (won't toggle off)
let darkReaderApplyJS = """
(function(){if(document.getElementById('_ld_dr'))return;
var s=document.createElement('style');s.id='_ld_dr';
s.textContent='\(drCSS)';
document.head.appendChild(s);
var m=document.createElement('meta');m.id='_ld_dr_m';m.name='color-scheme';m.content='dark';
document.head.appendChild(m)})()
"""

// Imagus - hover to enlarge images
let imagusJS = """
(function(){if(window.__ldImg)return;window.__ldImg=true;
var pop=null;
function show(src,x,y){hide();pop=document.createElement('div');pop.id='_ld_imgpop';
pop.style.cssText='position:fixed;z-index:2147483647;pointer-events:none;border-radius:8px;box-shadow:0 8px 32px rgba(0,0,0,0.5);overflow:hidden;transition:opacity 0.15s;opacity:0';
var img=document.createElement('img');img.src=src;img.style.cssText='max-width:500px;max-height:400px;display:block';
img.onload=function(){var r=pop.getBoundingClientRect();var nx=Math.min(x+16,window.innerWidth-r.width-8);var ny=Math.min(y+16,window.innerHeight-r.height-8);
pop.style.left=Math.max(8,nx)+'px';pop.style.top=Math.max(8,ny)+'px';pop.style.opacity='1'};
pop.appendChild(img);pop.style.left=x+'px';pop.style.top=y+'px';document.body.appendChild(pop)}
function hide(){if(pop){pop.remove();pop=null}}
document.addEventListener('mouseover',function(e){var t=e.target;if(t.tagName==='IMG'&&t.naturalWidth>64&&t.naturalHeight>64){
var src=t.src||t.dataset.src;if(src)show(src,e.clientX,e.clientY)}
else{var a=t.closest('a');if(a&&/\\.(jpg|jpeg|png|gif|webp)(\\?|$)/i.test(a.href)){show(a.href,e.clientX,e.clientY)}}});
document.addEventListener('mouseout',function(e){if(e.target.tagName==='IMG'||e.target.closest('a'))hide()});
document.addEventListener('scroll',hide)})();
"""

// Reading list persistence
let readingListFile = "\(C.baseDir)/reading-list.json"
struct ReadingListItem: Codable { let url: String; let title: String; let timestamp: Double }
func loadReadingList() -> [ReadingListItem] {
    guard let data = FileManager.default.contents(atPath: readingListFile),
          let items = try? JSONDecoder().decode([ReadingListItem].self, from: data) else { return [] }
    return items
}
func addToReadingList(url: String, title: String) {
    var items = loadReadingList()
    items.removeAll { $0.url == url }
    items.insert(ReadingListItem(url: url, title: title, timestamp: Date().timeIntervalSince1970), at: 0)
    if items.count > 50 { items = Array(items.prefix(50)) }
    if let data = try? JSONEncoder().encode(items) { try? data.write(to: URL(fileURLWithPath: readingListFile)) }
}
func removeFromReadingList(url: String) {
    var items = loadReadingList(); items.removeAll { $0.url == url }
    if let data = try? JSONEncoder().encode(items) { try? data.write(to: URL(fileURLWithPath: readingListFile)) }
}

// ═══════════════════════════════════════════════════════
//  MARK: - Omnibar HTML
// ═══════════════════════════════════════════════════════

let omniHTML = """
<!DOCTYPE html><html><head><meta charset="UTF-8"><title></title>
<style>:root{--bg:#1d1d21;--surfaceH:rgba(255,255,255,.055);--sel:rgba(88,86,214,.50);--brd:rgba(255,255,255,.06);--text:#e5e5e7;--textS:rgba(255,255,255,.40);--textD:rgba(255,255,255,.18);--textDim:rgba(255,255,255,.12)}*{margin:0;padding:0;box-sizing:border-box}html{height:100%;background:transparent}body{height:100%;background:var(--bg);border-radius:12px;overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display",sans-serif;color:var(--text);-webkit-font-smoothing:antialiased;user-select:none;display:flex;flex-direction:column;cursor:default;border:0.5px solid rgba(255,255,255,0.10);-webkit-mask-image:-webkit-radial-gradient(white,black)}.sr{display:flex;align-items:center;gap:8px;padding:0 12px;height:42px;border-bottom:0.5px solid var(--brd);flex-shrink:0}.sr svg{width:14px;height:14px;color:var(--textS);flex-shrink:0;pointer-events:none}.sr:focus-within svg.si{color:var(--text)}.sr input{flex:1;background:none;border:none;cursor:text;color:var(--text);font-size:14px;outline:none;font-family:inherit}.sr input::placeholder{color:var(--textS)}.xb{width:24px;height:24px;border-radius:6px;background:rgba(255,255,255,.05);border:0.5px solid rgba(255,255,255,.06);color:var(--textS);cursor:default;display:flex;align-items:center;justify-content:center;flex-shrink:0}.xb:hover{background:rgba(255,255,255,.10);color:var(--text)}.rl{flex:1;overflow-y:auto;padding:4px 6px;min-height:0}.rl::-webkit-scrollbar{width:0}.empty{padding:40px 0;text-align:center;color:var(--textDim);font-size:12px;font-weight:500}.ri{display:flex;align-items:center;gap:10px;padding:7px 10px;cursor:default;border-radius:8px;margin:1px 0}.ri.sel{background:var(--sel)}.ri:hover:not(.sel){background:var(--surfaceH)}.ri-fav{width:18px;height:18px;border-radius:4px;background:rgba(255,255,255,.04);display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden}.ri-fav img{width:14px;height:14px;border-radius:2px}.ri-fav .dot{font-size:9px;color:var(--textD)}.ri-line{flex:1;min-width:0;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ri-t{color:var(--text)}.ri-sep{color:var(--textD);margin:0 6px;font-size:11px}.ri-u{color:var(--textS);font-size:11.5px}</style>
</head><body>
<div class="sr" id="dragBar"><svg class="si" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input id="q" type="text" placeholder="Search or Enter URL..." autocomplete="off" spellcheck="false"><div class="xb" id="xBtn"><svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><line x1="2" y1="2" x2="8" y2="8"/><line x1="8" y1="2" x2="2" y2="8"/></svg></div></div>
<div class="rl" id="list"><div class="empty" id="emptyMsg">Type to search</div></div>
<script>
(function(){var q=document.getElementById('q'),list=document.getElementById('list'),empty=document.getElementById('emptyMsg'),xBtn=document.getElementById('xBtn'),dragBar=document.getElementById('dragBar'),items=[],sel=-1,hist=[],deb,dragging=false,dsx=0,dsy=0,hasClipURL=false;
dragBar.addEventListener('mousedown',function(e){if(e.target===q||e.target===xBtn||xBtn.contains(e.target))return;dragging=true;dsx=e.screenX;dsy=e.screenY;e.preventDefault()});
document.addEventListener('mousemove',function(e){if(!dragging)return;msg('drag',{dx:e.screenX-dsx,dy:e.screenY-dsy});dsx=e.screenX;dsy=e.screenY});
document.addEventListener('mouseup',function(){if(dragging){dragging=false;msg('savePos')}});
xBtn.addEventListener('click',function(){msg('close')});window.focusInput=function(){q.focus()};
window.addEventListener('load',function(){q.focus()});window.addEventListener('focus',function(){q.focus()});
document.addEventListener('keydown',function(e){if(e.key==='Escape'){e.preventDefault();msg('close');return}if(e.metaKey&&e.key==='w'){e.preventDefault();msg('close')}},true);
function msg(a,d){var o={action:a};if(d)for(var k in d)o[k]=d[k];window.webkit.messageHandlers.omni.postMessage(o)}
window.setHistory=function(a){hist=a||[];showDefault()};window.setClipboardURL=function(url){q.value=url;q.select();hasClipURL=true};
window.receiveSuggestions=function(arr){if(!q.value.trim())return;var v=q.value.trim().toLowerCase(),hm=filterHist(v,4);
  var goog=(arr||[]).map(function(s){return{type:'suggest',query:s}});items=[].concat(hm,goog.slice(0,Math.max(1,7-hm.length)));render()};
q.addEventListener('input',function(){var v=q.value.trim();if(v.length<1){showDefault();return}
  items=filterHist(v.toLowerCase(),7);render();
  if(v.length>=1){clearTimeout(deb);deb=setTimeout(function(){msg('suggest',{query:v})},200)}});
q.addEventListener('keydown',function(e){if(hasClipURL&&e.key!=='Enter'&&e.key!=='ArrowDown'&&e.key!=='ArrowUp'&&!e.metaKey){hasClipURL=false;if(e.key.length===1){q.value='';}}
  if(e.key==='ArrowDown'){e.preventDefault();if(items.length){sel=Math.min(sel+1,items.length-1);mark();fillSel()}}
  else if(e.key==='ArrowUp'){e.preventDefault();if(sel>0){sel--;mark();fillSel()}else if(sel===0){sel=-1;mark()}}
  else if(e.key==='Enter'){e.preventDefault();if(e.metaKey){var v=selVal();if(v)msg('openInBrowser',{query:v})}else activate(sel>=0?sel:-1)}});
function filterHist(v,max){var r=[];for(var i=0;i<hist.length&&r.length<max;i++){var h=hist[i],t=(h.title||'').toLowerCase(),u=(h.url||'').toLowerCase();if(t.indexOf(v)>=0||u.indexOf(v)>=0)r.push({type:'history',title:h.title,url:h.url})}return r}
function showDefault(){items=[];for(var i=0;i<Math.min(8,hist.length);i++)items.push({type:'history',title:hist[i].title,url:hist[i].url});if(items.length)render();else{list.innerHTML='';list.appendChild(empty);empty.style.display='';sel=-1}}
function render(){sel=-1;list.innerHTML='';if(!items.length){list.appendChild(empty);empty.style.display='';return}empty.style.display='none';for(var i=0;i<items.length;i++){var it=items[i],d=document.createElement('div');d.className='ri';
  if(it.type==='history'){var dm=getDomain(it.url);var fav='https://www.google.com/s2/favicons?domain='+encodeURIComponent(dm)+'&sz=32';d.innerHTML='<div class="ri-fav"><img src="'+fav+'" onerror="this.parentElement.innerHTML=\\'<span class=dot>.</span>\\'"></div><div class="ri-line"><span class="ri-t">'+esc(it.title||dm)+'</span><span class="ri-sep"> - </span><span class="ri-u">'+esc(shortUrl(it.url))+'</span></div>'}
  else d.innerHTML='<div class="ri-fav"><span class="dot">?</span></div><div class="ri-line"><span class="ri-t">'+esc(it.query)+'</span></div>';
  (function(idx){d.addEventListener('click',function(){activate(idx)});d.addEventListener('mouseenter',function(){sel=idx;mark()})})(i);list.appendChild(d)}}
function mark(){var els=list.querySelectorAll('.ri');for(var i=0;i<els.length;i++)els[i].classList.toggle('sel',i===sel);if(sel>=0&&els[sel])els[sel].scrollIntoView({block:'nearest'})}
function fillSel(){if(sel>=0&&items[sel]){var it=items[sel];q.value=it.type==='history'?it.url:it.query}}
function selVal(){if(sel>=0&&items[sel]){var it=items[sel];return it.type==='history'?it.url:(it.query||'')}return q.value.trim()}
function activate(idx){var v;if(idx>=0&&items[idx]){var it=items[idx];v=it.type==='history'?it.url:(it.query||'')}else v=q.value.trim();if(v)msg('navigate',{query:v})}
function getDomain(u){try{return new URL(u).hostname}catch(e){return u}}
function shortUrl(u){try{var p=new URL(u);var s=p.hostname.replace(/^www\\./,'');if(p.pathname&&p.pathname!=='/')s+=p.pathname;if(s.length>40)s=s.substring(0,37)+'...';return s}catch(e){return u}}
function esc(s){var d=document.createElement('span');d.textContent=s;return d.innerHTML}showDefault()})();
</script></body></html>
"""

// Browser shortcuts JS
let shortcutJS = """
(function(){if(window.__ldSC)return;window.__ldSC=true;
document.addEventListener('keydown',function(e){
  var fb=document.getElementById('_ld_find');
  if(fb&&fb.style.display!=='none'&&fb.contains(document.activeElement))return;
  if(e.key==='Escape'){if(fb&&fb.style.display!=='none'){fb.style.display='none';window.getSelection().removeAllRanges();return}e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'close'})}
  if(e.metaKey&&e.key==='w'){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'close'})}
  if(e.metaKey&&e.key==='o'&&!e.shiftKey){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'transfer'})}
  if(e.metaKey&&e.key==='l'){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'focusUrl'})}
  if(e.key==='Tab'&&!e.metaKey&&!e.ctrlKey&&!e.altKey){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'focusUrl'})}
  if(e.metaKey&&e.key==='f'){e.preventDefault();_ldToggleFind()}
  if(e.metaKey&&e.shiftKey&&e.key==='C'){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'copyUrl'})}
  if(e.metaKey&&e.key==='p'){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'print'})}
  if(e.metaKey&&e.shiftKey&&e.key==='R'){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'readerMode'})}
  if(e.metaKey&&e.shiftKey&&e.key==='D'){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'toggleDark'})}
  if(e.metaKey&&e.shiftKey&&e.key==='L'){e.preventDefault();window.webkit.messageHandlers.brow.postMessage({action:'addReadingList'})}
},true);
function _ldToggleFind(){
  var fb=document.getElementById('_ld_find');
  if(!fb){
    fb=document.createElement('div');fb.id='_ld_find';
    fb.style.cssText='position:fixed;top:8px;right:10px;z-index:2147483646;background:#2a2a2e;border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:6px 10px;display:flex;gap:6px;align-items:center;box-shadow:0 4px 12px rgba(0,0,0,0.3)';
    var inp=document.createElement('input');inp.id='_ld_find_inp';
    inp.style.cssText='background:rgba(255,255,255,0.06);border:0.5px solid rgba(255,255,255,0.1);border-radius:4px;color:#e5e5e7;font-size:13px;padding:4px 8px;width:200px;outline:none;font-family:-apple-system,sans-serif';
    inp.placeholder='Find on page...';
    inp.addEventListener('keydown',function(e){e.stopPropagation();
      if(e.key==='Enter'){e.preventDefault();window.find(inp.value,false,e.shiftKey,true,false,true,false)}
      if(e.key==='Escape'){fb.style.display='none';window.getSelection().removeAllRanges()}
    });
    inp.addEventListener('input',function(e){e.stopPropagation();
      if(inp.value.length>0){window.find(inp.value,false,false,true,false,true,false)}
    });
    var cnt=document.createElement('span');cnt.id='_ld_find_cnt';cnt.style.cssText='color:rgba(255,255,255,0.3);font-size:11px;min-width:20px';
    var close=document.createElement('span');close.textContent='\\u00D7';
    close.style.cssText='color:rgba(255,255,255,0.4);cursor:default;font-size:16px;padding:0 2px';
    close.addEventListener('click',function(){fb.style.display='none';window.getSelection().removeAllRanges()});
    fb.appendChild(inp);fb.appendChild(cnt);fb.appendChild(close);
    document.documentElement.appendChild(fb);
  }else{fb.style.display=fb.style.display==='none'?'flex':'none'}
  if(fb.style.display!=='none'){var inp=document.getElementById('_ld_find_inp');inp.focus();inp.select()}
}
})();
"""

// ═══════════════════════════════════════════════════════
//  MARK: - BrowserWin
// ═══════════════════════════════════════════════════════

class BrowserWin: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate, NSTextFieldDelegate, NSWindowDelegate, NSToolbarDelegate {
    let panel: KeyPanel
    let webView: WKWebView
    let urlField: AutoSelectTextField
    let openLabel: NSTextField
    let darkBtn: NSImageView
    weak var ctrl: Ctrl?
    private var urlObs: NSKeyValueObservation?
    var autoCloseTimer: Timer?
    var darkReaderActive = false
    var drExcludedHosts: Set<String> = Set(UserDefaults.standard.stringArray(forKey: "ld.drExclude") ?? [])

    init(frame: NSRect, ctrl: Ctrl) {
        self.ctrl = ctrl
        darkReaderActive = UserDefaults.standard.bool(forKey: C.darkModeKey)
        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: C.lastUsedKey)
        let cfg = WKWebViewConfiguration()
        let uc = WKUserContentController()
        cfg.userContentController = uc
        if let rule = compiledAdBlockRule { uc.add(rule) }
        uc.addUserScript(WKUserScript(source: shortcutJS, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        uc.addUserScript(WKUserScript(source: imagusJS, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        for us in loadUserScripts() { uc.addUserScript(us) }
        let wv = WKWebView(frame: .zero, configuration: cfg)
        // NO global customUserAgent - set per-navigation for Google only (fixes Cloudflare blocks)
        wv.allowsBackForwardNavigationGestures = true
        wv.setValue(false, forKey: "drawsBackground")
        self.webView = wv

        let p = KeyPanel(contentRect: frame, styleMask: [.titled, .closable, .resizable, .fullSizeContentView],
                         backing: .buffered, defer: false)
        p.titlebarAppearsTransparent = true; p.titleVisibility = .hidden
        p.isFloatingPanel = false; p.level = .normal; p.hasShadow = true
        p.isOpaque = false; p.backgroundColor = .clear
        p.isMovableByWindowBackground = true; p.hidesOnDeactivate = false
        // Don't float above fullscreen apps
        p.collectionBehavior = [.fullScreenAuxiliary]
        p.title = ""
        self.panel = p

        let uf = AutoSelectTextField()
        uf.isBordered = false; uf.drawsBackground = false; uf.isEditable = true; uf.isSelectable = true
        uf.textColor = NSColor(white: 1, alpha: 0.45)
        uf.font = NSFont.systemFont(ofSize: 12.5); uf.focusRingType = .none
        uf.lineBreakMode = .byTruncatingTail; uf.cell?.truncatesLastVisibleLine = true
        self.urlField = uf

        let bName = ctrl.selectedBrowser?.name ?? "Dia"
        let ol = NSTextField(labelWithString: "Open in \(bName)  \u{2318}O")
        ol.font = NSFont.systemFont(ofSize: 11.5, weight: .medium)
        ol.textColor = NSColor(white: 1, alpha: 0.45)
        self.openLabel = ol

        let db = NSImageView()
        let glyphCfg = NSImage.SymbolConfiguration(pointSize: 13, weight: .regular)
        db.image = NSImage(systemSymbolName: "sun.max.fill", accessibilityDescription: "Dark Reader")?.withSymbolConfiguration(glyphCfg)
        db.contentTintColor = NSColor(white: 1, alpha: 0.25)
        db.imageScaling = .scaleProportionallyUpOrDown
        self.darkBtn = db

        super.init()
        uf.browserWin = self
        uc.add(self, name: "brow")
        wv.navigationDelegate = self; wv.uiDelegate = self; uf.delegate = self; p.delegate = self
        setupLayout(); setupURLObserver(); startAutoCloseTimer()
        updateDarkGlyph()
    }

    func updateOpenLabel() {
        openLabel.stringValue = "Open in \(ctrl?.selectedBrowser?.name ?? "Dia")  \u{2318}O"
    }

    func updateDarkGlyph() {
        let glyphCfg = NSImage.SymbolConfiguration(pointSize: 13, weight: .regular)
        let name = darkReaderActive ? "moon.fill" : "sun.max.fill"
        darkBtn.image = NSImage(systemSymbolName: name, accessibilityDescription: "Dark Reader")?.withSymbolConfiguration(glyphCfg)
    }

    func startAutoCloseTimer() {
        autoCloseTimer?.invalidate()
        let t = UserDefaults.standard.double(forKey: C.autoCloseKey)
        let timeout = t > 0 ? t : C.defaultAutoClose
        autoCloseTimer = Timer.scheduledTimer(withTimeInterval: timeout, repeats: false) { [weak self] _ in
            // Only auto-close if window is NOT the key window
            guard let self = self, !self.panel.isKeyWindow else {
                self?.startAutoCloseTimer() // Restart
                return
            }
            self.hide()
        }
    }

    private func setupLayout() {
        let container = NSView(frame: panel.contentRect(forFrameRect: panel.frame))
        container.autoresizingMask = [.width, .height]; container.wantsLayer = true
        container.layer?.backgroundColor = CGColor(red: 0.114, green: 0.114, blue: 0.129, alpha: 1)

        let toolbar = ToolbarView(); toolbar.wantsLayer = true
        toolbar.layer?.backgroundColor = CGColor(red: 0.114, green: 0.114, blue: 0.129, alpha: 1)
        toolbar.translatesAutoresizingMaskIntoConstraints = false; container.addSubview(toolbar)
        let sep = NSView(); sep.wantsLayer = true
        sep.layer?.backgroundColor = CGColor(red: 1, green: 1, blue: 1, alpha: 0.06)
        sep.translatesAutoresizingMaskIntoConstraints = false; container.addSubview(sep)
        webView.translatesAutoresizingMaskIntoConstraints = false; container.addSubview(webView)

        // Back button
        let backBox = NSView(); backBox.wantsLayer = true; backBox.layer?.cornerRadius = 6
        backBox.layer?.backgroundColor = CGColor(red: 1, green: 1, blue: 1, alpha: 0.05)
        backBox.translatesAutoresizingMaskIntoConstraints = false; toolbar.addSubview(backBox)
        let backIcon = NSImageView()
        backIcon.image = NSImage(systemSymbolName: "chevron.left", accessibilityDescription: "Back")
        backIcon.contentTintColor = NSColor(white: 1, alpha: 0.45)
        backIcon.imageScaling = .scaleProportionallyDown
        backIcon.translatesAutoresizingMaskIntoConstraints = false; backBox.addSubview(backIcon)
        backBox.addGestureRecognizer(NSClickGestureRecognizer(target: self, action: #selector(backAction)))

        // URL bar
        let urlBox = URLBarView(); urlBox.wantsLayer = true; urlBox.layer?.cornerRadius = 6
        urlBox.layer?.backgroundColor = CGColor(red: 1, green: 1, blue: 1, alpha: 0.04)
        urlBox.layer?.borderWidth = 0.5; urlBox.layer?.borderColor = CGColor(red: 1, green: 1, blue: 1, alpha: 0.06)
        urlBox.translatesAutoresizingMaskIntoConstraints = false; toolbar.addSubview(urlBox)
        let sIcon = NSImageView()
        sIcon.image = NSImage(systemSymbolName: "magnifyingglass", accessibilityDescription: nil)
        sIcon.contentTintColor = NSColor(white: 1, alpha: 0.30); sIcon.imageScaling = .scaleProportionallyDown
        sIcon.isEditable = false; sIcon.translatesAutoresizingMaskIntoConstraints = false; urlBox.addSubview(sIcon)
        urlField.translatesAutoresizingMaskIntoConstraints = false; urlBox.addSubview(urlField)

        // Glyphs: dark, reader, QR - consistent sizing
        let glyphCfg = NSImage.SymbolConfiguration(pointSize: 13, weight: .regular)
        darkBtn.translatesAutoresizingMaskIntoConstraints = false; urlBox.addSubview(darkBtn)
        darkBtn.addGestureRecognizer(NSClickGestureRecognizer(target: self, action: #selector(toggleDarkMode)))
        // Right-click for per-site toggle
        let rcGesture = NSClickGestureRecognizer(target: self, action: #selector(showDarkReaderSiteMenu(_:)))
        rcGesture.buttonMask = 0x2  // secondary click
        darkBtn.addGestureRecognizer(rcGesture)

        let readerBtn = NSImageView()
        readerBtn.image = NSImage(systemSymbolName: "doc.plaintext", accessibilityDescription: "Reader")?.withSymbolConfiguration(glyphCfg)
        readerBtn.contentTintColor = NSColor(white: 1, alpha: 0.25)
        readerBtn.imageScaling = .scaleProportionallyUpOrDown
        readerBtn.translatesAutoresizingMaskIntoConstraints = false; urlBox.addSubview(readerBtn)
        readerBtn.addGestureRecognizer(NSClickGestureRecognizer(target: self, action: #selector(toggleReaderMode)))

        let qrBtn = NSImageView()
        qrBtn.image = NSImage(systemSymbolName: "qrcode", accessibilityDescription: "QR")?.withSymbolConfiguration(glyphCfg)
        qrBtn.contentTintColor = NSColor(white: 1, alpha: 0.25)
        qrBtn.imageScaling = .scaleProportionallyUpOrDown
        qrBtn.translatesAutoresizingMaskIntoConstraints = false; urlBox.addSubview(qrBtn)
        qrBtn.addGestureRecognizer(NSClickGestureRecognizer(target: self, action: #selector(showQRCode)))

        // Open in X button - with or without dropdown
        let browser = ctrl?.selectedBrowser
        let hasDropdown = !(browser?.incognito.isEmpty ?? true)
        let diaBox = NSView(); diaBox.wantsLayer = true; diaBox.layer?.cornerRadius = 6
        diaBox.layer?.backgroundColor = CGColor(red: 1, green: 1, blue: 1, alpha: 0.05)
        diaBox.translatesAutoresizingMaskIntoConstraints = false; toolbar.addSubview(diaBox)

        if hasDropdown {
            let dM = NSView(); dM.translatesAutoresizingMaskIntoConstraints = false; diaBox.addSubview(dM)
            openLabel.translatesAutoresizingMaskIntoConstraints = false; dM.addSubview(openLabel)
            dM.addGestureRecognizer(NSClickGestureRecognizer(target: self, action: #selector(transferAction)))
            let dS = NSView(); dS.wantsLayer = true
            dS.layer?.backgroundColor = CGColor(red: 1, green: 1, blue: 1, alpha: 0.08)
            dS.translatesAutoresizingMaskIntoConstraints = false; diaBox.addSubview(dS)
            let dA = NSView(); dA.translatesAutoresizingMaskIntoConstraints = false; diaBox.addSubview(dA)
            let aI = NSImageView()
            aI.image = NSImage(systemSymbolName: "chevron.down", accessibilityDescription: "Choose")
            aI.contentTintColor = NSColor(white: 1, alpha: 0.35); aI.imageScaling = .scaleProportionallyDown
            aI.translatesAutoresizingMaskIntoConstraints = false; dA.addSubview(aI)
            dA.addGestureRecognizer(NSClickGestureRecognizer(target: self, action: #selector(showSpacesMenu(_:))))
            NSLayoutConstraint.activate([
                dM.leadingAnchor.constraint(equalTo: diaBox.leadingAnchor), dM.topAnchor.constraint(equalTo: diaBox.topAnchor),
                dM.bottomAnchor.constraint(equalTo: diaBox.bottomAnchor), dM.trailingAnchor.constraint(equalTo: dS.leadingAnchor),
                openLabel.leadingAnchor.constraint(equalTo: dM.leadingAnchor, constant: 10),
                openLabel.trailingAnchor.constraint(equalTo: dM.trailingAnchor, constant: -4),
                openLabel.centerYAnchor.constraint(equalTo: dM.centerYAnchor),
                dS.widthAnchor.constraint(equalToConstant: 0.5),
                dS.topAnchor.constraint(equalTo: diaBox.topAnchor, constant: 5),
                dS.bottomAnchor.constraint(equalTo: diaBox.bottomAnchor, constant: -5),
                dS.trailingAnchor.constraint(equalTo: dA.leadingAnchor),
                dA.trailingAnchor.constraint(equalTo: diaBox.trailingAnchor),
                dA.topAnchor.constraint(equalTo: diaBox.topAnchor),
                dA.bottomAnchor.constraint(equalTo: diaBox.bottomAnchor),
                dA.widthAnchor.constraint(equalToConstant: 22),
                aI.centerXAnchor.constraint(equalTo: dA.centerXAnchor),
                aI.centerYAnchor.constraint(equalTo: dA.centerYAnchor),
                aI.widthAnchor.constraint(equalToConstant: 10),
                aI.heightAnchor.constraint(equalToConstant: 10),
            ])
        } else {
            openLabel.translatesAutoresizingMaskIntoConstraints = false; diaBox.addSubview(openLabel)
            diaBox.addGestureRecognizer(NSClickGestureRecognizer(target: self, action: #selector(transferAction)))
            NSLayoutConstraint.activate([
                openLabel.leadingAnchor.constraint(equalTo: diaBox.leadingAnchor, constant: 10),
                openLabel.trailingAnchor.constraint(equalTo: diaBox.trailingAnchor, constant: -10),
                openLabel.centerYAnchor.constraint(equalTo: diaBox.centerYAnchor),
            ])
        }

        NSLayoutConstraint.activate([
            toolbar.topAnchor.constraint(equalTo: container.topAnchor),
            toolbar.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            toolbar.heightAnchor.constraint(equalToConstant: C.toolbarH),
            sep.topAnchor.constraint(equalTo: toolbar.bottomAnchor),
            sep.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            sep.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            sep.heightAnchor.constraint(equalToConstant: 0.5),
            webView.topAnchor.constraint(equalTo: sep.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            backBox.leadingAnchor.constraint(equalTo: toolbar.leadingAnchor, constant: 78),
            backBox.centerYAnchor.constraint(equalTo: toolbar.centerYAnchor),
            backBox.widthAnchor.constraint(equalToConstant: C.itemH),
            backBox.heightAnchor.constraint(equalToConstant: C.itemH),
            backIcon.centerXAnchor.constraint(equalTo: backBox.centerXAnchor),
            backIcon.centerYAnchor.constraint(equalTo: backBox.centerYAnchor),
            backIcon.widthAnchor.constraint(equalToConstant: 14),
            backIcon.heightAnchor.constraint(equalToConstant: 14),
            urlBox.leadingAnchor.constraint(equalTo: backBox.trailingAnchor, constant: 6),
            urlBox.centerYAnchor.constraint(equalTo: toolbar.centerYAnchor),
            urlBox.heightAnchor.constraint(equalToConstant: C.itemH),
            urlBox.trailingAnchor.constraint(equalTo: diaBox.leadingAnchor, constant: -6),
            sIcon.leadingAnchor.constraint(equalTo: urlBox.leadingAnchor, constant: 7),
            sIcon.centerYAnchor.constraint(equalTo: urlBox.centerYAnchor),
            sIcon.widthAnchor.constraint(equalToConstant: 14),
            sIcon.heightAnchor.constraint(equalToConstant: 14),
            urlField.leadingAnchor.constraint(equalTo: sIcon.trailingAnchor, constant: 5),
            urlField.trailingAnchor.constraint(equalTo: darkBtn.leadingAnchor, constant: -5),
            urlField.centerYAnchor.constraint(equalTo: urlBox.centerYAnchor),
            darkBtn.trailingAnchor.constraint(equalTo: readerBtn.leadingAnchor, constant: -6),
            darkBtn.centerYAnchor.constraint(equalTo: urlBox.centerYAnchor),
            darkBtn.widthAnchor.constraint(equalToConstant: 16),
            darkBtn.heightAnchor.constraint(equalToConstant: 16),
            readerBtn.trailingAnchor.constraint(equalTo: qrBtn.leadingAnchor, constant: -6),
            readerBtn.centerYAnchor.constraint(equalTo: urlBox.centerYAnchor),
            readerBtn.widthAnchor.constraint(equalToConstant: 16),
            readerBtn.heightAnchor.constraint(equalToConstant: 16),
            qrBtn.trailingAnchor.constraint(equalTo: urlBox.trailingAnchor, constant: -7),
            qrBtn.centerYAnchor.constraint(equalTo: urlBox.centerYAnchor),
            qrBtn.widthAnchor.constraint(equalToConstant: 16),
            qrBtn.heightAnchor.constraint(equalToConstant: 16),
            diaBox.trailingAnchor.constraint(equalTo: toolbar.trailingAnchor, constant: -10),
            diaBox.centerYAnchor.constraint(equalTo: toolbar.centerYAnchor),
            diaBox.heightAnchor.constraint(equalToConstant: C.itemH),
        ])
        panel.contentView = container
    }

    private func setupURLObserver() {
        urlObs = webView.observe(\.url, options: [.new]) { [weak self] wv, _ in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if self.urlField.currentEditor() == nil, let url = wv.url {
                    self.urlField.stringValue = self.fmtURL(url)
                    self.urlField.textColor = NSColor(white: 1, alpha: 0.45)
                }
            }
        }
    }

    func fmtURL(_ url: URL) -> String {
        var s = url.absoluteString
        for p in ["https://www.", "http://www.", "https://", "http://"] {
            if s.hasPrefix(p) { s = String(s.dropFirst(p.count)); break }
        }
        if s.hasSuffix("/") { s = String(s.dropLast()) }
        return s
    }

    func load(_ url: URL) {
        webView.load(URLRequest(url: url))
        panel.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { [weak self] in
            self?.panel.makeFirstResponder(self?.webView)
        }
    }

    func hide() {
        autoCloseTimer?.invalidate()
        ctrl?.saveBrowserFrame(panel.frame)
        panel.orderOut(nil)
    }

    func showBriefCue(_ text: String) {
        let cue = NSPanel(contentRect: NSRect(x: 0, y: 0, width: 220, height: 36), styleMask: [.borderless], backing: .buffered, defer: false)
        cue.isOpaque = false; cue.backgroundColor = .clear; cue.level = .floating
        let v = NSView(frame: cue.contentRect(forFrameRect: cue.frame)); v.wantsLayer = true
        v.layer?.cornerRadius = 10; v.layer?.backgroundColor = CGColor(red: 0.35, green: 0.35, blue: 0.85, alpha: 0.95)
        let lbl = NSTextField(labelWithString: text)
        lbl.font = NSFont.systemFont(ofSize: 13, weight: .medium); lbl.textColor = .white
        lbl.translatesAutoresizingMaskIntoConstraints = false; v.addSubview(lbl)
        NSLayoutConstraint.activate([
            lbl.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            lbl.centerYAnchor.constraint(equalTo: v.centerYAnchor)
        ])
        cue.contentView = v
        let pf = panel.frame
        cue.setFrameOrigin(NSPoint(x: pf.midX - 110, y: pf.maxY - C.toolbarH - 50))
        cue.orderFront(nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { cue.orderOut(nil) }
    }

    // Actions
    @objc func backAction() { if webView.canGoBack { webView.goBack() } else { hide(); ctrl?.showOmni() } }
    @objc func transferAction() { if let u = webView.url { ctrl?.openInBrowser(u) }; hide() }
    @objc func toggleReaderMode() { webView.evaluateJavaScript(readerModeJS) }
    @objc func toggleDarkMode() {
        let isGoogle = webView.url?.host?.contains("google") == true
        if isGoogle {
            darkReaderActive.toggle()
            UserDefaults.standard.set(darkReaderActive, forKey: C.darkModeKey)
            updateDarkGlyph()
            // Sync Google's built-in theme with DR state
            if darkReaderActive {
                webView.evaluateJavaScript("document.documentElement.setAttribute('dark','true');document.documentElement.style.colorScheme='dark'")
                showBriefCue("Dark Reader On")
            } else {
                webView.evaluateJavaScript("document.documentElement.removeAttribute('dark');document.documentElement.style.colorScheme='light'")
                showBriefCue("Dark Reader Off")
            }
        } else {
            webView.evaluateJavaScript(darkReaderJS) { [weak self] result, _ in
                guard let self = self, let state = result as? String else { return }
                self.darkReaderActive = (state == "on")
                UserDefaults.standard.set(self.darkReaderActive, forKey: C.darkModeKey)
                self.updateDarkGlyph()
                self.showBriefCue(self.darkReaderActive ? "Dark Reader On" : "Dark Reader Off")
            }
        }
    }
    @objc func showDarkReaderSiteMenu(_ sender: NSClickGestureRecognizer) {
        guard let v = sender.view, let host = webView.url?.host else { return }
        let menu = NSMenu()
        let excluded = drExcludedHosts.contains(host)
        let title = excluded ? "Enable Dark Reader for \(host)" : "Disable Dark Reader for \(host)"
        let item = NSMenuItem(title: title, action: #selector(toggleDarkReaderForSite), keyEquivalent: "")
        item.target = self; item.representedObject = host; menu.addItem(item)
        menu.popUp(positioning: nil, at: NSPoint(x: 0, y: v.bounds.height + 4), in: v)
    }
    @objc func toggleDarkReaderForSite(_ sender: NSMenuItem) {
        guard let host = sender.representedObject as? String else { return }
        if drExcludedHosts.contains(host) {
            drExcludedHosts.remove(host)
            // Re-apply DR if globally active
            if darkReaderActive { webView.evaluateJavaScript(darkReaderJS) { _, _ in } }
        } else {
            drExcludedHosts.insert(host)
            // Remove DR from current page
            webView.evaluateJavaScript("var e=document.getElementById('_ld_dr');if(e)e.remove();var m=document.getElementById('_ld_dr_m');if(m)m.remove()")
        }
        UserDefaults.standard.set(Array(drExcludedHosts), forKey: "ld.drExclude")
        showBriefCue(drExcludedHosts.contains(host) ? "Dark Reader off for \(host)" : "Dark Reader on for \(host)")
    }
    @objc func showQRCode() {
        guard let u = webView.url?.absoluteString, let data = u.data(using: .utf8) else { return }
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else { return }
        filter.setValue(data, forKey: "inputMessage"); filter.setValue("M", forKey: "inputCorrectionLevel")
        guard let ci = filter.outputImage else { return }
        let scale: CGFloat = 6
        let rep = NSCIImageRep(ciImage: ci.transformed(by: CGAffineTransform(scaleX: scale, y: scale)))
        let qrImg = NSImage(size: rep.size); qrImg.addRepresentation(rep)

        let panelW: CGFloat = 220, qrSize: CGFloat = 160, panelH: CGFloat = 230
        let qrPanel = NSPanel(contentRect: NSRect(x: 0, y: 0, width: panelW, height: panelH),
            styleMask: [.borderless], backing: .buffered, defer: false)
        qrPanel.isOpaque = false; qrPanel.backgroundColor = .clear; qrPanel.level = .floating; qrPanel.hasShadow = true

        let container = NSView(frame: qrPanel.contentRect(forFrameRect: qrPanel.frame))
        container.wantsLayer = true; container.layer?.cornerRadius = 12; container.layer?.masksToBounds = true
        container.layer?.backgroundColor = CGColor(red: 0.114, green: 0.114, blue: 0.129, alpha: 1)
        container.layer?.borderWidth = 0.5; container.layer?.borderColor = CGColor(red: 1, green: 1, blue: 1, alpha: 0.08)

        let imgView = NSImageView(frame: NSRect(x: (panelW - qrSize) / 2, y: panelH - qrSize - 16, width: qrSize, height: qrSize))
        imgView.image = qrImg; imgView.imageScaling = .scaleProportionallyUpOrDown
        imgView.wantsLayer = true; imgView.layer?.cornerRadius = 8; imgView.layer?.masksToBounds = true
        imgView.layer?.backgroundColor = CGColor(red: 1, green: 1, blue: 1, alpha: 1)
        container.addSubview(imgView)

        let urlLabel = NSTextField(labelWithString: u)
        urlLabel.font = NSFont.systemFont(ofSize: 10); urlLabel.textColor = NSColor(white: 1, alpha: 0.35)
        urlLabel.lineBreakMode = .byTruncatingMiddle; urlLabel.alignment = .center
        urlLabel.frame = NSRect(x: 12, y: 12, width: panelW - 24, height: 28)
        container.addSubview(urlLabel)

        qrPanel.contentView = container

        // Position below the QR glyph
        let glyphFrame = panel.contentView!.convert(self.webView.superview!.frame, to: nil)
        let screenPt = panel.convertPoint(toScreen: NSPoint(x: panel.frame.width - 80, y: glyphFrame.maxY - C.toolbarH - 4))
        qrPanel.setFrameTopLeftPoint(NSPoint(x: screenPt.x - panelW / 2, y: screenPt.y))
        qrPanel.makeKeyAndOrderFront(nil)

        // Close on click outside or Escape
        var monitor: Any?
        monitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown, .keyDown]) { event in
            if event.type == .keyDown && event.keyCode == 53 { // Escape
                qrPanel.orderOut(nil); if let m = monitor { NSEvent.removeMonitor(m) }; return nil
            }
            if event.window !== qrPanel { qrPanel.orderOut(nil); if let m = monitor { NSEvent.removeMonitor(m) } }
            return event
        }
    }

    @objc func showSpacesMenu(_ sender: NSClickGestureRecognizer) {
        guard let v = sender.view, let browser = ctrl?.selectedBrowser else { return }
        let menu = NSMenu()
        // Show spaces for Chromium browsers with localState
        if browser.isChromium, let ls = browser.localState, FileManager.default.fileExists(atPath: ls) {
            let spaces = discoverSpaces(for: browser)
            for sp in spaces {
                let i = NSMenuItem(title: sp.name, action: #selector(openInSpace(_:)), keyEquivalent: "")
                i.target = self; i.representedObject = sp.profileDir; menu.addItem(i)
            }
            if !spaces.isEmpty { menu.addItem(NSMenuItem.separator()) }
        }
        // Private/incognito option
        if !browser.incognito.isEmpty {
            let label: String
            if browser.id == "com.apple.Safari" { label = "Private Window" }
            else if browser.id == "org.mozilla.firefox" { label = "Private Window" }
            else { label = "incognito" }
            let ic = NSMenuItem(title: label, action: #selector(openIncognito), keyEquivalent: "")
            ic.target = self; menu.addItem(ic)
        }
        menu.popUp(positioning: nil, at: NSPoint(x: 0, y: v.bounds.height + 4), in: v)
    }

    @objc func openInSpace(_ s: NSMenuItem) {
        guard let d = s.representedObject as? String, let u = webView.url else { return }
        ctrl?.openInBrowserSpace(u, dir: d); hide()
    }
    @objc func openIncognito() {
        guard let u = webView.url else { return }
        ctrl?.openInBrowserIncognito(u); hide()
    }

    // Copy URL with Dia-style URL bar feedback
    func copyCurrentURL() {
        guard let u = webView.url else { return }
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(u.absoluteString, forType: .string)
        let orig = urlField.stringValue
        let origColor = urlField.textColor
        urlField.stringValue = "Copied Current URL"
        urlField.textColor = NSColor(white: 1, alpha: 0.80)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            self?.urlField.stringValue = orig
            self?.urlField.textColor = origColor
        }
    }

    // NSTextFieldDelegate
    func control(_ c: NSControl, textView tv: NSTextView, doCommandBy sel: Selector) -> Bool {
        if sel == #selector(NSResponder.insertNewline(_:)) {
            let q = urlField.stringValue.trimmingCharacters(in: .whitespaces)
            if !q.isEmpty {
                webView.load(URLRequest(url: ctrl?.toURL(q) ?? URL(string: "https://google.com")!))
                panel.makeFirstResponder(webView)
            }
            return true
        }
        if sel == #selector(NSResponder.cancelOperation(_:)) {
            panel.makeFirstResponder(webView)
            if let u = webView.url { urlField.stringValue = fmtURL(u) }
            urlField.textColor = NSColor(white: 1, alpha: 0.45)
            return true
        }
        if sel == #selector(NSResponder.insertTab(_:)) { panel.makeFirstResponder(webView); return true }
        return false
    }

    func controlTextDidEndEditing(_ n: Notification) {
        if let u = webView.url { urlField.stringValue = fmtURL(u) }
        urlField.textColor = NSColor(white: 1, alpha: 0.45)
    }

    // WKScriptMessageHandler
    func userContentController(_ uc: WKUserContentController, didReceive m: WKScriptMessage) {
        guard let b = m.body as? [String: Any], let a = b["action"] as? String else { return }
        DispatchQueue.main.async { [weak self] in
            guard let s = self else { return }
            switch a {
            case "close": s.hide()
            case "transfer": s.transferAction()
            case "focusUrl": s.panel.makeFirstResponder(s.urlField)
            case "copyUrl": s.copyCurrentURL()
            case "print": s.webView.evaluateJavaScript("window.print()")
            case "readerMode": s.webView.evaluateJavaScript(readerModeJS)
            case "toggleDark": s.toggleDarkMode()
            case "addReadingList":
                if let u = s.webView.url { addToReadingList(url: u.absoluteString, title: s.webView.title ?? ""); s.showBriefCue("Added to Reading List") }
            default: break
            }
        }
    }

    // WKNavigationDelegate - Chrome UA only for Google domains (fixes Cloudflare blocks)
    func webView(_ w: WKWebView, decidePolicyFor a: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        // Set Chrome UA for Google domains only, on main frame navigations only
        if a.targetFrame?.isMainFrame == true {
            if let host = a.request.url?.host, host.contains("google") {
                w.customUserAgent = C.chromeUA
            } else {
                w.customUserAgent = nil  // Use default WebKit UA - matches TLS fingerprint
            }
        }
        decisionHandler(.allow)
    }

    func webView(_ w: WKWebView, didFinish n: WKNavigation!) {
        startAutoCloseTimer()
        let isGoogle = w.url?.host?.contains("google") == true
        let hostExcluded = w.url?.host.map { drExcludedHosts.contains($0) } ?? false
        // Sync Google's built-in dark/light theme with DR state
        if isGoogle {
            if darkReaderActive {
                w.evaluateJavaScript("document.documentElement.setAttribute('dark','true');document.documentElement.style.colorScheme='dark'")
            } else {
                w.evaluateJavaScript("document.documentElement.removeAttribute('dark');document.documentElement.style.colorScheme='light'")
            }
        }
        // Re-apply Dark Reader if active - skip Google and excluded hosts
        if darkReaderActive && !isGoogle && !hostExcluded {
            w.evaluateJavaScript(darkReaderApplyJS)
        }
        if let title = w.title, !title.isEmpty { panel.title = title }
        if let url = w.url, let title = w.title, !title.isEmpty,
           let paths = ctrl?.selectedBrowser?.histPaths, !paths.isEmpty {
            addToSelectedBrowserHistory(url.absoluteString, title, paths)
        }
    }

    // Handle target="_blank" and popups
    func webView(_ w: WKWebView, createWebViewWith c: WKWebViewConfiguration, for a: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if a.targetFrame == nil { w.load(a.request) }
        return nil
    }

    func windowDidMove(_ n: Notification) { ctrl?.updateOmniPosFromBrowser(panel.frame) }
    func windowDidEndLiveResize(_ n: Notification) {
        ctrl?.saveBrowserFrame(panel.frame)
        ctrl?.updateOmniPosFromBrowser(panel.frame)
    }

    // NSToolbarDelegate - single flexible space to extend titlebar
    func toolbar(_ toolbar: NSToolbar, itemForItemIdentifier id: NSToolbarItem.Identifier, willBeInsertedIntoToolbar flag: Bool) -> NSToolbarItem? {
        return NSToolbarItem(itemIdentifier: .flexibleSpace)
    }
    func toolbarDefaultItemIdentifiers(_ toolbar: NSToolbar) -> [NSToolbarItem.Identifier] { [.flexibleSpace] }
    func toolbarAllowedItemIdentifiers(_ toolbar: NSToolbar) -> [NSToolbarItem.Identifier] { [.flexibleSpace] }
}

// ═══════════════════════════════════════════════════════
//  MARK: - Omni Message Handler
// ═══════════════════════════════════════════════════════

class OmniMH: NSObject, WKScriptMessageHandler {
    weak var ctrl: Ctrl?
    func userContentController(_ uc: WKUserContentController, didReceive m: WKScriptMessage) {
        guard let b = m.body as? [String: Any], let a = b["action"] as? String else { return }
        DispatchQueue.main.async { [weak self] in
            guard let c = self?.ctrl else { return }
            switch a {
            case "drag": if let dx = b["dx"] as? CGFloat, let dy = b["dy"] as? CGFloat { c.dragOmni(dx: dx, dy: dy) }
            case "savePos": c.saveOmniPos()
            case "suggest": if let q = b["query"] as? String { c.omniSuggest(q) }
            case "navigate": if let q = b["query"] as? String { c.omniNavigate(q) }
            case "openInBrowser": if let q = b["query"] as? String { c.omniOpenInBrowser(q) }
            case "close": c.hideOmni()
            default: break
            }
        }
    }
}

// ═══════════════════════════════════════════════════════
//  MARK: - Controller
// ═══════════════════════════════════════════════════════

class Ctrl: NSObject, NSWindowDelegate {
    var omniPanel: KeyPanel!; var omniWV: WKWebView!
    var browserWindows: [BrowserWin] = []
    var mouseMonitor: Any?; var isDisabled = false
    var selectedBrowser: BrowserProfile?
    private let omniMH = OmniMH()
    private let defs = UserDefaults.standard

    override init() {
        super.init(); omniMH.ctrl = self
        isDisabled = defs.bool(forKey: C.disabledKey)
        if let id = defs.string(forKey: C.browserKey), let b = browserById(id) { selectedBrowser = b }
        else if let dia = browserById("so.dia.Dia"), dia.isInstalled {
            selectedBrowser = dia; defs.set(dia.id, forKey: C.browserKey)
        } else { selectedBrowser = installedBrowsers().first }
        setupOmni(); setupMouseButtons()
    }

    func selectBrowser(_ b: BrowserProfile) {
        selectedBrowser = b; defs.set(b.id, forKey: C.browserKey)
        for bw in browserWindows where bw.panel.isVisible { bw.updateOpenLabel() }
    }

    private func setupOmni() {
        let cfg = WKWebViewConfiguration()
        let uc = WKUserContentController()
        uc.add(omniMH, name: "omni")
        cfg.userContentController = uc
        omniWV = WKWebView(frame: .zero, configuration: cfg)
        omniWV.setValue(false, forKey: "drawsBackground")
        let clip = NSView(frame: NSRect(x: 0, y: 0, width: 100, height: 100))
        clip.wantsLayer = true; clip.layer?.cornerRadius = 12; clip.layer?.masksToBounds = true
        clip.autoresizingMask = [.width, .height]
        omniWV.frame = clip.bounds; omniWV.autoresizingMask = [.width, .height]; clip.addSubview(omniWV)
        omniPanel = KeyPanel(contentRect: .zero, styleMask: [.borderless, .resizable], backing: .buffered, defer: false)
        omniPanel.isFloatingPanel = false; omniPanel.level = .normal; omniPanel.hasShadow = true
        omniPanel.isOpaque = false; omniPanel.backgroundColor = .clear
        omniPanel.isMovableByWindowBackground = false; omniPanel.contentView = clip
        omniPanel.hidesOnDeactivate = false
        omniPanel.collectionBehavior = [.fullScreenAuxiliary]
        omniPanel.delegate = self
    }

    func windowDidResignKey(_ n: Notification) {
        if let w = n.object as? NSPanel, w === omniPanel { hideOmni() }
    }

    private func setupMouseButtons() {
        mouseMonitor = NSEvent.addLocalMonitorForEvents(matching: NSEvent.EventTypeMask.otherMouseUp) { [weak self] (event: NSEvent) -> NSEvent? in
            guard let self = self else { return event }
            for bw in self.browserWindows.reversed() where bw.panel.isVisible && bw.panel.isKeyWindow {
                if event.buttonNumber == 3 { if bw.webView.canGoBack { bw.webView.goBack(); return nil } }
                else if event.buttonNumber == 4 { if bw.webView.canGoForward { bw.webView.goForward(); return nil } }
            }
            return event
        }
    }

    func cleanupWindows() { browserWindows.removeAll { !$0.panel.isVisible } }
    func saveBrowserFrame(_ f: NSRect) { defs.set(["x": f.origin.x, "y": f.origin.y, "w": f.width, "h": f.height], forKey: C.bfKey) }
    func saveOmniPos() { let f = omniPanel.frame; defs.set(["cx": f.midX, "cy": f.midY], forKey: C.opKey) }
    func updateOmniPosFromBrowser(_ f: NSRect) { defs.set(["cx": f.midX, "cy": f.midY], forKey: C.opKey) }

    func loadBF() -> NSRect {
        if let d = defs.dictionary(forKey: C.bfKey),
           let x = d["x"] as? CGFloat, let y = d["y"] as? CGFloat,
           let w = d["w"] as? CGFloat, let h = d["h"] as? CGFloat {
            return NSRect(x: x, y: y, width: w, height: h)
        }
        return NSRect(x: 200, y: 100, width: C.defBW, height: C.defBH)
    }

    func omniFrame() -> NSRect {
        let scr = screenWithMouse()
        if let d = defs.dictionary(forKey: C.opKey),
           let cx = d["cx"] as? CGFloat, let cy = d["cy"] as? CGFloat {
            return clamp(NSRect(x: cx - C.omniW / 2, y: cy - C.omniH / 2, width: C.omniW, height: C.omniH), to: scr)
        }
        let v = scr.visibleFrame
        return NSRect(x: v.midX - C.omniW / 2, y: v.midY - C.omniH / 2, width: C.omniW, height: C.omniH)
    }

    func screenWithMouse() -> NSScreen {
        let l = NSEvent.mouseLocation
        return NSScreen.screens.first { $0.frame.contains(l) } ?? NSScreen.main ?? NSScreen.screens[0]
    }

    func clamp(_ f: NSRect, to scr: NSScreen) -> NSRect {
        let v = scr.visibleFrame; var r = f
        if r.maxX > v.maxX { r.origin.x = v.maxX - r.width }
        if r.minX < v.minX { r.origin.x = v.minX }
        if r.maxY > v.maxY { r.origin.y = v.maxY - r.height }
        if r.minY < v.minY { r.origin.y = v.minY }
        return r
    }

    func showOmni() {
        guard !isDisabled else { return }
        omniPanel.setFrame(omniFrame(), display: false)
        omniWV.loadHTMLString(omniHTML, baseURL: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { [weak self] in
            self?.omniPanel.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
        }
        let push: ([HistEntry]) -> Void = { [weak self] h in
            guard let self = self, self.omniPanel.isVisible else { return }
            let arr = h.map { ["url": $0.url, "title": $0.title] }
            if let d = try? JSONSerialization.data(withJSONObject: arr),
               let s = String(data: d, encoding: .utf8) {
                self.omniWV.evaluateJavaScript("if(window.setHistory)setHistory(\(s))")
            }
        }
        if histLoaded {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { push(cachedHist) }
            refreshHistory { push($0) }
        } else { refreshHistory { push($0) } }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
            self?.omniPanel.makeFirstResponder(self?.omniWV)
            self?.omniWV.evaluateJavaScript("if(window.focusInput)focusInput()")
        }
        // Clipboard URL detection
        if let clip = NSPasteboard.general.string(forType: .string), let cu = URL(string: clip),
           (cu.scheme == "http" || cu.scheme == "https") {
            let safe = clip.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "'", with: "\\'").replacingOccurrences(of: "\n", with: "")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { [weak self] in
                self?.omniWV.evaluateJavaScript("if(window.setClipboardURL)setClipboardURL('\(safe)')")
            }
        }
    }

    func hideOmni() { saveOmniPos(); omniPanel.orderOut(nil) }
    func dragOmni(dx: CGFloat, dy: CGFloat) {
        var f = omniPanel.frame; f.origin.x += dx; f.origin.y -= dy; omniPanel.setFrame(f, display: true)
    }
    func omniSuggest(_ q: String) {
        fetchSugg(q) { [weak self] s in
            if let d = try? JSONSerialization.data(withJSONObject: s),
               let js = String(data: d, encoding: .utf8) {
                self?.omniWV.evaluateJavaScript("if(window.receiveSuggestions)receiveSuggestions(\(js))")
            }
        }
    }
    func omniNavigate(_ query: String) {
        guard !query.isEmpty else { return }; saveOmniPos(); hideOmni(); cleanupWindows()
        let scr = screenWithMouse(); let of = omniPanel.frame; let bf = loadBF()
        let nf = clamp(NSRect(x: of.midX - bf.width / 2, y: of.midY - bf.height / 2, width: bf.width, height: bf.height), to: scr)
        let bw = BrowserWin(frame: nf, ctrl: self); browserWindows.append(bw); bw.load(toURL(query))
    }
    func omniOpenInBrowser(_ q: String) {
        guard !q.isEmpty else { return }; openInBrowser(toURL(q)); hideOmni()
    }
    func toggle() { if omniPanel.isVisible { hideOmni() } else { showOmni() } }

    func openURLInNewWindow(_ url: URL) {
        guard !isDisabled else { openInBrowser(url); return }
        cleanupWindows()
        let scr = screenWithMouse(); let bf = loadBF(); let v = scr.visibleFrame
        let nf = clamp(NSRect(x: v.midX - bf.width / 2, y: v.midY - bf.height / 2, width: bf.width, height: bf.height), to: scr)
        let bw = BrowserWin(frame: nf, ctrl: self); browserWindows.append(bw); bw.load(url)
    }

    // Browser launch
    func openInBrowser(_ url: URL) {
        guard let b = selectedBrowser else { return }
        let s = url.absoluteString.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"")
        if b.id == "com.apple.Safari" {
            NSAppleScript(source: "tell application \"Safari\" to open location \"\(s)\"")?.executeAndReturnError(nil)
        } else {
            NSAppleScript(source: "tell application \"\(b.name)\" to open location \"\(s)\"")?.executeAndReturnError(nil)
        }
    }
    func openInBrowserSpace(_ url: URL, dir: String) {
        guard let b = selectedBrowser else { return }
        let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/open")
        p.arguments = ["-a", b.name, url.absoluteString, "--args", "--profile-directory=\(dir)"]
        try? p.run()
    }
    func openInBrowserIncognito(_ url: URL) {
        guard let b = selectedBrowser, !b.incognito.isEmpty else { return }
        if b.id == "com.apple.Safari" {
            // Safari private window via AppleScript
            let s = url.absoluteString.replacingOccurrences(of: "\"", with: "\\\"")
            NSAppleScript(source: """
            tell application "Safari"
                activate
                tell window 1
                    set current tab to (make new tab with properties {URL:"\(s)"})
                end tell
            end tell
            """)?.executeAndReturnError(nil)
            // Fallback: open URL and let user use File > New Private Window
            let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/open")
            p.arguments = ["-a", "Safari", url.absoluteString]; try? p.run()
        } else if b.id == "org.mozilla.firefox" {
            let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/open")
            p.arguments = ["-a", "Firefox", "--args", "-private-window", url.absoluteString]; try? p.run()
        } else {
            // Chromium browsers
            let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/open")
            p.arguments = ["-na", b.name, "--args", b.incognito, url.absoluteString]; try? p.run()
        }
    }
    func toURL(_ q: String) -> URL {
        if q.hasPrefix("http://") || q.hasPrefix("https://") { return URL(string: q) ?? gURL(q) }
        if q.contains(".") && !q.contains(" ") { return URL(string: "https://\(q)") ?? gURL(q) }
        return gURL(q)
    }
    private func gURL(_ q: String) -> URL {
        URL(string: "https://www.google.com/search?q=\(q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? q)")!
    }
}

// ═══════════════════════════════════════════════════════

private func _ck() -> Bool {
    let d = UserDefaults.standard
    if d.object(forKey: "ld.eeInstalled") as? Bool == false { return false }
    if d.object(forKey: "ld.ee") == nil { return true }
    return d.bool(forKey: "ld.ee")
}
private var _sc = 0
func _bv() { _sc += 1; let b = UserDefaults.standard.integer(forKey: "ld.max"); if _sc > b { UserDefaults.standard.set(_sc, forKey: "ld.max") } }
func _ds() -> Int { max(_sc, UserDefaults.standard.integer(forKey: "ld.max")) }

private let _p: [String] = {
    let r: [[UInt32]] = [
        [84,105,109,101,32,102,111,114,32,115,111,109,101,32,119,97,116,101,114,32,127754],
        [72,101,121,32,104,97,110,100,115,111,109,101,32,129766],
        [84,97,107,101,32,99,97,114,101,32,111,102,32,121,111,117,114,115,101,108,102,32,127793],
        [68,111,110,39,116,32,102,111,114,103,101,116,32,116,111,32,115,116,114,101,116,99,104,32,129336,8205,9792,65039],
        [71,114,101,97,116,32,128077],
        [76,105,116,116,108,101,32,68,105,97,32,108,111,118,101,115,32,121,111,117,32,128156],
        [68,101,101,112,32,98,114,101,97,116,104,32,105,110,32,127788,65039],
        [83,110,97,99,107,32,98,114,101,97,107,63,32,127850],
        [89,111,117,39,118,101,32,103,111,116,32,116,104,105,115,32,128170],
        [66,101,32,107,105,110,100,32,116,111,32,121,111,117,114,115,101,108,102,32,116,111,100,97,121,32,128155],
        [79,110,101,32,115,116,101,112,32,97,116,32,97,32,116,105,109,101,32,128062],
        [82,101,115,116,32,105,115,32,112,114,111,100,117,99,116,105,118,101,32,116,111,111,32,128715,65039],
        [80,111,115,116,117,114,101,32,99,104,101,99,107,32,129496],
        [66,108,105,110,107,33,32,128064],
        [67,101,108,101,98,114,97,116,101,32,115,109,97,108,108,32,119,105,110,115,32,127881],
        [71,111,32,111,117,116,115,105,100,101,32,102,111,114,32,97,32,109,105,110,117,116,101,32,9728,65039],
    ]
    return r.map { $0.compactMap { UnicodeScalar($0).map { String($0) } }.joined() }
}()
private var _rc: [Int] = []
func _nq() -> String {
    let k = max(1, Int(Double(_p.count) * 0.75))
    var i: Int
    repeat { i = Int.random(in: 0..<_p.count) } while _rc.contains(i)
    _rc.append(i); if _rc.count > k { _rc.removeFirst() }
    return _p[i]
}

// ═══════════════════════════════════════════════════════
//  MARK: - App Delegate
// ═══════════════════════════════════════════════════════

class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    var ctrl: Ctrl!; var escMonitor: Any?; var statusItem: NSStatusItem!

    func menuNeedsUpdate(_ menu: NSMenu) { populateMenu(menu) }

    func applicationDidFinishLaunching(_ n: Notification) {
        NSApp.setActivationPolicy(.accessory); setupMainMenu()
        compileAdBlock(); refreshHistory { _ in }; ctrl = Ctrl()
        registerGlobalHotkey { [weak self] in self?.ctrl.toggle() }
        DistributedNotificationCenter.default().addObserver(self, selector: #selector(handleNote),
            name: NSNotification.Name(C.note), object: nil)
        escMonitor = NSEvent.addLocalMonitorForEvents(matching: NSEvent.EventTypeMask.keyDown) { [weak self] (event: NSEvent) -> NSEvent? in
            guard let self = self else { return event }
            if event.keyCode == 53 {
                if self.ctrl.omniPanel.isVisible { self.ctrl.hideOmni(); return nil }
                for bw in self.ctrl.browserWindows.reversed() where bw.panel.isVisible && bw.panel.isKeyWindow {
                    bw.hide(); return nil
                }
            }
            return event
        }
        setupMenuBar()
        if CommandLine.arguments.contains("--toggle") { ctrl.toggle() }
    }

    func setupMainMenu() {
        let m = NSMenu()
        let am = NSMenu()
        am.addItem(NSMenuItem(title: "Quit Little Dia", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"))
        let ai = NSMenuItem(); ai.submenu = am; m.addItem(ai)
        let em = NSMenu(title: "Edit")
        em.addItem(NSMenuItem(title: "Undo", action: Selector(("undo:")), keyEquivalent: "z"))
        em.addItem(NSMenuItem(title: "Redo", action: Selector(("redo:")), keyEquivalent: "Z"))
        em.addItem(NSMenuItem.separator())
        em.addItem(NSMenuItem(title: "Cut", action: #selector(NSText.cut(_:)), keyEquivalent: "x"))
        em.addItem(NSMenuItem(title: "Copy", action: #selector(NSText.copy(_:)), keyEquivalent: "c"))
        em.addItem(NSMenuItem(title: "Paste", action: #selector(NSText.paste(_:)), keyEquivalent: "v"))
        em.addItem(NSMenuItem(title: "Select All", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a"))
        let ei = NSMenuItem(); ei.submenu = em; m.addItem(ei)
        NSApp.mainMenu = m
    }

    func setupMenuBar() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        updateMenuBarIcon()
        let menu = NSMenu(); menu.delegate = self; populateMenu(menu); statusItem.menu = menu
    }

    func updateMenuBarIcon() {
        guard let btn = statusItem.button else { return }
        let isDefault = isLittleDiaDefault()
        let ee = _ck()
        let base = ee ? (isDefault ? "hand.pinch.fill" : "hand.pinch") : (isDefault ? "diamond.fill" : "diamond")
        if ctrl.isDisabled {
            let config = NSImage.SymbolConfiguration(paletteColors: [.systemRed])
            btn.image = NSImage(systemSymbolName: base, accessibilityDescription: "Little Dia")?.withSymbolConfiguration(config)
            btn.image?.isTemplate = false
        } else {
            btn.image = NSImage(systemSymbolName: base, accessibilityDescription: "Little Dia")
            btn.image?.isTemplate = true
        }
    }

    func populateMenu(_ menu: NSMenu) {
        menu.removeAllItems()
        let isDefault = isLittleDiaDefault()

        if isDefault {
            let txt = _ck() ? "Little Dia is your default browser \u{1F44D}" : "Little Dia is your default browser"
            let i = NSMenuItem(title: txt, action: nil, keyEquivalent: "")
            i.isEnabled = false; menu.addItem(i)
            // Affirmation only when default
            if _ck() {
                let q = NSMenuItem(title: _nq(), action: #selector(_qc), keyEquivalent: "")
                q.target = self; menu.addItem(q)
            }
        } else {
            let i = NSMenuItem(title: "Set as Default Browser", action: #selector(setAsDefault), keyEquivalent: "")
            i.target = self; menu.addItem(i)
        }
        menu.addItem(NSMenuItem.separator())

        // Open in... submenu
        let browsers = installedBrowsers()
        if !browsers.isEmpty {
            let sub = NSMenu()
            for b in browsers {
                let i = NSMenuItem(title: b.name, action: #selector(selectBrowserItem(_:)), keyEquivalent: "")
                i.target = self; i.representedObject = b.id
                if b.id.lowercased() == ctrl.selectedBrowser?.id.lowercased() { i.state = .on }
                sub.addItem(i)
            }
            let bi = NSMenuItem(title: "Open in...", action: nil, keyEquivalent: "")
            bi.submenu = sub; menu.addItem(bi)
        }

        menu.addItem(NSMenuItem.separator())
        let di = NSMenuItem(title: "Little Dia enabled", action: #selector(toggleDisabled), keyEquivalent: "")
        di.target = self; di.state = ctrl.isDisabled ? .off : .on; menu.addItem(di)

        if UserDefaults.standard.object(forKey: "ld.eeInstalled") as? Bool == true {
            let ee = NSMenuItem(title: "Easter eggs enabled", action: #selector(toggleEasterEggs), keyEquivalent: "")
            ee.target = self; ee.state = _ck() ? .on : .off; menu.addItem(ee)
        }

        // Reading list
        let rlItems = loadReadingList()
        if !rlItems.isEmpty {
            let rlSub = NSMenu()
            for item in rlItems.prefix(15) {
                let i = NSMenuItem(title: item.title.prefix(40) + (item.title.count > 40 ? "..." : ""),
                                   action: #selector(openReadingListItem(_:)), keyEquivalent: "")
                i.target = self; i.representedObject = item.url; rlSub.addItem(i)
            }
            rlSub.addItem(NSMenuItem.separator())
            let clear = NSMenuItem(title: "Clear Reading List", action: #selector(clearReadingList), keyEquivalent: "")
            clear.target = self; rlSub.addItem(clear)
            let rl = NSMenuItem(title: "Reading List", action: nil, keyEquivalent: "")
            rl.submenu = rlSub; menu.addItem(rl)
        }

        menu.addItem(NSMenuItem.separator())
        let scripts = NSMenuItem(title: "Show user scripts folder", action: #selector(revealUserScriptsFolder), keyEquivalent: "")
        scripts.target = self; menu.addItem(scripts)
        menu.addItem(NSMenuItem.separator())
        let ab = NSMenuItem(title: "About Little Dia", action: #selector(showAbout), keyEquivalent: "")
        ab.target = self; menu.addItem(ab)
        menu.addItem(NSMenuItem(title: "Quit Little Dia", action: #selector(quitApp), keyEquivalent: "q"))
    }

    /// Reveal ~/.little-dia/scripts/ in Finder. The folder is auto-created
    /// on first install but never surfaced anywhere - so without a menu
    /// entry users would need to know that .js files dropped there get
    /// injected into every page. Creates the folder lazily if missing.
    @objc func revealUserScriptsFolder() {
        let home = FileManager.default.homeDirectoryForCurrentUser
        let dir = home.appendingPathComponent(".little-dia/scripts", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        NSWorkspace.shared.open(dir)
    }

    func isLittleDiaDefault() -> Bool {
        guard let u = NSWorkspace.shared.urlForApplication(toOpen: URL(string: "https://example.com")!),
              let id = Bundle(url: u)?.bundleIdentifier else { return false }
        return id.lowercased() == C.bundleId
    }

    @objc func setAsDefault() {
        LSSetDefaultHandlerForURLScheme("http" as CFString, C.bundleId as CFString)
        LSSetDefaultHandlerForURLScheme("https" as CFString, C.bundleId as CFString)
        updateMenuBarIcon()
    }
    @objc func _qc() { _bv() }
    @objc func selectBrowserItem(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? String, let b = browserById(id) else { return }
        ctrl.selectBrowser(b)
    }
    @objc func toggleDisabled() {
        ctrl.isDisabled.toggle()
        UserDefaults.standard.set(ctrl.isDisabled, forKey: C.disabledKey)
        updateMenuBarIcon()
    }
    @objc func toggleEasterEggs() {
        UserDefaults.standard.set(!_ck(), forKey: "ld.ee")
        updateMenuBarIcon()
    }
    @objc func showAbout() {
        let alert = NSAlert(); alert.messageText = "Little Dia"
        let ee = _ck()
        alert.icon = NSImage(systemSymbolName: ee ? "hand.pinch.fill" : "diamond.fill", accessibilityDescription: nil)
        let score = _ds()
        var text = "Version 1.0.0 (beta)\n\n"
        text += "A floating search and browser window,\ninspired by Arc Browser's Little Arc.\n\n"
        if ee {
            text += "Built with Swift, AppKit, WebKit, and love.\n\n"
            text += "Developed in constant dialogue with Claude (Anthropic).\n\n"
        } else {
            text += "Built with Swift, AppKit, and WebKit.\n\n"
            text += "Developed with assistance from Claude by Anthropic.\n\n"
        }
        if ee && score > 0 { text += "\(String([72,105,103,104,32,115,99,111,114,101].map{Character(UnicodeScalar($0))})): \(score)\n\n" }
        text += "Licensed under the MIT License\n"
        text += "\u{00A9} 2026 mord58562\n\n"
        text += "Dark mode uses techniques from Dark Reader\n"
        text += "(darkreader.org, MIT License).\n"
        text += "Copyright \u{00A9} Dark Reader contributors.\n\n"
        text += "PROVIDED AS-IS, WITHOUT WARRANTY OF ANY KIND."
        alert.informativeText = text
        alert.alertStyle = .informational; alert.addButton(withTitle: "OK")
        NSApp.activate(ignoringOtherApps: true); alert.runModal()
    }
    @objc func openReadingListItem(_ sender: NSMenuItem) {
        guard let url = sender.representedObject as? String else { return }
        removeFromReadingList(url: url)
        ctrl.openURLInNewWindow(URL(string: url)!)
    }
    @objc func clearReadingList() {
        try? FileManager.default.removeItem(atPath: readingListFile)
    }
    @objc func quitApp() { NSApp.terminate(nil) }
    @objc func handleNote(_ n: Notification) { ctrl.toggle() }
    func applicationShouldTerminateAfterLastWindowClosed(_ s: NSApplication) -> Bool { false }
    func applicationWillTerminate(_ n: Notification) {
        if isLittleDiaDefault() {
            let id = ctrl.selectedBrowser?.id ?? "so.dia.Dia"
            LSSetDefaultHandlerForURLScheme("http" as CFString, id as CFString)
            LSSetDefaultHandlerForURLScheme("https" as CFString, id as CFString)
        }
    }
    func application(_ application: NSApplication, open urls: [URL]) {
        for url in urls where url.scheme == "http" || url.scheme == "https" {
            ctrl.openURLInNewWindow(url)
        }
    }
}

// ═══════════════════════════════════════════════════════
//  MARK: - Main
// ═══════════════════════════════════════════════════════

let lockPath = "/tmp/littledia.lock"
let myPID = ProcessInfo.processInfo.processIdentifier
if let d = try? String(contentsOfFile: lockPath, encoding: .utf8),
   let pid = Int32(d.trimmingCharacters(in: .whitespacesAndNewlines)),
   pid != myPID, kill(pid, 0) == 0 {
    DistributedNotificationCenter.default().post(name: NSNotification.Name(C.note), object: nil)
    exit(0)
}
try? "\(myPID)".write(toFile: lockPath, atomically: true, encoding: .utf8)
// Restrict lock file permissions to owner only
chmod(lockPath, 0o600)
atexit { try? FileManager.default.removeItem(atPath: lockPath) }
let app = NSApplication.shared; let del = AppDelegate(); app.delegate = del; app.run()
