#!/bin/bash
# Little Dia setup - Licensed under the MIT License
INSTALL_DIR="$HOME/.little-dia"; SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo ""
printf '  \033[1;97m--- Little Dia ---\033[0m\n'
echo ""
pkill -f "LittleDia.app" 2>/dev/null||true;pkill -f "LittleDia$" 2>/dev/null||true;rm -f /tmp/littledia.lock;sleep 0.3
if ! xcode-select -p &>/dev/null;then echo "  Xcode CLI tools needed.";xcode-select --install;exit 1;fi;echo "  ✓ Xcode CLI tools"
echo "  → Compiling...";mkdir -p "$INSTALL_DIR" "$INSTALL_DIR/scripts"
if ! swiftc -O -framework Cocoa -framework WebKit -framework Carbon -target arm64-apple-macos11.0 "$SCRIPT_DIR/LittleDia.swift" -o "$INSTALL_DIR/LittleDia" 2>/tmp/ld_c.log;then
if ! swiftc -O -framework Cocoa -framework WebKit -framework Carbon "$SCRIPT_DIR/LittleDia.swift" -o "$INSTALL_DIR/LittleDia" 2>/tmp/ld_c.log;then cat /tmp/ld_c.log;echo "  ✗ Failed";exit 1;fi;fi
chmod +x "$INSTALL_DIR/LittleDia";echo "  ✓ Compiled"
APP="$INSTALL_DIR/LittleDia.app";rm -rf "$APP";mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$INSTALL_DIR/LittleDia" "$APP/Contents/MacOS/LittleDia"
cat > "$APP/Contents/Info.plist" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>com.littledia.app</string>
<key>CFBundleName</key><string>Little Dia</string>
<key>CFBundleExecutable</key><string>LittleDia</string>
<key>CFBundleVersion</key><string>1.0.0</string>
<key>CFBundleShortVersionString</key><string>1.0.0</string>
<key>LSUIElement</key><true/>
<key>LSMinimumSystemVersion</key><string>11.0</string>
<key>NSAppTransportSecurity</key><dict><key>NSAllowsArbitraryLoads</key><true/></dict>
<key>CFBundleURLTypes</key><array><dict>
<key>CFBundleURLName</key><string>Web URL</string>
<key>CFBundleURLSchemes</key><array><string>http</string><string>https</string></array>
</dict></array></dict></plist>
PLIST
echo "  ✓ App bundle"
/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister -f "$APP" 2>/dev/null||true;echo "  ✓ Launch Services"
AGENT="$HOME/Library/LaunchAgents/com.littledia.app.plist";launchctl unload "$AGENT" 2>/dev/null||true
cat > "$AGENT" << AGENT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>Label</key><string>com.littledia.app</string>
<key>ProgramArguments</key><array><string>$APP/Contents/MacOS/LittleDia</string></array>
<key>RunAtLoad</key><true/><key>KeepAlive</key><false/></dict></plist>
AGENT
launchctl load "$AGENT" 2>/dev/null||true;echo "  ✓ LaunchAgent"
defaults delete com.littledia.app ld.max 2>/dev/null||true
defaults write com.littledia.app ld.darkMode -bool true
[ -f "$SCRIPT_DIR/LittleDia.command" ] && chmod +x "$SCRIPT_DIR/LittleDia.command" && xattr -dr com.apple.quarantine "$SCRIPT_DIR/LittleDia.command" 2>/dev/null||true

echo "";echo "  ─── Browser Detection ───"
BROWSERS=()
detect(){ local found="";found=$(mdfind "kMDItemCFBundleIdentifier == '$1'" 2>/dev/null|head -1)
[ -z "$found" ]&&{ [ -d "/Applications/$3.app" ]||[ -d "$HOME/Applications/$3.app" ];}&&found="y"
[ -n "$found" ]&&BROWSERS+=("$2|$1");return 0;}
detect "so.dia.Dia" "Dia" "Dia"
detect "company.thebrowser.Browser" "Arc" "Arc"
detect "com.apple.Safari" "Safari" "Safari"
detect "com.google.Chrome" "Chrome" "Google Chrome"
detect "com.brave.Browser" "Brave" "Brave Browser"
detect "com.operasoftware.Opera" "Opera" "Opera"
detect "com.microsoft.edgemac" "Edge" "Microsoft Edge"
detect "com.vivaldi.Vivaldi" "Vivaldi" "Vivaldi"
detect "org.mozilla.firefox" "Firefox" "Firefox"

if [ ${#BROWSERS[@]} -gt 0 ];then
    N="";for b in "${BROWSERS[@]}";do N="$N $(echo "$b"|cut -d'|' -f1)";done
    echo "  Found:$N"
    echo ""
    read -p "  Import history from all detected browsers? [Y/n] " REPLY
    if [[ "$REPLY" =~ ^[Nn]$ ]];then
        for b in "${BROWSERS[@]}";do
            BN=$(echo "$b"|cut -d'|' -f1)
            read -p "  Import from $BN? [Y/n] " R
        done
    fi
fi

echo ""
HAS_DIA=false;for b in "${BROWSERS[@]}";do [[ "$b" == Dia* ]]&&HAS_DIA=true;done
if $HAS_DIA;then
    read -p "  Use Dia for the 'Open in' button? [Y/n] " REPLY
    if [[ "$REPLY" =~ ^[Nn]$ ]];then
        echo "  Note: Little Dia is primarily designed for Dia."
        SORTED=();while IFS= read -r l;do SORTED+=("$l");done < <(printf '%s\n' "${BROWSERS[@]}"|sort -t'|' -k1)
        echo "  Available:";for i in "${!SORTED[@]}";do echo "    $((i+1)). $(echo "${SORTED[$i]}"|cut -d'|' -f1)";done
        read -p "  Select number: " NUM
        if [[ "$NUM" =~ ^[0-9]+$ ]]&&[ "$NUM" -ge 1 ]&&[ "$NUM" -le ${#SORTED[@]} ];then
            defaults write com.littledia.app ld.browser "$(echo "${SORTED[$((NUM-1))]}"|cut -d'|' -f2)"
            echo "  ✓ Set to $(echo "${SORTED[$((NUM-1))]}"|cut -d'|' -f1)"
        else defaults write com.littledia.app ld.browser "so.dia.Dia";echo "  ✓ Defaulting to Dia";fi
    else defaults write com.littledia.app ld.browser "so.dia.Dia";echo "  ✓ Set to Dia";fi
else
    echo "  Dia not found. Little Dia is primarily designed for Dia."
    if [ ${#BROWSERS[@]} -gt 0 ];then
        SORTED=();while IFS= read -r l;do SORTED+=("$l");done < <(printf '%s\n' "${BROWSERS[@]}"|sort -t'|' -k1)
        echo "  Available:";for i in "${!SORTED[@]}";do echo "    $((i+1)). $(echo "${SORTED[$i]}"|cut -d'|' -f1)";done
        read -p "  Select number: " NUM
        if [[ "$NUM" =~ ^[0-9]+$ ]]&&[ "$NUM" -ge 1 ]&&[ "$NUM" -le ${#SORTED[@]} ];then
            defaults write com.littledia.app ld.browser "$(echo "${SORTED[$((NUM-1))]}"|cut -d'|' -f2)"
            echo "  ✓ Set to $(echo "${SORTED[$((NUM-1))]}"|cut -d'|' -f1)"
        fi
    fi
fi

echo "";read -p "  Enable easter eggs? [Y/n] " R
if [[ "$R" =~ ^[Nn]$ ]];then defaults write com.littledia.app ld.eeInstalled -bool false;defaults write com.littledia.app ld.ee -bool false;echo "  ✓ Easter eggs disabled"
else defaults write com.littledia.app ld.eeInstalled -bool true;defaults write com.littledia.app ld.ee -bool true;echo "  ✓ Easter eggs enabled";fi
echo "";echo "  → Starting...";open -a "$APP";sleep 0.5
echo "";echo "  ✓ Setup complete!";echo "  Press ⌘E from any app to open Little Dia.";echo ""
