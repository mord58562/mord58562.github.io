#!/bin/bash
APP="$HOME/.little-dia/LittleDia.app"
LOCK="/tmp/littledia.lock"
if [ -f "$LOCK" ] && kill -0 "$(cat "$LOCK")" 2>/dev/null; then exit 0; fi
if [ -d "$APP" ]; then open -a "$APP"; else echo "Run setup.sh first."; fi
