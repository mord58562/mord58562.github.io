# Little Dia

A lightweight floating search and browser window for [Dia Browser](https://dia.so) and other browsers, inspired by Arc's "Little Arc". Compatible with Dia, Arc, Chrome, Brave, Edge, Vivaldi, Opera, Safari, and Firefox.

**Version 1.0.0 (beta)**

## Disclaimer

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## License

Copyright (c) 2026 mord58562 & Claude (Anthropic)

Released under the MIT License. See the [LICENSE](LICENSE) file for the full text.

Dark mode uses techniques from [Dark Reader](https://darkreader.org) (MIT License). Copyright Dark Reader contributors.

## Features

- Global ⌘E hotkey from any app
- Native AppKit window bar with auto page title
- Multi-browser history with frecency scoring
- Google autocomplete suggestions
- Clipboard URL detection
- History sync with selected browser
- Open in any installed browser with space/profile selection
- Private/incognito windows for all supported browsers
- Dark Reader with per-site toggle (right-click moon glyph)
- Google dark/light theme synced with Dark Reader state
- Imagus-style image hover enlarge
- Reading list (⌘⇧L to add, menu bar to access)
- Find in page, reader mode, QR code panel
- Copy URL with visual feedback (⌘⇧C)
- Auto-close timer (pauses when active)
- Userscript support (~/.little-dia/scripts/)

## Install

    cd ~/Downloads/"Little Dia"
    chmod +x setup.sh
    ./setup.sh

## Keyboard Shortcuts

    ⌘E            Toggle omnibar (global)
    ↑ / ↓         Navigate suggestions
    Return        Open in Little Dia
    ⌘Return       Open in selected browser
    Escape        Close window
    ⌘W            Close window
    ⌘O            Transfer to browser
    ⌘L / Tab      Focus URL bar
    ⌘F            Find in page
    ⌘P            Print
    ⌘⇧C           Copy current URL
    ⌘⇧R           Toggle reader mode
    ⌘⇧D           Toggle Dark Reader
    ⌘⇧L           Add to reading list
    ⌘A            Select all
    ⌘C / ⌘V      Copy / Paste
    ⌘X / ⌘Z      Cut / Undo

## Uninstall

    pkill -f LittleDia; rm -f /tmp/littledia.lock; rm -rf ~/.little-dia
    launchctl unload ~/Library/LaunchAgents/com.littledia.app.plist
    rm ~/Library/LaunchAgents/com.littledia.app.plist
